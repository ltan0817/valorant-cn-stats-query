# 调试与故障排查

## 最小检查顺序

```powershell
Test-NetConnection 127.0.0.1 -Port 8787
Test-NetConnection 127.0.0.1 -Port 9223
curl.exe -s -o NUL -w "%{http_code}`n" http://127.0.0.1:8787/public
curl.exe http://127.0.0.1:8787/api/wegame-session-status
```

先确认 8787，再确认专用 Chrome 9223，最后检查 WeGame 登录状态。不要通过反复
重装依赖来代替分层定位。

## 查询暂时不可用

1. 确认是 `start-local.cmd` 启动的专用 Chrome；
2. 打开专用 Chrome，确认 WeGame 页面仍然登录；
3. 关闭重复占用 9223 的旧 Chrome；
4. 重新运行 `code/launch-login-chrome.cmd`；
5. 等待状态接口恢复后再查询。

## 8787 无法启动

```powershell
Get-NetTCPConnection -LocalPort 8787 -ErrorAction SilentlyContinue
python .\code\wgame_query_server.py --port 8787
```

在前台运行可以看到 Python 异常。常见原因是依赖未安装、端口被占用或文件被安全
软件隔离。

## 当前对局没有数据

```powershell
Get-NetTCPConnection -LocalPort 8083 -State Listen -ErrorAction SilentlyContinue
Get-ChildItem .\code\captures -Filter "proxifier-game-*.jsonl"
```

确认 Proxifier 规则已经加载、mitmproxy 正在监听，并且抓包文件更新时间持续变化。
登录态 token 有时效，旧记录不能代表当前会话。

## 恢复网络

优先运行：

```powershell
.\code\stop-proxifier-capture.ps1
```

然后检查 Proxifier 已加载 Direct 配置。仍异常时完全退出并重新启动游戏相关进程。

## 修改代码

修改后至少执行：

```powershell
python -m compileall -q .\code
```

不要把 `data/`、`captures/`、浏览器 profile 或调试日志作为问题附件公开上传。
