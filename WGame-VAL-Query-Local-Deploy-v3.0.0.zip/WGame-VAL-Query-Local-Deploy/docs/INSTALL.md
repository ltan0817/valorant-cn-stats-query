# 安装与启动

## 1. 环境要求

- Windows 10/11
- Python 3.10 或更高版本
- Google Chrome
- WeGame 账号
- 可选：mitmproxy 10+、Proxifier

所有命令都在解压目录内执行，不要求固定盘符或固定 Windows 用户名。

## 2. 安装依赖

双击根目录的 `install-dependencies.cmd`，或手工执行：

```powershell
python -m pip install -r .\code\requirements.txt
```

## 3. 启动查询

双击 `start-local.cmd`。脚本只会：

1. 在本机 `127.0.0.1:8787` 启动 Python 服务；
2. 用独立 profile 启动 Chrome 调试端口 `127.0.0.1:9223`；
3. 打开本机查询页。

首次使用时，在专用 Chrome 中登录 WeGame，然后刷新：

```text
http://127.0.0.1:8787/public
```

停止服务可双击 `stop-local.cmd`。

## 4. 当前对局（可选）

安装 mitmproxy 和 Proxifier 后：

```powershell
Set-Location .\code
.\start-proxifier-capture.ps1
```

首次抓包前，mitmproxy 会在当前 Windows 用户目录生成本机 CA。确认文件来自本机
mitmproxy 后，可运行：

```powershell
.\install-local-certificate.ps1
```

结束抓包：

```powershell
.\stop-proxifier-capture.ps1
```

如果游戏网络异常，立即停止抓包、确认 Proxifier 已恢复 Direct 配置，并完全退出
后重新启动 WeGame、Riot Client 与游戏。

## 5. 局域网访问

发布包默认不开放局域网。若自行修改监听地址、防火墙或反向代理，即代表主动扩大
安全边界；需要同时配置访问控制、HTTPS、日志脱敏和密钥管理。
