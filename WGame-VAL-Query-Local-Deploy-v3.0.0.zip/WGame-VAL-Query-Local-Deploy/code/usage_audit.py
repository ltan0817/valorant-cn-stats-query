from __future__ import annotations

import ipaddress
import os
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


APP_DIR = Path(__file__).resolve().parent
DEFAULT_DB_PATH = APP_DIR / "data" / "usage_audit.sqlite3"


def audit_retention_days() -> int:
    try:
        value = int(os.environ.get("WGAME_AUDIT_RETENTION_DAYS", "180"))
    except ValueError:
        value = 180
    return max(1, min(value, 3650))


def _connect(db_path: Path = DEFAULT_DB_PATH) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(db_path, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("pragma journal_mode=WAL")
    db.execute("pragma synchronous=NORMAL")
    db.execute("pragma busy_timeout=10000")
    return db


@contextmanager
def _database(db_path: Path = DEFAULT_DB_PATH) -> Iterator[sqlite3.Connection]:
    db = _connect(db_path)
    try:
        with db:
            yield db
    finally:
        db.close()


def init_audit_db(db_path: Path = DEFAULT_DB_PATH) -> None:
    with _database(db_path) as db:
        db.execute(
            """
            create table if not exists audit_events (
                id integer primary key autoincrement,
                occurred_at integer not null,
                category text not null,
                action text not null,
                client_ip text not null default '',
                session_ip text not null default '',
                query_text text not null default '',
                account_display text not null default '',
                account_subject text not null default '',
                session_id text not null default '',
                result_status text not null default '',
                endpoint text not null default ''
            )
            """
        )
        db.execute(
            "create index if not exists idx_audit_events_time on audit_events(occurred_at desc)"
        )
        db.execute(
            "create index if not exists idx_audit_events_category_time "
            "on audit_events(category, occurred_at desc)"
        )
        db.execute(
            "create index if not exists idx_audit_events_client_ip "
            "on audit_events(client_ip, occurred_at desc)"
        )
        db.execute(
            "create index if not exists idx_audit_events_account "
            "on audit_events(account_subject, occurred_at desc)"
        )
        db.execute(
            """
            create table if not exists audit_meta (
                key text primary key,
                value text not null
            )
            """
        )
    cleanup_audit_data(db_path=db_path)


def normalize_ip(value: Any) -> str:
    candidate = str(value or "").strip().strip("[]")
    if not candidate:
        return ""
    try:
        return str(ipaddress.ip_address(candidate))
    except ValueError:
        return ""


def session_source_ip(source: Any) -> str:
    text = str(source or "").strip()
    candidate = text.rsplit(":", 1)[-1] if ":" in text else text
    return normalize_ip(candidate)


def _short(value: Any, limit: int) -> str:
    text = str(value or "").strip()
    return text[:limit]


def record_audit_event(
    *,
    category: str,
    action: str,
    client_ip: str = "",
    session_ip: str = "",
    query_text: str = "",
    account_display: str = "",
    account_subject: str = "",
    session_id: str = "",
    result_status: str = "",
    endpoint: str = "",
    db_path: Path = DEFAULT_DB_PATH,
) -> int | None:
    try:
        init_audit_db(db_path)
        with _database(db_path) as db:
            cursor = db.execute(
                """
                insert into audit_events(
                    occurred_at, category, action, client_ip, session_ip,
                    query_text, account_display, account_subject, session_id,
                    result_status, endpoint
                ) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    int(time.time()),
                    _short(category, 32),
                    _short(action, 48),
                    normalize_ip(client_ip),
                    normalize_ip(session_ip),
                    _short(query_text, 160),
                    _short(account_display, 160),
                    _short(account_subject, 64).lower(),
                    _short(session_id, 64).lower(),
                    _short(result_status, 48),
                    _short(endpoint, 120),
                ),
            )
            return int(cursor.lastrowid)
    except Exception:
        return None


def record_public_query(
    *,
    client_ip: str,
    query_text: str,
    result_status: str,
    account_display: str = "",
    account_subject: str = "",
    endpoint: str = "/public-query",
    db_path: Path = DEFAULT_DB_PATH,
) -> int | None:
    return record_audit_event(
        category="public_query",
        action="query",
        client_ip=client_ip,
        query_text=query_text,
        account_display=account_display,
        account_subject=account_subject,
        result_status=result_status,
        endpoint=endpoint,
        db_path=db_path,
    )


def record_live_usage(
    *,
    action: str,
    client_ip: str,
    session: dict[str, Any],
    endpoint: str,
    result_status: str = "ok",
    db_path: Path = DEFAULT_DB_PATH,
) -> int | None:
    return record_audit_event(
        category="live",
        action=action,
        client_ip=client_ip,
        session_ip=session_source_ip(session.get("source")),
        account_display=str(session.get("display") or ""),
        account_subject=str(session.get("subject") or ""),
        session_id=str(session.get("id") or ""),
        result_status=result_status,
        endpoint=endpoint,
        db_path=db_path,
    )


def cleanup_audit_data(
    *,
    db_path: Path = DEFAULT_DB_PATH,
    retention_days: int | None = None,
    force: bool = False,
) -> int:
    days = retention_days if retention_days is not None else audit_retention_days()
    now = int(time.time())
    try:
        with _database(db_path) as db:
            row = db.execute(
                "select value from audit_meta where key = 'last_cleanup_at'"
            ).fetchone()
            last_cleanup = int(row[0]) if row else 0
            if not force and now - last_cleanup < 24 * 60 * 60:
                return 0
            cursor = db.execute(
                "delete from audit_events where occurred_at < ?",
                (now - max(1, int(days)) * 24 * 60 * 60,),
            )
            db.execute(
                "insert into audit_meta(key, value) values('last_cleanup_at', ?) "
                "on conflict(key) do update set value = excluded.value",
                (str(now),),
            )
            return max(0, int(cursor.rowcount))
    except sqlite3.OperationalError:
        return 0


def audit_summary(db_path: Path = DEFAULT_DB_PATH) -> dict[str, int]:
    init_audit_db(db_path)
    now = int(time.time())
    with _database(db_path) as db:
        row = db.execute(
            """
            select
                count(*) as total,
                sum(case when occurred_at >= ? then 1 else 0 end) as day_total,
                sum(case when occurred_at >= ? then 1 else 0 end) as week_total,
                count(distinct case when client_ip <> '' then client_ip end) as unique_ips,
                count(distinct case when category = 'live' and account_subject <> '' then account_subject end) as live_accounts,
                count(distinct case when category = 'public_query' and account_subject <> '' then account_subject end) as queried_accounts
            from audit_events
            """,
            (now - 24 * 60 * 60, now - 7 * 24 * 60 * 60),
        ).fetchone()
    return {key: int(row[key] or 0) for key in row.keys()}


def list_audit_events(
    *,
    category: str = "all",
    search: str = "",
    days: int = 30,
    page: int = 1,
    page_size: int = 100,
    db_path: Path = DEFAULT_DB_PATH,
) -> dict[str, Any]:
    init_audit_db(db_path)
    category = category if category in {"all", "public_query", "live"} else "all"
    page = max(1, int(page))
    page_size = max(20, min(int(page_size), 500))
    days = max(1, min(int(days), audit_retention_days()))
    clauses = ["occurred_at >= ?"]
    params: list[Any] = [int(time.time()) - days * 24 * 60 * 60]
    if category != "all":
        clauses.append("category = ?")
        params.append(category)
    search = _short(search, 160)
    if search:
        clauses.append(
            "(client_ip like ? or session_ip like ? or query_text like ? "
            "or account_display like ? or account_subject like ?)"
        )
        marker = f"%{search}%"
        params.extend([marker] * 5)
    where_sql = " and ".join(clauses)
    with _database(db_path) as db:
        total = int(
            db.execute(f"select count(*) from audit_events where {where_sql}", params).fetchone()[0]
        )
        rows = db.execute(
            f"""
            select id, occurred_at, category, action, client_ip, session_ip,
                   query_text, account_display, account_subject, session_id,
                   result_status, endpoint
            from audit_events
            where {where_sql}
            order by occurred_at desc, id desc
            limit ? offset ?
            """,
            [*params, page_size, (page - 1) * page_size],
        ).fetchall()
    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": max(1, (total + page_size - 1) // page_size),
        "rows": [dict(row) for row in rows],
    }
