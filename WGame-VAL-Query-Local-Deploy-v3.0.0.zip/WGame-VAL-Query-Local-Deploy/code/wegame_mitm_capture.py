"""
mitmproxy addon for capturing WeGame / Valorant panel traffic.

It writes JSONL records to WEGAME_CAPTURE_OUTPUT.
Secrets such as cookies, auth headers, tokens, signatures, and tickets are
redacted by default. Set WEGAME_CAPTURE_RAW=1 to store raw values.
"""

from __future__ import annotations

import base64
import datetime as _dt
import gzip
import hashlib
import json
import os
import re
import time
import urllib.parse
import zlib
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Any

from mitmproxy import ctx, http

try:
    import brotli
except ImportError:
    brotli = None


DEFAULT_TARGET_KEYWORDS = (
    "wegame",
    "tgp",
    "tencent",
    "qq.com",
    "gtimg",
    "game.qq",
    "val.qq",
    "valorant",
    "wgame",
)

EXCLUDED_HOST_KEYWORDS = (
    "chatgpt.com",
    "openai.com",
    "oaistatic.com",
    "oaiusercontent.com",
)

STATIC_EXTENSIONS = (
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".ico",
    ".svg",
    ".bmp",
    ".css",
    ".woff",
    ".woff2",
    ".ttf",
    ".otf",
    ".mp4",
    ".webm",
    ".mp3",
    ".wav",
)

TOKEN_KEY_RE = re.compile(
    r"(authorization|cookie|token|ticket|sig|sign|skey|session|csrf|secret|"
    r"password|passwd|credential|jwt|access[_-]?token|refresh[_-]?token|"
    r"verify|captcha|oauth|bearer)",
    re.I,
)

ACCOUNT_KEY_RE = re.compile(
    r"^(open[_-]?id|union[_-]?id|uin|qq|qqid|qquin|qq_uin|account|"
    r"account[_-]?id|user[_-]?account)$",
    re.I,
)

INTERESTING_KEY_RE = re.compile(
    r"(role|player|puuid|uuid|uid|uin|open.?id|match|game|season|area|server|"
    r"partition|region|nick|name|tag|combat|valorant|account|score|kda|rank)",
    re.I,
)

MAX_TEXT_CHARS = int(os.environ.get("WEGAME_CAPTURE_MAX_TEXT_CHARS", "12000"))
MAX_BODY_BYTES = int(os.environ.get("WEGAME_CAPTURE_MAX_BODY_BYTES", "2097152"))
CAPTURE_ALL = os.environ.get("WEGAME_CAPTURE_ALL", "").lower() in ("1", "true", "yes")
RAW_CAPTURE = os.environ.get("WEGAME_CAPTURE_RAW", "").lower() in ("1", "true", "yes")
SKIP_STATIC = os.environ.get("WEGAME_CAPTURE_SKIP_STATIC", "1").lower() not in (
    "0",
    "false",
    "no",
)
TARGET_KEYWORDS = tuple(
    item.strip().lower()
    for item in os.environ.get(
        "WEGAME_CAPTURE_KEYWORDS", ",".join(DEFAULT_TARGET_KEYWORDS)
    ).split(",")
    if item.strip()
)


class SafeWeGameCapture:
    def __init__(self) -> None:
        default_output = Path(__file__).resolve().parent / "captures" / "wegame_capture.jsonl"
        self.output_path = Path(os.environ.get("WEGAME_CAPTURE_OUTPUT", default_output))
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        self.summary_path = self.output_path.with_suffix(self.output_path.suffix + ".summary.txt")
        self.identity_map: OrderedDict[tuple[str, str], str] = OrderedDict()
        self.host_counts: Counter[str] = Counter()
        self.endpoint_counts: Counter[str] = Counter()
        self.records = 0

    def load(self, loader: Any) -> None:
        ctx.log.info(f"SafeWeGameCapture writing to {self.output_path}")
        ctx.log.info("Redaction: OFF / raw capture" if RAW_CAPTURE else "Redaction: ON")
        ctx.log.info(
            "Target keywords: "
            + ("ALL TRAFFIC" if CAPTURE_ALL else ", ".join(TARGET_KEYWORDS))
        )

    def response(self, flow: http.HTTPFlow) -> None:
        if not self._should_capture(flow):
            return
        record = self._flow_record(flow, error=None)
        self._write_record(record)

    def error(self, flow: http.HTTPFlow) -> None:
        if not self._should_capture(flow):
            return
        err = str(flow.error) if flow.error else "unknown error"
        record = self._flow_record(flow, error=err)
        self._write_record(record)

    def _should_capture(self, flow: http.HTTPFlow) -> bool:
        host = (flow.request.host or "").lower()
        path = (flow.request.path or "").lower()
        host_path = f"{host}{path}"

        if any(k in host for k in EXCLUDED_HOST_KEYWORDS):
            return False

        if not CAPTURE_ALL and not any(k in host_path for k in TARGET_KEYWORDS):
            return False

        if SKIP_STATIC:
            clean_path = path.split("?", 1)[0]
            if clean_path.endswith(STATIC_EXTENSIONS):
                return False

        return True

    def _flow_record(self, flow: http.HTTPFlow, error: str | None) -> dict[str, Any]:
        request_body = self._body_record(flow.request.headers, flow.request.raw_content)
        response_body = None
        if flow.response is not None:
            response_body = self._body_record(flow.response.headers, flow.response.raw_content)

        request_part = {
            "method": flow.request.method,
            "scheme": flow.request.scheme,
            "host": flow.request.host,
            "port": flow.request.port,
            "path": self._sanitize_path(flow.request.path),
            "query": self._sanitize_query(flow.request.query.items(multi=True)),
            "headers": self._sanitize_headers(flow.request.headers),
            "body": request_body,
        }

        response_part = None
        if flow.response is not None:
            response_part = {
                "status_code": flow.response.status_code,
                "reason": flow.response.reason,
                "headers": self._sanitize_headers(flow.response.headers),
                "body": response_body,
            }

        interesting: list[dict[str, Any]] = []
        self._collect_interesting(interesting, "request.query", request_part["query"])
        self._collect_interesting(interesting, "request.body", request_body)
        self._collect_interesting(interesting, "response.body", response_body)

        endpoint = f"{flow.request.method} {flow.request.host}{flow.request.path.split('?', 1)[0]}"
        return {
            "captured_at": _dt.datetime.now().isoformat(timespec="seconds"),
            "ts_start": flow.request.timestamp_start,
            "duration_ms": self._duration_ms(flow),
            "endpoint": endpoint,
            "request": request_part,
            "response": response_part,
            "error": error,
            "interesting_keys": interesting[:160],
        }

    def _duration_ms(self, flow: http.HTTPFlow) -> int | None:
        end = None
        if flow.response is not None:
            end = flow.response.timestamp_end
        elif flow.error is not None:
            end = time.time()
        if end is None or flow.request.timestamp_start is None:
            return None
        return int((end - flow.request.timestamp_start) * 1000)

    def _write_record(self, record: dict[str, Any]) -> None:
        with self.output_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")

        self.records += 1
        host = record["request"]["host"]
        endpoint = record["endpoint"]
        self.host_counts[host] += 1
        self.endpoint_counts[endpoint] += 1

        if self.records == 1 or self.records % 10 == 0:
            self._write_summary()

    def _write_summary(self) -> None:
        lines = [
            "SafeWeGameCapture summary",
            f"Output: {self.output_path}",
            f"Records: {self.records}",
            "",
            "Top hosts:",
        ]
        for host, count in self.host_counts.most_common(20):
            lines.append(f"  {count:5d}  {host}")

        lines.append("")
        lines.append("Top endpoints:")
        for endpoint, count in self.endpoint_counts.most_common(40):
            lines.append(f"  {count:5d}  {endpoint}")

        self.summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def _sanitize_headers(self, headers: Any) -> dict[str, str]:
        output: dict[str, str] = {}
        for key, value in headers.items(multi=True):
            if RAW_CAPTURE:
                output[key] = str(value)
            elif TOKEN_KEY_RE.search(key):
                output[key] = self._redacted("secret")
            elif ACCOUNT_KEY_RE.search(key):
                output[key] = self._placeholder(key, value)
            else:
                output[key] = self._mask_text(str(value), limit=2000)
        return output

    def _sanitize_query(self, pairs: list[tuple[str, str]]) -> list[dict[str, Any]]:
        output: list[dict[str, Any]] = []
        for key, value in pairs:
            output.append({"key": key, "value": self._sanitize_value(key, value)})
        return output

    def _sanitize_path(self, path: str) -> str:
        parsed = urllib.parse.urlsplit(path)
        if not parsed.query:
            return path
        pairs = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
        sanitized_pairs = []
        for key, value in pairs:
            sanitized = self._sanitize_value(key, value)
            if isinstance(sanitized, (dict, list)):
                sanitized = json.dumps(sanitized, ensure_ascii=False)
            sanitized_pairs.append((key, str(sanitized)))
        query = urllib.parse.urlencode(sanitized_pairs, doseq=True)
        return urllib.parse.urlunsplit(("", "", parsed.path, query, parsed.fragment))

    def _body_record(self, headers: Any, raw_content: bytes | None) -> Any:
        if not raw_content:
            return None

        original_size = len(raw_content)
        if original_size > MAX_BODY_BYTES:
            raw_content = raw_content[:MAX_BODY_BYTES]

        content_type = (headers.get("content-type", "") or "").lower()
        content_encoding = (headers.get("content-encoding", "") or "").lower()
        decoded_content = self._decode_content(raw_content, content_encoding)
        text = self._decode_bytes(decoded_content)

        record: dict[str, Any] = {
            "content_type": content_type,
            "content_encoding": content_encoding,
            "size_bytes": original_size,
            "truncated_bytes": original_size > len(raw_content),
            "sha256": hashlib.sha256(raw_content).hexdigest(),
            "decoded_size_bytes": len(decoded_content),
        }

        if self._looks_json(content_type, text):
            parsed = self._parse_json(text)
            if parsed is not None:
                record["json"] = self._sanitize_obj(parsed)
                return record

        if "application/x-www-form-urlencoded" in content_type:
            parsed_pairs = urllib.parse.parse_qsl(text, keep_blank_values=True)
            record["form"] = self._sanitize_query(parsed_pairs)
            return record

        if self._looks_text(content_type, decoded_content):
            record["text"] = self._mask_text(text, limit=MAX_TEXT_CHARS)
            record["truncated_text"] = len(text) > MAX_TEXT_CHARS
            return record

        record["binary_sample_base64"] = base64.b64encode(decoded_content[:80]).decode("ascii")
        return record

    def _decode_content(self, data: bytes, content_encoding: str) -> bytes:
        if not data:
            return data
        if "gzip" in content_encoding or data.startswith(b"\x1f\x8b\x08"):
            try:
                return gzip.decompress(data)
            except Exception:
                try:
                    decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
                    decoded = decoder.decompress(data) + decoder.flush()
                    return decoded or data
                except Exception:
                    return data
        if "br" in content_encoding and brotli is not None:
            try:
                return brotli.decompress(data)
            except Exception:
                return data
        if "deflate" in content_encoding:
            try:
                return zlib.decompress(data)
            except Exception:
                return data
        return data

    def _decode_bytes(self, data: bytes) -> str:
        for encoding in ("utf-8", "gb18030", "latin-1"):
            try:
                return data.decode(encoding)
            except UnicodeDecodeError:
                continue
        return data.decode("utf-8", errors="replace")

    def _looks_json(self, content_type: str, text: str) -> bool:
        stripped = text.lstrip()
        return "json" in content_type or stripped.startswith("{") or stripped.startswith("[")

    def _looks_text(self, content_type: str, data: bytes) -> bool:
        if any(item in content_type for item in ("text/", "json", "xml", "javascript", "html")):
            return True
        if b"\x00" in data[:512]:
            return False
        return True

    def _parse_json(self, text: str) -> Any:
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return None

    def _sanitize_obj(self, obj: Any, key_hint: str = "") -> Any:
        if isinstance(obj, dict):
            return {str(k): self._sanitize_obj(v, str(k)) for k, v in obj.items()}
        if isinstance(obj, list):
            return [self._sanitize_obj(v, key_hint) for v in obj]
        if isinstance(obj, str):
            return self._sanitize_value(key_hint, obj)
        return obj

    def _sanitize_value(self, key: str, value: Any) -> Any:
        if value is None:
            return None
        text = str(value)
        if RAW_CAPTURE:
            return text
        if TOKEN_KEY_RE.search(key):
            return self._redacted("secret")
        if ACCOUNT_KEY_RE.search(key):
            return self._placeholder(key, text)
        return self._mask_text(text, limit=MAX_TEXT_CHARS)

    def _placeholder(self, key: str, value: str) -> str:
        value = str(value)
        map_key = (key.lower(), value)
        if map_key not in self.identity_map:
            label = re.sub(r"[^a-z0-9_]+", "_", key.lower()).strip("_") or "id"
            self.identity_map[map_key] = f"<{label}#{len(self.identity_map) + 1}>"
        return self.identity_map[map_key]

    def _redacted(self, reason: str) -> str:
        return f"<redacted:{reason}>"

    def _mask_text(self, text: str, limit: int) -> str:
        if RAW_CAPTURE:
            if len(text) > limit:
                return text[:limit] + f"...<truncated:{len(text) - limit} chars>"
            return text
        masked = re.sub(
            r"(?i)(authorization|bearer|token|ticket|sig|sign|skey|session|csrf|"
            r"secret|password|passwd|credential|jwt|access_token|refresh_token)"
            r"([\"'\s:=]+)([^&\s\"',;}]+)",
            lambda m: m.group(1) + m.group(2) + self._redacted("secret"),
            text,
        )
        masked = re.sub(
            r"(?i)\b(openid|unionid|uin|qq|qquin|account_id|accountid)=([^&\s\"']+)",
            lambda m: f"{m.group(1)}={self._placeholder(m.group(1), m.group(2))}",
            masked,
        )
        if len(masked) > limit:
            return masked[:limit] + f"...<truncated:{len(masked) - limit} chars>"
        return masked

    def _collect_interesting(self, out: list[dict[str, Any]], path: str, obj: Any) -> None:
        if obj is None or len(out) >= 160:
            return
        if isinstance(obj, dict):
            for key, value in obj.items():
                child_path = f"{path}.{key}"
                if INTERESTING_KEY_RE.search(str(key)):
                    out.append({"path": child_path, "value": self._brief(value)})
                self._collect_interesting(out, child_path, value)
                if len(out) >= 160:
                    return
        elif isinstance(obj, list):
            for idx, value in enumerate(obj[:80]):
                self._collect_interesting(out, f"{path}[{idx}]", value)
                if len(out) >= 160:
                    return

    def _brief(self, value: Any) -> Any:
        if isinstance(value, (dict, list)):
            text = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
            return self._mask_text(text, limit=500)
        if isinstance(value, str):
            return self._mask_text(value, limit=500)
        return value


addons = [SafeWeGameCapture()]
