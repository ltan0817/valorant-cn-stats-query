"""Run mitmdump in the current Python process for reliable supervision."""

from mitmproxy.tools.main import mitmdump


if __name__ == "__main__":
    raise SystemExit(mitmdump())
