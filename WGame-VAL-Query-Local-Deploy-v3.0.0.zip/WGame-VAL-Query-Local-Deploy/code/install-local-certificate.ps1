﻿$ErrorActionPreference = "Stop"
$cert = Join-Path $env:USERPROFILE ".mitmproxy\mitmproxy-ca-cert.cer"
if (-not (Test-Path -LiteralPath $cert)) {
    throw "未找到本机 mitmproxy CA：$cert。请先启动一次 mitmproxy。"
}
certutil.exe -user -addstore Root $cert
if ($LASTEXITCODE -ne 0) {
    throw "证书安装失败。"
}
Write-Host "已把本机 mitmproxy CA 安装到当前用户证书存储。" -ForegroundColor Green
