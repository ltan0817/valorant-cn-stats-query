from __future__ import annotations

import argparse
import base64
import glob
import json
import time
from pathlib import Path
from typing import Any
from urllib import request
from urllib.error import HTTPError, URLError


APP_DIR = Path(__file__).resolve().parent
CAPTURE_DIRS = [
    APP_DIR / "captures",
]
REDGE_HOST = "alpha1-glz-redge.val.qq.com"
NAME_HOST = "alpha1-pd-redge.val.qq.com"
ENTITLEMENTS_HOST = "alpha1-entitlements.val.qq.com"
DEFAULT_CLIENT_VERSION = "release-china-13.01-shipping-14-5026731"
DEFAULT_CLIENT_PLATFORM = base64.b64encode(
    json.dumps(
        {
            "platformType": "PC",
            "platformOS": "Windows",
            "platformOSVersion": "10.0.19045.1.256.64bit",
            "platformChipset": "Unknown",
        },
        separators=(",", ":"),
    ).encode("utf-8")
).decode("ascii")


def b64url_json(part: str) -> dict[str, Any]:
    padding = "=" * (-len(part) % 4)
    raw = base64.urlsafe_b64decode((part + padding).encode("ascii"))
    return json.loads(raw.decode("utf-8"))


def decode_jwt_payload(token: str) -> dict[str, Any]:
    parts = token.split(".")
    if len(parts) < 2:
        return {}
    try:
        return b64url_json(parts[1])
    except Exception:
        return {}


def compact_error(exc: Exception) -> str:
    if isinstance(exc, HTTPError):
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return f"HTTP {exc.code}: {body[:240]}"
    if isinstance(exc, URLError):
        return f"URL error: {exc.reason}"
    return f"{type(exc).__name__}: {exc}"


def latest_capture_files() -> list[Path]:
    files: list[Path] = []
    for capture_dir in CAPTURE_DIRS:
        files += [Path(p) for p in glob.glob(str(capture_dir / "proxifier-game-*.jsonl"))]
        files += [Path(p) for p in glob.glob(str(capture_dir / "pushed-game-token-*.jsonl"))]
        files += [Path(p) for p in glob.glob(str(capture_dir / "wegame-*.jsonl"))]
        files += [Path(p) for p in glob.glob(str(capture_dir / "mobile-val-*.jsonl"))]
    return sorted((p for p in files if p.exists()), key=lambda p: p.stat().st_mtime, reverse=True)


def tail_text_lines(path: Path, limit: int) -> list[str]:
    """Read only enough data from the end of a growing JSONL capture."""
    if limit <= 0:
        return []
    chunks: list[bytes] = []
    newline_count = 0
    chunk_size = 64 * 1024
    with path.open("rb") as fp:
        fp.seek(0, 2)
        position = fp.tell()
        while position > 0 and newline_count <= limit:
            read_size = min(chunk_size, position)
            position -= read_size
            fp.seek(position)
            chunk = fp.read(read_size)
            chunks.append(chunk)
            newline_count += chunk.count(b"\n")
    data = b"".join(reversed(chunks))
    return data.decode("utf-8", errors="ignore").splitlines()[-limit:]


def title_header(key: str) -> str:
    return "-".join(part.capitalize() for part in key.split("-"))


def base_game_headers(lowered: dict[str, str], auth: str, ent: str | None = None) -> dict[str, str]:
    user_agent = lowered.get("user-agent", f"ShooterGame/14 Windows/10.0 valorant/{DEFAULT_CLIENT_VERSION}")
    client_version = lowered.get("x-riot-clientversion")
    if not client_version and "valorant/" in user_agent:
        client_version = user_agent.rsplit("valorant/", 1)[-1].strip()
    redge_headers = {
        "Authorization": auth,
        "Accept": "application/json",
        "Content-Type": "application/json",
        "User-Agent": user_agent,
        "X-Riot-ClientVersion": client_version or DEFAULT_CLIENT_VERSION,
        "X-Riot-ClientPlatform": lowered.get("x-riot-clientplatform") or DEFAULT_CLIENT_PLATFORM,
    }
    if ent:
        redge_headers["X-Riot-Entitlements-JWT"] = ent
    for key in ["x-riot-clientversion", "x-riot-clientplatform", "x-b3-traceid", "x-b3-sessionid"]:
        if key in lowered:
            redge_headers[title_header(key)] = lowered[key]
    return redge_headers


def extract_latest_game_headers(
    paths: list[Path],
    source_filter: str | None = None,
    subject_filter: str | None = None,
) -> tuple[dict[str, str], str | None, Path | None]:
    latest_combo: tuple[float, dict[str, str], str | None, Path | None] | None = None
    latest_auth: tuple[float, str, dict[str, str], str | None, Path | None] | None = None
    latest_ent: tuple[float, str, Path | None] | None = None
    for path in paths:
        try:
            lines = tail_text_lines(path, 6000)
        except Exception:
            continue
        for line in lines:
            if REDGE_HOST not in line and NAME_HOST not in line and ENTITLEMENTS_HOST not in line:
                continue
            try:
                item = json.loads(line)
            except Exception:
                continue
            item_source = str(item.get("source") or "")
            if source_filter and item_source != source_filter:
                continue
            req = item.get("request") or {}
            headers = req.get("headers") or {}
            lowered = {str(k).lower(): str(v) for k, v in headers.items()}
            auth = lowered.get("authorization")
            ent = lowered.get("x-riot-entitlements-jwt")
            ts = float(item.get("ts_start") or 0.0)

            resp = item.get("response") or {}
            body = resp.get("body") if isinstance(resp, dict) else None
            body_json = body.get("json") if isinstance(body, dict) else None
            if isinstance(body_json, dict) and body_json.get("entitlements_token"):
                if latest_ent is None or ts > latest_ent[0]:
                    latest_ent = (ts, str(body_json["entitlements_token"]), path)

            if auth:
                bearer = auth.removeprefix("Bearer").strip()
                payload = decode_jwt_payload(bearer)
                subject = payload.get("sub")
                if subject_filter and str(subject).lower() != subject_filter.lower():
                    continue
                if latest_auth is None or ts > latest_auth[0]:
                    latest_auth = (ts, auth, lowered, subject, path)
                if ent:
                    redge_headers = base_game_headers(lowered, auth, ent)
                    if latest_combo is None or ts > latest_combo[0]:
                        latest_combo = (ts, redge_headers, subject, path)

    if latest_combo and (latest_auth is None or latest_combo[0] >= latest_auth[0] - 5):
        return latest_combo[1], latest_combo[2], latest_combo[3]
    if latest_auth and latest_ent:
        _, auth, lowered, subject, auth_path = latest_auth
        _, ent, ent_path = latest_ent
        return base_game_headers(lowered, auth, ent), subject, auth_path or ent_path
    if latest_combo:
        return latest_combo[1], latest_combo[2], latest_combo[3]
    return {}, None, None


def http_json(method: str, url: str, headers: dict[str, str], data: Any = None) -> tuple[int, Any]:
    body = None if data is None else json.dumps(data, ensure_ascii=False).encode("utf-8")
    req = request.Request(url, data=body, headers=headers, method=method)
    with request.urlopen(req, timeout=10) as resp:
        text = resp.read().decode("utf-8", errors="replace")
        try:
            return resp.status, json.loads(text)
        except Exception:
            return resp.status, text


def name_lookup(subjects: list[str], headers: dict[str, str]) -> dict[str, str]:
    if not subjects:
        return {}
    url = f"https://{NAME_HOST}/name-service/v2/players"
    try:
        _, data = http_json("PUT", url, headers, subjects)
    except Exception:
        return {}
    out: dict[str, str] = {}
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and item.get("Subject"):
                name = f"{item.get('GameName') or ''}#{item.get('TagLine') or ''}".strip("#")
                out[item["Subject"]] = name
    return out


def summarize_match(
    match: dict[str, Any],
    headers: dict[str, str],
    include_names: bool = True,
) -> dict[str, Any]:
    players: list[dict[str, Any]] = []
    if isinstance(match.get("Players"), list):
        for item in match["Players"]:
            players.append(
                {
                    "subject": item.get("Subject"),
                    "team": item.get("TeamID"),
                    "characterId": item.get("CharacterID"),
                }
            )
    ally = ((match.get("AllyTeam") or {}).get("Players") or []) if isinstance(match.get("AllyTeam"), dict) else []
    for item in ally:
        identity = item.get("PlayerIdentity") or {}
        players.append(
            {
                "subject": identity.get("Subject"),
                "team": "Ally",
                "characterId": item.get("CharacterID"),
                "state": item.get("PregamePlayerState"),
            }
        )
    if include_names:
        subjects = [p["subject"] for p in players if p.get("subject")]
        names = name_lookup(subjects, headers)
        for player in players:
            if player.get("subject") in names:
                player["name"] = names[player["subject"]]
    return {
        "matchId": match.get("MatchID") or match.get("ID"),
        "state": match.get("State") or match.get("PregameState"),
        "mapId": match.get("MapID"),
        "queueId": match.get("QueueID"),
        "playerCount": len(players),
        "players": players,
    }


def summarize_party(
    party: dict[str, Any],
    headers: dict[str, str],
    include_names: bool = True,
) -> dict[str, Any]:
    members = party.get("Members") if isinstance(party.get("Members"), list) else []
    players = []
    for member in members:
        if not isinstance(member, dict):
            continue
        identity = member.get("PlayerIdentity") if isinstance(member.get("PlayerIdentity"), dict) else {}
        subject = member.get("Subject") or identity.get("Subject")
        if not subject:
            continue
        players.append(
            {
                "subject": subject,
                "competitiveTier": member.get("CompetitiveTier"),
                "accountLevel": identity.get("AccountLevel"),
                "isOwner": bool(member.get("IsOwner")),
                "isReady": bool(member.get("IsReady")),
            }
        )
    if include_names:
        names = name_lookup([player["subject"] for player in players], headers)
        for player in players:
            if player["subject"] in names:
                player["name"] = names[player["subject"]]
    matchmaking = party.get("MatchmakingData") if isinstance(party.get("MatchmakingData"), dict) else {}
    return {
        "partyId": party.get("ID"),
        "state": party.get("State"),
        "previousState": party.get("PreviousState"),
        "accessibility": party.get("Accessibility"),
        "queueId": matchmaking.get("QueueID"),
        "memberCount": len(players),
        "players": players,
    }


def probe_party(
    headers: dict[str, str],
    subject: str,
    include_names: bool = True,
) -> dict[str, Any]:
    attempts = []
    player_url = f"https://{REDGE_HOST}/parties/v1/players/{subject}"
    try:
        status, player_data = http_json("GET", player_url, headers)
        attempts.append(
            {
                "playersStatus": status,
                "playersKeys": list(player_data.keys())
                if isinstance(player_data, dict)
                else type(player_data).__name__,
            }
        )
    except Exception as exc:
        return {"ok": False, "attempts": [{"playersError": compact_error(exc)}]}
    party_id = player_data.get("CurrentPartyID") if isinstance(player_data, dict) else None
    if not party_id:
        return {"ok": False, "attempts": attempts}
    party_url = f"https://{REDGE_HOST}/parties/v1/parties/{party_id}"
    try:
        status, party_data = http_json("GET", party_url, headers)
        attempts[-1]["partyStatus"] = status
    except Exception as exc:
        attempts[-1]["partyError"] = compact_error(exc)
        return {"ok": False, "attempts": attempts}
    if isinstance(party_data, dict) and status == 200:
        return {
            "ok": True,
            "source": "game-redge-party",
            "attempts": attempts,
            "party": summarize_party(party_data, headers, include_names=include_names),
        }
    return {"ok": False, "attempts": attempts}


def probe(
    headers: dict[str, str],
    subject: str,
    include_names: bool = True,
) -> dict[str, Any]:
    attempts = []
    for phase in ["pregame", "core-game"]:
        player_url = f"https://{REDGE_HOST}/{phase}/v1/players/{subject}"
        try:
            status, player_data = http_json("GET", player_url, headers)
            attempts.append({"phase": phase, "playersStatus": status, "playersKeys": list(player_data.keys()) if isinstance(player_data, dict) else type(player_data).__name__})
        except Exception as exc:
            attempts.append({"phase": phase, "playersError": compact_error(exc)})
            continue
        if not isinstance(player_data, dict) or not player_data.get("MatchID"):
            continue
        match_id = player_data["MatchID"]
        match_url = f"https://{REDGE_HOST}/{phase}/v1/matches/{match_id}"
        try:
            status, match_data = http_json("GET", match_url, headers)
            attempts[-1]["matchStatus"] = status
        except Exception as exc:
            attempts[-1]["matchError"] = compact_error(exc)
            continue
        if isinstance(match_data, dict) and status == 200:
            return {
                "ok": True,
                "phase": phase,
                "source": "game-redge",
                "attempts": attempts,
                "match": summarize_match(match_data, headers, include_names=include_names),
            }
    return {"ok": False, "attempts": attempts}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--capture", action="append", type=Path, help="mitmproxy jsonl capture file")
    parser.add_argument("--subject", help="override self subject")
    args = parser.parse_args()

    paths = args.capture or latest_capture_files()[:10]
    headers, subject, source = extract_latest_game_headers(paths)
    if args.subject:
        subject = args.subject
    if not headers:
        print(json.dumps({"ok": False, "error": "没有在抓包文件里找到游戏侧 Authorization / Entitlement 头。需要开游戏并抓一次 redge 流量。"}, ensure_ascii=False, indent=2))
        return
    payload = decode_jwt_payload(headers["Authorization"].removeprefix("Bearer").strip())
    exp = payload.get("exp")
    now = int(time.time())
    if not subject:
        print(json.dumps({"ok": False, "error": "找到游戏侧登录头，但 token 里没有 subject。"}, ensure_ascii=False, indent=2))
        return
    result = probe(headers, subject)
    result["selfSubject"] = subject
    result["tokenExpiresInSec"] = exp - now if isinstance(exp, int) else None
    result["captureSource"] = str(source) if source else None
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
