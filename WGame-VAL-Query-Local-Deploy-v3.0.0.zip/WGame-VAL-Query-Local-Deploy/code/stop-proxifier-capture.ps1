﻿param(
    [string]$SessionPath = (Join-Path $PSScriptRoot "captures\proxifier-capture-session.json")
)

$ErrorActionPreference = "Stop"
$Proxifier = "C:\Program Files (x86)\Proxifier\Proxifier.exe"
$CaptureDir = Split-Path -Parent $SessionPath
$StopMarkerPath = Join-Path $CaptureDir "proxifier-capture.stop"

if (-not (Test-Path -LiteralPath $SessionPath)) {
    throw "Session file not found: $SessionPath"
}

$session = Get-Content -Raw -LiteralPath $SessionPath | ConvertFrom-Json
(Get-Date).ToString("o") | Set-Content -Encoding UTF8 -LiteralPath $StopMarkerPath

if ($session.direct_profile -and (Test-Path ([string]$session.direct_profile)) -and (Test-Path $Proxifier)) {
    Start-Process -FilePath $Proxifier -ArgumentList @(([string]$session.direct_profile), "silent-load") -WindowStyle Hidden | Out-Null
    Start-Sleep -Seconds 1
}
if ($session.listen_port) {
    Get-NetTCPConnection -LocalPort ([int]$session.listen_port) -State Listen -ErrorAction SilentlyContinue |
        ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
}
if ($session.cmd_pid) {
    Stop-Process -Id ([int]$session.cmd_pid) -Force -ErrorAction SilentlyContinue
}
if ($session.supervisor_pid) {
    Stop-Process -Id ([int]$session.supervisor_pid) -Force -ErrorAction SilentlyContinue
}
Write-Host "抓包已停止，Proxifier 已切回 Direct 配置。" -ForegroundColor Green
