@echo off
cd /d "%~dp0"
python wgame_query_server.py --launch-chrome
