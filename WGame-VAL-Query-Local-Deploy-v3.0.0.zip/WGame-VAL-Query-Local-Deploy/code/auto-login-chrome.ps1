﻿param(
    [string]$ProjectDir = $PSScriptRoot
)

$ErrorActionPreference = "Stop"
$ProjectDir = (Resolve-Path -LiteralPath $ProjectDir).Path
$ChromeProfile = Join-Path $ProjectDir "data\chrome-profile"
New-Item -ItemType Directory -Force -Path $ChromeProfile | Out-Null

$chromePaths = @(
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "$env:PROGRAMFILES\Google\Chrome\Application\chrome.exe",
    "$env:PROGRAMFILES(X86)\Google\Chrome\Application\chrome.exe"
)
$chromeExe = $chromePaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $chromeExe) {
    throw "未找到 Google Chrome，请先安装浏览器。"
}

$port = 9223
Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
    ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 500

$helperUrl = "https://www.wegame.com.cn/helper/valorant/"
$arguments = @(
    "--remote-debugging-port=$port",
    "--remote-allow-origins=*",
    "--user-data-dir=`"$ChromeProfile`"",
    "--no-first-run",
    "--no-default-browser-check",
    "--start-maximized",
    "--disable-extensions",
    "--disable-features=Translate",
    $helperUrl
)
Start-Process -FilePath $chromeExe -ArgumentList $arguments | Out-Null
Write-Host "专用 Chrome 已启动。登录后访问 http://127.0.0.1:8787/public" -ForegroundColor Green
