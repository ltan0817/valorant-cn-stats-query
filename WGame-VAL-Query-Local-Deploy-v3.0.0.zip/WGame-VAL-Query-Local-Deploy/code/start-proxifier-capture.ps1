﻿param(
    [int]$ProxyPort = 8083,
    [string[]]$IgnoreHosts = @(
        "^www\.wegame\.com\.cn:443$",
        "^wegame\.gtimg\.com:443$",
        "^trace\.tgp\.qq\.com:443$",
        "^alpha1-chat\.val\.qq\.com:443$",
        "^alpha1-rms\.val\.qq\.com:443$"
    )
)

$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$CaptureDir = Join-Path $Root "captures"
New-Item -ItemType Directory -Force -Path $CaptureDir | Out-Null

$existing = Get-NetTCPConnection -LocalPort $ProxyPort -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($existing) {
    throw "Port $ProxyPort is already listening, owner PID $($existing.OwningProcess). Stop the old capture first."
}

$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Output = Join-Path $CaptureDir "proxifier-game-$Timestamp.jsonl"
$StdoutLog = Join-Path $CaptureDir "proxifier-game-$Timestamp.stdout.log"
$StderrLog = Join-Path $CaptureDir "proxifier-game-$Timestamp.stderr.log"
$ProfilePath = Join-Path $CaptureDir "proxifier-game-$Timestamp.ppx"
$DirectProfilePath = Join-Path $CaptureDir "proxifier-direct.ppx"
$SessionPath = Join-Path $CaptureDir "proxifier-capture-session.json"
$StopMarkerPath = Join-Path $CaptureDir "proxifier-capture.stop"
$SupervisorLogPath = Join-Path $CaptureDir "proxifier-capture-supervisor.log"
Remove-Item -LiteralPath $StopMarkerPath -Force -ErrorAction SilentlyContinue

$Proxifier = "C:\Program Files (x86)\Proxifier\Proxifier.exe"
if (-not (Test-Path $Proxifier)) {
    throw "Proxifier.exe not found: $Proxifier"
}

$profile = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ProxifierProfile version="101" platform="Windows" product_id="0" product_minver="310">
 <Options>
  <Resolve>
   <AutoModeDetection enabled="true" />
   <ViaProxy enabled="true">
    <TryLocalDnsFirst enabled="false" />
   </ViaProxy>
   <ExclusionList>%ComputerName%; localhost; *.local</ExclusionList>
   <DnsUdpMode>0</DnsUdpMode>
  </Resolve>
  <Encryption mode="basic" />
  <HttpProxiesSupport enabled="false" />
  <HandleDirectConnections enabled="false" />
  <ConnectionLoopDetection enabled="true" />
  <ProcessServices enabled="true" />
  <ProcessOtherUsers enabled="true" />
 </Options>
 <ProxyList>
  <Proxy id="100" type="SOCKS5">
   <Address>127.0.0.1</Address>
   <Port>$ProxyPort</Port>
   <Options>48</Options>
  </Proxy>
 </ProxyList>
 <ChainList />
 <RuleList>
  <Rule enabled="true">
   <Name>Localhost direct</Name>
   <Targets>localhost; 127.0.0.1; ::1; %ComputerName%</Targets>
   <Action type="Direct" />
  </Rule>
  <Rule enabled="true">
   <Name>WeGame client direct</Name>
   <Applications>wegame.exe;WeGame.exe;TenioDL.exe;tgp_daemon.exe;TCLS.exe</Applications>
   <Action type="Direct" />
  </Rule>
  <Rule enabled="true">
   <Name>ACE anticheat hosts direct</Name>
   <Targets>*.anticheatexpert.com; down.anticheatexpert.com; cschannel.anticheatexpert.com</Targets>
   <Action type="Direct" />
  </Rule>
  <Rule enabled="true">
   <Name>ACE processes direct</Name>
   <Applications>ACE-Tray.exe;ACE-Service.exe;ACE-Guard.exe;ACE-Helper.exe</Applications>
   <Action type="Direct" />
  </Rule>
  <Rule enabled="true">
   <Name>Certificate-pinned services direct</Name>
   <Targets>www.wegame.com.cn; wegame.gtimg.com; trace.tgp.qq.com; alpha1-chat.val.qq.com; alpha1-rms.val.qq.com</Targets>
   <Action type="Direct" />
  </Rule>
  <Rule enabled="true">
   <Name>Riot client capture</Name>
   <Applications>VALORANT.exe;VALORANT-Win64-Shipping.exe;RiotClientServices.exe;RiotClientUx.exe;RiotClientUxRender.exe</Applications>
   <Action type="Proxy">100</Action>
  </Rule>
  <Rule enabled="true">
   <Name>Default direct</Name>
   <Action type="Direct" />
  </Rule>
 </RuleList>
</ProxifierProfile>
"@
$profile | Set-Content -Encoding UTF8 -Path $ProfilePath

$directProfile = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ProxifierProfile version="101" platform="Windows" product_id="0" product_minver="310">
 <Options>
  <Resolve>
   <AutoModeDetection enabled="true" />
   <ViaProxy enabled="false">
    <TryLocalDnsFirst enabled="false" />
   </ViaProxy>
   <ExclusionList>%ComputerName%; localhost; *.local</ExclusionList>
   <DnsUdpMode>0</DnsUdpMode>
  </Resolve>
  <Encryption mode="basic" />
  <HttpProxiesSupport enabled="false" />
  <HandleDirectConnections enabled="false" />
  <ConnectionLoopDetection enabled="true" />
  <ProcessServices enabled="true" />
  <ProcessOtherUsers enabled="true" />
 </Options>
 <ProxyList />
 <ChainList />
 <RuleList>
  <Rule enabled="true">
   <Name>Default direct</Name>
   <Action type="Direct" />
  </Rule>
 </RuleList>
</ProxifierProfile>
"@
$directProfile | Set-Content -Encoding UTF8 -Path $DirectProfilePath

function Restore-ProxifierDirect {
    if ((Test-Path $Proxifier) -and (Test-Path $DirectProfilePath)) {
        # Loading a profile by invoking Proxifier synchronously blocks forever
        # when no Proxifier instance exists yet. Start it asynchronously so the
        # failure path can finish while the direct-only profile stays active.
        Start-Process -FilePath $Proxifier -ArgumentList @($DirectProfilePath, "silent-load") -WindowStyle Hidden | Out-Null
    }
}

function Write-SupervisorLog {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"), $Message
    Add-Content -LiteralPath $SupervisorLogPath -Encoding UTF8 -Value $line
}

$MitmDump = (Get-Command mitmdump -ErrorAction Stop).Source
$MitmPython = Join-Path (Split-Path (Split-Path $MitmDump -Parent) -Parent) "python.exe"
$MitmRunner = Join-Path $Root "mitmdump_runner.py"
$Addon = Join-Path $Root "wegame_mitm_capture.py"
if (-not (Test-Path $Addon)) {
    throw "mitm addon not found: $Addon"
}
if (-not (Test-Path $MitmPython)) {
    throw "mitmdump Python runtime not found: $MitmPython"
}
if (-not (Test-Path $MitmRunner)) {
    throw "mitmdump runner not found: $MitmRunner"
}

$mitmArgs = @(
    "--mode", "socks5",
    "--listen-host", "127.0.0.1",
    "--listen-port", "$ProxyPort",
    "--ssl-insecure",
    "--set", "connection_strategy=lazy"
)
if ($IgnoreHosts) {
    $ignorePattern = ($IgnoreHosts | Where-Object { $_ } | ForEach-Object { "(?:$_)" }) -join "|"
    if ($ignorePattern) {
        # mitmdump does not document --ignore-hosts as repeatable. A single
        # combined expression guarantees every certificate-pinned endpoint is
        # tunneled without TLS interception.
        $mitmArgs += @("--ignore-hosts", $ignorePattern)
    }
}
$mitmArgs += @("-s", $Addon)

# This PowerShell process exists only for the capture supervisor, so setting
# its environment is safe and lets Start-Process pass the capture settings to
# mitmdump without an intermediate cmd.exe parser.
$env:WEGAME_CAPTURE_ALL = "1"
$env:WEGAME_CAPTURE_RAW = "1"
$env:WEGAME_CAPTURE_MAX_TEXT_CHARS = "1000000"
$env:WEGAME_CAPTURE_MAX_BODY_BYTES = "10485760"
$env:WEGAME_CAPTURE_SKIP_STATIC = "1"
$env:WEGAME_CAPTURE_KEYWORDS = "val.qq.com,pvp.net,riotgames,wegame,valorant,qq.com,gtimg"

$supervisorStartedAt = (Get-Date).ToString("o")
$restartCount = 0
try {
    while (-not (Test-Path -LiteralPath $StopMarkerPath)) {
        $attemptSuffix = if ($restartCount -eq 0) { $Timestamp } else { "$Timestamp-r$restartCount" }
        $Output = Join-Path $CaptureDir "proxifier-game-$attemptSuffix.jsonl"
        $StdoutLog = Join-Path $CaptureDir "proxifier-game-$attemptSuffix.stdout.log"
        $StderrLog = Join-Path $CaptureDir "proxifier-game-$attemptSuffix.stderr.log"
        $env:WEGAME_CAPTURE_OUTPUT = $Output
        $process = $null
        $listener = $null
        $proxifierProcess = $null
        $exitCode = $null
        $attemptError = ""

        try {
            Write-SupervisorLog "starting attempt=$restartCount port=$ProxyPort"
            $runnerArgs = @($MitmRunner) + $mitmArgs
            $process = Start-Process `
                -FilePath $MitmPython `
                -ArgumentList $runnerArgs `
                -WorkingDirectory $Root `
                -WindowStyle Hidden `
                -RedirectStandardOutput $StdoutLog `
                -RedirectStandardError $StderrLog `
                -PassThru

            for ($i = 0; $i -lt 15; $i++) {
                Start-Sleep -Seconds 1
                $listener = Get-NetTCPConnection -LocalPort $ProxyPort -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($listener) {
                    break
                }
                if ($process.HasExited) {
                    break
                }
            }
            if (-not $listener) {
                throw "mitmdump did not start listening on $ProxyPort. Check $StderrLog"
            }

            $proxifierProcess = Start-Process -FilePath $Proxifier -ArgumentList @($ProfilePath, "silent-load") -PassThru -WindowStyle Hidden
            Start-Sleep -Seconds 2

            [ordered]@{
                started_at = $supervisorStartedAt
                attempt_started_at = (Get-Date).ToString("o")
                state = "running"
                supervisor_pid = $PID
                cmd_pid = $process.Id
                listener_pid = $listener.OwningProcess
                proxifier_pid = $proxifierProcess.Id
                listen_port = $ProxyPort
                restart_count = $restartCount
                output = $Output
                stdout_log = $StdoutLog
                stderr_log = $StderrLog
                supervisor_log = $SupervisorLogPath
                profile = $ProfilePath
                direct_profile = $DirectProfilePath
                stop_marker = $StopMarkerPath
            } | ConvertTo-Json | Set-Content -Encoding UTF8 -Path $SessionPath

            [ordered]@{
                supervisor_pid = $PID
                cmd_pid = $process.Id
                listening = $true
                listener_pid = $listener.OwningProcess
                restart_count = $restartCount
                output = $Output
                session = $SessionPath
                profile = $ProfilePath
            } | ConvertTo-Json -Depth 5

            Wait-Process -Id $process.Id -ErrorAction SilentlyContinue
            $process.Refresh()
            if ($process.HasExited) {
                $exitCode = $process.ExitCode
            }
            Write-SupervisorLog "mitmdump exited attempt=$restartCount exit_code=$exitCode"
        } catch {
            $attemptError = $_.Exception.Message
            Write-SupervisorLog "attempt=$restartCount failed: $attemptError"
            if ($process -and -not $process.HasExited) {
                & taskkill.exe /PID $process.Id /T /F | Out-Null
            }
        } finally {
            Restore-ProxifierDirect
        }

        if (Test-Path -LiteralPath $StopMarkerPath) {
            break
        }

        [ordered]@{
            started_at = $supervisorStartedAt
            state = "restarting"
            supervisor_pid = $PID
            cmd_pid = if ($process) { $process.Id } else { 0 }
            listen_port = $ProxyPort
            restart_count = $restartCount
            last_exit_at = (Get-Date).ToString("o")
            last_exit_code = $exitCode
            last_error = $attemptError
            output = $Output
            stdout_log = $StdoutLog
            stderr_log = $StderrLog
            supervisor_log = $SupervisorLogPath
            profile = $ProfilePath
            direct_profile = $DirectProfilePath
            stop_marker = $StopMarkerPath
        } | ConvertTo-Json | Set-Content -Encoding UTF8 -Path $SessionPath

        $restartCount += 1
        $delaySeconds = [Math]::Min(30, 3 * $restartCount)
        Write-SupervisorLog "restart scheduled in ${delaySeconds}s"
        for ($i = 0; $i -lt $delaySeconds; $i++) {
            if (Test-Path -LiteralPath $StopMarkerPath) {
                break
            }
            Start-Sleep -Seconds 1
        }
    }
} finally {
    Restore-ProxifierDirect
    Write-SupervisorLog "supervisor stopped"
}
