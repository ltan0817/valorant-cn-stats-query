# WGame VAL Query 本地部署版

这是一个只在本机运行的源码交付包。默认服务只监听 `127.0.0.1`，不会连接项目
维护者的域名、远程服务器或 token 中继。

## 快速开始

1. Windows 10/11 安装 Python 3.10+ 与 Google Chrome。
2. 双击 `install-dependencies.cmd` 安装 Python 依赖。
3. 双击 `start-local.cmd`。
4. 在自动打开的专用 Chrome 中登录 WeGame。
5. 使用以下本机入口：

   - 战绩查询：`http://127.0.0.1:8787/public`
   - 实时对局：`http://127.0.0.1:8787/live`

查询输入格式为完整的 `昵称#数字ID`。公开查询只加载排位数据。

## 可选：读取自己的当前对局

此功能需要 mitmproxy 10+ 和 Proxifier，并会读取本机游戏网络流量。请先完整阅读
`docs/INSTALL.md` 与 `docs/SECURITY.md`，确认风险后再运行
`code/start-proxifier-capture.ps1`。结束时运行
`code/stop-proxifier-capture.ps1` 恢复直连配置。

## 文档

- `docs/INSTALL.md`：安装与启动
- `docs/ARCHITECTURE.md`：本地实现流程
- `docs/API.md`：适合二次开发的本地接口
- `docs/DEBUGGING.md`：常见故障与检查命令
- `docs/SECURITY.md`：数据、网络与发布边界

## 隐私

运行后产生的 `code/data/`、`code/captures/`、`code/pages/` 以及 Chrome profile
可能包含登录态、玩家标识或网络请求记录。不要上传、分享或提交这些目录。

本项目是非官方社区工具，与游戏运营方无隶属或授权关系。
