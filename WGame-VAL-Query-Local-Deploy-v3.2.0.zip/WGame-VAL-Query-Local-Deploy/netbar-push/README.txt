WGame VAL Token Push - 使用说明
================================

两种使用场景:
  1. 网吧个人用 (无 Proxifier, 系统代理模式)
  2. 给队友提供服务 (有 Proxifier, 进程拦截模式)


首次使用 (必做)
----------------
1. 双击 setup.cmd
   -> 自动下载便携版 mitmproxy 到 mitmproxy/ 子目录
   -> 只需做一次

2. 在家里电脑的控制中心 (http://127.0.0.1:8788) → 推送 Token 管理
   -> 点击"新建 Token", 填备注(如 user-zhangsan)
   -> 复制生成的完整 Token
   -> 把 Token 填入本目录 config.ini 的 [push] token =

3. (可选) 修改 config.ini 的 [push] source 为队友标识


场景1: 网吧个人用
-----------------
1. 把整个 netbar-push/ 文件夹拷到网吧电脑
2. 双击 start-netbar.cmd
   -> 自动请求管理员权限 (点"是")
   -> 自动安装 CA 证书
   -> 自动设置系统代理
   -> 启动 mitmproxy 抓包推送
3. 正常打开 WeGame / 游戏
4. 用完后按 Ctrl+C 自动恢复网络
5. (可选) 如果自动恢复失败, 双击 restore.cmd


场景2: 给队友提供服务
---------------------
1. 队友电脑需先安装 Proxifier (付费软件)
2. 编辑 config.ini:
   -> [push] token = 在控制中心生成的队友专属口令
   -> [push] source = 队友标识 (如 user-zhangsan)
3. 双击 start-user.cmd
   -> 自动安装 CA 证书
   -> 自动启动 Proxifier (加载预置 netbar-capture.ppx, 拦截 VALORANT.exe / RiotClient*.exe)
   -> 启动 mitmproxy 抓包推送
4. 用完后按 Ctrl+C 自动恢复
5. (可选) 双击 restore.cmd 手动恢复


文件说明
--------
setup.cmd          首次运行: 下载 mitmproxy
start-netbar.cmd   网吧模式启动 (系统代理)
start-user.cmd     队友模式启动 (Proxifier)
restore.cmd        恢复网络 + 清理证书
config.ini         配置文件 (推送口令、来源标签、推送端点)
push_addon.py      mitmproxy 推送插件 (自动调用, 不用管)
run.ps1            主逻辑脚本 (自动调用, 不用管)
restore.ps1        恢复逻辑脚本 (自动调用, 不用管)
netbar-capture.ppx 预置 Proxifier 配置 (VALORANT→8083, ACE/WeGame 直连)
mitmproxy/         便携版 mitmproxy (setup 后生成)
.mitmproxy/        CA 证书目录 (首次运行后生成)


注意事项
--------
- 管理员权限: 证书安装和代理设置需要管理员权限, 点"是"即可
- Vanguard 风险: 游戏反作弊可能检测到 MITM, 导致 VAL29/VAL59 踢出
  这与旧 VPS 方式风险相同, 非新问题
- Token 有效期: 游戏 token 约1小时过期, 保持抓包运行即可自动续推
- 恢复网络: 用完务必恢复, 否则代理残留会影响其他程序上网
- 口令管理: 每个队友使用独立口令, 管理员可在控制中心按 IP 封禁
