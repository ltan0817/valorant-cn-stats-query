﻿#requires -Version 5.1
<# setup.ps1 - download portable mitmproxy to mitmproxy/ subfolder #>
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MitmDir = Join-Path $ScriptDir "mitmproxy"

if (Test-Path (Join-Path $MitmDir "mitmdump.exe")) {
    Write-Host "[OK] mitmproxy already exists, skip download" -ForegroundColor Green
    Read-Host "Press Enter to exit"
    exit 0
}

$ProgressPreference = 'SilentlyContinue'

# Get latest version from GitHub API, then download from mitmproxy CDN
Write-Host "Fetching latest mitmproxy version..." -ForegroundColor Cyan
$version = $null
try {
    $release = Invoke-RestMethod "https://api.github.com/repos/mitmproxy/mitmproxy/releases/latest" -TimeoutSec 15 -Headers @{ "User-Agent" = "netbar-push-setup" }
    $version = $release.tag_name -replace "^v", ""
    Write-Host "Latest version: $version" -ForegroundColor Cyan
} catch {
    Write-Host "[!] GitHub API failed: $_" -ForegroundColor Yellow
}

if (-not $version) {
    $version = "12.2.3"
    Write-Host "Using fallback version: $version" -ForegroundColor Yellow
}

# Try CDN URL patterns
$urls = @(
    "https://downloads.mitmproxy.org/$version/mitmproxy-$version-windows-x86_64.zip",
    "https://downloads.mitmproxy.org/$version/mitmproxy-$version-windows.zip"
)

$url = $null
foreach ($u in $urls) {
    try {
        $resp = Invoke-WebRequest $u -Method Head -TimeoutSec 10 -ErrorAction Stop
        if ($resp.StatusCode -eq 200) {
            $url = $u
            $sizeMB = [math]::Round([int64]$resp.Headers["Content-Length"] / 1MB, 1)
            Write-Host "Found: $url ($sizeMB MB)" -ForegroundColor Cyan
            break
        }
    } catch {}
}

if (-not $url) {
    Write-Host "[!] Cannot find download URL" -ForegroundColor Red
    Write-Host "    Please download manually from https://mitmproxy.org/downloads/" -ForegroundColor Cyan
    Write-Host "    Extract to mitmproxy/ subfolder (ensure mitmproxy\mitmdump.exe exists)" -ForegroundColor Cyan
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "Downloading..." -ForegroundColor Cyan
$zip = Join-Path $env:TEMP "mitmproxy-windows.zip"
Invoke-WebRequest $url -OutFile $zip -TimeoutSec 300

Write-Host "Extracting to mitmproxy/..." -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $MitmDir | Out-Null
Expand-Archive $zip -DestinationPath $MitmDir -Force
Remove-Item $zip -Force

# Find and flatten mitmdump.exe
$mitmdump = Get-ChildItem -Path $MitmDir -Recurse -Filter "mitmdump.exe" | Select-Object -First 1
if ($mitmdump) {
    if ($mitmdump.DirectoryName -ne $MitmDir) {
        Get-ChildItem $mitmdump.DirectoryName | Move-Item -Destination $MitmDir -Force
    }
    Write-Host "[OK] mitmproxy ready: $MitmDir\mitmdump.exe" -ForegroundColor Green
    Get-ChildItem $MitmDir -Name | ForEach-Object { Write-Host "  $_" }
} else {
    Write-Host "[!] mitmdump.exe not found after extraction" -ForegroundColor Red
}

Read-Host "Press Enter to exit"
