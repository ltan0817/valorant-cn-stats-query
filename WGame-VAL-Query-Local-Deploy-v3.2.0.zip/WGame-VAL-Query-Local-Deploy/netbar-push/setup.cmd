@echo off
cd /d "%~dp0"
echo === mitmproxy setup ===
powershell -NoProfile -ExecutionPolicy Bypass -File "setup.ps1"
