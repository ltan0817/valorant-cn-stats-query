﻿#requires -Version 5.1
<# restore.ps1 - restore network settings after capture #>
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

Write-Host "==== WGame VAL Restore ====" -ForegroundColor Cyan

# Stop mitmdump
$mitmProcs = Get-Process mitmdump -ErrorAction SilentlyContinue
if ($mitmProcs) {
    $mitmProcs | Stop-Process -Force -ErrorAction SilentlyContinue
    Write-Host "[OK] Stopped mitmdump" -ForegroundColor Green
} else {
    Write-Host "[--] mitmdump not running" -ForegroundColor Gray
}

# Stop Proxifier
$proxProcs = Get-Process Proxifier -ErrorAction SilentlyContinue
if ($proxProcs) {
    $proxProcs | Stop-Process -Force -ErrorAction SilentlyContinue
    Write-Host "[OK] Stopped Proxifier" -ForegroundColor Green
} else {
    Write-Host "[--] Proxifier not running" -ForegroundColor Gray
}

# Reset system proxy
Write-Host "[..] Resetting system proxy..." -ForegroundColor Yellow
netsh winhttp reset proxy
$reg = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
Set-ItemProperty -Path $reg -Name ProxyEnable -Value 0 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty -Path $reg -Name ProxyServer -Value "" -Type String -ErrorAction SilentlyContinue
Remove-ItemProperty -Path $reg -Name AutoConfigURL -ErrorAction SilentlyContinue
Remove-ItemProperty -Path $reg -Name ProxyOverride -ErrorAction SilentlyContinue

$sig = '[DllImport("wininet.dll", SetLastError=true)] public static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int dwBufferLength);'
if (-not ("WinINet.Native" -as [type])) { Add-Type -Namespace WinINet -Name Native -MemberDefinition $sig }
[void][WinINet.Native]::InternetSetOption([IntPtr]::Zero, 39, [IntPtr]::Zero, 0)
[void][WinINet.Native]::InternetSetOption([IntPtr]::Zero, 37, [IntPtr]::Zero, 0)
Write-Host "[OK] System proxy reset" -ForegroundColor Green

# Clean env vars
$env:http_proxy = $null; $env:https_proxy = $null
$env:no_proxy = $null; $env:NO_PROXY = $null
$env:WGVAL_PUSH_TOKEN = $null; $env:WGVAL_PUSH_SOURCE = $null
Write-Host "[OK] Env vars cleaned" -ForegroundColor Green

# Remove mitmproxy CA cert
$CaCertPath = Join-Path $ScriptDir ".mitmproxy\mitmproxy-ca-cert.cer"
if (Test-Path $CaCertPath) {
    try {
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($CaCertPath)
        $store = New-Object System.Security.Cryptography.X509Certificates.X509Store("Root", "LocalMachine")
        $store.Open("ReadWrite")
        $existing = $store.Certificates | Where-Object { $_.Thumbprint -eq $cert.Thumbprint }
        if ($existing) {
            $store.Remove($existing)
            Write-Host "[OK] Removed CA cert" -ForegroundColor Green
        } else {
            Write-Host "[--] CA cert not in store" -ForegroundColor Gray
        }
        $store.Close()
    } catch {
        Write-Host "[!] CA removal failed: $_" -ForegroundColor Yellow
    }
} else {
    Write-Host "[--] CA cert file not found" -ForegroundColor Gray
}

# Flush DNS
ipconfig /flushdns | Out-Null
Write-Host "[OK] DNS flushed" -ForegroundColor Green

Write-Host ""
Write-Host "==== Restore complete ====" -ForegroundColor Cyan
Write-Host "Restart WeGame / Riot Client / VALORANT" -ForegroundColor Yellow

# If called from run.ps1 (finally block), don't pause
if (-not $MyInvocation.ScriptName.EndsWith("run.ps1")) {
    Write-Host ""
    Read-Host "Press Enter to exit"
}
