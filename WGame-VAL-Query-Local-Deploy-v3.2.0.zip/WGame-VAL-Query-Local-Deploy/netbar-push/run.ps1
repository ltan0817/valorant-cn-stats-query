﻿#requires -Version 5.1
<#
.SYNOPSIS
  netbar-push main runner (called by start-netbar.cmd / start-user.cmd)

.PARAMETER Mode
  netbar - system proxy mode (no Proxifier needed)
  user   - Proxifier mode (needs Proxifier installed)
#>
param(
    [ValidateSet("netbar", "user")]
    [string]$Mode = "netbar"
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$AddonPath = Join-Path $ScriptDir "push_addon.py"
$ConfigPath = Join-Path $ScriptDir "config.ini"
$MitmDir = Join-Path $ScriptDir "mitmproxy"
$ConfDir = Join-Path $ScriptDir ".mitmproxy"
$CaCertPath = Join-Path $ConfDir "mitmproxy-ca-cert.cer"

# ---- Admin elevation ----
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "Requesting admin..." -ForegroundColor Yellow
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Mode $Mode"
    exit
}

# ---- Parse config.ini ----
function Get-IniValue($file, $section, $key) {
    if (-not (Test-Path $file)) { return $null }
    $lines = Get-Content $file -Encoding UTF8
    $inSection = $false
    foreach ($line in $lines) {
        $line = $line.Trim()
        if ($line -match "^\[(.+)\]$") {
            $inSection = ($matches[1] -eq $section)
            continue
        }
        if ($inSection -and $line -match "^([^=]+)=(.*)$") {
            if ($matches[1].Trim() -eq $key) { return $matches[2].Trim() }
        }
    }
    return $null
}

$pushToken = Get-IniValue $ConfigPath "push" "token"
$pushSource = Get-IniValue $ConfigPath "push" "source"
if (-not $pushSource) { $pushSource = if ($Mode -eq "user") { "user-proxifier" } else { "netbar" } }
$pushUrl = Get-IniValue $ConfigPath "push" "url"
if (-not $pushUrl) { $pushUrl = "http://127.0.0.1:8787/api/push-game-token" }

# 端口固定 8084, 与预置 netbar-capture.ppx 保持一致 (避开本机 8083 游戏抓包)
$proxyPort = 8084

# ---- Find mitmdump ----
function Find-Mitmdump {
    $local = Join-Path $MitmDir "mitmdump.exe"
    if (Test-Path $local) { return $local }
    $cmd = Get-Command mitmdump -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

$Mitmdump = Find-Mitmdump
if (-not $Mitmdump) {
    Write-Host "[ERROR] mitmdump not found!" -ForegroundColor Red
    Write-Host "Run setup.cmd first to download portable mitmproxy." -ForegroundColor Cyan
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host "[OK] mitmdump: $Mitmdump" -ForegroundColor Green

# ---- Push token ----
if (-not $pushToken) {
    Write-Host ""
    Write-Host "Push token not set in config.ini" -ForegroundColor Yellow
    Write-Host "Get it from: 控制中心 → 推送 Token 管理 → 新建 Token" -ForegroundColor Cyan
    $pushToken = Read-Host "Enter push token"
    if ($pushToken) {
        # Save to config.ini for next time
        $content = Get-Content $ConfigPath -Encoding UTF8 -Raw
        $content = $content -replace "(?<=token\s*=\s*)", $pushToken
        Set-Content $ConfigPath -Encoding UTF8 -Value $content
        Write-Host "[OK] Token saved to config.ini" -ForegroundColor Green
    }
}
if (-not $pushToken) {
    Write-Host "[ERROR] Token is required" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# ---- Port check ----
$existing = Get-NetTCPConnection -LocalPort $proxyPort -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($existing) {
    throw "Port $proxyPort in use (PID $($existing.OwningProcess)). Stop old capture or change port in config.ini"
}

# ---- Generate CA cert (first run) ----
if (-not (Test-Path $CaCertPath)) {
    Write-Host "[..] Generating mitmproxy CA cert..." -ForegroundColor Yellow
    New-Item -ItemType Directory -Force -Path $ConfDir | Out-Null
    $p = Start-Process -FilePath $Mitmdump -ArgumentList "--listen-port",$proxyPort,"--set","confdir=$ConfDir","--no-server","-q" -PassThru -WindowStyle Hidden
    Start-Sleep -Seconds 3
    $p | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
}
if (Test-Path $CaCertPath) {
    Write-Host "[OK] CA cert: $CaCertPath" -ForegroundColor Green
} else {
    Write-Host "[!] CA cert not generated yet, mitmdump will create it on start" -ForegroundColor Yellow
}

# ---- Install CA cert ----
Write-Host "[..] Installing CA cert to Windows root store..." -ForegroundColor Yellow
if (Test-Path $CaCertPath) {
    certutil -addstore -f Root $CaCertPath 2>$null | Out-Null
    Write-Host "[OK] CA cert installed" -ForegroundColor Green
}

# ---- Set env for addon ----
$env:WGVAL_PUSH_TOKEN = $pushToken
$env:WGVAL_PUSH_SOURCE = $pushSource
$env:WGVAL_PUSH_URL = $pushUrl

# ---- Mode: system proxy ----
function Set-SystemProxy {
    Write-Host "[..] Setting system proxy -> 127.0.0.1:$proxyPort" -ForegroundColor Yellow
    netsh winhttp set proxy "127.0.0.1:$proxyPort"
    $reg = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
    Set-ItemProperty -Path $reg -Name ProxyEnable -Value 1 -Type DWord
    Set-ItemProperty -Path $reg -Name ProxyServer -Value "127.0.0.1:$proxyPort" -Type String
    Set-ItemProperty -Path $reg -Name ProxyOverride -Value "<local>" -Type String
    $sig = '[DllImport("wininet.dll", SetLastError=true)] public static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int dwBufferLength);'
    if (-not ("WinINet.Native" -as [type])) { Add-Type -Namespace WinINet -Name Native -MemberDefinition $sig }
    [void][WinINet.Native]::InternetSetOption([IntPtr]::Zero, 39, [IntPtr]::Zero, 0)
    [void][WinINet.Native]::InternetSetOption([IntPtr]::Zero, 37, [IntPtr]::Zero, 0)
    Write-Host "[OK] System proxy set" -ForegroundColor Green
}

# ---- Mode: Proxifier ----
function Start-ProxifierMode {
    $ProfilePath = Join-Path $ScriptDir "netbar-capture.ppx"
    if (-not (Test-Path $ProfilePath)) {
        throw "Proxifier profile not found: $ProfilePath"
    }

    # 自动查找 Proxifier.exe (不再从 config.ini 读取路径)
    $proxifierPath = $null
    $candidates = @(
        "C:\Program Files (x86)\Proxifier\Proxifier.exe",
        "C:\Program Files\Proxifier\Proxifier.exe"
    )
    foreach ($c in $candidates) { if (Test-Path $c) { $proxifierPath = $c; break } }
    if (-not $proxifierPath) {
        $cmd = Get-Command Proxifier.exe -ErrorAction SilentlyContinue
        if ($cmd) { $proxifierPath = $cmd.Source }
    }
    if (-not $proxifierPath) {
        throw "Proxifier not found. Install Proxifier or use netbar mode (start-netbar.cmd)."
    }

    Start-Process -FilePath $proxifierPath -ArgumentList $ProfilePath
    Start-Sleep -Seconds 2
    Write-Host "[OK] Proxifier started (profile: netbar-capture.ppx, proxy: 127.0.0.1:$proxyPort)" -ForegroundColor Green
}

# ---- Execute mode ----
if ($Mode -eq "netbar") {
    Set-SystemProxy
} else {
    Start-ProxifierMode
}

# ---- Start mitmdump ----
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Capture started" -ForegroundColor Cyan
Write-Host " Mode: $Mode" -ForegroundColor Cyan
Write-Host " Proxy: 127.0.0.1:$proxyPort" -ForegroundColor Cyan
Write-Host " Push:  $pushUrl" -ForegroundColor Cyan
Write-Host " Source: $pushSource" -ForegroundColor Cyan
Write-Host " Press Ctrl+C to stop and restore" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

try {
        & $Mitmdump --mode socks5 --listen-port $proxyPort --set "confdir=$ConfDir" -s $AddonPath
} finally {
    Write-Host ""
    Write-Host "[..] Restoring network..." -ForegroundColor Yellow
    & (Join-Path $ScriptDir "restore.ps1")
}
