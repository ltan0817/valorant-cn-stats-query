@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "restore.ps1"
pause
