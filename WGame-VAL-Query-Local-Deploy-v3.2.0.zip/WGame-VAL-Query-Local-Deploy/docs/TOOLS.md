# 离线采集与分析工具

`code/tools/` 下的工具不参与 8787/8788 在线服务，用于批量历史与组队分析。

## collect_wegame_history.py

分页采集历史战绩（每页 10 场，`after` 游标翻页），支持断点续跑、限速、冷却。

```powershell
python tools\collect_wegame_history.py `
  --subject <subject> --display-name "昵称#ID" `
  --output-dir .\out --delay 3 --batch-pages 7 --cooldown 45 --max-pages 100
```

输出：`matches.raw.json`、`matches.csv`、`ranked.csv`、`history.html`、
`by-month/`、`README.md`、断点 `matches.checkpoint.json`。

## collect_match_rosters.py

为每场补采双方阵容，并按同一 `matchId/apEventId` 对齐各玩家记录、读取
`partyId`。

```powershell
python tools\collect_match_rosters.py `
  --source .\out\matches.raw.json --output .\out\rosters.json `
  --target-subject <subject> --target-name "昵称#ID" --limit 100 `
  --player-delay 0.5 --match-delay 2.5 --retries 3
```

## build_detailed_party_report.py

生成逐场玩家与组队分析报告（HTML/CSV/JSON/说明）。

```powershell
python tools\build_detailed_party_report.py `
  --raw-matches .\out\matches.raw.json --rosters .\out\rosters.json `
  --output-dir .\report --target-name "昵称#ID" --limit 100 --allow-partial --overwrite
```

## build_party_showcase.py

把真实报告匿名化为公共示例。只替换昵称与内部 ID，仍保留时间/比分等结构，
发布前必须人工复核。

```powershell
python tools\build_party_showcase.py --source .\report\分析数据.json --output .\demo.html
```

## 隐私

工具输出包含真实玩家标识（subject、matchId、apEventId、partyId），只能放在
私密目录；公开前必须匿名化并人工检查。

## 掌瓦证书安装（可选）

`code/tools/install-mval-cert.py` 用于把本机 mitmproxy 证书安装到 Android
模拟器系统证书目录（掌瓦属地功能可选）。脚本已脱敏：ADB 从 PATH 或
`ADB_PATH` 环境变量读取，证书路径默认为当前用户的 `.mitmproxy` 目录。
历史的一次性调试脚本（Frida/SSL unpin 等）不随包分发。
