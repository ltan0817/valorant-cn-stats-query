# 面向开发者 / AI 的数据接入指南

本文描述“如何从本服务拿到数据”：调用流程、参数、可用字段和限制。适合想要
二次开发或让 AI 助手自动接数的场景。

## 总体流程

```text
昵称#数字ID
  -> 解析 subject（内部玩家标识）
  -> GetBattleList（近期战绩，按时间倒序）
  -> 选择 apEventId（单局标识）
  -> GetBattleDetail / GetMatchup（10 人详情）
  -> 可选：离线批量采集 + 阵容 + PartyID 组队分析
```

## 第 1 步：昵称到 subject

- 本地缓存：`code/data/subjects.sqlite3`（表 `subjects`：
  `key / display_name / subject / source / updated_at`）；
- 在线解析：`GET /api/qq-summary?q=昵称%23ID` 会返回 `subject`；
- 新鲜解析依赖游戏侧 token（本机抓包或游戏在线），失败时接口返回明确错误。

subject 是 UUID，示例：`00000000-0000-0000-0000-000000000000`。不要把它当作
昵称展示给最终用户。

## 第 2 步：拉取近期战绩

推荐直接使用本服务接口，而不是自己重放 WeGame 接口（登录态/环境校验会拦截）。

```powershell
curl.exe "http://127.0.0.1:8787/api/qq-summary?q=示例玩家%2312345&limit=10"
```

结构化数据在 `battles[]`，字段见 `docs/API.md`。核心字段：

| 字段 | 含义 |
| --- | --- |
| `dtEventTime` | 对局时间（倒序） |
| `apEventId` | 单局详情标识 |
| `queueId` | 模式（`competitive` 为排位） |
| `mapId` / `characterId` | 地图 / 英雄 |
| `wonMatch` | 胜负 |
| `statsKills/Deaths/Assists` | KDA |
| `roundsWon/Played` | 比分 |
| `competitiveTier` | 段位 |
| `CompetitiveTierRankedRatingEarned` | RR 变化 |
| `partyId` | 组队标识（部分接口返回） |

## 第 3 步：单局详情

`GetBattleDetail` 正常时返回 10 人；返回 `8000009` 时服务端自动用
`GetMatchup` 取阵容，再逐玩家 `GetBattleList(size=50)` 按 `apEventId` 对齐重建。

详情玩家字段：`subject`、`name`、`teamId`、`characterId`、`partyId`、
`statsKills/Deaths/Assists`、`statsScore`、`roundsPlayed`、`wonMatch`、
`competitiveTier`、`rankedRatingEarned`、`recordResolved`、`isTarget`、
`isTargetParty`。

限制：

- 上游对部分历史局不放行详情；
- 隐私玩家可能查不到记录；
- 连续请求过快会触发限流（空响应），请控制间隔。

## 第 4 步：实时对局（本机）

只有本机游戏流量经 8083 抓包后才能使用：

```text
GET /api/live-sessions
GET /api/current-room-teammates?session=<id>
GET /api/current-room-status?session=<id>
GET /api/task/<taskId>
```

实时接口要求使用“正在对局账号”自己的 token；他人 token 会被上游拒绝
（`NONSELF_OPERATION`）。

## 第 5 步：离线批量采集与组队分析

需要超过 10 场的历史数据时，使用 `code/tools/`（详见 `docs/TOOLS.md`）：

```powershell
python code\tools\collect_wegame_history.py --subject <subject> --display-name "昵称#ID" --output-dir .\out
python code\tools\collect_match_rosters.py --source .\out\matches.raw.json --output .\out\rosters.json --target-subject <subject> --target-name "昵称#ID" --limit 100
python code\tools\build_detailed_party_report.py --raw-matches .\out\matches.raw.json --rosters .\out\rosters.json --output-dir .\report --target-name "昵称#ID" --limit 100 --allow-partial --overwrite
```

组队判定：同一场、同阵营、相同非空 `partyId` 为“确定组队”；完整阵容且无相同
`partyId` 为“确定单排”（反证）。公开示例必须走 `build_party_showcase.py`
匿名化并人工复核。

## 数据可用性限制

- 单页最多 10 场，批量靠 `after` 游标翻页，遇到空列表即上游可见历史末尾；
- 查询依赖专用 Chrome 的 WeGame 登录态（健康时 30 分钟刷新，异常时 30 秒重试）；
- 昵称搜索一次最多 500 条且无分页，不能证明同名全集；
- “暂未获取段位”可能是限流，不等于未定级；
- 所有真实数据只在本机；不要提交 `data/`、`captures/`、`pages/`。

## 二次开发建议

- 优先复用主服务提供的 HTTP 接口和 `browser_context_query()`，不要裸调
  WeGame API；
- 异步任务返回 `task_id` 后轮询 `/api/task/<id>`，不要阻塞主线程；
- 展示层只接收脱敏结构，不向前端输出 subject、apEventId、Cookie 或抓包内容；
- 修改代码后执行 `python -m compileall -q code`。
