# 本地接口

基准地址：

```text
http://127.0.0.1:8787
```

本文只列出适合本地使用和二次开发的接口，不包含维护者的公网运维接口。
管理类接口本地可直接访问；如需口令，`k` 参数值见 `docs/CONFIG.md`。

## 页面

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/public` | 查询首页 |
| GET | `/public-query?q=<昵称%23数字ID>` | 近期排位结果页 |
| GET | `/query?q=<昵称%23ID或subject>` | 本地内部查询页 |
| GET | `/battle?subject=<subject>&apEventId=<事件ID>` | 单局详情页 |
| GET | `/live` | 本机实时对局页 |
| GET | `/teammates-live` | 房间/匹配队友近 3 场页 |
| GET | `/party-analysis-demo` | 匿名组队分析示例 |
| GET | `/privacy` | 隐私说明 |
| GET | `/launch-chrome` | 启动或激活专用 Chrome |

## 战绩与详情接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/qq-summary?q=<昵称%23ID>&limit=5` | QQ 文本摘要，返回 `reply` |
| GET | `/api/wegame-session-status` | 专用 Chrome 与登录态状态 |
| GET | `/api/recent-cache` | 最近缓存表格 HTML |
| GET | `/api/public/battle-detail?ref=<引用>` | 结果页单局详情片段 |
| GET | `/assets/agent-icon/<agent-id>.png` | 英雄头像缓存 |
| GET | `/assets/map-art/<map-key>.png` | 地图图片缓存 |

`/api/qq-summary` 请求示例：

```powershell
curl.exe "http://127.0.0.1:8787/api/qq-summary?q=示例玩家%2312345&limit=5"
```

响应字段：`ok`、`query`、`subject`、`record`（如 `3胜 2负`）、`reply`（可直接
发送的文本）、`battles[]`（结构化战绩）。

单局详情结果页使用短期随机引用，浏览器不直接接触 subject 与事件 ID；引用
默认 30 分钟有效，服务重启后失效属于预期行为。

## 实时对局接口（本机）

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/live-sessions` | 本机抓包产生的实时会话列表 |
| GET | `/api/current-room-teammates?session=<id>` | 房间成员 + 匹配队友近 3 场任务 |
| GET | `/api/current-room-status?session=<id>` | 房间/匹配状态与成员签名 |
| GET | `/api/task/<taskId>` | 异步任务轮询 |
| GET | `/api/task/<taskId>/save` | 保存页面快照 |

实时会话只来自本机 `captures/proxifier-game-*.jsonl` 与历史
`pushed-game-token-*.jsonl`，来源为 `local-capture`。

## 推送与掌瓦（可选）

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/api/push-game-token?k=<token>` | 接收游戏侧 token（多用户 token 校验） |
| POST | `/api/mval/session/upsert` | 接收掌瓦登录态（属地用） |

`/api/push-game-token` 请求体示例：

```json
{
  "source": "local-capture:127.0.0.1",
  "headers": {
    "Authorization": "Bearer <占位>",
    "X-Riot-Entitlements-JWT": "<占位>",
    "X-Riot-ClientVersion": "<占位>",
    "X-Riot-ClientPlatform": "<占位>",
    "User-Agent": "<占位>"
  }
}
```

## 管理接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/api/admin/name-search` | 精确昵称搜索全部 `#ID` |
| GET | `/api/admin/name-search-ranks?task=<id>` | 轮询段位任务 |
| POST | `/api/admin/name-search-page-game-times` | 当前页最近游戏时间 |
| GET | `/admin/name-search` | 管理搜索页 |
| GET | `/admin/live` | 全部本机实时会话页 |

## 控制中心接口（8788）

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/ping` | 轻量存活检查 |
| GET | `/api/status` | 组件状态快照 |
| POST | `/api/component/<key>/<start|stop|restart>` | 组件操作 |
| GET | `/audit` | 本地访问审计页 |

## 战绩字段说明

`GetBattleList` 返回的每场对局包含：`dtEventTime`（时间）、`apEventId`、
`matchId`、`queueId`、`mapId`、`characterId`、`wonMatch`、`statsKills` /
`statsDeaths` / `statsAssists`、`roundsWon` / `roundsPlayed`、
`competitiveTier`、`CompetitiveTierBefore/After`、
`CompetitiveTierRankedRatingEarned`、`isTeamMvp` / `isMatchMvp`、
`firstKillCount` / `quadraKillCount` / `pentaKillCount`、`gameLengthMillis`、
`partyId`（可用时）。

## 错误约定

- `200`：请求成功或页面正常渲染
- `400`：输入格式错误
- `403`：本地保护或风险协议未满足
- `404`：路径或短期引用不存在
- `429`：请求过快
- `503`：WeGame 登录态或上游服务暂时不可用
- `8025004`：WeGame 登录信息过期，需要在专用 Chrome 重新登录
- `8000009`：单局详情受限，会走 `GetMatchup` 重建
- `8000120 / 8000102`：登录态/环境校验失败，应使用浏览器同源链路

二次开发时不要把内部标识、Cookie、Authorization 或抓包内容返回给前端。
