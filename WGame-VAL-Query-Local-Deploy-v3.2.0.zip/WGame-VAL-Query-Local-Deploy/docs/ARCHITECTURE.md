# 本地架构与实现流程

## 组件

| 组件 | 端口 | 职责 |
| --- | --- | --- |
| `wgame_query_server.py` | 8787 | 页面、API、战绩查询、实时任务、缓存 |
| `ops_control_center.py` | 8788 | 本机组件状态、启停、审计 |
| 专用 Chrome | 9223 | WeGame 登录态与同源查询 |
| `current_match_probe.py` | - | 读取抓包、探测房间/对局 |
| `wegame_mitm_capture.py` | 8083 | 本机游戏抓包 addon |
| `frp_auth_proxy.py` | 8790 | 本地可选鉴权代理 |
| `tools/*.py` | - | 离线历史采集与组队分析 |

## 战绩查询

```text
浏览器 -> http://127.0.0.1:8787/public
  -> wgame_query_server.py
  -> 专用 Chrome CDP 127.0.0.1:9223
  -> 已登录的 WeGame 页面环境
  -> 昵称解析、排位列表、按需单局详情
  -> 本机 HTML 结果
```

服务通过专用 Chrome 的登录态发起同源查询。直接请求不可用时，会回退到浏览器
页面环境；两个列表路径都只请求竞技排位，不使用普通匹配结果填充。

## 当前对局（可选）

```text
本机游戏流量 -> Proxifier 规则 -> mitmproxy 127.0.0.1:8083
  -> wegame_mitm_capture.py -> code/captures/*.jsonl
  -> current_match_probe.py -> http://127.0.0.1:8787/live
```

抓包链路只读取当前电脑的数据。本发布包不含公网隧道、远程推送或公网鉴权代理。

## 本地存储

| 路径 | 用途 |
| --- | --- |
| `code/data/subjects.sqlite3` | 昵称、数字 ID 与内部玩家标识缓存 |
| `code/data/usage_audit.sqlite3` | 本地访问审计 |
| `code/data/push-tokens.json` | 本地推送 token（可选） |
| `code/data/chrome-profile/` | 专用 Chrome 登录态 |
| `code/data/agent-icons/`、`map-art/` | 素材缓存 |
| `code/captures/` | 可选抓包记录 |
| `code/pages/` | 本地生成页面 |

这些目录是运行数据，不属于源码，也不应进入公开仓库。
