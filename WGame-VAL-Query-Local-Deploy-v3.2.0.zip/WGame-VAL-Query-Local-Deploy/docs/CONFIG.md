# 配置文件与需要修改的地方

本地包的所有默认值已经指向 `127.0.0.1`，通常解压后即可运行。以下内容仅在
需要调整行为时修改。

## 1. 端口

| 服务 | 默认端口 | 修改方式 |
| --- | --- | --- |
| 主查询服务 | `8787` | `python code\wgame_query_server.py --port <端口>` |
| 控制中心 | `8788` | `python code\ops_control_center.py --port <端口>` |
| 专用 Chrome | `9223` | 代码常量 `CHROME_PORT` |
| 游戏抓包 | `8083` | `start-proxifier-capture.ps1 -ProxyPort <端口>` |
| 掌瓦抓包（可选） | `8081` | 外部脚本 |

## 2. 环境变量

在运行服务的 PowerShell 中设置，或参考根目录
`config-examples/local.env.example` 创建自己的环境文件：

| 变量 | 作用 | 默认 |
| --- | --- | --- |
| `WGAME_AUDIT_RETENTION_DAYS` | 本地审计保留天数 | `180` |
| `ADB_PATH` | 掌瓦模拟器 adb 可执行文件路径 | `adb`（PATH 查找） |
| `MVAL_SESSION_PUSH_URL` | 掌瓦 session 推送目标 | 本机 8787 |
| `FRP_DIR` | 可选 FRP 客户端目录 | `code/data/frp` |
| `FRP_CONFIG_DIR` | 可选 FRP TOML 输出目录 | `code/data/frp` |
| `FRP_SERVER_ADDR` | 可选 FRP 服务器地址 | `127.0.0.1`（占位） |
| `FRP_VAL_AUTH_TOKEN` / `FRP_VIP_AUTH_TOKEN` | 可选 FRP 认证 | 留空=禁用 |
| `WEGAME_CAPTURE_RAW` | 抓包是否保存原始 token | `0` |

## 3. 管理口令

本地主服务的管理入口默认口令为 `root`。修改方式：

1. 编辑 `code/captures/public-query-token.txt`（不存在则首次启动自动创建）；
2. 或设置环境变量让鉴权代理读取该文件；
3. 修改后重启对应服务。

注意：本地模式只绑定 `127.0.0.1`，口令仅用于本机管理页面与本地 QQ 接口。

## 4. 推送 Token（可选）

本机抓包/本地推送使用 `code/data/push-tokens.json` 校验。首次启动会自动创建
并把旧单一口令迁移为 `migrated-default`。结构参考：

```text
config-examples/push-tokens.example.json
```

为每个需要推送的用户创建独立 token，并可配置 `enabled`、`blocked_ips`、
`remark`。控制中心“推送 Token 管理”面板可完成全部操作。

## 5. Proxifier 配置模板

`config-examples/` 提供：

- `proxifier-local-capture.ppx`：抓包模板（游戏进程走 SOCKS5 127.0.0.1:8083，
  WeGame/ACE/证书敏感域名直连，默认直连）；
- `proxifier-direct.ppx`：恢复直连模板。

`start-proxifier-capture.ps1` 会在运行时自动生成等价配置，模板仅用于手工加载、
检查和排障。

## 6. FRP / Cloudflare Tunnel（可选，需自己的服务器）

本地包不包含任何公网服务器信息。控制中心的 FRP 与 Cloudflare 组件保留代码与
UI，但默认 `auto=False`、不自动恢复；如需公网访问，请使用你自己的服务器：

- FRP：参考 `config-examples/frpc.example.toml`，把占位符换成你的服务器；
- Cloudflare：自行安装 cloudflared 并修改 `CLOUDFLARED_DIR` 与组件配置。

公网暴露会显著扩大安全边界，必须自行完成 HTTPS、限流、Fail2ban 与密钥管理。
