# 远程推送工具（脱敏版）

`netbar-push/` 是在另一台电脑（网吧、队友机）上运行的小工具：抓取游戏侧
Authorization/Entitlements 等必要请求头，推送到你自己的服务端，用于实时对局。
本包只包含源码与配置模板，不包含维护者的服务器地址、真实口令或证书。

## 包含文件

| 文件 | 用途 |
| --- | --- |
| `push_addon.py` | mitmproxy 插件：提取请求头并按间隔推送 |
| `config.ini` | 用户配置（token / source / url） |
| `netbar-capture.ppx` | Proxifier 抓包模板（SOCKS5 127.0.0.1:8084） |
| `setup.cmd` / `setup.ps1` | 下载/安装 mitmproxy（本包不附带二进制） |
| `run.ps1` | 读取配置并启动 mitmdump |
| `start-user.cmd` | 用户模式一键启动 |
| `start-netbar.cmd` | 网吧模式启动 |
| `restore.cmd` / `restore.ps1` | 恢复网络代理设置 |
| `README.txt` | 原始使用说明（已脱敏） |

## 配置

编辑 `config.ini`：

```ini
[push]
token = CHANGE_ME_YOUR_PUSH_TOKEN
source = remote-user
url = http://127.0.0.1:8787/api/push-game-token
```

- `token`：在你的服务端控制中心 → 推送 Token 管理 中生成；
- `url`：本机测试用默认值；远程使用改为**你自己的服务器地址**；
- `source`：来源标签，便于区分用户。

## 使用步骤

1. 在被推送电脑上运行 `setup.cmd` 安装 mitmproxy（或自行提供）；
2. 运行 `start-user.cmd`（管理员），按提示填写配置；
3. 打开 Proxifier 并加载 `netbar-capture.ppx`，启动游戏；
4. 使用结束后运行 `restore.cmd` 恢复网络。

## 安全提示

- token 只发送到你自己的服务端，不要把真实口令写入公开位置；
- 结束使用后必须恢复 Direct 配置；ACE 反作弊域名保持直连；
- 本包不包含 mitmproxy 二进制与 CA，请使用你自己的本机 CA 并自行信任；
- 不要在其他电脑上重复使用同一口令，建议每名用户独立 token。
