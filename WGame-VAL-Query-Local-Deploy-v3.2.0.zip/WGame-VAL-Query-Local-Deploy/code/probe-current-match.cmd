@echo off
cd /d "%~dp0"
python current_match_probe.py %*
