from __future__ import annotations

import argparse
import csv
import datetime as dt
import html
import io
import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from usage_audit import (
    DEFAULT_DB_PATH as AUDIT_DB_PATH,
    audit_retention_days,
    audit_summary,
    init_audit_db,
    list_audit_events,
)


APP_DIR = Path(__file__).resolve().parent


def load_private_env(path: Path) -> None:
    """加载不进入 Git 的本机生产配置，已有环境变量优先。"""
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except FileNotFoundError:
        return
    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key:
            os.environ.setdefault(key, value.strip())


load_private_env(APP_DIR / ".private" / "frp-production.env")
CAPTURE_DIR = APP_DIR / "captures"
DATA_DIR = APP_DIR / "data"
MVAL_DIR = DATA_DIR / "mval"
FRP_DIR = Path(os.environ.get("FRP_DIR", str(DATA_DIR / "frp")))
CLOUDFLARED_DIR = Path(os.environ.get("CLOUDFLARED_DIR", str(DATA_DIR / "cloudflared")))
# frpc TOML 单独放在项目目录，避免 C:\dev\ 受 Windows Defender 受控文件夹访问
# 等机制限制导致 Python 无法原子写入临时文件。
FRP_CONFIG_DIR = Path(os.environ.get("FRP_CONFIG_DIR", str(DATA_DIR / "frp")))
ADB_PATH = Path(os.environ.get("ADB_PATH", "adb"))
PYTHON = Path(sys.executable)
OPS_LOG = CAPTURE_DIR / "ops-control-center.log"
PUBLIC_TOKEN_PATH = CAPTURE_DIR / "public-query-token.txt"
MVAL_SESSION_PATH = MVAL_DIR / "mval-session.json"
SUBJECT_DB_PATH = DATA_DIR / "subjects.sqlite3"
LOCATION_CACHE_PATH = DATA_DIR / "player_locations.json"

CONTROL_PORT = 8788
MAIN_PORT = 8787
AUTH_PORT = 8790
CHROME_PORT = 9223
MVAL_PROXY_PORT = 8081
MVAL_SESSION_PUSH_URL = os.environ.get(
    "MVAL_SESSION_PUSH_URL",
    f"http://127.0.0.1:{MAIN_PORT}/api/mval/session/upsert",
).strip()

# 健康检查配置
HEALTH_CHECK_INTERVAL = 30  # 秒
STATUS_REFRESH_INTERVAL = 10  # 秒
AUTO_RECOVER_COMPONENTS = ["main", "chrome"]  # 本地版自动恢复主服务与专用 Chrome
MAX_CONSECUTIVE_RESTARTS = 3  # 连续重启上限，防止无限重启循环
RECOVERY_COOLDOWN_SECONDS = 300
FRP_RECOVER_AFTER_FAILURES = max(
    2,
    int(os.environ.get("FRP_RECOVER_AFTER_FAILURES", "10")),
)

# ====== FRP 服务器地址（支持总开关和两条线路分别覆盖） ======
FRP_SERVER_ADDR = os.environ.get("FRP_SERVER_ADDR", "127.0.0.1")
FRP_VAL_SERVER_ADDR = os.environ.get("FRP_VAL_SERVER_ADDR", FRP_SERVER_ADDR)
FRP_VIP_SERVER_ADDR = os.environ.get("FRP_VIP_SERVER_ADDR", FRP_SERVER_ADDR)
FRP_VAL_SERVER_PORT = int(os.environ.get("FRP_VAL_SERVER_PORT", "7000"))
FRP_VIP_SERVER_PORT = int(os.environ.get("FRP_VIP_SERVER_PORT", "7001"))
FRP_VAL_AUTH_TOKEN = os.environ.get("FRP_VAL_AUTH_TOKEN", "").strip()
FRP_VIP_AUTH_TOKEN = os.environ.get("FRP_VIP_AUTH_TOKEN", "").strip()
# ================================================

CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0
ACTION_LOCK = threading.Lock()
STATUS_LOCK = threading.Lock()
STATUS_SNAPSHOT: dict[str, Any] | None = None
STATUS_UPDATED_MONOTONIC = 0.0
COMPONENT_ALIASES = {"frpc": "frpc_val"}
DESIRED_RUNNING = {key: True for key in AUTO_RECOVER_COMPONENTS}


def ensure_dirs() -> None:
    CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def now() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log_event(message: str, detail: str = "") -> None:
    ensure_dirs()
    line = f"[{now()}] {message}"
    if detail:
        line += f"\n{detail.rstrip()}"
    with OPS_LOG.open("a", encoding="utf-8", errors="ignore") as f:
        f.write(line + "\n")


def esc(value: Any) -> str:
    return html.escape(str(value), quote=True)


def tail_file(path: Path, max_bytes: int = 48_000) -> str:
    if not path.exists():
        return ""
    with path.open("rb") as f:
        try:
            f.seek(-max_bytes, os.SEEK_END)
        except OSError:
            f.seek(0)
        data = f.read()
    return data.decode("utf-8", errors="replace")


def main_service_request(
    method: str,
    path: str,
    body: dict[str, Any] | None = None,
) -> tuple[int, Any]:
    """调用主服务 8787 的 admin API（本地环回）。返回 (status, json)。"""
    url = f"http://127.0.0.1:{MAIN_PORT}{path}"
    data = None
    headers = {"Accept": "application/json"}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            try:
                return resp.status, json.loads(raw)
            except Exception:
                return resp.status, {"ok": False, "error": raw[:200]}
    except urllib.error.HTTPError as exc:
        try:
            return exc.code, json.loads(exc.read().decode("utf-8"))
        except Exception:
            return exc.code, {"ok": False, "error": f"HTTP {exc.code}"}
    except Exception as exc:
        return 0, {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


def file_age(path: Path) -> str:
    if not path.exists():
        return "不存在"
    seconds = max(0, int(time.time() - path.stat().st_mtime))
    if seconds < 60:
        return f"{seconds}秒前"
    if seconds < 3600:
        return f"{seconds // 60}分钟前"
    if seconds < 86400:
        return f"{seconds // 3600}小时前"
    return f"{seconds // 86400}天前"


def port_open(port: int, host: str = "127.0.0.1", timeout: float = 0.5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def http_probe(url: str, timeout: float = 3.0) -> tuple[bool, str]:
    # Windows 下优先用 curl.exe（Schannel）直连探测：本机 Python 3.9 的
    # OpenSSL 与 Cloudflare 边缘 TLS 握手会被重置（FileNotFoundError），
    # 导致 cloudflared 健康检查误判并反复重启；curl 直连实测正常。
    if os.name == "nt":
        code, out = run_capture(
            [
                "curl.exe",
                "-sS",
                "-o",
                "NUL",
                "-w",
                "%{http_code}",
                "--noproxy",
                "*",
                "--max-time",
                str(max(1, int(timeout))),
                url,
            ],
            timeout=max(1.0, timeout) + 3.0,
        )
        if code == 0 and out.strip().isdigit():
            status = int(out.strip())
            return 200 <= status < 500, f"HTTP {status}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "ops-control-center/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 500, f"HTTP {resp.status}"
    except urllib.error.HTTPError as exc:
        return exc.code < 500, f"HTTP {exc.code}"
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def frp_tcp_connected(pids: list[int], remote_port: int) -> bool:
    """确认指定 frpc 进程确实与对应 FRPS 端口建立了 TCP 连接。"""
    if not pids:
        return False
    code, out = run_capture(["netstat.exe", "-ano", "-p", "tcp"], timeout=6)
    if code != 0:
        return False
    expected_pids = {int(pid) for pid in pids}
    expected_port = str(int(remote_port))
    for line in out.splitlines():
        parts = line.split()
        if len(parts) < 5 or parts[0].upper() != "TCP":
            continue
        try:
            pid = int(parts[-1])
        except ValueError:
            continue
        remote_endpoint = parts[-3]
        state = parts[-2].upper()
        if (
            pid in expected_pids
            and state == "ESTABLISHED"
            and remote_endpoint.rsplit(":", 1)[-1] == expected_port
        ):
            return True
    return False


def run_capture(args: list[str], cwd: Path | None = None, timeout: float = 12.0) -> tuple[int, str]:
    try:
        proc = subprocess.run(
            args,
            cwd=str(cwd) if cwd else None,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            creationflags=CREATE_NO_WINDOW,
        )
        return proc.returncode, (proc.stdout or "") + (proc.stderr or "")
    except subprocess.TimeoutExpired as exc:
        out = (exc.stdout or "") + (exc.stderr or "")
        if isinstance(out, bytes):
            out = out.decode("utf-8", errors="replace")
        return 124, str(out) + "\nTIMEOUT"
    except Exception as exc:
        return 1, f"{type(exc).__name__}: {exc}"


def powershell(script: str, timeout: float = 12.0) -> tuple[int, str]:
    return run_capture(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        timeout=timeout,
    )


def list_processes() -> list[dict[str, Any]]:
    script = (
        "Get-CimInstance Win32_Process | "
        "Select-Object ProcessId,ParentProcessId,Name,CommandLine | "
        "ConvertTo-Json -Depth 3 -Compress"
    )
    code, out = powershell(script, timeout=18)
    if code != 0 or not out.strip():
        return []
    try:
        data = json.loads(out)
    except json.JSONDecodeError:
        return []
    if isinstance(data, dict):
        return [data]
    return [p for p in data if isinstance(p, dict)]


def match_proc(proc: dict[str, Any], patterns: list[str]) -> bool:
    cmd = str(proc.get("CommandLine") or "")
    name = str(proc.get("Name") or "")
    text = f"{name} {cmd}".lower()
    return all(p.lower() in text for p in patterns)


def find_processes(
    patterns: list[str],
    process_list: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    current_pid = os.getpid()
    return [
        p
        for p in (process_list if process_list is not None else list_processes())
        if int(p.get("ProcessId") or 0) != current_pid and match_proc(p, patterns)
    ]


def stop_pid_tree(pid: int) -> tuple[bool, str]:
    code, out = run_capture(["taskkill.exe", "/PID", str(pid), "/T", "/F"], timeout=12)
    return code == 0, out


def start_process(
    name: str,
    args: list[str],
    cwd: Path,
    stdout_log: Path,
    stderr_log: Path,
    env: dict[str, str] | None = None,
) -> int:
    ensure_dirs()
    stdout_log.parent.mkdir(parents=True, exist_ok=True)
    stderr_log.parent.mkdir(parents=True, exist_ok=True)
    out = stdout_log.open("ab")
    err = stderr_log.open("ab")
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    try:
        proc = subprocess.Popen(
            args,
            cwd=str(cwd),
            stdout=out,
            stderr=err,
            stdin=subprocess.DEVNULL,
            env=merged_env,
            creationflags=CREATE_NO_WINDOW,
        )
    finally:
        # 子进程已经继承句柄；控制中心及时关闭自己的副本，避免多次重启后泄漏。
        out.close()
        err.close()
    log_event(f"启动 {name}", "PID={}\nCMD={}".format(proc.pid, " ".join(map(str, args))))
    return proc.pid


def adb(args: list[str], timeout: float = 10.0) -> tuple[int, str]:
    if not ADB_PATH.exists():
        return 1, f"ADB 不存在：{ADB_PATH}"
    return run_capture([str(ADB_PATH), *args], timeout=timeout)


def adb_device() -> str:
    code, out = adb(["devices"], timeout=8)
    if code != 0:
        return "ADB异常"
    for line in out.splitlines():
        if "\tdevice" in line:
            return line.split()[0]
    return "未连接"


def adb_get_proxy() -> str:
    code, out = adb(["shell", "settings", "get", "global", "http_proxy"], timeout=8)
    if code != 0:
        return out.strip() or "读取失败"
    return out.strip() or "空"


def adb_reverse_list() -> str:
    code, out = adb(["reverse", "--list"], timeout=8)
    if code != 0:
        return out.strip() or "读取失败"
    return out.strip() or "无"


def set_android_mval_proxy() -> str:
    chunks = []
    for args in (
        ["reverse", "tcp:8081", "tcp:8081"],
        ["shell", "settings", "put", "global", "http_proxy", "127.0.0.1:8081"],
        ["shell", "settings", "put", "global", "global_http_proxy_host", "127.0.0.1"],
        ["shell", "settings", "put", "global", "global_http_proxy_port", "8081"],
    ):
        code, out = adb(args, timeout=10)
        chunks.append(f"adb {' '.join(args)} -> {code}\n{out.strip()}")
    return "\n".join(chunks)


def clear_android_proxy() -> str:
    chunks = []
    for args in (
        ["shell", "settings", "put", "global", "http_proxy", ":0"],
        ["shell", "settings", "delete", "global", "global_http_proxy_host"],
        ["shell", "settings", "delete", "global", "global_http_proxy_port"],
        ["reverse", "--remove", "tcp:8081"],
    ):
        code, out = adb(args, timeout=10)
        chunks.append(f"adb {' '.join(args)} -> {code}\n{out.strip()}")
    return "\n".join(chunks)


def launch_mval_app() -> str:
    code1, out1 = adb(["shell", "am", "force-stop", "com.tencent.apps.valorant"], timeout=8)
    code2, out2 = adb(
        [
            "shell",
            "am",
            "start",
            "-n",
            "com.tencent.apps.valorant/com.tencent.zone.main.LauncherActivity",
        ],
        timeout=8,
    )
    return f"force-stop -> {code1}\n{out1.strip()}\nam start -> {code2}\n{out2.strip()}"


def component_configs() -> dict[str, dict[str, Any]]:
    ignore_hosts = r".*(ptlogin2\.qq\.com|openmobile\.qq\.com|graph\.qq\.com|connect\.qq\.com).*"
    return {
        "main": {
            "title": "主查询服务",
            "desc": "网页、API、战绩查询、当前对局和掌瓦属地。",
            "patterns": ["wgame_query_server.py", "--port", "8787"],
            "port": MAIN_PORT,
            "health_url": "http://127.0.0.1:8787/public",
            "cwd": APP_DIR,
            "args": [str(PYTHON), "wgame_query_server.py", "--port", "8787"],
            "stdout": CAPTURE_DIR / "ops-main.stdout.log",
            "stderr": CAPTURE_DIR / "ops-main.stderr.log",
            "auto": True,
        },
        "auth": {
            "title": "公网鉴权代理",
            "desc": "本机 8790，给 FRP/Nginx 提供公开页和管理口令控制。",
            "patterns": ["frp_auth_proxy.py", "--listen-port", "8790"],
            "port": AUTH_PORT,
            "health_url": "http://127.0.0.1:8790/public",
            "cwd": APP_DIR,
            "args": [
                str(PYTHON),
                "frp_auth_proxy.py",
                "--listen-port",
                "8790",
                "--upstream-port",
                "8787",
                "--token-file",
                "captures\\public-query-token.txt",
            ],
            "stdout": CAPTURE_DIR / "ops-auth.stdout.log",
            "stderr": CAPTURE_DIR / "ops-auth.stderr.log",
            "auto": True,
        },
        "cloudflared": {
            "title": "Cloudflare Tunnel（可选）",
            "desc": "可选：由用户自行配置自己的隧道后使用；本地包不包含维护者隧道。",
            "patterns": ["cloudflared.exe", "tunnel"],
            "health_url": "http://127.0.0.1:8787/public",
            "health_timeout": 10.0,
            "cwd": APP_DIR,
            "args": [str(CLOUDFLARED_DIR / "cloudflared.exe"), "tunnel", "run"],
            "stdout": CAPTURE_DIR / "ops-cloudflared.stdout.log",
            "stderr": CAPTURE_DIR / "ops-cloudflared.stderr.log",
            "auto": True,
            "recover_after_failures": 3,
        },
        "frpc_val": {
            "title": "FRP · 可选线路 A",
            "desc": f"普通线路 → {FRP_VAL_SERVER_ADDR}:{FRP_VAL_SERVER_PORT}，远端端口 8787。",
            "patterns": ["frpc.exe", "frpc-wgame-query.toml"],
            "health_url": "http://127.0.0.1:8787/public",
            "cwd": FRP_CONFIG_DIR,
            "args": [str(FRP_DIR / "frpc.exe"), "-c", str(FRP_CONFIG_DIR / "frpc-wgame-query.toml")],
            "stdout": CAPTURE_DIR / "ops-frpc-val.stdout.log",
            "stderr": CAPTURE_DIR / "ops-frpc-val.stderr.log",
            "auto": False,
            "kind": "frpc",
            "server_addr": FRP_VAL_SERVER_ADDR,
            "server_port": FRP_VAL_SERVER_PORT,
            "auth_token": FRP_VAL_AUTH_TOKEN,
            "config_path": FRP_CONFIG_DIR / "frpc-wgame-query.toml",
            "proxy_name": "wgame-query-auth",
            "local_port": AUTH_PORT,
            "remote_port": 8787,
            "recover_after_failures": FRP_RECOVER_AFTER_FAILURES,
            "before_start": "ensure_frpc_config",
        },
        "frpc_vip": {
            "title": "FRP · 可选线路 B",
            "desc": f"VIP 线路 → {FRP_VIP_SERVER_ADDR}:{FRP_VIP_SERVER_PORT}，远端端口 8788。",
            "patterns": ["frpc.exe", "frpc-wgame-vip.toml"],
            "health_url": "http://127.0.0.1:8787/public",
            "cwd": FRP_CONFIG_DIR,
            "args": [
                str(FRP_DIR / "frpc.exe"),
                "-c",
                str(FRP_CONFIG_DIR / "frpc-wgame-vip.toml"),
            ],
            "stdout": CAPTURE_DIR / "ops-frpc-vip.stdout.log",
            "stderr": CAPTURE_DIR / "ops-frpc-vip.stderr.log",
            "auto": False,
            "kind": "frpc",
            "server_addr": FRP_VIP_SERVER_ADDR,
            "server_port": FRP_VIP_SERVER_PORT,
            "auth_token": FRP_VIP_AUTH_TOKEN,
            "config_path": FRP_CONFIG_DIR / "frpc-wgame-vip.toml",
            "proxy_name": "wgame-vip-query",
            "local_port": AUTH_PORT,
            "remote_port": 8788,
            "recover_after_failures": FRP_RECOVER_AFTER_FAILURES,
            "before_start": "ensure_frpc_config",
        },
        "chrome": {
            "title": "专用 Chrome 登录态",
            "desc": f"{CHROME_PORT} 调试端口，WeGame 查询依赖这个浏览器登录态。",
            "patterns": ["chrome", f"--remote-debugging-port={CHROME_PORT}"],
            "port": CHROME_PORT,
            "health_url": f"http://127.0.0.1:{CHROME_PORT}/json/version",
            "cwd": APP_DIR,
            "args": [str(PYTHON), "wgame_query_server.py", "--launch-chrome"],
            "stdout": CAPTURE_DIR / "ops-launch-chrome.stdout.log",
            "stderr": CAPTURE_DIR / "ops-launch-chrome.stderr.log",
            "auto": True,
            "oneshot": True,
        },
        "game_capture": {
            "title": "游戏 subject 抓包",
            "desc": "Proxifier + mitmproxy 8083，实时捕获当前对局 token / subject；ACE 反作弊域名直连。",
            "patterns": ["mitmdump", "8083"],
            "alt_patterns": [["Proxifier.exe", "proxifier-game"]],
            "port": 8083,
            "cwd": APP_DIR,
            "args": [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(APP_DIR / "start-proxifier-capture.ps1"),
            ],
            "stdout": CAPTURE_DIR / "ops-game-capture.stdout.log",
            "stderr": CAPTURE_DIR / "ops-game-capture.stderr.log",
            "auto": True,
        },
        "mval_capture": {
            "title": "掌瓦抓包代理",
            "desc": "mitmproxy 8081，抓 app.mval.qq.com 登录态和公开 IP属地所需 Cookie。",
            "patterns": ["run-android-val-capture.ps1"],
            "alt_patterns": [["mitmdump", "8081"]],
            "port": MVAL_PROXY_PORT,
            "cwd": MVAL_DIR,
            "args": [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(MVAL_DIR / "run-android-val-capture.ps1"),
                "-AdbPath",
                str(ADB_PATH),
                "-Raw",
                "-CaptureAll",
                "-Direct",
                "-IgnoreHosts",
                ignore_hosts,
            ],
            "stdout": MVAL_DIR / "captures" / "ops-mval-capture.stdout.log",
            "stderr": MVAL_DIR / "captures" / "ops-mval-capture.stderr.log",
            "auto": True,
            "before_start": "prepare_mval_capture",
            "after_stop": "clear_android_proxy",
        },
        "mval_pusher": {
            "title": "掌瓦登录态推送",
            "desc": "监听抓包文件，把掌瓦 Cookie 推送给本机主服务。",
            "patterns": ["mval_session_pusher.py", "--watch"],
            "cwd": MVAL_DIR,
            "args": [
                str(PYTHON),
                str(MVAL_DIR / "mval_session_pusher.py"),
                "--api-url",
                MVAL_SESSION_PUSH_URL,
                "--watch",
                "--verbose",
            ],
            "stdout": MVAL_DIR / "captures" / "ops-mval-pusher.stdout.log",
            "stderr": MVAL_DIR / "captures" / "ops-mval-pusher.stderr.log",
            "auto": True,
        },
        "alias_watch": {
            "title": "好友 subject 监听",
            "desc": "扫描抓包里的好友搜索/添加结果，补充 nickname#tag 到 subject 缓存。",
            "patterns": ["watch-friend-aliases.py"],
            "cwd": APP_DIR,
            "args": [str(PYTHON), "watch-friend-aliases.py"],
            "stdout": CAPTURE_DIR / "ops-alias-watch.stdout.log",
            "stderr": CAPTURE_DIR / "ops-alias-watch.stderr.log",
            "auto": True,
        },
    }


def processes_for(
    cfg: dict[str, Any],
    process_list: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    procs = find_processes(cfg.get("patterns", []), process_list)
    for patterns in cfg.get("alt_patterns", []):
        known = {int(p.get("ProcessId") or 0) for p in procs}
        for proc in find_processes(patterns, process_list):
            if int(proc.get("ProcessId") or 0) not in known:
                procs.append(proc)
    return procs


def unique_procs(groups: list[list[dict[str, Any]]]) -> list[dict[str, Any]]:
    seen: set[int] = set()
    result: list[dict[str, Any]] = []
    for group in groups:
        for proc in group:
            pid = int(proc.get("ProcessId") or 0)
            if pid and pid not in seen:
                seen.add(pid)
                result.append(proc)
    return result


def game_capture_process_groups(
    process_list: list[dict[str, Any]] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    mitm = unique_procs([
        find_processes(["8083", "mitmdump"], process_list),
        find_processes(["8083", "wegame_mitm_capture.py"], process_list),
    ])
    proxifier = find_processes(["Proxifier.exe", "proxifier-game"], process_list)
    return mitm, proxifier


def component_status(
    key: str,
    cfg: dict[str, Any],
    process_list: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    if key == "game_capture":
        mitm_procs, proxifier_procs = game_capture_process_groups(process_list)
        port_ok = port_open(8083)
        # Loading a new profile into an existing Proxifier instance does not
        # update that process's original command line. After a tested fallback
        # to proxifier-direct.ppx, the same instance can therefore be actively
        # using the capture profile while its command line still says
        # "proxifier-direct". Accept it only when mitmdump and 8083 are both
        # present, so an idle direct-only Proxifier never makes this component
        # look healthy or running.
        if port_ok and mitm_procs and not proxifier_procs:
            proxifier_procs = find_processes(["Proxifier.exe"], process_list)
        supervisor_procs = find_processes(["start-proxifier-capture.ps1"], process_list)
        procs = unique_procs([mitm_procs, proxifier_procs, supervisor_procs])
        http_ok = None
        http_msg = ""
        tunnel_ok = None
        running = bool(procs) or bool(port_ok)
        healthy = bool(port_ok) and bool(mitm_procs) and bool(proxifier_procs)
    else:
        procs = processes_for(cfg, process_list)
        pids = [int(p.get("ProcessId") or 0) for p in procs]
        port_ok = port_open(int(cfg["port"])) if cfg.get("port") else None
        http_ok = None
        http_msg = ""
        if cfg.get("health_url"):
            http_ok, http_msg = http_probe(str(cfg["health_url"]), timeout=cfg.get("health_timeout", 3.0))
        running = bool(procs) or bool(port_ok)
        tunnel_ok = None
        if cfg.get("kind") == "frpc":
            tunnel_ok = frp_tcp_connected(pids, int(cfg["server_port"]))
            # 公网 HTTP 可能受 DNS/Nginx/上游瞬时波动影响。FRP 守护只根据
            # frpc 进程和它到 FRPS 的实际 TCP 连接决定是否重启。
            healthy = bool(running and tunnel_ok and len(pids) == 1)
            tcp_msg = "FRPS TCP 已连接" if tunnel_ok else "FRPS TCP 未连接"
            if len(pids) > 1:
                tcp_msg += f" · 检测到 {len(pids)} 个重复进程"
            http_msg = f"{tcp_msg} · 公网 {http_msg or '未探测'}"
        else:
            healthy = running
            if port_ok is False:
                healthy = False
            if http_ok is False:
                healthy = False
            tunnel_ok = None
    desired_running = DESIRED_RUNNING.get(key, True)
    return {
        "key": key,
        "title": cfg["title"],
        "desc": cfg["desc"],
        "running": running,
        "healthy": healthy,
        "pids": [int(p.get("ProcessId") or 0) for p in procs],
        "instance_count": len(procs),
        "port_ok": port_ok,
        "http_ok": http_ok,
        "http_msg": http_msg,
        "tunnel_ok": tunnel_ok,
        "desired_running": desired_running,
        "stdout": str(cfg.get("stdout", "")),
        "stderr": str(cfg.get("stderr", "")),
        "auto": bool(cfg.get("auto")),
    }


def all_status() -> dict[str, Any]:
    configs = component_configs()
    process_list = list_processes()
    components = {
        key: component_status(key, cfg, process_list)
        for key, cfg in configs.items()
    }
    try:
        with urllib.request.urlopen("http://127.0.0.1:8787/api/wegame-session-status", timeout=5) as resp:
            wg_data: dict[str, Any] = json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception as exc:
        wg_data = {"ok": False, "healthy": False, "message": f"{type(exc).__name__}: {exc}"}
    public_component = components.get("frpc_val") or {}
    vip_public_component = components.get("frpc_vip") or {}
    public_ok = bool(public_component.get("http_ok"))
    public_msg = str(public_component.get("http_msg") or "")
    vip_public_ok = bool(vip_public_component.get("http_ok"))
    vip_public_msg = str(vip_public_component.get("http_msg") or "")
    device = adb_device()
    if device == "未连接":
        adb_proxy = "未连接"
        adb_reverse = "未连接"
    else:
        adb_proxy = adb_get_proxy()
        adb_reverse = adb_reverse_list()
    return {
        "now": now(),
        "components": components,
        "files": {
            "subjects_db": {"path": str(SUBJECT_DB_PATH), "exists": SUBJECT_DB_PATH.exists(), "age": file_age(SUBJECT_DB_PATH)},
            "mval_session": {"path": str(MVAL_SESSION_PATH), "exists": MVAL_SESSION_PATH.exists(), "age": file_age(MVAL_SESSION_PATH)},
            "location_cache": {"path": str(LOCATION_CACHE_PATH), "exists": LOCATION_CACHE_PATH.exists(), "age": file_age(LOCATION_CACHE_PATH)},
            "usage_audit": {"path": str(AUDIT_DB_PATH), "exists": AUDIT_DB_PATH.exists(), "age": file_age(AUDIT_DB_PATH)},
            "public_token": {"path": str(PUBLIC_TOKEN_PATH), "exists": PUBLIC_TOKEN_PATH.exists(), "age": file_age(PUBLIC_TOKEN_PATH)},
        },
        "adb": {
            "device": device,
            "proxy": adb_proxy,
            "reverse": adb_reverse,
        },
        "wegame": wg_data,
        "public": {"ok": public_ok, "message": public_msg},
        "vip_public": {"ok": vip_public_ok, "message": vip_public_msg},
        "ops_log": str(OPS_LOG),
    }


def initial_status_snapshot() -> dict[str, Any]:
    """构造不执行外部探测的首屏状态，保证控制中心可以立即打开。"""
    components = {}
    for key, cfg in component_configs().items():
        components[key] = {
            "key": key,
            "title": cfg["title"],
            "desc": cfg["desc"],
            "running": False,
            "healthy": None,
            "pids": [],
            "instance_count": 0,
            "port_ok": None,
            "http_ok": None,
            "http_msg": "后台检测中",
            "tunnel_ok": None,
            "desired_running": DESIRED_RUNNING.get(key, True),
            "stdout": str(cfg.get("stdout", "")),
            "stderr": str(cfg.get("stderr", "")),
            "auto": bool(cfg.get("auto")),
        }
    return {
        "now": now(),
        "components": components,
        "files": {
            "subjects_db": {"path": str(SUBJECT_DB_PATH), "exists": SUBJECT_DB_PATH.exists(), "age": file_age(SUBJECT_DB_PATH)},
            "mval_session": {"path": str(MVAL_SESSION_PATH), "exists": MVAL_SESSION_PATH.exists(), "age": file_age(MVAL_SESSION_PATH)},
            "location_cache": {"path": str(LOCATION_CACHE_PATH), "exists": LOCATION_CACHE_PATH.exists(), "age": file_age(LOCATION_CACHE_PATH)},
            "usage_audit": {"path": str(AUDIT_DB_PATH), "exists": AUDIT_DB_PATH.exists(), "age": file_age(AUDIT_DB_PATH)},
            "public_token": {"path": str(PUBLIC_TOKEN_PATH), "exists": PUBLIC_TOKEN_PATH.exists(), "age": file_age(PUBLIC_TOKEN_PATH)},
        },
        "adb": {
            "device": "后台检测中",
            "proxy": "后台检测中",
            "reverse": "后台检测中",
        },
        "wegame": {"ok": None, "healthy": None, "message": "后台检测中"},
        "public": {"ok": None, "message": "后台检测中"},
        "vip_public": {"ok": None, "message": "后台检测中"},
        "ops_log": str(OPS_LOG),
    }


def cached_status() -> tuple[dict[str, Any], float | None]:
    """读取最近一次完整探测，不在 HTTP 请求线程里执行慢探测。"""
    with STATUS_LOCK:
        state = STATUS_SNAPSHOT
        updated = STATUS_UPDATED_MONOTONIC
    if state is None:
        return initial_status_snapshot(), None
    return state, max(0.0, time.monotonic() - updated)


def refresh_status_snapshot() -> None:
    state = all_status()
    with STATUS_LOCK:
        global STATUS_SNAPSHOT, STATUS_UPDATED_MONOTONIC
        STATUS_SNAPSHOT = state
        STATUS_UPDATED_MONOTONIC = time.monotonic()


def status_refresh_daemon() -> None:
    """串行刷新完整状态，避免浏览器刷新叠加昂贵的系统/网络探测。"""
    time.sleep(1)
    while True:
        try:
            refresh_status_snapshot()
        except Exception as exc:
            log_event("状态缓存刷新异常", f"{type(exc).__name__}: {exc}")
        time.sleep(STATUS_REFRESH_INTERVAL)


def expected_frpc_config(cfg: dict[str, Any]) -> str:
    auth_token = str(cfg.get("auth_token") or "").strip()
    if not auth_token:
        raise RuntimeError(
            f"{cfg['title']} 缺少认证凭据；请配置 .private/frp-production.env "
            "或对应的 FRP_*_AUTH_TOKEN 环境变量。"
        )
    return f"""serverAddr = "{cfg['server_addr']}"
serverPort = {int(cfg['server_port'])}
loginFailExit = false
transport.tls.enable = true
auth.method = "token"
auth.token = "{auth_token}"

[[proxies]]
name = "{cfg['proxy_name']}"
type = "tcp"
localIP = "127.0.0.1"
localPort = {int(cfg['local_port'])}
remotePort = {int(cfg['remote_port'])}
"""


def ensure_frpc_config(cfg: dict[str, Any]) -> str:
    """仅在内容变化时原子更新配置，避免运行中的 frpc 短暂占用导致恢复失败。"""
    config_path = Path(cfg["config_path"])
    expected = expected_frpc_config(cfg)
    try:
        current = config_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        current = ""
    if current.replace("\r\n", "\n") == expected.replace("\r\n", "\n"):
        return f"FRPC 配置已校验（无需写入）→ {cfg['server_addr']}:{cfg['server_port']}"

    config_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = config_path.with_name(f".{config_path.name}.{os.getpid()}.{time.time_ns()}.tmp")
    try:
        temp_path.write_text(expected, encoding="utf-8")
        os.replace(temp_path, config_path)
    except OSError as exc:
        # 处理检查与替换之间的竞争：若其他线程已经写好，则继续启动。
        try:
            latest = config_path.read_text(encoding="utf-8")
        except OSError:
            latest = ""
        if latest.replace("\r\n", "\n") != expected.replace("\r\n", "\n"):
            raise RuntimeError(f"无法更新 FRPC 配置 {config_path}: {type(exc).__name__}: {exc}") from exc
    finally:
        try:
            temp_path.unlink(missing_ok=True)
        except OSError:
            pass
    log_event(
        "FRPC 配置已更新",
        f"path={config_path}\nserver={cfg['server_addr']}:{cfg['server_port']}\nremote_port={cfg['remote_port']}",
    )
    return f"FRPC 配置已更新 → {cfg['server_addr']}:{cfg['server_port']}"


def canonical_component_key(key: str) -> str:
    return COMPONENT_ALIASES.get(key, key)


def start_component(key: str, *, update_desired: bool = True) -> str:
    key = canonical_component_key(key)
    cfg = component_configs()[key]
    if update_desired and key in DESIRED_RUNNING:
        DESIRED_RUNNING[key] = True
    status = component_status(key, cfg)
    if status["running"] and not cfg.get("oneshot"):
        if cfg.get("kind") != "frpc" or status.get("instance_count") == 1:
            return f"{cfg['title']} 已在运行：PID {status['pids']}"
        cleanup = stop_component(key, update_desired=False)
        time.sleep(1)
        log_event(f"清理 {cfg['title']} 重复实例", cleanup)
    if cfg.get("before_start") == "prepare_mval_capture":
        # 先清理上次异常退出遗留的代理/reverse，再由正式脚本记录干净旧状态并
        # 独立建立 8081。否则脚本会把 8081 误记成“旧代理”，异常退出后恢复到
        # 一个已经移除 reverse 的死代理，导致模拟器断网。
        detail = clear_android_proxy()
        log_event("准备模拟器掌瓦抓包", detail)
    if cfg.get("before_start") == "ensure_frpc_config":
        ensure_frpc_config(cfg)
    pid = start_process(key, cfg["args"], cfg["cwd"], cfg["stdout"], cfg["stderr"])
    return f"{cfg['title']} 已启动：PID {pid}"


def stop_component(key: str, *, update_desired: bool = True) -> str:
    key = canonical_component_key(key)
    cfg = component_configs()[key]
    if update_desired and key in DESIRED_RUNNING:
        DESIRED_RUNNING[key] = False
    if key == "game_capture":
        stop_script = APP_DIR / "stop-proxifier-capture.ps1"
        code, out = run_capture(
            [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(stop_script),
            ],
            timeout=25,
        )
        detail = out.strip()
        log_event("停止 game_capture", detail or f"exit={code}")
        if code == 0:
            return f"{cfg['title']} 已停止\n{detail}"
        return f"{cfg['title']} 停止失败（exit={code}）\n{detail}"
    procs = processes_for(cfg)
    if not procs:
        if cfg.get("after_stop") == "clear_android_proxy":
            detail = clear_android_proxy()
            log_event("清理模拟器代理", detail)
        return f"{cfg['title']} 未运行"
    outputs = []
    for proc in procs:
        pid = int(proc.get("ProcessId") or 0)
        ok, out = stop_pid_tree(pid)
        outputs.append(f"PID {pid}: {'OK' if ok else 'FAIL'}\n{out.strip()}")
    if cfg.get("after_stop") == "clear_android_proxy":
        detail = clear_android_proxy()
        outputs.append("清理模拟器代理：\n" + detail)
    detail = "\n\n".join(outputs)
    log_event(f"停止 {key}", detail)
    return f"{cfg['title']} 已停止\n{detail}"


def restart_component(key: str, *, update_desired: bool = True) -> str:
    key = canonical_component_key(key)
    if update_desired and key in DESIRED_RUNNING:
        DESIRED_RUNNING[key] = True
    a = stop_component(key, update_desired=False)
    time.sleep(1)
    b = start_component(key, update_desired=False)
    return a + "\n\n" + b


def repair_all() -> str:
    configs = component_configs()
    messages = []
    for key, cfg in configs.items():
        if not cfg.get("auto"):
            continue
        status = component_status(key, cfg)
        if key == "mval_capture":
            detail = set_android_mval_proxy()
            messages.append("模拟器掌瓦代理已校准\n" + detail)
            # 掌瓦组件在 ADB 无设备时异常不阻塞主链路
            if not status["healthy"]:
                if status["running"]:
                    messages.append(f"{cfg['title']} 半坏状态（无模拟器），不影响 WeGame 主链路")
                else:
                    messages.append(f"{cfg['title']} 未运行（无模拟器），不影响 WeGame 主链路")
                continue
        if not status["healthy"]:
            if status["running"]:
                messages.append(restart_component(key))
            else:
                messages.append(start_component(key))
        else:
            messages.append(f"{cfg['title']} 正常运行")
    wg = all_status().get("wegame") or {}
    if wg.get("ok") and not wg.get("healthy"):
        messages.append(start_component("chrome"))
    result = "\n\n".join(messages)
    log_event("执行自动检测修复", result)
    return result


def render_status_badge(ok: bool | None, running: bool | None = None) -> str:
    if ok is True:
        return '<span class="badge good">正常</span>'
    if ok is False:
        return '<span class="badge bad">异常</span>'
    if running:
        return '<span class="badge warn">运行中</span>'
    return '<span class="badge muted">未知</span>'


def render_page(message: str = "") -> str:
    state, status_age = cached_status()
    rows = []
    for key, item in state["components"].items():
        pids = ", ".join(str(p) for p in item["pids"]) or "-"
        port = "未配置" if item["port_ok"] is None else ("监听" if item["port_ok"] else "未监听")
        http_s = item["http_msg"] or "-"
        if not item.get("desired_running", True):
            http_s = "已手动停止，自动恢复暂停"
        rows.append(
            f"""
            <tr data-key="{esc(key)}">
              <td>
                <strong>{esc(item['title'])}</strong>
                <span>{esc(item['desc'])}</span>
              </td>
              <td>{render_status_badge(item['healthy'], item['running'])}</td>
              <td>{esc(pids)}</td>
              <td>{esc(port)}</td>
              <td>{esc(http_s)}</td>
              <td class="actions">
                <button onclick="act('{esc(key)}','start')">启动</button>
                <button onclick="act('{esc(key)}','stop')">停止</button>
                <button onclick="act('{esc(key)}','restart')">重启</button>
                <button onclick="logs('{esc(key)}')">日志</button>
              </td>
            </tr>
            """
        )

    files = "".join(
        f"""
        <tr>
          <td>{esc(name)}</td>
          <td>{render_status_badge(bool(info['exists']))}</td>
          <td>{esc(info['age'])}</td>
          <td><code>{esc(info['path'])}</code></td>
        </tr>
        """
        for name, info in state["files"].items()
    )
    wg_ok = (state.get("wegame") or {}).get("healthy")
    public_ok = (state.get("public") or {}).get("ok")
    vip_public_ok = (state.get("vip_public") or {}).get("ok")
    status_age_text = "首次检测中" if status_age is None else f"{status_age:.1f} 秒前"
    css = """
    :root{color-scheme:dark;--bg:#0b1118;--panel:#131c26;--panel2:#0f1720;--line:#2b3a49;--text:#edf7ff;--muted:#91a6ba;--good:#26e08a;--bad:#ff476f;--warn:#ffd166;--blue:#8ed4ff}
    *{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:"Microsoft YaHei","Segoe UI",Arial,sans-serif;font-size:15px;letter-spacing:0}
    main{max-width:1660px;margin:0 auto;padding:24px 22px 40px}.top{display:flex;justify-content:space-between;align-items:center;gap:18px;margin-bottom:18px}.top h1{margin:0;font-size:30px;line-height:1.12}.top p{margin:7px 0 0;color:var(--muted);font-size:14px}
    .bar{display:flex;gap:10px;flex-wrap:wrap}.panel{background:var(--panel);border:1px solid var(--line);border-radius:8px;margin-bottom:18px;overflow:hidden}.panel h2{font-size:21px;margin:0;padding:16px 18px;border-bottom:1px solid var(--line);background:rgba(255,255,255,.025)}
    .grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;padding:16px}.metric{background:var(--panel2);border:1px solid var(--line);border-radius:7px;padding:14px}.metric span{display:block;color:var(--muted);font-size:13px}.metric strong{display:block;margin-top:7px;font-size:20px;line-height:1.35;word-break:break-all}
    table{width:100%;border-collapse:collapse}th,td{padding:14px 12px;border-bottom:1px solid var(--line);vertical-align:middle;text-align:left;font-size:14px;line-height:1.45}th{color:var(--blue);font-weight:800;background:rgba(255,255,255,.02);font-size:13px}td strong{display:block;font-size:16px}td span{display:block;color:var(--muted);margin-top:5px}code{color:#ccecff;word-break:break-all;font-size:12px}
    button,.btn{min-height:38px;border:1px solid #456078;background:#1b2a38;color:var(--text);border-radius:6px;padding:0 13px;font-size:14px;font-weight:800;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px}button:hover,.btn:hover{border-color:#7bb7e8}.primary{background:#f3c45f;color:#111923;border-color:#f3c45f}.danger{background:#3a1923;border-color:#7a3045}.actions{white-space:nowrap}.actions button{margin:0 5px 5px 0}
    .badge{display:inline-block;min-width:54px;text-align:center;padding:6px 10px;border-radius:999px;font-weight:900;font-size:13px}.good{background:rgba(38,224,138,.14);color:var(--good);border:1px solid rgba(38,224,138,.35)}.bad{background:rgba(255,71,111,.14);color:var(--bad);border:1px solid rgba(255,71,111,.35)}.warn{background:rgba(255,209,102,.13);color:var(--warn);border:1px solid rgba(255,209,102,.35)}.muted{background:#1b2632;color:var(--muted);border:1px solid var(--line)}
    .msg{white-space:pre-wrap;background:#0c1620;border:1px solid var(--line);border-radius:7px;margin-bottom:18px;padding:14px;color:#d9f0ff;font-size:14px;line-height:1.5}.logbox{white-space:pre-wrap;background:#071018;border-top:1px solid var(--line);padding:16px;max-height:560px;overflow:auto;font-family:Consolas,monospace;font-size:13px;line-height:1.5;color:#c9e8ff}
    @media(max-width:900px){main{padding:14px}.grid{grid-template-columns:1fr}.top{align-items:flex-start;flex-direction:column}.actions{white-space:normal}th:nth-child(3),td:nth-child(3),th:nth-child(4),td:nth-child(4){display:none}}
    """
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>WGame VAL 控制中心</title>
  <style>{css}</style>
</head>
<body>
<main>
  <div class="top">
    <div>
      <h1>WGame VAL 控制中心</h1>
      <p>状态时间 {esc(state['now'])}（{esc(status_age_text)}） · 控制中心端口 {CONTROL_PORT} · FRP：val {esc(FRP_VAL_SERVER_ADDR)}:{FRP_VAL_SERVER_PORT} / VIP {esc(FRP_VIP_SERVER_ADDR)}:{FRP_VIP_SERVER_PORT}</p>
    </div>
    <div class="bar">
      <button class="primary" onclick="repair()">自动检测修复</button>
      <button onclick="location.reload()">刷新</button>
      <a class="btn" href="http://127.0.0.1:8787/admin/live" target="_blank" rel="noopener noreferrer">全部实时对局</a>
      <a class="btn" href="/audit">访问数据</a>
      <a class="btn" href="http://127.0.0.1:8787/?k=root">主站</a>
      <a class="btn" href="http://127.0.0.1:8787/public">公网</a>
    </div>
  </div>
  {f'<div class="msg">{esc(message)}</div>' if message else ''}
  <section class="panel">
    <h2>总览</h2>
    <div class="grid">
      <div class="metric"><span>公网访问</span><strong>{render_status_badge(public_ok)} {esc(state['public']['message'])}</strong></div>
      <div class="metric"><span>VIP 公网访问</span><strong>{render_status_badge(vip_public_ok)} {esc(state['vip_public']['message'])}</strong></div>
      <div class="metric"><span>WeGame 登录态</span><strong>{render_status_badge(wg_ok)} {esc((state.get('wegame') or {}).get('message','-'))}</strong></div>
      <div class="metric"><span>模拟器</span><strong>{esc(state['adb']['device'])}</strong></div>
      <div class="metric"><span>模拟器代理</span><strong>{esc(state['adb']['proxy'])}</strong></div>
    </div>
  </section>
  <section class="panel">
    <h2>组件</h2>
    <table>
      <thead><tr><th>组件</th><th>状态</th><th>PID</th><th>端口</th><th>健康检查</th><th>操作</th></tr></thead>
      <tbody>{''.join(rows)}</tbody>
    </table>
  </section>
  <section class="panel">
    <h2>关键文件</h2>
    <table>
      <thead><tr><th>文件</th><th>状态</th><th>更新时间</th><th>路径</th></tr></thead>
      <tbody>{files}</tbody>
    </table>
  </section>
  <section class="panel">
    <h2>模拟器工具</h2>
    <div class="grid">
      <button onclick="tool('mval-login-mode')">掌瓦登录模式</button>
      <button onclick="tool('mval-capture-mode')">掌瓦抓包模式</button>
      <button onclick="tool('launch-mval')">打开掌瓦</button>
      <button onclick="logs('ops')">控制中心日志</button>
    </div>
    <div class="msg">ADB reverse: {esc(state['adb']['reverse'])}</div>
  </section>
  <section class="panel">
    <h2>推送 Token 管理</h2>
    <div class="grid">
      <button class="primary" onclick="createPushToken()">新建 Token</button>
      <button onclick="loadPushTokens()">刷新列表</button>
    </div>
    <div id="push-token-msg" class="msg" style="display:none"></div>
    <table>
      <thead><tr><th>Token</th><th>备注</th><th>状态</th><th>最近推送</th><th>最近 IP</th><th>封禁 IP</th><th>操作</th></tr></thead>
      <tbody id="push-token-body"><tr><td colspan="7">加载中…</td></tr></tbody>
    </table>
  </section>
  <section class="panel">
    <h2>日志</h2>
    <div id="log" class="logbox">点击组件后的“日志”按钮查看。</div>
  </section>
</main>
<script>
async function post(url) {{
  const r = await fetch(url, {{method:'POST'}});
  const t = await r.text();
  let d; try {{ d = JSON.parse(t); }} catch(e) {{ d = {{ok:false,error:t}}; }}
  alert((d.ok ? '完成：' : '失败：') + (d.message || d.error || ''));
  location.reload();
}}
function act(key, action) {{ post('/api/component/' + encodeURIComponent(key) + '/' + action); }}
function repair() {{ post('/api/repair'); }}
function tool(action) {{ post('/api/tool/' + action); }}
async function logs(key) {{
  const r = await fetch('/api/logs?component=' + encodeURIComponent(key));
  const d = await r.json();
  document.getElementById('log').textContent = d.text || d.error || '无日志';
}}
function escHtml(s) {{ return String(s).replace(/[&<>"']/g, c => ({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}})[c]); }}
function fmtPushTime(ts) {{ if (!ts) return '-'; try {{ return new Date(ts*1000).toLocaleString('zh-CN'); }} catch(e) {{ return '-'; }} }}
let pushTokensData = [];
async function loadPushTokens() {{
  const body = document.getElementById('push-token-body');
  try {{
    const r = await fetch('/api/push-tokens', {{cache:'no-store'}});
    const d = await r.json();
    if (!d.ok || !d.tokens) {{ body.innerHTML = '<tr><td colspan="7">'+escHtml(d.error||'加载失败')+'</td></tr>'; return; }}
    if (!d.tokens.length) {{ body.innerHTML = '<tr><td colspan="7">暂无 Token，点击“新建 Token”创建。</td></tr>'; return; }}
    pushTokensData = d.tokens;
    body.innerHTML = d.tokens.map((t,i) => {{
      const ips = (t.blocked_ips||[]).join(', ') || '-';
      const status = t.enabled ? '<span class="badge good">启用</span>' : '<span class="badge bad">禁用</span>';
      const toggleBtn = t.enabled ? '禁用' : '启用';
      return '<tr><td><code>'+escHtml(t.token_masked)+'</code></td><td>'+escHtml(t.remark||'-')+'</td><td>'+status+'</td><td>'+fmtPushTime(t.last_push)+'</td><td><code>'+escHtml(t.last_ip||'-')+'</code></td><td><code>'+escHtml(ips)+'</td><td class="actions"><button onclick="togglePushToken('+i+')">'+toggleBtn+'</button><button onclick="editRemark('+i+')">备注</button><button onclick="blockIp('+i+')">封禁IP</button>'+(t.blocked_ips&&t.blocked_ips.length?'<button onclick="unblockIpMenu('+i+')">解封IP</button>':'')+'<button class="danger" onclick="deletePushToken('+i+')">删除</button></td></tr>';
    }}).join('');
  }} catch(e) {{ body.innerHTML = '<tr><td colspan="7">加载失败：'+escHtml(e)+'</td></tr>'; }}
}}
async function ptPost(action, token, body) {{
  try {{
    const r = await fetch('/api/push-tokens/'+encodeURIComponent(token)+'/'+action, {{method:'POST',headers:{{'content-type':'application/json'}},body:JSON.stringify(body)}});
    const d = await r.json();
    alert(d.ok ? '完成' : ('失败：'+(d.error||'')));
    loadPushTokens();
  }} catch(e) {{ alert('失败：'+e); loadPushTokens(); }}
}}
function togglePushToken(i) {{ const t=pushTokensData[i]; ptPost('update', t.token, {{enabled: !t.enabled}}); }}
function editRemark(i) {{ const t=pushTokensData[i]; const v=prompt('备注：', t.remark||''); if(v===null) return; ptPost('update', t.token, {{remark: v}}); }}
function blockIp(i) {{ const t=pushTokensData[i]; const ip=prompt('要封禁的推送来源 IP：'); if(!ip) return; ptPost('update', t.token, {{add_blocked_ip: ip}}); }}
function unblockIpMenu(i) {{
  const t=pushTokensData[i]; if(!t.blocked_ips||!t.blocked_ips.length) return;
  const ip=prompt('要解封的 IP：\n'+t.blocked_ips.join('\n'));
  if(!ip) return; ptPost('update', t.token, {{remove_blocked_ip: ip}});
}}
function deletePushToken(i) {{ const t=pushTokensData[i]; if(!confirm('删除 Token '+t.token_masked+'？')) return; ptPost('delete', t.token, {{}}); }}
async function createPushToken() {{
  const remark=prompt('备注（可选）：','');
  if(remark===null) return;
  try {{
    const r=await fetch('/api/push-tokens',{{method:'POST',headers:{{'content-type':'application/json'}},body:JSON.stringify({{remark:remark||''}})}});
    const d=await r.json();
    if(d.ok) {{
      const msg=document.getElementById('push-token-msg');
      msg.style.display='block';
      msg.textContent='新 Token（仅显示一次，请立即复制）：'+d.token;
      alert('Token 已创建，请从页面顶部提示框复制完整 Token。');
      loadPushTokens();
    }} else {{ alert('失败：'+(d.error||'')); }}
  }} catch(e) {{ alert('失败：'+e); }}
}}
loadPushTokens();
setTimeout(() => {{ if(document.getElementById('push-token-msg').style.display!=='block') location.reload(); }}, 15000);
</script>
</body>
</html>"""


def format_audit_time(value: Any) -> str:
    try:
        return dt.datetime.fromtimestamp(int(value)).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "-"


def audit_csv_cell(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    if value.startswith(("=", "+", "-", "@", "\t", "\r")):
        return "'" + value
    return value


def render_audit_page(params: dict[str, list[str]]) -> str:
    category = (params.get("category") or ["all"])[0]
    search = (params.get("q") or [""])[0].strip()[:160]
    try:
        days = int((params.get("days") or ["30"])[0])
    except ValueError:
        days = 30
    try:
        page = int((params.get("page") or ["1"])[0])
    except ValueError:
        page = 1
    data = list_audit_events(
        category=category,
        search=search,
        days=days,
        page=page,
        page_size=100,
    )
    summary = audit_summary()
    category = category if category in {"all", "public_query", "live"} else "all"
    days = max(1, min(days, audit_retention_days()))
    category_options = "".join(
        f'<option value="{value}"{" selected" if value == category else ""}>{label}</option>'
        for value, label in (
            ("all", "全部记录"),
            ("public_query", "公共查询"),
            ("live", "实时对局"),
        )
    )
    days_options = "".join(
        f'<option value="{value}"{" selected" if value == days else ""}>最近 {value} 天</option>'
        for value in (1, 7, 30, 90, 180)
        if value <= audit_retention_days()
    )
    rows = []
    category_labels = {"public_query": "公共查询", "live": "实时对局"}
    action_labels = {"query": "查询", "select": "选择账号", "room": "房间战绩", "match": "当前对局"}
    for item in data["rows"]:
        status = str(item.get("result_status") or "-")
        status_class = "good" if status == "ok" else ("warn" if status in {"not_found", "unavailable"} else "bad")
        account = str(item.get("account_display") or "-")
        subject = str(item.get("account_subject") or "")
        query = str(item.get("query_text") or "-")
        rows.append(
            f"""
            <tr>
              <td><strong>{esc(format_audit_time(item.get('occurred_at')))}</strong><span>#{int(item.get('id') or 0)}</span></td>
              <td><span class="type-badge">{esc(category_labels.get(str(item.get('category')), str(item.get('category') or '-')))}</span><strong>{esc(action_labels.get(str(item.get('action')), str(item.get('action') or '-')))}</strong></td>
              <td><code>{esc(item.get('client_ip') or '-')}</code><span>会话来源：{esc(item.get('session_ip') or '-')}</span></td>
              <td><strong>{esc(account)}</strong><span class="mono">{esc(subject or '-')}</span></td>
              <td><strong>{esc(query)}</strong><span>{esc(item.get('endpoint') or '-')}</span></td>
              <td><span class="status {status_class}">{esc(status)}</span></td>
            </tr>
            """
        )
    if not rows:
        rows.append('<tr><td class="empty" colspan="6">当前筛选条件下没有记录</td></tr>')

    base_params = {"category": category, "q": search, "days": str(days)}
    export_url = "/api/audit/export.csv?" + urllib.parse.urlencode(base_params)
    prev_link = ""
    next_link = ""
    if data["page"] > 1:
        prev_link = "/audit?" + urllib.parse.urlencode({**base_params, "page": data["page"] - 1})
    if data["page"] < data["pages"]:
        next_link = "/audit?" + urllib.parse.urlencode({**base_params, "page": data["page"] + 1})
    pagination = (
        f'<a class="btn{" disabled" if not prev_link else ""}" href="{esc(prev_link or "#")}">上一页</a>'
        f'<span>第 {data["page"]} / {data["pages"]} 页，共 {data["total"]} 条</span>'
        f'<a class="btn{" disabled" if not next_link else ""}" href="{esc(next_link or "#")}">下一页</a>'
    )
    css = """
    :root{color-scheme:dark;--bg:#0b1118;--panel:#131c26;--line:#2b3a49;--text:#edf7ff;--muted:#91a6ba;--cyan:#7fd7e8;--yellow:#f3c45f;--green:#36d995;--red:#ff6680}
    *{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:"Microsoft YaHei","Segoe UI",Arial,sans-serif;font-size:14px;letter-spacing:0}a{color:inherit}
    main{max-width:1720px;margin:0 auto;padding:24px 22px 44px}.top{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;margin-bottom:20px}.top h1{margin:0;font-size:30px}.top p{margin:8px 0 0;color:var(--muted)}.bar{display:flex;gap:9px;flex-wrap:wrap}
    .btn,button{min-height:38px;padding:0 13px;border:1px solid #456078;border-radius:6px;background:#1b2a38;color:var(--text);font-family:inherit;font-size:14px;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}.btn:hover,button:hover{border-color:var(--cyan)}.primary{background:var(--yellow);border-color:var(--yellow);color:#111923}.disabled{opacity:.35;pointer-events:none}
    .metrics{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;margin-bottom:18px}.metric{min-height:92px;padding:14px;border:1px solid var(--line);border-radius:7px;background:var(--panel)}.metric span{color:var(--muted);font-size:12px}.metric strong{display:block;margin-top:8px;font-size:24px}
    .filter{display:grid;grid-template-columns:180px 170px minmax(260px,1fr) auto;gap:10px;padding:14px;border:1px solid var(--line);border-radius:7px 7px 0 0;background:var(--panel)}select,input{height:40px;border:1px solid #435467;border-radius:5px;background:#0a1219;color:var(--text);padding:0 12px;font:14px inherit}input{width:100%}
    .table-wrap{overflow:auto;border:1px solid var(--line);border-top:0}table{width:100%;min-width:1200px;border-collapse:collapse}th,td{padding:13px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:middle}th{position:sticky;top:0;background:#17212c;color:var(--cyan);font-size:12px}td strong{display:block;font-size:14px;line-height:1.45}td span{display:block;margin-top:4px;color:var(--muted);font-size:12px}.mono,code{font-family:Consolas,monospace;color:#cdeeff;word-break:break-all}.type-badge{display:inline-block;margin:0 0 6px;padding:3px 7px;border:1px solid #42566b;border-radius:4px;color:#dbeaff;background:#1a2836}.status{display:inline-block;margin:0;padding:5px 9px;border-radius:4px;font-weight:800}.status.good{color:var(--green);background:rgba(54,217,149,.12)}.status.warn{color:var(--yellow);background:rgba(243,196,95,.12)}.status.bad{color:var(--red);background:rgba(255,102,128,.12)}.empty{text-align:center;color:var(--muted);padding:38px}
    .pager{display:flex;align-items:center;justify-content:center;gap:14px;padding:14px;border:1px solid var(--line);border-top:0;border-radius:0 0 7px 7px;background:var(--panel)}.pager span{color:var(--muted)}.notice{margin-top:16px;padding:14px 16px;border-left:3px solid var(--cyan);background:#101a23;color:var(--muted);line-height:1.7}
    @media(max-width:980px){main{padding:14px}.top{flex-direction:column}.metrics{grid-template-columns:repeat(2,minmax(0,1fr))}.filter{grid-template-columns:1fr}.bar{width:100%}.bar .btn{flex:1}}
    """
    return f"""<!doctype html>
<html lang="zh-CN">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>访问数据 · WGame VAL 控制中心</title><style>{css}</style></head>
<body><main>
  <div class="top">
    <div><h1>访问数据</h1><p>公共查询与实时对局账号使用记录 · 数据库仅在本机控制中心开放</p></div>
    <div class="bar"><a class="btn" href="/ops">返回控制中心</a><a class="btn" href="/audit">刷新</a><a class="btn primary" href="{esc(export_url)}">导出 CSV</a></div>
  </div>
  <section class="metrics" aria-label="访问统计">
    <div class="metric"><span>全部记录</span><strong>{summary['total']}</strong></div>
    <div class="metric"><span>最近 24 小时</span><strong>{summary['day_total']}</strong></div>
    <div class="metric"><span>最近 7 天</span><strong>{summary['week_total']}</strong></div>
    <div class="metric"><span>独立访问 IP</span><strong>{summary['unique_ips']}</strong></div>
    <div class="metric"><span>实时账号</span><strong>{summary['live_accounts']}</strong></div>
    <div class="metric"><span>被查询账号</span><strong>{summary['queried_accounts']}</strong></div>
  </section>
  <form class="filter" method="get" action="/audit">
    <select name="category" aria-label="记录类型">{category_options}</select>
    <select name="days" aria-label="时间范围">{days_options}</select>
    <input name="q" value="{esc(search)}" placeholder="搜索 IP、昵称、查询词或账号标识" maxlength="160">
    <button type="submit">筛选</button>
  </form>
  <div class="table-wrap"><table>
    <thead><tr><th>时间</th><th>类型</th><th>访问 IP</th><th>账号</th><th>查询或入口</th><th>结果</th></tr></thead>
    <tbody>{''.join(rows)}</tbody>
  </table></div>
  <div class="pager">{pagination}</div>
  <div class="notice">原始 IP、查询内容和账号标识属于需要保护的使用数据。默认保留 {audit_retention_days()} 天，超过期限自动删除；不要把数据库或 CSV 上传到公开仓库、Issue 或聊天记录。</div>
</main></body></html>"""


def audit_csv_bytes(params: dict[str, list[str]]) -> bytes:
    category = (params.get("category") or ["all"])[0]
    search = (params.get("q") or [""])[0].strip()[:160]
    try:
        days = int((params.get("days") or ["30"])[0])
    except ValueError:
        days = 30
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["ID", "时间", "类型", "动作", "访问IP", "会话来源IP", "查询内容", "账号昵称", "账号标识", "会话ID", "结果", "入口"])
    page = 1
    while True:
        data = list_audit_events(category=category, search=search, days=days, page=page, page_size=500)
        for item in data["rows"]:
            writer.writerow([audit_csv_cell(value) for value in [
                item.get("id"),
                format_audit_time(item.get("occurred_at")),
                item.get("category"),
                item.get("action"),
                item.get("client_ip"),
                item.get("session_ip"),
                item.get("query_text"),
                item.get("account_display"),
                item.get("account_subject"),
                item.get("session_id"),
                item.get("result_status"),
                item.get("endpoint"),
            ]])
        if page >= data["pages"]:
            break
        page += 1
    return ("\ufeff" + output.getvalue()).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "WGameValOps/0.1"

    def log_message(self, format: str, *args: Any) -> None:
        """控制中心由 pythonw 启动，不向可被 QuickEdit 暂停的控制台写请求日志。"""
        return

    def send_json(self, data: dict[str, Any], status: int = 200) -> None:
        encoded = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def send_html(self, body: str, status: int = 200) -> None:
        encoded = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def send_bytes(
        self,
        data: bytes,
        content_type: str,
        *,
        filename: str = "",
        status: int = 200,
    ) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        if parsed.path == "/api/ping":
            self.send_json({"ok": True, "service": "ops-control-center"})
            return
        if parsed.path == "/api/push-tokens":
            status, data = main_service_request("GET", "/api/push-tokens")
            self.send_json(data, status if status else 502)
            return
        if parsed.path in ("/", "/ops"):
            self.send_html(render_page())
            return
        if parsed.path == "/audit":
            self.send_html(render_audit_page(params))
            return
        if parsed.path == "/api/audit/export.csv":
            filename = f"wgame-usage-audit-{dt.datetime.now():%Y%m%d-%H%M%S}.csv"
            self.send_bytes(
                audit_csv_bytes(params),
                "text/csv; charset=utf-8",
                filename=filename,
            )
            return
        if parsed.path == "/api/status":
            state, status_age = cached_status()
            self.send_json({
                "ok": True,
                "status_age_seconds": None if status_age is None else round(status_age, 3),
                **state,
            })
            return
        if parsed.path == "/api/logs":
            component = (params.get("component") or ["ops"])[0]
            component = canonical_component_key(component)
            configs = component_configs()
            text = ""
            if component == "ops":
                text = tail_file(OPS_LOG)
            elif component in configs:
                cfg = configs[component]
                text = (
                    f"== STDOUT {cfg.get('stdout')} ==\n"
                    + tail_file(Path(cfg.get("stdout")))
                    + f"\n\n== STDERR {cfg.get('stderr')} ==\n"
                    + tail_file(Path(cfg.get("stderr")))
                )
            else:
                self.send_json({"ok": False, "error": "unknown component"}, 404)
                return
            self.send_json({"ok": True, "component": component, "text": text})
            return
        self.send_json({"ok": False, "error": "not found"}, 404)

    def do_POST(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        parts = [p for p in parsed.path.split("/") if p]
        try:
            with ACTION_LOCK:
                if parts == ["api", "push-tokens"]:
                    length = int(self.headers.get("content-length") or "0")
                    body = {}
                    if length > 0:
                        try:
                            body = json.loads(self.rfile.read(length).decode("utf-8"))
                        except Exception:
                            body = {}
                    status, data = main_service_request("POST", "/api/push-tokens", body)
                    if status and data.get("ok"):
                        log_event("新建 push token", str(data.get("token_masked") or ""))
                    self.send_json(data, status if status else 502)
                    return
                if (
                    len(parts) == 4
                    and parts[0] == "api"
                    and parts[1] == "push-tokens"
                    and parts[3] in ("delete", "update")
                ):
                    token = urllib.parse.unquote(parts[2])
                    action = parts[3]
                    length = int(self.headers.get("content-length") or "0")
                    body = {}
                    if length > 0:
                        try:
                            body = json.loads(self.rfile.read(length).decode("utf-8"))
                        except Exception:
                            body = {}
                    method = "DELETE" if action == "delete" else "PUT"
                    status, data = main_service_request(
                        method,
                        f"/api/push-tokens/{urllib.parse.quote(token, safe='')}",
                        body if method == "PUT" else None,
                    )
                    if status and data.get("ok"):
                        log_event(f"push token {action}", token[:4] + "••••")
                    self.send_json(data, status if status else 502)
                    return
                if parts == ["api", "repair"]:
                    message = repair_all()
                    self.send_json({"ok": True, "message": message})
                    return
                if len(parts) == 4 and parts[0] == "api" and parts[1] == "component":
                    key = urllib.parse.unquote(parts[2])
                    key = canonical_component_key(key)
                    action = parts[3]
                    if key not in component_configs():
                        self.send_json({"ok": False, "error": "unknown component"}, 404)
                        return
                    if action == "start":
                        message = start_component(key)
                    elif action == "stop":
                        message = stop_component(key)
                    elif action == "restart":
                        message = restart_component(key)
                    else:
                        self.send_json({"ok": False, "error": "unknown action"}, 400)
                        return
                    log_event(f"操作 {key}/{action}", message)
                    self.send_json({"ok": True, "message": message})
                    return
                if len(parts) == 3 and parts[0] == "api" and parts[1] == "tool":
                    action = parts[2]
                    if action == "mval-login-mode":
                        message = clear_android_proxy()
                    elif action == "mval-capture-mode":
                        message = set_android_mval_proxy()
                    elif action == "launch-mval":
                        message = launch_mval_app()
                    else:
                        self.send_json({"ok": False, "error": "unknown tool"}, 400)
                        return
                    log_event(f"工具 {action}", message)
                    self.send_json({"ok": True, "message": message})
                    return
        except Exception as exc:
            log_event("操作异常", f"{type(exc).__name__}: {exc}")
            self.send_json({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, 500)
            return
        self.send_json({"ok": False, "error": "not found"}, 404)


def health_check_daemon() -> None:
    """后台守护线程：独立检查组件；确认异常后重启并提供冷却保护。"""
    restart_count: dict[str, int] = {key: 0 for key in AUTO_RECOVER_COMPONENTS}
    consecutive_failures: dict[str, int] = {key: 0 for key in AUTO_RECOVER_COMPONENTS}
    cooldown_until: dict[str, float] = {key: 0.0 for key in AUTO_RECOVER_COMPONENTS}

    while True:
        try:
            configs = component_configs()
            process_list = list_processes()
            for key in AUTO_RECOVER_COMPONENTS:
                if key not in configs or not DESIRED_RUNNING.get(key, True):
                    continue
                cfg = configs[key]
                status = component_status(key, cfg, process_list)
                if status["healthy"]:
                    if restart_count[key] > 0:
                        log_event(f"健康检查：{cfg['title']} 已恢复")
                    restart_count[key] = 0
                    consecutive_failures[key] = 0
                    cooldown_until[key] = 0.0
                    continue

                now_ts = time.time()
                if now_ts < cooldown_until[key]:
                    continue
                consecutive_failures[key] += 1
                required_failures = 1 if not status["running"] else int(cfg.get("recover_after_failures", 1))
                if consecutive_failures[key] < required_failures:
                    log_event(
                        f"健康检查待确认：{cfg['title']}",
                        f"failure={consecutive_failures[key]}/{required_failures} "
                        f"running={status['running']} tunnel_ok={status.get('tunnel_ok')} "
                        f"http_ok={status['http_ok']}",
                    )
                    continue

                with ACTION_LOCK:
                    # 用户操作可能在等待锁期间已经修复或停止组件，重查一次。
                    if not DESIRED_RUNNING.get(key, True):
                        consecutive_failures[key] = 0
                        continue
                    latest = component_status(key, cfg)
                    if latest["healthy"]:
                        consecutive_failures[key] = 0
                        continue
                    restart_count[key] += 1
                    consecutive_failures[key] = 0
                    log_event(
                        f"健康检查异常：{cfg['title']}（第 {restart_count[key]} 次自动重启）",
                        f"running={latest['running']} port_ok={latest['port_ok']} "
                        f"tunnel_ok={latest.get('tunnel_ok')} http_ok={latest['http_ok']}",
                    )
                    try:
                        result = restart_component(key, update_desired=False)
                        log_event(f"自动重启 {cfg['title']} 结果", result)
                    except Exception as exc:
                        log_event(f"自动重启 {cfg['title']} 失败", f"{type(exc).__name__}: {exc}")
                if restart_count[key] >= MAX_CONSECUTIVE_RESTARTS:
                    cooldown_until[key] = time.time() + RECOVERY_COOLDOWN_SECONDS
                    restart_count[key] = 0
                    log_event(
                        f"健康检查冷却：{cfg['title']}",
                        f"{RECOVERY_COOLDOWN_SECONDS} 秒后继续尝试，避免重启循环",
                    )
        except Exception as exc:
            log_event("健康检查守护异常", f"{type(exc).__name__}: {exc}")
        time.sleep(HEALTH_CHECK_INTERVAL)


def main() -> None:
    parser = argparse.ArgumentParser(description="WGame VAL ops control center")
    parser.add_argument("--port", type=int, default=CONTROL_PORT)
    parser.add_argument("--open-browser", action="store_true")
    args = parser.parse_args()
    ensure_dirs()
    init_audit_db()
    url = f"http://127.0.0.1:{args.port}/"
    try:
        server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    except OSError as exc:
        if args.open_browser and getattr(exc, "winerror", None) == 10048:
            if sys.stdout is not None:
                print(f"Ops control center is already running at {url}")
            webbrowser.open(url)
            return
        raise
    server.daemon_threads = True
    log_event(
        "控制中心启动",
        f"port={args.port} auto_recover={AUTO_RECOVER_COMPONENTS} "
        f"health_interval={HEALTH_CHECK_INTERVAL}s status_interval={STATUS_REFRESH_INTERVAL}s",
    )
    status_daemon = threading.Thread(
        target=status_refresh_daemon,
        daemon=True,
        name="status-refresh",
    )
    status_daemon.start()
    daemon = threading.Thread(target=health_check_daemon, daemon=True, name="health-check")
    daemon.start()
    if args.open_browser:
        opener = threading.Timer(0.25, webbrowser.open, args=(url,))
        opener.daemon = True
        opener.start()
    if sys.stdout is not None:
        print(f"Ops control center listening at {url}")
    server.serve_forever()


if __name__ == "__main__":
    main()
