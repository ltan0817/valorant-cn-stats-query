# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import base64
import hashlib
import html
import importlib
import ipaddress
import json
import os
import re
import secrets
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import uuid
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import requests
import websocket

from usage_audit import (
    audit_retention_days,
    init_audit_db,
    normalize_ip,
    record_live_usage,
    record_public_query,
)

try:
    from curl_cffi import requests as curl_requests
except Exception:
    curl_requests = None


APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
PAGES_DIR = APP_DIR / "pages"
CAPTURE_DIR = APP_DIR / "captures"
DB_PATH = DATA_DIR / "subjects.sqlite3"
CHROME_PROFILE = DATA_DIR / "chrome-profile"
CURRENT_MATCH_CACHE = DATA_DIR / "current-match.subjects.json"
BATTLE_DETAIL_CACHE = DATA_DIR / "current-match-recent-battles.json"
MVAL_SCRIPT_DIR = DATA_DIR / "mval"
MVAL_SESSION_PATH = MVAL_SCRIPT_DIR / "mval-session.json"
LOCATION_CACHE_PATH = DATA_DIR / "player_locations.json"
AGENT_ICON_DIR = DATA_DIR / "agent-icons"
MAP_ART_DIR = DATA_DIR / "map-art"
PUBLIC_TOKEN_PATH = CAPTURE_DIR / "public-query-token.txt"
PUSH_TOKENS_PATH = DATA_DIR / "push-tokens.json"
BAIDU_VERIFY_DIR = DATA_DIR / "baidu-verification"
PUBLIC_PREVIEW_PATH = APP_DIR / "assets" / "public-query-preview-20260723.png"
PUBLIC_CONTACT_ASSET_PATH = APP_DIR / "assets" / "contact-info.png"
PARTY_ANALYSIS_DEMO_PATH = PAGES_DIR / "party-analysis-demo.html"
LOCATION_CACHE_TTL = 24 * 60 * 60
LOCATION_ERROR_TTL = 10 * 60
WEGAME_CDP_PORT = 9222   # WeGame 桌面客户端 debug port（备用）
CHROME_PORT = 9223       # 专用 Chrome 调试端口
SERVER_PORT = 8787
BASE_URL = "https://www.wegame.com.cn"
HELPER_URL = "https://www.wegame.com.cn/helper/valorant/"
PUBLIC_SITE_URL = "http://127.0.0.1:8787"
PUBLIC_PAGE_UPDATED = "2026-07-30"
PUBLIC_BATTLE_DETAIL_REF_TTL = 30 * 60
PUBLIC_BATTLE_DETAIL_REF_LIMIT = 2048
MATCH_HEADSHOT_CACHE_TTL = 30 * 60
MATCH_HEADSHOT_CACHE_LIMIT = 512
PUBLIC_LIVE_COOKIE = "wgame_live_choice"
PUBLIC_LIVE_RISK_COOKIE = "wgame_live_risk_consent"
PUBLIC_LIVE_RISK_NONCE_COOKIE = "wgame_live_risk_nonce"
PUBLIC_LIVE_RISK_CLIENT_COOKIE = "wgame_live_risk_client"
LIVE_RISK_AGREEMENT_VERSION = "2026-07-21-v3"
LIVE_RISK_AGREEMENT_EFFECTIVE_DATE = "2026年7月21日"
LIVE_RISK_CONSENT_TTL = 180 * 24 * 60 * 60
LIVE_RISK_RECORD_TTL = 365 * 24 * 60 * 60
LIVE_RISK_AGREEMENT_TEXT = """实时对局功能风险知情与使用协议
版本：2026-07-21-v3；生效日期：2026年7月21日

一、重要风险提示
截至本协议版本发布日，本站仅在有限测试范围内暂未发现因使用实时对局功能直接导致游戏账号被封禁的情况。该测试结果不构成零风险承诺、安全保证、官方认可证明或对未来结果的预测。实时对局功能需要在用户设备上配置代理或证书，并采集、转发、读取和分析与游戏实时状态有关的网络请求。此类行为可能被游戏运营方、反作弊系统、网络服务商或其他第三方识别为异常，并可能导致警告、强制下线、功能限制、数据异常、临时封禁、永久封禁、设备限制、网络故障或其他不利后果。

二、用户自主决定与合规义务
用户应当在充分理解风险后自主决定是否启用本功能，并自行核对、遵守游戏运营方现行的用户协议、反作弊规则及其他适用规则。用户仅可在本人所有或已获得充分授权的设备、网络和游戏账号上使用本功能，不得用于作弊、篡改游戏、绕过安全机制、干扰服务、截取他人通信、侵犯他人权益或实施任何违法违规行为。用户对其安装证书、配置代理、使用查询结果以及其他操作行为独立负责。

三、责任范围
在适用法律允许的最大范围内，因用户主动启用或使用本功能、配置错误、未及时恢复网络设置、违反游戏运营方协议或规则、第三方检测或处罚、网络及设备环境变化等原因产生的账号限制或封禁、数据丢失、网络中断、财产损失及其他后果，由用户自行承担。本站不保证功能持续可用、结果绝对准确、操作不会被识别或账号不会受到处罚，也不对游戏运营方或其他第三方独立作出的处理决定负责。

前述责任限制不适用于依法不得排除或限制的责任，包括因本站故意或重大过失造成的财产损失、造成用户人身损害的责任，以及法律法规规定不得免责的其他情形。本站将对自身依法应当承担的责任负责。

四、网络流量、确认记录与使用审计
为提供实时对局功能，相关游戏网络请求可能经过本站指定的代理链路并被自动处理。本站应按照功能所需的最小范围处理数据，不以本功能收集游戏账号密码。为证明用户已收到显著风险提示并作出主动确认，本站会保存协议版本、协议正文摘要、确认时间、随机确认编号以及经哈希处理的网络和浏览器环境摘要；不在确认记录中保存原始 IP 地址。未撤回的确认记录最长保存365天，用于安全审计、争议处理和防止确认凭证被滥用，期限届满后删除或匿名化。

为关联用户主动选择的实时游戏账号、保障服务安全、排查滥用并统计功能使用情况，本站另行保存使用时间、访问 IP、游戏会话来源 IP、所选游戏昵称和账号标识、访问的实时功能及处理结果，默认保存180天。该使用审计记录与风险确认记录分开保存，仅限本机控制中心管理使用，不在公共页面展示。具体规则见本站隐私说明。

五、确认期限、更新与停止使用
本次确认有效期为180天。协议内容、数据处理方式或风险发生重要变化时，本站会要求用户重新确认。用户不同意本协议的，应停止使用实时对局功能且无需继续提交。用户可以随时点击实时页面的“一键撤回并永久锁定”；撤回后原确认记录不会删除，而会追加撤回时间并保留当前浏览器标识的哈希摘要，在实时功能持续提供期间用于执行不可恢复锁定和证明撤回事实。撤回后当前浏览器不能再次确认或使用实时功能，撤回不影响此前已完成处理的效力。由于本站没有用户账号体系，永久锁定依赖当前浏览器保存的独立标识；用户主动清除全部站点数据后，本站可能无法继续识别该浏览器。

六、第三方关系
本站为非官方社区工具，与游戏开发商、发行商及运营方不存在隶属、授权、担保或背书关系。游戏名称及相关商标归各自权利人所有。
"""
SUBJECT_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)
NAME_TAG_RE = re.compile(r"^(.+?)#([A-Za-z0-9]{3,8})$")
BAIDU_VERIFY_RE = re.compile(r"^baidu_verify_[A-Za-z0-9_-]+\.html$")
TASKS: dict[str, dict[str, Any]] = {}
TASK_LOCK = threading.Lock()
LOCATION_LOCK = threading.Lock()
AGENT_ICON_LOCK = threading.Lock()
MAP_ART_LOCK = threading.Lock()
LIVE_RISK_LOCK = threading.Lock()
PUBLIC_BATTLE_DETAIL_REF_LOCK = threading.Lock()
PUBLIC_BATTLE_DETAIL_REFS: dict[str, dict[str, Any]] = {}
MATCH_HEADSHOT_CACHE_LOCK = threading.Lock()
MATCH_HEADSHOT_CACHE: dict[str, dict[str, Any]] = {}
NICKNAME_RANK_TASK_LOCK = threading.Lock()
NICKNAME_RANK_TASKS: dict[str, dict[str, Any]] = {}
PUSH_TOKENS_LOCK = threading.Lock()


GAME_TOKEN_HEADERS = {
    "authorization",
    "x-riot-entitlements-jwt",
    "x-riot-clientversion",
    "x-riot-clientplatform",
    "user-agent",
}


RANK_NAMES = {
    0: "未定级",
    1: "未定级",
    2: "未定级",
    3: "黑铁1",
    4: "黑铁2",
    5: "黑铁3",
    6: "青铜1",
    7: "青铜2",
    8: "青铜3",
    9: "白银1",
    10: "白银2",
    11: "白银3",
    12: "黄金1",
    13: "黄金2",
    14: "黄金3",
    15: "铂金1",
    16: "铂金2",
    17: "铂金3",
    18: "钻石1",
    19: "钻石2",
    20: "钻石3",
    21: "超凡1",
    22: "超凡2",
    23: "超凡3",
    24: "神话1",
    25: "神话2",
    26: "神话3",
    27: "赋能战魂",
}

AGENTS = {
    "0e38b510-41a8-5780-5e8f-568b2a4f2d6c": "壹决 / Iso",
    "117ed9e3-49f3-6512-3ccf-0cada7e3823b": "零 / Cypher",
    "1dbf2edd-4729-0984-3115-daa5eed44993": "暮蝶 / Clove",
    "1e58de9c-4950-5125-93e9-a0aee9f98746": "奇乐 / Killjoy",
    "22697a3d-45bf-8dd7-4fec-84a9e28c69d7": "尚勃勒 / Chamber",
    "320b2a48-4d9b-a075-30f1-1f93a9b638fa": "猎枭 / Sova",
    "41fb69c1-4189-7b37-f117-bcaf1e96f1bf": "星礈 / Astra",
    "569fdd95-4d10-43ab-ca70-79becc718b46": "贤者 / Sage",
    "5f8d3a7f-467b-97f3-062c-13acf203c006": "铁臂 / Breach",
    "601dbbe7-43ce-be57-2a40-4abd24953621": "K/O / KAYO",
    "6f2a04ca-43e0-be17-7f36-b3908627744d": "斯凯 / Skye",
    "707eab51-4836-f488-046a-cda6bf494859": "蝰蛇 / Viper",
    "7c8a4701-4de6-9355-b254-e09bc2a34b72": "迷核 / Miks",
    "7f94d92c-4234-0a36-9646-3a87eb8b5c89": "夜露 / Yoru",
    "8e253930-4c05-31dd-1b6c-968525494517": "幽影 / Omen",
    "92eeef5d-43b5-1d4a-8d03-b3927a09034b": "禁灭",
    "95b78ed7-4637-86d9-7e41-71ba8c293152": "海神 / Harbor",
    "9f0d8ba9-4140-b941-57d3-a7ad57c6b417": "炼狱 / Brimstone",
    "a3bfb853-43b2-7238-a4f1-ad90e9e46bcc": "芮娜 / Reyna",
    "add6443a-41bd-e414-f6ad-e58d267f4e95": "捷风 / Jett",
    "b444168c-4e35-8076-db47-ef9bf368f384": "钛狐 / Tejo",
    "bb2a4828-46eb-8cd1-e765-15848195d751": "霓虹 / Neon",
    "cc8b64c8-4b25-4ff9-6e7f-37b4da43d235": "钢锁 / Deadlock",
    "dade69b4-4f5a-8528-247b-219e5a1facd6": "黑梦 / Fade",
    "df1cb487-4902-002e-5c17-d28e83e78588": "幻棱",
    "e370fa57-4757-3604-3648-499e1f642d3f": "盖可 / Gekko",
    "eb93336a-449b-9c1b-0a54-a891f7921d69": "不死鸟 / Phoenix",
    "efba5359-4016-a1e5-7626-b1ae76895940": "维斯 / Vyse",
    "f94c3b30-42be-e959-889c-5aa313dba261": "雷兹 / Raze",
}

MAP_NAMES = {
    "ascent": "亚海悬城",
    "bonsai": "霓虹町",
    "split": "霓虹町",
    "canyon": "裂变峡谷",
    "fracture": "裂变峡谷",
    "duality": "源工重镇",
    "bind": "源工重镇",
    "foxtrot": "微风岛屿",
    "breeze": "微风岛屿",
    "infinity": "幽邃地窟",
    "abyss": "幽邃地窟",
    "jam": "莲华古城",
    "lotus": "莲华古城",
    "juliett": "日落之城",
    "sunset": "日落之城",
    "pitt": "深海明珠",
    "pearl": "深海明珠",
    "plummet": "天枢云阙",
    "summit": "天枢云阙",
    "port": "森寒冬港",
    "icebox": "森寒冬港",
    "rook": "盐海矿镇",
    "corrode": "盐海矿镇",
    "triad": "隐世修所",
    "haven": "隐世修所",
    "npev2": "基础训练",
    "range": "靶场",
    "rangev2": "靶场",
    "skirmish_a": "斗牛 1",
    "skirmish_b": "斗牛 2",
    "skirmish_c": "斗牛 3",
    "skirmish_d": "斗牛 4",
    "skirmish_e": "斗牛 5",
    "hurm_alley": "商街",
    "hurm_bowl": "古城",
    "hurm_helix": "渔市",
    "hurm_hightide": "乱次元",
    "hurm_yard": "小镇",
}

MAP_ASSET_UUIDS = {
    "ascent": "7eaecc1b-4337-bbf6-6ab9-04b8f06b3319",
    "bonsai": "d960549e-485c-e861-8d71-aa9d1aed12a2",
    "split": "d960549e-485c-e861-8d71-aa9d1aed12a2",
    "canyon": "b529448b-4d60-346e-e89e-00a4c527a405",
    "fracture": "b529448b-4d60-346e-e89e-00a4c527a405",
    "duality": "2c9d57ec-4431-9c5e-2939-8f9ef6dd5cba",
    "bind": "2c9d57ec-4431-9c5e-2939-8f9ef6dd5cba",
    "foxtrot": "2fb9a4fd-47b8-4e7d-a969-74b4046ebd53",
    "breeze": "2fb9a4fd-47b8-4e7d-a969-74b4046ebd53",
    "infinity": "224b0a95-48b9-f703-1bd8-67aca101a61f",
    "abyss": "224b0a95-48b9-f703-1bd8-67aca101a61f",
    "jam": "2fe4ed3a-450a-948b-6d6b-e89a78e680a9",
    "lotus": "2fe4ed3a-450a-948b-6d6b-e89a78e680a9",
    "juliett": "92584fbe-486a-b1b2-9faa-39b0f486b498",
    "sunset": "92584fbe-486a-b1b2-9faa-39b0f486b498",
    "pitt": "fd267378-4d1d-484f-ff52-77821ed10dc2",
    "pearl": "fd267378-4d1d-484f-ff52-77821ed10dc2",
    "plummet": "756da597-416b-c0f2-f47b-afbdf28670bc",
    "summit": "756da597-416b-c0f2-f47b-afbdf28670bc",
    "port": "e2ad5c54-4114-a870-9641-8ea21279579a",
    "icebox": "e2ad5c54-4114-a870-9641-8ea21279579a",
    "rook": "1c18ab1f-420d-0d8b-71d0-77ad3c439115",
    "corrode": "1c18ab1f-420d-0d8b-71d0-77ad3c439115",
    "triad": "2bee0dc9-4ffe-519b-1cbd-7fbe763a6047",
    "haven": "2bee0dc9-4ffe-519b-1cbd-7fbe763a6047",
}

APP_CSS = """
    :root {
      color-scheme: dark;
      --bg: #0d151e;
      --panel: #141f2a;
      --panel2: #101923;
      --line: #2a3948;
      --line2: #33465a;
      --text: #eef7ff;
      --muted: #8fa5ba;
      --cyan: #96d9ff;
      --green: #31f08c;
      --red: #ff3f68;
      --gold: #ffd166;
      --chip: #223244;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: var(--bg);
      color: var(--text);
      font-family: "Microsoft YaHei", "Segoe UI", Arial, sans-serif;
      letter-spacing: 0;
    }
    main { max-width: 1780px; margin: 0 auto; padding: 24px 22px 40px; }
    a { color: var(--gold); text-decoration: none; }
    h1, h2, p { margin-top: 0; }
    .topbar { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 14px; color: var(--muted); font-size: 13px; }
    .panel {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      overflow: hidden;
      margin: 0 0 18px;
    }
    .player-head {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 22px;
      padding: 20px 22px 18px;
      border-bottom: 1px solid var(--line);
      background: rgba(255,255,255,.025);
    }
    .player-head h1, .player-head h2 { margin: 0 0 7px; font-size: 28px; line-height: 1.12; }
    .player-head p { margin: 0; color: var(--muted); font-size: 14px; }
    .record {
      white-space: nowrap;
      padding: 9px 14px;
      border: 1px solid var(--line2);
      border-radius: 999px;
      color: var(--gold);
      font-size: 16px;
      font-weight: 800;
      background: rgba(0,0,0,.15);
    }
    .team-blue { border-left: 3px solid #45b7ff; }
    .team-red { border-left: 3px solid #ff4d6d; }
    .live-layout {
      display: grid;
      grid-template-columns: 290px minmax(0, 1fr);
      gap: 16px;
      max-width: 1760px;
      margin: 0 auto;
      padding: 24px 22px 40px;
    }
    .live-main {
      max-width: none;
      margin: 0;
      padding: 0;
      min-width: 0;
    }
    .live-sidebar {
      position: sticky;
      top: 14px;
      align-self: start;
      max-height: calc(100vh - 28px);
      overflow-y: auto;
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
    }
    .live-sidebar-head {
      padding: 15px 16px 13px;
      border-bottom: 1px solid var(--line);
      background: rgba(255,255,255,.025);
    }
    .live-sidebar-head strong { display: block; font-size: 17px; }
    .live-sidebar-head span { display: block; margin-top: 4px; color: var(--muted); font-size: 12px; }
    .side-group {
      position: relative;
      isolation: isolate;
      padding: 12px;
      border-bottom: 1px solid var(--line);
    }
    .side-group:last-child { border-bottom: 0; }
    .side-title {
      position: relative;
      z-index: 3;
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin: 0 0 10px;
      color: var(--cyan);
      font-size: 13px;
      font-weight: 900;
    }
    .nav-player {
      --team-accent: var(--line2);
      --party-color: transparent;
      position: relative;
      z-index: 1;
      width: 100%;
      display: grid;
      grid-template-columns: 50px minmax(0, 1fr);
      grid-template-rows: repeat(3, auto);
      gap: 3px 10px;
      min-height: 72px;
      margin: 0 0 8px;
      padding: 9px 10px;
      border: 1px solid var(--line2);
      border-left-width: 3px;
      border-radius: 6px;
      background: #101923;
      color: #fff;
      text-align: left;
    }
    .nav-player:hover { background: #172434; }
    .nav-player.own { --team-accent: #45b7ff; border-left-color: #45b7ff; }
    .nav-player.enemy { --team-accent: #ff4d6d; border-left-color: #ff4d6d; }
    .nav-player.loaded { border-color: rgba(49,240,140,.55); }
    .nav-player.error { border-color: rgba(255,63,104,.75); }
    .nav-player.party-linked .nav-avatar {
      box-shadow:
        0 0 0 2px #101923,
        0 0 0 5px var(--party-color),
        0 0 14px rgba(255,255,255,.12);
    }
    .party-link-line,
    .party-link-branch {
      position: absolute;
      pointer-events: none;
      border-radius: 999px;
      background: var(--party-color);
      box-shadow: 0 0 8px var(--party-color);
    }
    .party-link-line {
      z-index: 0;
      width: 3px;
      transform: translateX(-50%);
    }
    .party-link-branch {
      z-index: 2;
      height: 3px;
      transform: translateY(-50%);
    }
    .nav-avatar {
      position: relative;
      grid-column: 1;
      grid-row: 1 / span 3;
      align-self: center;
      width: 48px;
      height: 48px;
      overflow: hidden;
      border: 3px solid var(--team-accent);
      border-radius: 50%;
      background: #0b121a;
      box-shadow: 0 0 0 2px rgba(255,255,255,.06);
    }
    .nav-avatar img {
      position: relative;
      z-index: 1;
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center top;
    }
    .nav-avatar-fallback {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--gold);
      font-size: 12px;
      font-weight: 900;
    }
    .nav-hero {
      grid-column: 2;
      color: var(--gold);
      font-size: 12px;
      font-weight: 900;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .nav-identity {
      grid-column: 2;
      display: flex;
      align-items: center;
      gap: 7px;
      min-width: 0;
    }
    .nav-name {
      flex: 1 1 auto;
      min-width: 0;
      color: #fff;
      font-size: 14px;
      font-weight: 800;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .nav-rank {
      flex: 0 0 auto;
      max-width: 82px;
      padding: 2px 6px;
      overflow: hidden;
      border: 1px solid #3b4a58;
      border-radius: 999px;
      background: #17222d;
      color: #dce8f1;
      font-size: 10px;
      font-weight: 900;
      line-height: 1.4;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .nav-rank.pending { color: var(--muted); }
    .nav-rank.unknown { color: #8fa0ae; }
    .nav-state {
      grid-column: 2;
      display: flex;
      align-items: center;
      gap: 6px;
      min-width: 0;
      color: var(--muted);
      font-size: 12px;
    }
    .nav-state-text {
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .nav-party-label {
      display: none;
      align-items: center;
      gap: 4px;
      flex: 0 0 auto;
      color: var(--party-color);
      font-weight: 900;
      white-space: nowrap;
    }
    .nav-party-label::before {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: currentColor;
      box-shadow: 0 0 7px currentColor;
      content: "";
    }
    .nav-player.party-linked .nav-party-label { display: inline-flex; }
    .scroll-target { scroll-margin-top: 18px; }
    .table-wrap { overflow-x: auto; border-top: 1px solid var(--line); }
    table {
      width: 100%;
      min-width: 1360px;
      border-collapse: collapse;
      table-layout: fixed;
      font-size: 14px;
      line-height: 1.42;
    }
    th, td {
      border-bottom: 1px solid var(--line);
      padding: 13px 12px;
      text-align: left;
      vertical-align: middle;
      overflow-wrap: anywhere;
    }
    th {
      color: var(--cyan);
      background: #101923;
      font-size: 13px;
      font-weight: 800;
    }
    tbody tr:hover { background: rgba(150,217,255,.06); }
    .idx { width: 40px; color: var(--cyan); }
    .time { width: 156px; font-weight: 800; color: #fff; }
    .result-col { width: 58px; }
    .hero-col { width: 150px; }
    .score-col { width: 70px; }
    .kda-col { width: 96px; }
    .acs-col { width: 66px; }
    .map-col { width: 94px; }
    .rank-col { width: 76px; }
    .rr-col { width: 64px; }
    .duration-col { width: 76px; }
    .event-col { width: 220px; }
    .highlight-col { width: 190px; }
    .actions-col { width: 150px; }
    .result {
      display: inline-block;
      font-weight: 900;
      font-size: 15px;
      line-height: 1.15;
    }
    .result.win { color: var(--green); }
    .result.loss { color: var(--red); }
    .hero { color: #f4fbff; font-size: 14px; font-weight: 800; }
    .muted { color: var(--muted); }
    code { color: #bde4ff; font-size: 11px; word-break: break-all; }
    .mate {
      display: inline-flex;
      flex-direction: column;
      gap: 2px;
      margin: 0 5px 5px 0;
      padding: 7px 9px;
      border: 1px solid var(--line2);
      border-radius: 5px;
      background: var(--chip);
      color: #fff;
      font-size: 13px;
      line-height: 1.15;
      white-space: nowrap;
    }
    .mate small { color: var(--muted); font-size: 12px; }
    .detail-link, .small-link {
      display: inline-flex;
      align-items: center;
      min-height: 32px;
      padding: 0 12px;
      border: 1px solid var(--line2);
      border-radius: 4px;
      background: #1d2b38;
      color: #fff;
      font-size: 13px;
      font-weight: 800;
    }
    .detail-link { margin-bottom: 5px; color: var(--gold); }
    .small-link { min-height: 30px; margin-right: 6px; font-size: 12px; }
    .cache-table { min-width: 1160px; }
    .cache-name { width: 210px; font-weight: 800; }
    .cache-subject { width: 390px; }
    .cache-location { width: 140px; color: var(--cyan); }
    .cache-source { width: 250px; color: var(--muted); }
    .cache-time { width: 150px; color: var(--muted); }
    .cache-actions { width: 190px; }
    .detail-grid {
      display: grid;
      grid-template-columns: repeat(4, minmax(130px, 1fr));
      gap: 10px;
      padding: 16px 22px;
      border-bottom: 1px solid var(--line);
      background: rgba(0,0,0,.08);
    }
    .team-title {
      padding: 14px 22px;
      color: var(--cyan);
      font-size: 16px;
      font-weight: 900;
      border-bottom: 1px solid var(--line);
      background: #101923;
    }
    .tools {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-bottom: 18px;
    }
    form.panel { padding: 18px; }
    input {
      width: min(560px, 100%);
      padding: 13px 14px;
      border: 1px solid var(--line2);
      background: #0f1822;
      color: #fff;
      border-radius: 5px;
      font-size: 15px;
      outline: none;
    }
    button, .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 42px;
      padding: 0 16px;
      border: 1px solid #4b6072;
      border-radius: 5px;
      background: #1d2b38;
      color: #fff;
      font-size: 14px;
      font-weight: 800;
      cursor: pointer;
    }
    button.primary, .btn.primary { background: #ffd166; border-color: #ffd166; color: #111; }
    .msg { color: var(--gold); margin: 8px 0 0; }
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(5, minmax(140px, 1fr));
      gap: 10px;
      padding: 16px 22px;
      border-bottom: 1px solid var(--line);
      background: rgba(0,0,0,.08);
    }
    .live-summary-grid { grid-template-columns: repeat(6, minmax(120px, 1fr)); }
    .stat { color: var(--muted); font-size: 13px; }
    .stat strong { display: block; margin-top: 4px; color: #fff; font-size: 17px; }
    .subject-stat strong { font: 12px/1.45 Consolas, "Cascadia Mono", monospace; overflow-wrap: anywhere; }
    .empty { padding: 28px; text-align: center; color: var(--muted); font-size: 14px; }
    #party-body[hidden] { display: none !important; }
    @media (max-width: 900px) {
      .live-layout { display: block; padding: 12px; }
      .live-sidebar { position: static; max-height: none; margin-bottom: 12px; }
      main { padding: 12px; }
      .live-main { padding: 0; }
      .player-head { flex-direction: column; }
      .summary-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .live-summary-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .detail-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    }
"""

PUBLIC_CSS = APP_CSS + """
    :root {
      --public-bg: #090d12;
      --public-surface: #111820;
      --public-surface-2: #151f29;
      --public-line: #26323e;
      --public-text: #f3f6f8;
      --public-muted: #9ba8b5;
      --public-cyan: #55c7d9;
      --public-coral: #ff5d68;
      --public-yellow: #f2c14e;
      --public-green: #49c789;
    }
    body.public-page {
      min-width: 320px;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      background: var(--public-bg);
      color: var(--public-text);
      font-family: "Microsoft YaHei UI", "Microsoft YaHei", "PingFang SC", "Segoe UI", Arial, sans-serif;
    }
    .public-page .site-header { flex-shrink: 0; }
    .public-page .public-main { flex: 1; }
    .public-page .site-footer { flex-shrink: 0; }
    .skip-link {
      position: fixed;
      left: 16px;
      top: -60px;
      z-index: 100;
      padding: 10px 14px;
      border-radius: 4px;
      background: #fff;
      color: #111;
      font-weight: 800;
    }
    .skip-link:focus { top: 12px; }
    .site-header {
      border-bottom: 1px solid var(--public-line);
      background: #0d1218;
    }
    .site-header-inner {
      width: min(1180px, calc(100% - 40px));
      min-height: 68px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 24px;
    }
    .brand {
      display: inline-flex;
      align-items: center;
      gap: 12px;
      color: var(--public-text);
      font-weight: 900;
    }
    .brand-mark {
      width: 34px;
      height: 34px;
      display: grid;
      place-items: center;
      border: 1px solid #3b4c5d;
      border-left: 3px solid var(--public-coral);
      background: #151d25;
      color: #fff;
      font: 900 13px/1 "Segoe UI", Arial, sans-serif;
    }
    .brand-copy { display: grid; gap: 2px; }
    .brand-copy strong { font-size: 15px; line-height: 1.1; }
    .brand-copy small { color: var(--public-muted); font-size: 11px; font-weight: 600; }
    .site-nav { display: flex; align-items: center; gap: 22px; font-size: 13px; }
    .site-nav a { color: var(--public-muted); }
    .site-nav a:hover { color: var(--public-text); }
    .site-nav .live-link { color: var(--public-yellow); font-weight: 800; }
    .site-nav a[aria-current="page"] { color: #fff; }
    .public-main {
      width: min(1180px, calc(100% - 40px));
      max-width: none;
      margin: 0 auto;
      padding: 0 0 56px;
    }
    .query-intro { padding: 58px 0 42px; }
    .query-hero {
      display: block;
      padding: 68px 0 54px;
      text-align: center;
    }
    .query-hero-inner {
      width: min(900px, 100%);
      margin: 0 auto;
    }
    .eyebrow {
      margin: 0 0 12px;
      color: var(--public-cyan);
      font-size: 12px;
      font-weight: 900;
      letter-spacing: .08em;
    }
    .query-intro h1 {
      max-width: 920px;
      margin: 0;
      color: #fff;
      font-size: 46px;
      line-height: 1.16;
      font-weight: 900;
    }
    .query-hero h1 {
      max-width: none;
      font-size: clamp(36px, 4vw, 46px);
      letter-spacing: -.03em;
    }
    .query-title-accent { color: var(--public-yellow); }
    .query-lead {
      max-width: 780px;
      margin: 18px 0 0;
      color: var(--public-muted);
      font-size: 17px;
      line-height: 1.8;
    }
    .query-hero .query-lead {
      max-width: 700px;
      margin: 15px auto 0;
      font-size: 16px;
      line-height: 1.75;
    }
    .query-meta {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-wrap: wrap;
      gap: 8px 20px;
      margin: 16px 0 0;
      color: #92a2af;
      font-size: 12px;
      font-weight: 700;
    }
    .query-meta span {
      display: inline-flex;
      align-items: center;
      gap: 7px;
    }
    .query-meta span::before {
      content: "";
      width: 5px;
      height: 5px;
      border-radius: 50%;
      background: var(--public-green);
    }
    .query-form {
      width: min(820px, 100%);
      margin: 28px auto 0;
      padding: 9px;
      border: 1px solid #3a4957;
      border-radius: 12px;
      background:
        radial-gradient(circle at 12% 0, rgba(85, 199, 217, .08), transparent 34%),
        #111922;
      box-shadow: 0 18px 48px rgba(0, 0, 0, .24);
    }
    .visually-hidden {
      position: absolute !important;
      width: 1px !important;
      height: 1px !important;
      padding: 0 !important;
      margin: -1px !important;
      overflow: hidden !important;
      clip: rect(0, 0, 0, 0) !important;
      white-space: nowrap !important;
      border: 0 !important;
    }
    .search-row {
      display: grid;
      grid-template-columns: minmax(0, 1fr) 142px;
      gap: 10px;
    }
    .query-form .search-row { grid-template-columns: minmax(0, 1fr) 148px; gap: 8px; }
    .public-page .query-input {
      width: 100%;
      height: 56px;
      padding: 0 18px;
      border: 1px solid #455566;
      border-radius: 8px;
      background: #090e14;
      color: #fff;
      font-size: 16px;
    }
    .public-page .query-input::placeholder { color: #73808d; }
    .public-page .query-input:focus {
      border-color: var(--public-cyan);
      box-shadow: 0 0 0 3px rgba(85, 199, 217, .14);
    }
    .public-page .query-button {
      height: 56px;
      border-color: var(--public-coral);
      border-radius: 8px;
      background: var(--public-coral);
      color: #fff;
      font-size: 15px;
      white-space: nowrap;
    }
    .public-page .query-button:hover { background: #ff737c; }
    .query-help {
      margin: 12px 0 0;
      color: var(--public-muted);
      font-size: 12px;
      line-height: 1.6;
    }
    .query-message {
      margin: 12px 0 0;
      padding: 10px 12px;
      border-left: 3px solid var(--public-yellow);
      background: #211c10;
      color: #ffe09a;
      font-size: 13px;
      line-height: 1.55;
    }
    .live-promo {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 14px;
      margin: 0 0 40px;
      padding: 10px 16px;
      border: 1px solid #25303a;
      border-radius: 6px;
      background: #0d131a;
    }
    .live-promo-body { flex: 1; min-width: 0; }
    .live-promo-kicker {
      margin: 0;
      color: var(--public-green);
      font-size: 12px;
      font-weight: 800;
    }
    .live-promo-desc {
      margin: 2px 0 0;
      color: var(--public-muted);
      font-size: 12px;
      line-height: 1.4;
    }
    .live-promo h2 {
      margin: 0;
      color: #fff;
      font-size: 22px;
      line-height: 1.3;
    }
    .live-promo p {
      max-width: 760px;
      margin: 8px 0 0;
      color: var(--public-muted);
      font-size: 13px;
      line-height: 1.75;
    }
    .live-cta {
      min-width: 120px;
      min-height: 34px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0 14px;
      border: 1px solid var(--public-green);
      border-radius: 5px;
      background: var(--public-green);
      color: #08130e;
      font-weight: 800;
      white-space: nowrap;
    }
    .live-cta:hover { background: #67d59c; }
    .signal-strip {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      border-top: 1px solid var(--public-line);
      border-bottom: 1px solid var(--public-line);
    }
    .signal-item {
      min-height: 104px;
      padding: 22px 20px;
      border-right: 1px solid var(--public-line);
    }
    .signal-item:last-child { border-right: 0; }
    .signal-item strong {
      display: block;
      color: #fff;
      font-size: 18px;
      line-height: 1.25;
    }
    .signal-item span {
      display: block;
      margin-top: 7px;
      color: var(--public-muted);
      font-size: 12px;
      line-height: 1.5;
    }
    .content-band {
      padding: 52px 0;
      border-bottom: 1px solid var(--public-line);
    }
    .section-heading {
      display: grid;
      grid-template-columns: minmax(220px, .72fr) minmax(0, 1.28fr);
      gap: 56px;
      align-items: start;
      margin-bottom: 30px;
    }
    .section-heading h2 {
      margin: 0;
      color: #fff;
      font-size: 28px;
      line-height: 1.25;
    }
    .section-heading p {
      margin: 0;
      color: var(--public-muted);
      font-size: 14px;
      line-height: 1.8;
    }
    .field-table {
      width: 100%;
      min-width: 0;
      border-collapse: collapse;
      table-layout: fixed;
      font-size: 14px;
    }
    .field-table th,
    .field-table td {
      padding: 14px 16px;
      border: 1px solid var(--public-line);
      vertical-align: top;
    }
    .field-table th {
      width: 170px;
      background: var(--public-surface);
      color: var(--public-cyan);
    }
    .field-table td {
      background: #0d1319;
      color: #d6dee5;
    }
    .product-preview {
      display: grid;
      grid-template-columns: minmax(230px, .62fr) minmax(0, 1.38fr);
      gap: 44px;
      align-items: center;
    }
    .product-preview h2 {
      margin: 0 0 12px;
      color: #fff;
      font-size: 28px;
      line-height: 1.3;
    }
    .product-preview p {
      margin: 0;
      color: var(--public-muted);
      font-size: 14px;
      line-height: 1.8;
    }
    .preview-points {
      display: grid;
      gap: 12px;
      margin: 22px 0 0;
      padding: 0;
      list-style: none;
    }
    .preview-points li {
      position: relative;
      padding-left: 24px;
      color: #cbd5dd;
      font-size: 13px;
      line-height: 1.65;
    }
    .preview-points li::before {
      content: "✓";
      position: absolute;
      left: 0;
      top: 0;
      color: var(--public-green);
      font-weight: 900;
    }
    .preview-points strong { color: #fff; }
    .preview-frame {
      margin: 0;
      border: 1px solid var(--public-line);
      background: #070a0e;
      overflow: hidden;
    }
    .preview-frame img {
      display: block;
      width: 100%;
      height: auto;
      aspect-ratio: 16 / 9;
      object-fit: cover;
      object-position: top center;
    }
    .faq-list { border-top: 1px solid var(--public-line); }
    .faq-list details { border-bottom: 1px solid var(--public-line); }
    .faq-list summary {
      padding: 18px 2px;
      color: #fff;
      font-weight: 800;
      cursor: pointer;
    }
    .faq-list p {
      max-width: 850px;
      margin: -3px 0 20px;
      color: var(--public-muted);
      font-size: 14px;
      line-height: 1.8;
    }
    .feature-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      border-top: 1px solid var(--public-line);
      border-left: 1px solid var(--public-line);
    }
    .feature-item {
      min-height: 160px;
      padding: 24px;
      border-right: 1px solid var(--public-line);
      border-bottom: 1px solid var(--public-line);
      background: #0d1319;
    }
    .feature-number {
      display: block;
      margin-bottom: 18px;
      color: var(--public-coral);
      font: 900 12px/1 "Segoe UI", Arial, sans-serif;
    }
    .feature-item h3 {
      margin: 0;
      color: #fff;
      font-size: 18px;
      line-height: 1.35;
    }
    .feature-item p {
      margin: 8px 0 0;
      color: var(--public-muted);
      font-size: 13px;
      line-height: 1.75;
    }
    .live-hero { padding-bottom: 34px; }
    .live-status {
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 24px;
      align-items: center;
      margin-top: 28px;
      padding: 22px 24px;
      border: 1px solid #344453;
      border-left: 3px solid var(--public-yellow);
      border-radius: 8px;
      background: var(--public-surface);
    }
    .live-status.ready { border-left-color: var(--public-green); }
    .live-status strong {
      display: block;
      color: #fff;
      font-size: 18px;
    }
    .live-status p {
      margin: 6px 0 0;
      color: var(--public-muted);
      font-size: 13px;
      line-height: 1.65;
    }
    .live-dashboard-hero {
      padding: 48px 0 32px;
    }
    .live-hero-copy {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }
    .live-hero-copy h1 {
      max-width: 760px;
      margin: 10px 0 18px;
      color: #fff;
      font-size: clamp(42px, 6vw, 72px);
      line-height: 1.02;
      letter-spacing: -.045em;
    }
    .live-hero-copy .query-lead { max-width: 720px; margin: 0; }
    .live-capabilities {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-top: 28px;
    }
    .live-capabilities span {
      padding: 8px 11px;
      border: 1px solid #334351;
      border-radius: 999px;
      background: #101820;
      color: #c7d2db;
      font-size: 12px;
      font-weight: 800;
    }
    .deploy-main {
      max-width: 800px;
      margin: 0 auto;
      padding: 48px 0;
    }
    .deploy-header {
      text-align: center;
      margin-bottom: 40px;
    }
    .deploy-header .eyebrow {
      margin-bottom: 10px;
    }
    .deploy-header h1 {
      max-width: 520px;
      margin: 0 auto 18px;
      color: #fff;
      font-size: clamp(36px, 5vw, 56px);
      line-height: 1.1;
      letter-spacing: -.03em;
    }
    .deploy-intro {
      max-width: 580px;
      margin: 0 auto 28px;
      color: var(--public-muted);
      font-size: 15px;
      line-height: 1.8;
    }
    .deploy-capabilities {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 8px;
      max-width: 600px;
      margin: 0 auto;
    }
    .deploy-capabilities span {
      padding: 8px 14px;
      border: 1px solid #334351;
      border-radius: 999px;
      background: #101820;
      color: #c7d2db;
      font-size: 12px;
      font-weight: 800;
    }
    .deploy-features {
      background: #101820;
      border: 1px solid #354653;
      border-radius: 16px;
      padding: 36px;
      box-shadow: 0 22px 60px rgba(0,0,0,.2);
    }
    .deploy-features h2 {
      margin: 0 0 24px;
      color: #fff;
      font-size: 22px;
    }
    .deploy-features ul {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 14px;
      margin: 0 0 28px;
      padding: 0;
      list-style: none;
    }
    .deploy-features li {
      position: relative;
      padding-left: 24px;
      color: #c7d2db;
      font-size: 14px;
      line-height: 1.65;
    }
    .deploy-features li::before {
      content: "✓";
      position: absolute;
      left: 0;
      color: var(--public-green);
      font-weight: 900;
    }
    .deploy-actions {
      text-align: center;
      padding-top: 24px;
      border-top: 1px solid #334351;
    }
    .deploy-note {
      margin: 16px 0 0;
      color: #66707a;
      font-size: 12px;
      line-height: 1.7;
    }
    .self-deploy-content {
      max-width: 680px;
      margin: 0 auto;
      text-align: center;
    }
    .self-deploy-content p {
      color: #8fa5ba;
      font-size: 14px;
      line-height: 1.7;
      margin: 0 0 20px;
    }
    .self-deploy-actions {
      display: flex;
      gap: 12px;
      justify-content: center;
      flex-wrap: wrap;
      margin-bottom: 12px;
    }
    .self-deploy-actions .live-action {
      min-width: 180px;
    }
    .live-control-card {
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: center;
      min-height: 330px;
      padding: 30px;
      overflow: hidden;
      border: 1px solid #354653;
      border-radius: 14px;
      background: #101820;
      box-shadow: 0 22px 60px rgba(0,0,0,.25);
    }
    .live-control-card::before {
      content: "";
      position: absolute;
      inset: 0 auto 0 0;
      width: 4px;
      background: var(--public-yellow);
    }
    .live-control-card.ready::before { background: var(--public-green); }
    .live-control-label {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 28px;
      color: var(--public-muted);
      font-size: 12px;
      font-weight: 900;
      letter-spacing: .08em;
    }
    .live-control-dot {
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background: var(--public-yellow);
      box-shadow: 0 0 0 5px rgba(255,209,102,.1);
    }
    .ready .live-control-dot {
      background: var(--public-green);
      box-shadow: 0 0 0 5px rgba(72,199,142,.1);
    }
    .live-control-card h2 { margin: 0; color: #fff; font-size: 26px; line-height: 1.25; }
    .live-control-card > p { margin: 10px 0 0; color: var(--public-muted); font-size: 13px; line-height: 1.75; }
    .live-control-card .live-actions { justify-content: flex-start; margin-top: 28px; }
    .live-risk-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 18px;
      margin-bottom: 26px;
      padding: 14px 16px;
      border: 1px solid #4d4328;
      border-radius: 8px;
      background: #19160f;
      color: #cfc29c;
      font-size: 12px;
      line-height: 1.7;
    }
    .live-risk-bar a { color: var(--public-yellow); text-decoration: underline; }
    .live-risk-bar form { flex: 0 0 auto; }
    .live-risk-bar button {
      min-height: 34px;
      padding: 0 11px;
      border: 1px solid #66542d;
      border-radius: 4px;
      background: #2a2314;
      color: #ffe09a;
      font-size: 12px;
      font-weight: 800;
      cursor: pointer;
      white-space: nowrap;
    }
    .live-flow {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      border: 1px solid var(--public-line);
      border-radius: 12px;
      overflow: hidden;
      background: #0d1319;
    }
    .live-flow-step {
      position: relative;
      min-height: 132px;
      padding: 22px 22px 20px 66px;
      border-right: 1px solid var(--public-line);
      color: inherit;
    }
    .live-flow-step:last-child { border-right: 0; }
    .live-flow-step:hover { background: #121c25; }
    .live-flow-index {
      position: absolute;
      top: 23px;
      left: 22px;
      color: var(--public-coral);
      font: 900 12px/1 "Segoe UI", Arial, sans-serif;
    }
    .live-flow-step strong { display: block; color: #fff; font-size: 17px; }
    .live-flow-step span { display: block; margin-top: 8px; color: var(--public-muted); font-size: 12px; line-height: 1.6; }
    .live-section-heading { margin-bottom: 24px; }
    .live-section-kicker {
      display: block;
      margin-bottom: 8px;
      color: var(--public-coral);
      font-size: 11px;
      font-weight: 900;
      letter-spacing: .12em;
    }
    .setup-method-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
    }
    .setup-method {
      position: relative;
      min-height: 132px;
      padding: 22px 56px 22px 22px;
      border: 1px solid var(--public-line);
      border-radius: 10px;
      background: #0d1319;
      color: inherit;
      text-align: left;
      cursor: pointer;
    }
    .setup-method::after {
      content: "";
      position: absolute;
      top: 24px;
      right: 22px;
      width: 16px;
      height: 16px;
      border: 1px solid #526270;
      border-radius: 50%;
      box-shadow: inset 0 0 0 4px #0d1319;
    }
    .setup-method[aria-pressed="true"] {
      border-color: var(--public-cyan);
      background: #101c24;
      box-shadow: inset 3px 0 0 var(--public-cyan);
    }
    .setup-method[aria-pressed="true"]::after { background: var(--public-cyan); border-color: var(--public-cyan); }
    .setup-method-label { display: block; margin-bottom: 10px; color: var(--public-cyan); font-size: 11px; font-weight: 900; letter-spacing: .1em; }
    .setup-method strong { display: block; color: #fff; font-size: 19px; }
    .setup-method small { display: block; margin-top: 8px; color: var(--public-muted); font-size: 12px; line-height: 1.65; }
    .setup-panel {
      margin-top: 14px;
      padding: 24px;
      border: 1px solid #334351;
      border-radius: 10px;
      background: #0b1117;
    }
    .setup-panel[hidden] { display: none !important; }
    .script-setup-layout {
      display: grid;
      grid-template-columns: minmax(0, .8fr) minmax(320px, 1.2fr);
      gap: 30px;
      align-items: center;
    }
    .script-setup-copy h3,
    .manual-panel-head h3 { margin: 0; color: #fff; font-size: 22px; }
    .script-setup-copy p,
    .manual-panel-head p { margin: 8px 0 0; color: var(--public-muted); font-size: 13px; line-height: 1.75; }
    .script-setup-copy .connect-option-actions { margin-top: 18px; }
    .setup-checklist { display: grid; gap: 10px; margin: 0; padding: 0; list-style: none; counter-reset: setup; }
    .setup-checklist li {
      position: relative;
      min-height: 52px;
      padding: 10px 12px 10px 48px;
      border: 1px solid var(--public-line);
      border-radius: 7px;
      background: #101820;
      color: #d8e1e7;
      font-size: 13px;
      line-height: 1.55;
      counter-increment: setup;
    }
    .setup-checklist li::before {
      content: counter(setup);
      position: absolute;
      top: 11px;
      left: 13px;
      width: 24px;
      height: 24px;
      display: grid;
      place-items: center;
      border-radius: 50%;
      background: #1f303d;
      color: var(--public-cyan);
      font-size: 11px;
      font-weight: 900;
    }
    .manual-panel-head { margin-bottom: 18px; }
    .live-route-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-bottom: 24px;
    }
    .live-route-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 7px 10px;
      border: 1px solid #385061;
      border-radius: 999px;
      background: #12202a;
      color: #bfe9ff;
      font-size: 11px;
      font-weight: 900;
    }
    .live-route-badge::before {
      content: "";
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: var(--public-cyan);
    }
    .live-mode-badge { color: var(--public-muted); font-size: 11px; font-weight: 800; }
    .live-vip-teaser {
      display: block;
      margin-top: 22px;
      padding-top: 18px;
      border-top: 1px solid var(--public-line);
      color: #dbc8ff;
      font-size: 12px;
      font-weight: 800;
    }
    .live-vip-teaser:hover { color: #fff; }
    .plans-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 14px;
    }
    .plan-card {
      position: relative;
      display: flex;
      flex-direction: column;
      min-height: 430px;
      padding: 28px;
      overflow: hidden;
      border: 1px solid var(--public-line);
      border-radius: 12px;
      background: #0d1319;
    }
    .plan-card.vip {
      border-color: #554878;
      background: #151323;
      box-shadow: inset 0 3px 0 #9a7cff;
    }
    .plan-kicker { color: var(--public-cyan); font-size: 11px; font-weight: 900; letter-spacing: .12em; }
    .plan-card.vip .plan-kicker { color: #c5b4ff; }
    .plan-card h3 { margin: 12px 0 0; color: #fff; font-size: 27px; }
    .plan-subtitle { margin: 8px 0 0; color: var(--public-muted); font-size: 13px; line-height: 1.7; }
    .plan-status {
      display: inline-flex;
      align-self: flex-start;
      margin-top: 18px;
      padding: 6px 9px;
      border-radius: 4px;
      background: #17232d;
      color: #cbd7df;
      font-size: 11px;
      font-weight: 900;
    }
    .plan-card.vip .plan-status { background: #29213f; color: #d9cdff; }
    .plan-features { display: grid; gap: 12px; margin: 24px 0 26px; padding: 0; list-style: none; }
    .plan-features li {
      position: relative;
      padding-left: 23px;
      color: #d8e0e6;
      font-size: 13px;
      line-height: 1.6;
    }
    .plan-features li::before { content: "✓"; position: absolute; left: 0; color: var(--public-green); font-weight: 900; }
    .plan-card.vip .plan-features li::before { color: #b99cff; }
    .plan-card .live-action { align-self: flex-start; margin-top: auto; }
    .plan-footnote { margin: 14px 0 0; color: #788692; font-size: 11px; line-height: 1.65; }
    .support-layout {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(260px, 330px);
      gap: 32px;
      align-items: stretch;
    }
    .support-copy {
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 34px;
      border: 1px solid var(--public-line);
      border-radius: 12px;
      background: #0d1319;
    }
    .support-copy h2 { margin: 8px 0 0; color: #fff; font-size: 32px; line-height: 1.25; }
    .support-copy > p { margin: 14px 0 0; color: var(--public-muted); font-size: 14px; line-height: 1.85; }
    .support-services {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
      margin: 24px 0 0;
    }
    .support-services span {
      padding: 11px 12px;
      border: 1px solid #2f3e49;
      border-radius: 6px;
      background: #111a22;
      color: #cdd7de;
      font-size: 12px;
    }
    .sponsor-note {
      margin-top: 26px;
      padding: 18px;
      border-left: 3px solid var(--public-yellow);
      background: #19160f;
    }
    .sponsor-note strong { display: block; color: #fff0bd; font-size: 15px; }
    .sponsor-note p { margin: 7px 0 0; color: #c5b88e; font-size: 12px; line-height: 1.75; }
    .qq-contact-card {
      display: flex;
      flex-direction: column;
      padding: 16px;
      border: 1px solid #455567;
      border-radius: 12px;
      background: #f7f8fa;
      color: #111;
      box-shadow: 0 22px 55px rgba(0,0,0,.24);
    }
    .qq-qr-placeholder {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      aspect-ratio: 1 / 1;
      width: 100%;
      border: 2px dashed #d4d9df;
      border-radius: 8px;
      background: #fff;
      color: #66707a;
      font-size: 13px;
      overflow: hidden;
      position: relative;
    }
    .qq-qr-placeholder img {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
    }
    .qq-contact-card img {
      display: block;
      width: 100%;
      height: auto;
      border-radius: 7px;
      background: #fff;
    }
    .qq-contact-meta { padding: 16px 8px 6px; text-align: center; }
    .qq-contact-meta strong { display: block; font-size: 18px; }
    .qq-contact-meta span { display: block; margin-top: 5px; color: #66707a; font-size: 12px; line-height: 1.55; }
    .qq-number {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-top: 12px;
      padding: 9px 12px;
      border: 1px solid #d4d9df;
      border-radius: 6px;
      background: #fff;
      color: #20252b;
      font-weight: 900;
      cursor: pointer;
    }
    .modal-overlay {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.6);
      z-index: 1000;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .modal-overlay.active {
      display: flex;
    }
    .modal-content {
      position: relative;
      background: #f7f8fa;
      border-radius: 16px;
      max-width: 400px;
      width: 100%;
      padding: 28px;
      box-shadow: 0 25px 60px rgba(0,0,0,.35);
      color: #111;
    }
    .modal-close {
      position: absolute;
      top: 12px;
      right: 12px;
      width: 32px;
      height: 32px;
      border: none;
      border-radius: 50%;
      background: #e8eaed;
      color: #666;
      font-size: 20px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      line-height: 1;
    }
    .modal-body {
      text-align: center;
    }
    .modal-body h3 {
      margin: 0 0 12px;
      font-size: 22px;
      color: #111;
    }
    .modal-body p {
      margin: 0 0 20px;
      color: #66707a;
      font-size: 14px;
      line-height: 1.6;
    }
    .modal-qr-container {
      width: 100%;
      max-width: 180px;
      margin: 0 auto 20px;
    }
    .live-actions {
      display: flex;
      align-items: center;
      gap: 10px;
      flex-wrap: wrap;
      justify-content: flex-end;
    }
    .live-action {
      min-height: 44px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0 16px;
      border: 1px solid #4a5b6b;
      border-radius: 5px;
      background: #1a2631;
      color: #fff;
      font-weight: 900;
      white-space: nowrap;
    }
    .live-action.primary {
      border-color: var(--public-coral);
      background: var(--public-coral);
    }
    .session-list {
      display: grid;
      gap: 10px;
    }
    #sessions.has-sessions {
      border: 1px solid var(--public-coral);
      border-left: 4px solid var(--public-coral);
      border-radius: 6px;
      padding: 28px 24px 20px;
      margin-top: 12px;
      background: linear-gradient(135deg, #1a1014 0%, #11161a 100%);
    }
    #sessions.has-sessions .section-heading {
      border-bottom: 1px solid #2a1a20;
      padding-bottom: 14px;
      margin-bottom: 18px;
    }
    .session-choice {
      display: grid;
      grid-template-columns: minmax(220px, 1fr) auto;
      gap: 20px;
      align-items: center;
      padding: 18px 20px;
      border: 1px solid var(--public-line);
      border-left: 3px solid #465767;
      border-radius: 8px;
      background: #0d1319;
    }
    .session-choice.selected {
      border-left-color: var(--public-green);
      background: #0d1714;
    }
    .session-choice h3 {
      margin: 0;
      color: #fff;
      font-size: 18px;
      line-height: 1.35;
      overflow-wrap: anywhere;
    }
    .session-choice p {
      margin: 6px 0 0;
      color: var(--public-muted);
      font-size: 12px;
      line-height: 1.6;
    }
    .session-badge {
      display: inline-block;
      margin-left: 8px;
      color: var(--public-green);
      font-size: 11px;
      vertical-align: 2px;
    }
    .session-choice-actions {
      display: flex;
      gap: 8px;
      align-items: center;
      flex-wrap: wrap;
      justify-content: flex-end;
    }
    .session-empty {
      padding: 22px;
      border: 1px solid var(--public-line);
      border-left: 3px solid var(--public-yellow);
      background: #111820;
      color: var(--public-muted);
      font-size: 13px;
      line-height: 1.75;
    }
    .connect-warning {
      margin: 0 0 20px;
      padding: 16px 18px;
      border-left: 3px solid var(--public-yellow);
      background: #211c10;
      color: #e8d59b;
      font-size: 13px;
      line-height: 1.75;
    }
    .connect-options {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
      margin: 0 0 24px;
    }
    .connect-option {
      padding: 20px;
      border: 1px solid var(--public-line);
      border-radius: 8px;
      background: var(--public-surface);
    }
    .connect-option.recommended { border-color: #395b6f; }
    .connect-option h3 { margin: 0 0 8px; color: #fff; font-size: 18px; }
    .connect-option p { margin: 0 0 16px; color: var(--public-muted); font-size: 13px; line-height: 1.7; }
    .connect-option-actions { display: flex; gap: 8px; flex-wrap: wrap; }
    .manual-connect-heading { margin-top: 6px; }
    .connect-steps {
      display: grid;
      gap: 12px;
    }
    .connect-step {
      display: grid;
      grid-template-columns: 220px minmax(0, 1fr);
      border: 1px solid var(--public-line);
      border-radius: 8px;
      overflow: hidden;
      background: #0d1319;
    }
    .connect-step.restore-step { border-left: 3px solid var(--public-coral); }
    .connect-step-meta {
      padding: 20px;
      border-right: 1px solid var(--public-line);
      background: var(--public-surface);
    }
    .connect-step-index {
      display: inline-flex;
      width: 32px;
      height: 32px;
      align-items: center;
      justify-content: center;
      margin-bottom: 20px;
      border: 1px solid #455565;
      border-radius: 4px;
      color: var(--public-cyan);
      font: 900 13px/1 "Segoe UI", Arial, sans-serif;
    }
    .restore-step .connect-step-index {
      border-color: var(--public-coral);
      color: var(--public-coral);
    }
    .connect-step h3 {
      margin: 0;
      color: #fff;
      font-size: 18px;
      line-height: 1.35;
    }
    .connect-step-meta p {
      margin: 8px 0 0;
      color: var(--public-muted);
      font-size: 12px;
      line-height: 1.7;
    }
    .connect-command {
      min-width: 0;
      background: #080d12;
    }
    .connect-command-head {
      min-height: 50px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      padding: 8px 12px 8px 16px;
      border-bottom: 1px solid var(--public-line);
      color: #a9b6c2;
      font-size: 12px;
    }
    .copy-command {
      min-height: 34px;
      padding: 0 12px;
      border: 1px solid #4a5b6b;
      border-radius: 4px;
      background: #17232e;
      color: #fff;
      font-size: 12px;
      font-weight: 900;
      cursor: pointer;
      white-space: nowrap;
    }
    .copy-command:hover { border-color: var(--public-cyan); }
    .connect-command pre {
      margin: 0;
      padding: 18px 16px 20px;
      overflow-x: auto;
      color: #d9e8f2;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      tab-size: 2;
      font: 12px/1.65 Consolas, "Cascadia Mono", monospace;
    }
    .connect-finish {
      margin: 16px 0 0;
      color: var(--public-muted);
      font-size: 13px;
      line-height: 1.75;
    }
    .connect-toggle {
      margin-top: 32px;
      border: 1px solid var(--public-table-cell);
      border-radius: 6px;
      overflow: hidden;
    }
    .connect-toggle[open] {
      border-color: var(--public-cyan);
    }
    .connect-toggle-summary {
      cursor: pointer;
      padding: 16px 20px;
      background: #13181e;
      list-style: none;
      transition: background .2s;
    }
    .connect-toggle-summary::-webkit-details-marker {
      display: none;
    }
    .connect-toggle-summary:hover {
      background: #18202a;
    }
    .connect-toggle-summary h2 {
      color: var(--public-cyan);
      font-size: 15px;
      font-weight: 600;
      margin: 4px 0 0;
    }
    .connect-toggle-summary p {
      color: var(--public-muted);
      font-size: 13px;
      margin: 6px 0 0;
    }
    .connect-toggle[open] .connect-toggle-summary {
      border-bottom: 1px solid var(--public-table-cell);
    }
    .privacy-note {
      padding: 18px 20px;
      border-left: 3px solid var(--public-cyan);
      background: #0d151c;
      color: var(--public-muted);
      font-size: 13px;
      line-height: 1.75;
    }
    .public-live-shell { background: var(--public-bg); }
    .public-live-shell .live-layout { max-width: 1500px; margin: 0 auto; }
    .public-live-shell .live-sidebar { top: 16px; }
    .public-live-shell .topbar { margin-top: 0; }
    .site-footer {
      width: min(1180px, calc(100% - 40px));
      margin: 0 auto;
      padding: 26px 0 34px;
      display: flex;
      justify-content: space-between;
      gap: 24px;
      color: #74818e;
      font-size: 12px;
      line-height: 1.7;
    }
    .site-footer a { color: #9bacbb; }
    .result-main { padding-top: 28px; }
    .result-search {
      margin: 0 0 14px;
      padding: 14px;
      border: 1px solid var(--public-line);
      border-radius: 8px;
      background: var(--public-surface);
    }
    .result-search .search-row { grid-template-columns: minmax(0, 1fr) 132px; }
    .public-result-panel {
      margin: 0;
      border-color: var(--public-line);
      background: var(--public-surface);
    }
    .public-result-panel .player-head { border-bottom-color: var(--public-line); }
    .public-result-panel .summary-grid { border-bottom-color: var(--public-line); }
    .public-result-panel .table-wrap { border-top-color: var(--public-line); }
    .public-result-panel table { min-width: 1120px; }
    .public-result-panel th,
    .public-result-panel td { border-bottom-color: var(--public-line); }
    .public-result-panel th { background: #0d1319; }
    .detail-col {
      position: sticky;
      right: 0;
      z-index: 2;
      width: 72px;
      min-width: 72px;
      padding-right: 8px;
      padding-left: 8px;
      text-align: center;
      background: var(--public-surface, #111820);
      box-shadow: -12px 0 18px rgba(0, 0, 0, .26), -1px 0 0 var(--public-line, #2c3945);
    }
    th.detail-col {
      z-index: 3;
      background: #0d1319;
    }
    tbody tr:hover td.detail-col { background: #18232d; }
    .public-detail-button {
      min-height: 32px;
      padding: 0 12px;
      border: 1px solid #486171;
      border-radius: 4px;
      background: #17242e;
      color: var(--public-yellow);
      font-size: 12px;
      font-weight: 900;
      white-space: nowrap;
    }
    .public-detail-button:hover { border-color: var(--public-yellow); }
    .public-detail-button[aria-expanded="true"] { background: #2b2516; }
    .battle-detail-row[hidden] { display: none; }
    .battle-detail-row:hover { background: transparent; }
    .battle-detail-cell {
      padding: 0;
      background: #0b1117;
      border-bottom: 2px solid #33424f;
    }
    .public-battle-detail { min-height: 92px; }
    .public-detail-state {
      padding: 24px 22px;
      color: var(--public-muted);
      font-size: 13px;
      line-height: 1.7;
    }
    .public-detail-state.error { color: #ffc2c6; }
    .public-detail-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 18px;
      padding: 16px 20px;
      border-bottom: 1px solid var(--public-line);
      background: #0e171f;
    }
    .public-detail-head strong { display: block; color: #fff; font-size: 15px; }
    .public-detail-head span { color: var(--public-muted); font-size: 12px; }
    .public-detail-grid {
      display: grid;
      grid-template-columns: repeat(6, minmax(110px, 1fr));
      gap: 1px;
      background: var(--public-line);
      border-bottom: 1px solid var(--public-line);
    }
    .public-detail-stat { padding: 13px 15px; background: #101820; color: var(--public-muted); font-size: 11px; }
    .public-detail-stat strong { display: block; margin-top: 4px; color: #fff; font-size: 14px; }
    .public-detail-team-title {
      display: flex;
      justify-content: space-between;
      gap: 16px;
      padding: 12px 20px;
      border-bottom: 1px solid var(--public-line);
      color: var(--public-cyan);
      font-size: 13px;
      font-weight: 900;
    }
    .public-detail-team-title .loss { color: var(--public-coral); }
    .public-detail-table-wrap { overflow-x: auto; }
    .public-detail-table {
      min-width: 1040px;
      table-layout: auto;
      font-size: 13px;
    }
    .public-detail-table th,
    .public-detail-table td { padding: 10px 14px; }
    .public-detail-table .target-player { color: var(--public-yellow); font-weight: 900; }
    .result-meta { color: var(--public-muted); }
    .result-note {
      margin: 14px 0 0;
      color: var(--public-muted);
      font-size: 12px;
      line-height: 1.6;
    }
    .public-deploy-notice {
      display: flex;
      gap: 16px;
      align-items: flex-start;
      padding: 16px 20px;
      margin: 16px 0;
      border: 1px solid #3d5166;
      border-radius: 12px;
      background: linear-gradient(135deg, rgba(56, 120, 180, 0.12) 0%, rgba(30, 60, 90, 0.08) 100%);
    }
    .public-deploy-notice .notice-icon {
      font-size: 24px;
      line-height: 1;
      flex-shrink: 0;
      margin-top: 2px;
    }
    .public-deploy-notice .notice-body {
      flex: 1;
    }
    .public-deploy-notice .notice-body p {
      margin: 0 0 6px;
      color: #9bb0c4;
      font-size: 13px;
      line-height: 1.6;
    }
    .public-deploy-notice .notice-body p strong {
      color: #e8edf2;
    }
    .public-deploy-notice .notice-features {
      margin: 4px 0 12px !important;
      display: flex;
      flex-wrap: wrap;
      gap: 7px;
    }
    .public-deploy-notice .notice-features span {
      display: inline-flex;
      align-items: center;
      min-height: 27px;
      padding: 4px 9px;
      border: 1px solid rgba(119, 156, 189, 0.25);
      border-radius: 999px;
      background: rgba(15, 28, 40, 0.62);
      color: #9db1c5;
      font-size: 12px !important;
    }
    .public-deploy-notice .notice-actions {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 9px;
    }
    .public-deploy-notice .notice-btn {
      display: inline-block;
      padding: 8px 18px;
      border: none;
      border-radius: 8px;
      background: linear-gradient(135deg, #3b82c4 0%, #2563a0 100%);
      color: #fff;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: opacity 0.2s;
      text-decoration: none;
    }
    .public-deploy-notice .notice-btn:hover {
      opacity: 0.9;
    }
    .public-deploy-notice .notice-btn.secondary {
      border: 1px solid #536f88;
      background: rgba(15, 28, 40, 0.74);
      color: #cfe5f6;
    }
    .risk-main { padding-bottom: 64px; }
    .risk-hero { padding: 50px 0 28px; }
    .risk-hero h1 {
      max-width: 920px;
      margin: 0;
      color: #fff;
      font-size: 42px;
      line-height: 1.18;
    }
    .risk-version { margin: 12px 0 0; color: var(--public-muted); font-size: 13px; }
    .risk-critical {
      margin-top: 26px;
      padding: 20px 22px;
      border: 1px solid #743944;
      border-left: 4px solid var(--public-coral);
      border-radius: 6px;
      background: #241117;
    }
    .risk-critical strong { display: block; color: #ffb4ba; font-size: 18px; line-height: 1.5; }
    .risk-critical p {
      max-width: 980px;
      margin: 8px 0 0;
      color: #d9b9bd;
      font-size: 14px;
      line-height: 1.8;
    }
    .risk-layout {
      display: grid;
      grid-template-columns: minmax(0, 1fr) 360px;
      gap: 24px;
      align-items: start;
      padding-top: 20px;
      border-top: 1px solid var(--public-line);
    }
    .risk-document { min-width: 0; border: 1px solid var(--public-line); background: #0d1319; }
    .risk-document-head {
      min-height: 70px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 18px;
      padding: 14px 20px;
      border-bottom: 1px solid var(--public-line);
      background: var(--public-surface);
    }
    .risk-document-head span {
      display: block;
      color: var(--public-yellow);
      font-size: 12px;
      font-weight: 900;
    }
    .risk-document-head strong { display: block; margin-top: 4px; color: #fff; font-size: 14px; }
    .risk-print {
      min-height: 36px;
      padding: 0 13px;
      border: 1px solid #4b5b6a;
      border-radius: 4px;
      background: #17222c;
      color: #fff;
      font-weight: 800;
      cursor: pointer;
      white-space: nowrap;
    }
    .risk-document section { padding: 24px 26px; border-bottom: 1px solid var(--public-line); }
    .risk-document section:last-child { border-bottom: 0; }
    .risk-document h2 { margin: 0 0 12px; color: #fff; font-size: 19px; line-height: 1.4; }
    .risk-document p { margin: 10px 0 0; color: #b3bfca; font-size: 14px; line-height: 1.9; }
    .risk-document p strong { color: #ffd1d4; }
    .risk-document a { color: var(--public-cyan); }
    .risk-confirm {
      position: sticky;
      top: 18px;
      border: 1px solid #4a3e2c;
      border-top: 3px solid var(--public-yellow);
      background: var(--public-surface);
    }
    .risk-confirm form { padding: 22px; }
    .risk-confirm h2 { margin: 0; color: #fff; font-size: 22px; }
    .risk-confirm > form > p {
      margin: 8px 0 18px;
      color: var(--public-muted);
      font-size: 13px;
      line-height: 1.7;
    }
    .risk-form-message {
      padding: 10px 12px;
      border-left: 3px solid var(--public-coral);
      background: #241117;
      color: #ffc2c6 !important;
    }
    .risk-check {
      display: grid;
      grid-template-columns: 20px minmax(0, 1fr);
      gap: 10px;
      align-items: start;
      padding: 14px 0;
      border-top: 1px solid var(--public-line);
      color: #d5dde4;
      font-size: 13px;
      line-height: 1.7;
      cursor: pointer;
    }
    .risk-check input {
      width: 18px;
      height: 18px;
      margin: 3px 0 0;
      accent-color: var(--public-coral);
    }
    .risk-submit {
      width: 100%;
      min-height: 48px;
      margin-top: 16px;
      border: 1px solid var(--public-coral);
      border-radius: 5px;
      background: var(--public-coral);
      color: #fff;
      font-size: 14px;
      font-weight: 900;
      cursor: pointer;
    }
    .risk-submit:disabled {
      border-color: #3d4852;
      background: #252f38;
      color: #77838e;
      cursor: not-allowed;
    }
    .risk-decline {
      min-height: 42px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-top: 8px;
      color: var(--public-muted);
      font-size: 13px;
      font-weight: 800;
    }
    .risk-record-note { margin: 12px 0 0 !important; color: #7f8c97 !important; font-size: 11px !important; }
    .risk-locked { border-color: #6b3038; border-top-color: var(--public-coral); }
    .risk-locked-body { padding: 24px; }
    .risk-locked-kicker {
      margin: 0 0 8px !important;
      color: #ff9da5 !important;
      font-size: 12px !important;
      font-weight: 900;
    }
    .risk-locked h2 { line-height: 1.35; }
    .risk-locked-body > p:not(.risk-locked-kicker) {
      margin: 12px 0 0;
      color: var(--public-muted);
      font-size: 13px;
      line-height: 1.8;
    }
    .risk-locked-return {
      margin-top: 18px;
      border: 1px solid #485967;
      border-radius: 4px;
      background: #17222c;
      color: #fff;
    }
    .risk-reminder { display: flex; align-items: center; justify-content: space-between; gap: 18px; }
    .risk-reminder a { color: var(--public-yellow); text-decoration: underline; }
    .risk-reminder form { flex: 0 0 auto; }
    .risk-reminder button {
      min-height: 36px;
      padding: 0 12px;
      border: 1px solid #66542d;
      border-radius: 4px;
      background: #2a2314;
      color: #ffe09a;
      font-weight: 800;
      cursor: pointer;
      white-space: nowrap;
    }
    :focus-visible { outline: 2px solid var(--public-yellow); outline-offset: 3px; }
    @media (max-width: 820px) {
      .site-header-inner { width: min(100% - 28px, 1180px); min-height: 62px; }
      .site-nav a:not(.live-link) { display: none; }
      .public-main { width: min(100% - 28px, 1180px); }
      .query-intro { padding: 38px 0 30px; }
      .query-intro h1 { font-size: 36px; }
      .query-hero { padding: 46px 0 38px; }
      .query-hero h1 { font-size: 36px; }
      .query-lead { font-size: 15px; }
      .search-row,
      .result-search .search-row { grid-template-columns: 1fr; }
      .query-form { margin-top: 24px; }
      .query-form .search-row { grid-template-columns: 1fr; }
      .public-page .query-button { width: 100%; }
      .signal-strip { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .signal-item:nth-child(2) { border-right: 0; }
      .signal-item:nth-child(-n+2) { border-bottom: 1px solid var(--public-line); }
      .section-heading,
      .product-preview { grid-template-columns: 1fr; gap: 18px; }
      .live-promo { flex-direction: column; align-items: flex-start; }
      .live-cta { width: 100%; }
      .live-status { grid-template-columns: 1fr; gap: 18px; }
      .live-dashboard-hero { grid-template-columns: 1fr; padding-top: 38px; }
      .live-hero-copy { min-height: 0; padding-right: 0; }
      .live-control-card { min-height: 0; }
      .live-risk-bar { align-items: flex-start; flex-direction: column; }
      .live-flow { grid-template-columns: 1fr; }
      .live-flow-step { min-height: 108px; border-right: 0; border-bottom: 1px solid var(--public-line); }
      .live-flow-step:last-child { border-bottom: 0; }
      .setup-method-grid,
      .script-setup-layout,
      .plans-grid,
      .support-layout { grid-template-columns: 1fr; }
      .support-services { grid-template-columns: 1fr; }
      .qq-contact-card { max-width: 360px; }
      .live-actions { justify-content: flex-start; }
      .feature-grid { grid-template-columns: 1fr; }
      .session-choice { grid-template-columns: 1fr; }
      .session-choice-actions { justify-content: flex-start; }
      .connect-step { grid-template-columns: 1fr; }
      .connect-options { grid-template-columns: 1fr; }
      .connect-step-meta { border-right: 0; border-bottom: 1px solid var(--public-line); }
      .connect-step-index { margin-bottom: 12px; }
      .risk-hero { padding: 36px 0 24px; }
      .risk-hero h1 { font-size: 32px; }
      .risk-layout { grid-template-columns: 1fr; }
      .risk-confirm { position: static; }
      .risk-document section { padding: 20px 18px; }
      .risk-reminder { align-items: flex-start; flex-direction: column; }
      .content-band { padding: 38px 0; }
      .field-table th { width: 116px; }
      .site-footer { width: min(100% - 28px, 1180px); flex-direction: column; }
      .public-result-panel .player-head { padding: 18px; }
      .public-detail-grid { grid-template-columns: repeat(3, minmax(110px, 1fr)); }
    }
    @media (max-width: 430px) {
      .brand-copy small { display: none; }
      .query-intro h1 { font-size: 32px; }
      .query-hero { padding: 36px 0 30px; }
      .query-hero h1 { font-size: 32px; }
      .query-hero .query-lead { font-size: 14px; line-height: 1.7; }
      .query-form { padding: 7px; border-radius: 10px; }
      .public-page .query-input,
      .public-page .query-button { height: 52px; }
      .query-meta { gap: 8px 14px; }
      .signal-item { min-height: 96px; padding: 18px 14px; }
      .signal-item strong { font-size: 16px; }
      .connect-command-head { align-items: flex-start; }
      .connect-command pre { padding: 14px 12px 16px; font-size: 11px; }
      .risk-hero h1 { font-size: 28px; }
      .risk-document-head { align-items: flex-start; }
      .public-detail-grid { grid-template-columns: repeat(2, minmax(110px, 1fr)); }
    }
    @media print {
      .site-header, .site-footer, .risk-confirm, .risk-print, .skip-link { display: none !important; }
      body.public-page { background: #fff; color: #111; }
      .public-main { width: 100%; padding: 0; }
      .risk-hero { padding: 0 0 20px; }
      .risk-hero h1, .risk-document h2, .risk-document-head strong { color: #111; }
      .risk-version, .risk-document p { color: #333; }
      .risk-critical { border-color: #777; background: #fff; }
      .risk-critical strong, .risk-critical p, .risk-document p strong { color: #111; }
      .risk-layout { display: block; border: 0; padding: 0; }
      .risk-document, .risk-document-head, .risk-document section { border-color: #bbb; background: #fff; }
    }

    /* 公共查询页预览轮播 */
    .preview-carousel {
      width: min(1100px, calc(100% - 40px));
      margin: 44px auto 0;
      padding: 18px;
      border: 1px solid var(--public-line);
      border-radius: 16px;
      background: var(--public-surface);
      box-shadow: 0 20px 60px rgba(0,0,0,.28);
    }
    .preview-carousel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      margin: 0 0 14px;
    }
    .preview-carousel-header h2 {
      margin: 0;
      font-size: 15px;
      font-weight: 800;
      color: var(--public-text);
    }
    .preview-carousel-header p {
      margin: 0;
      font-size: 12px;
      color: var(--public-muted);
    }
    .preview-carousel-viewport {
      position: relative;
      width: 100%;
      aspect-ratio: 16 / 10.5;
      border-radius: 12px;
      overflow: hidden;
      background: #070a0f;
    }
    .preview-carousel-track {
      display: flex;
      height: 100%;
      transition: transform .55s cubic-bezier(.4,0,.2,1);
    }
    .preview-carousel-slide {
      flex: 0 0 100%;
      height: 100%;
      display: grid;
      place-items: center;
      padding: 10px;
    }
    .preview-carousel-slide img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
      border-radius: 8px;
      user-select: none;
      -webkit-user-drag: none;
    }
    .preview-carousel-nav {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      width: 38px;
      height: 38px;
      display: grid;
      place-items: center;
      border: 1px solid rgba(255,255,255,.12);
      border-radius: 50%;
      background: rgba(9,13,18,.72);
      color: #fff;
      font-size: 18px;
      cursor: pointer;
      opacity: 0;
      transition: opacity .2s, background .2s;
      z-index: 2;
    }
    .preview-carousel-viewport:hover .preview-carousel-nav { opacity: 1; }
    .preview-carousel-nav:hover { background: rgba(9,13,18,.92); }
    .preview-carousel-nav.prev { left: 12px; }
    .preview-carousel-nav.next { right: 12px; }
    .preview-carousel-dots {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      margin: 14px 0 0;
    }
    .preview-carousel-dot {
      width: 8px;
      height: 8px;
      border: 0;
      border-radius: 50%;
      background: #3a4c5d;
      cursor: pointer;
      transition: background .2s, transform .2s;
    }
    .preview-carousel-dot.active {
      background: var(--public-cyan);
      transform: scale(1.25);
    }
    @media (max-width: 720px) {
      .preview-carousel { padding: 12px; margin-top: 30px; }
      .preview-carousel-viewport { aspect-ratio: 16 / 12; }
      .preview-carousel-header { flex-direction: column; align-items: flex-start; gap: 4px; }
      .preview-carousel-header h2 { font-size: 14px; }
      .preview-carousel-nav { opacity: 1; width: 32px; height: 32px; }
    }

    /* /live 页面功能预览 Tabs */
    .live-preview-section { margin-top: 48px; }
    .live-preview-tabs {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin: 0 0 16px;
      padding: 0;
      list-style: none;
    }
    .live-preview-tabs li {}
    .live-preview-tabs button {
      padding: 9px 16px;
      border: 1px solid var(--public-line);
      border-radius: 8px;
      background: var(--public-surface-2);
      color: var(--public-muted);
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      transition: .2s;
    }
    .live-preview-tabs button:hover { color: var(--public-text); border-color: #4a5d70; }
    .live-preview-tabs button.active {
      background: rgba(85,199,217,.12);
      border-color: var(--public-cyan);
      color: var(--public-cyan);
    }
    .live-preview-panels { position: relative; }
    .live-preview-panel {
      display: none;
      border: 1px solid var(--public-line);
      border-radius: 14px;
      padding: 14px;
      background: var(--public-surface);
    }
    .live-preview-panel.active { display: block; }
    .live-preview-frame {
      width: 100%;
      aspect-ratio: 16 / 10;
      border-radius: 10px;
      background: #070a0f;
      display: grid;
      place-items: center;
      overflow: hidden;
    }
    .live-preview-frame img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
      user-select: none;
      -webkit-user-drag: none;
    }
    .live-preview-caption {
      margin: 12px 0 0;
      color: var(--public-muted);
      font-size: 13px;
      text-align: center;
    }
    @media (max-width: 720px) {
      .live-preview-section { margin-top: 34px; }
      .live-preview-tabs button { padding: 7px 12px; font-size: 12px; }
      .live-preview-frame { aspect-ratio: 16 / 12; }
    }
"""

PUBLIC_CSS += """
    /* 2026-07-30 公共查询体验重构：代码原生、双端独立布局 */
    :root {
      --public-bg: #071018;
      --public-surface: #0e1822;
      --public-surface-2: #121f2b;
      --public-surface-3: #172633;
      --public-line: #263746;
      --public-line-strong: #3a5062;
      --public-text: #f5f7fa;
      --public-muted: #8fa0af;
      --public-cyan: #66d4e7;
      --public-coral: #ff5f72;
      --public-yellow: #f5c453;
      --public-green: #49d6a0;
      --public-loss: #ff6577;
    }
    body.public-page {
      background:
        radial-gradient(circle at 50% -180px, rgba(32, 84, 112, .17), transparent 430px),
        linear-gradient(180deg, #071018 0%, #08111a 42%, #071018 100%);
      color: var(--public-text);
      overflow-x: hidden;
    }
    .site-header {
      position: relative;
      z-index: 20;
      border-color: rgba(98, 127, 149, .28);
      background: rgba(7, 16, 24, .92);
      backdrop-filter: blur(18px);
    }
    .site-header-inner,
    .site-footer {
      width: min(1380px, calc(100% - 48px));
    }
    .site-header-inner { min-height: 72px; }
    .brand { gap: 13px; }
    .brand-mark {
      position: relative;
      width: 40px;
      height: 40px;
      border: 1px solid #354a5c;
      border-left: 4px solid var(--public-coral);
      border-radius: 2px;
      background: linear-gradient(145deg, #14212c, #0b141d);
      color: #fff;
      font-size: 13px;
      letter-spacing: -.08em;
      box-shadow: inset 0 0 24px rgba(255, 95, 114, .06);
    }
    .brand-copy strong { font-size: 17px; letter-spacing: -.015em; }
    .brand-copy small { font-size: 10px; letter-spacing: .06em; text-transform: uppercase; }
    .site-nav { gap: 28px; font-size: 13px; font-weight: 700; }
    .site-nav a {
      position: relative;
      min-height: 72px;
      display: inline-flex;
      align-items: center;
    }
    .site-nav a[aria-current="page"]::after {
      position: absolute;
      right: 0;
      bottom: 0;
      left: 0;
      height: 3px;
      background: var(--public-coral);
      content: "";
    }
    .site-nav .live-link::before {
      width: 5px;
      height: 5px;
      margin-right: 7px;
      border-radius: 50%;
      background: currentColor;
      box-shadow: 0 0 9px currentColor;
      content: "";
    }
    .public-main { width: min(1380px, calc(100% - 48px)); }
    .section-kicker {
      display: block;
      margin: 0 0 7px;
      color: var(--public-coral);
      font: 900 10px/1 "Segoe UI", Arial, sans-serif;
      letter-spacing: .14em;
    }

    /* 首页 */
    .public-home-page .public-main {
      position: relative;
      padding-bottom: 72px;
    }
    .public-home-page .query-hero {
      position: relative;
      padding: 72px 0 48px;
    }
    .public-home-page .query-hero::before,
    .public-home-page .query-hero::after {
      position: absolute;
      top: 145px;
      width: 190px;
      height: 100px;
      border-top: 1px solid rgba(102, 212, 231, .12);
      border-bottom: 1px solid rgba(255, 95, 114, .1);
      transform: skewX(-28deg);
      pointer-events: none;
      content: "";
    }
    .public-home-page .query-hero::before { right: calc(50% + 520px); }
    .public-home-page .query-hero::after { left: calc(50% + 520px); }
    .public-home-page .eyebrow {
      width: fit-content;
      margin: 0 auto 18px;
      padding: 9px 16px;
      border: 1px solid #304354;
      border-radius: 2px;
      background: rgba(13, 25, 35, .8);
      color: #b9c5cf;
      letter-spacing: .09em;
    }
    .public-home-page .eyebrow::before {
      display: inline-block;
      width: 8px;
      height: 8px;
      margin-right: 9px;
      background: var(--public-coral);
      clip-path: polygon(0 0, 100% 0, 70% 100%, 30% 100%);
      content: "";
    }
    .public-home-page .query-hero h1 {
      max-width: 920px;
      margin: 0 auto;
      font-size: clamp(38px, 4.2vw, 58px);
      line-height: 1.12;
      letter-spacing: -.045em;
    }
    .public-home-page .query-title-accent { color: var(--public-coral); }
    .public-home-page .query-lead {
      max-width: 720px;
      margin-top: 17px;
      color: #a8b5c0;
      font-size: 16px;
    }
    .public-home-page .query-form {
      width: min(860px, 100%);
      margin-top: 30px;
      padding: 5px;
      border: 1px solid #425a6d;
      border-radius: 8px;
      background: rgba(14, 25, 35, .96);
      box-shadow: 0 24px 70px rgba(0, 0, 0, .28);
    }
    .public-home-page .query-form .search-row {
      grid-template-columns: minmax(0, 1fr) 150px;
      gap: 6px;
    }
    .public-home-page .query-input {
      height: 58px;
      border-color: transparent;
      border-radius: 5px;
      background: #08121b;
    }
    .public-home-page .query-button {
      height: 58px;
      border-radius: 5px;
      box-shadow: 0 10px 28px rgba(255, 95, 114, .16);
    }
    .public-home-page .query-meta {
      gap: 10px 28px;
      margin-top: 18px;
      color: #a7b5c0;
    }
    .public-home-page .query-meta span::before {
      width: 7px;
      height: 7px;
      border: 1px solid var(--public-coral);
      border-radius: 2px;
      background: transparent;
      transform: rotate(45deg);
    }
    .home-product-preview {
      margin: 16px 0 0;
      padding-top: 36px;
      border-top: 1px solid rgba(80, 109, 132, .38);
    }
    .home-preview-heading {
      display: grid;
      grid-template-columns: minmax(280px, .8fr) minmax(340px, 1.2fr);
      gap: 48px;
      align-items: end;
      margin: 0 0 24px;
    }
    .home-preview-heading h2 {
      margin: 0;
      color: #fff;
      font-size: 28px;
      line-height: 1.22;
      letter-spacing: -.025em;
    }
    .home-preview-heading p {
      max-width: 660px;
      margin: 0;
      color: var(--public-muted);
      font-size: 13px;
      line-height: 1.8;
    }
    .home-demo-shell {
      overflow: hidden;
      border: 1px solid #314657;
      border-radius: 10px;
      background:
        linear-gradient(140deg, rgba(41, 95, 123, .09), transparent 48%),
        #0b151f;
      box-shadow: 0 30px 80px rgba(0, 0, 0, .25);
    }
    .home-demo-profile {
      display: grid;
      grid-template-columns: minmax(220px, .72fr) minmax(0, 1.28fr);
      gap: 30px;
      align-items: center;
      padding: 24px 26px;
      border-bottom: 1px solid #283b4a;
    }
    .home-demo-profile > div:first-child { display: grid; gap: 4px; }
    .home-demo-profile > div:first-child > strong { color: #fff; font-size: 24px; }
    .home-demo-profile > div:first-child > small { color: var(--public-muted); }
    .home-demo-stats {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
    }
    .home-demo-stats > span {
      min-width: 0;
      display: grid;
      gap: 4px;
      padding: 7px 18px;
      border-left: 1px solid #263846;
    }
    .home-demo-stats small,
    .home-demo-match small { color: var(--public-muted); font-size: 10px; }
    .home-demo-stats strong { color: #fff; font-size: 18px; }
    .home-demo-body {
      display: grid;
      grid-template-columns: minmax(300px, .72fr) minmax(0, 1.28fr);
      gap: 1px;
      background: #263846;
    }
    .home-demo-agents,
    .home-demo-history {
      min-width: 0;
      padding: 20px;
      background: #0b151f;
    }
    .home-demo-label {
      display: block;
      margin-bottom: 12px;
      color: #d8e0e7;
      font-size: 12px;
      font-weight: 900;
    }
    .home-demo-agent {
      display: grid;
      grid-template-columns: 50px minmax(0, 1fr);
      gap: 12px;
      align-items: center;
      min-height: 58px;
      margin-top: 8px;
      padding: 4px 8px 4px 4px;
      border: 1px solid #263a4a;
      border-radius: 5px;
      background: #0f1c27;
    }
    .home-demo-agent img {
      width: 50px;
      height: 50px;
      object-fit: cover;
      object-position: center top;
      border-radius: 3px;
      background: #09131b;
    }
    .home-demo-agent > span { min-width: 0; display: grid; gap: 4px; }
    .home-demo-agent strong { color: #fff; font-size: 13px; }
    .home-demo-agent small { color: var(--public-muted); font-size: 10px; }
    .home-demo-match {
      --demo-result: var(--public-green);
      position: relative;
      isolation: isolate;
      display: grid;
      grid-template-columns: 58px 78px 1fr 66px minmax(116px, .9fr) 55px;
      gap: 12px;
      align-items: center;
      min-height: 70px;
      margin-top: 8px;
      overflow: hidden;
      border: 1px solid #2b4050;
      border-left: 3px solid var(--demo-result);
      border-radius: 5px;
      background: #0f1c27;
    }
    .home-demo-match.loss { --demo-result: var(--public-loss); }
    .home-demo-match::before {
      position: absolute;
      z-index: -1;
      inset: 0 0 0 48%;
      background:
        linear-gradient(90deg, #0f1c27, rgba(15, 28, 39, .72), rgba(15, 28, 39, .9)),
        var(--match-map-art) center / cover;
      opacity: .56;
      content: "";
    }
    .home-demo-match > img {
      width: 58px;
      height: 68px;
      object-fit: cover;
      object-position: center top;
      background: #09131b;
    }
    .home-demo-match > span { min-width: 0; display: grid; gap: 4px; }
    .home-demo-match strong { color: #f5f7f9; font-size: 14px; }
    .home-demo-result b { color: var(--demo-result); font-size: 12px; }
    .home-demo-result strong { font-size: 19px; }
    .home-demo-map strong { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .home-value-grid {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 1px;
      margin-top: 18px;
      border: 1px solid #273947;
      background: #273947;
    }
    .home-value-grid > div {
      min-height: 112px;
      padding: 22px 24px;
      background: #0b151f;
    }
    .home-value-grid strong { display: block; color: #fff; font-size: 15px; }
    .home-value-grid span { display: block; margin-top: 8px; color: var(--public-muted); font-size: 12px; line-height: 1.65; }

    /* 查询结果 */
    .public-results-page .result-main { padding: 22px 0 64px; }
    .public-results-page .result-search {
      margin: 0 0 12px;
      padding: 5px;
      border-color: #314758;
      border-radius: 7px;
      background: #0c1721;
    }
    .public-results-page .result-search .search-row {
      grid-template-columns: minmax(0, 1fr) 108px;
      gap: 6px;
    }
    .public-results-page .result-search .query-input,
    .public-results-page .result-search .query-button {
      height: 48px;
      border-radius: 4px;
    }
    .public-results-page .result-search .query-input {
      border-color: transparent;
      background: #07111a;
      font-size: 14px;
    }
    .result-profile,
    .rank-timeline,
    .agent-overview,
    .public-data-note,
    .match-history {
      border: 1px solid #2b4050;
      border-radius: 8px;
      background: rgba(12, 23, 33, .94);
    }
    .result-profile {
      display: grid;
      grid-template-columns: minmax(350px, .8fr) minmax(520px, 1.2fr);
      gap: 26px;
      align-items: center;
      padding: 22px 24px;
      background:
        linear-gradient(110deg, rgba(45, 104, 134, .1), transparent 55%),
        rgba(12, 23, 33, .96);
    }
    .result-identity {
      min-width: 0;
      display: grid;
      grid-template-columns: 92px minmax(0, 1fr);
      gap: 18px;
      align-items: center;
    }
    .result-portrait {
      position: relative;
      width: 92px;
      height: 92px;
      display: grid;
      place-items: center;
      overflow: hidden;
      border: 1px solid #466276;
      border-left: 3px solid var(--public-coral);
      border-radius: 6px;
      background: #0a131c;
      color: var(--public-coral);
      font-weight: 900;
    }
    .result-portrait::after {
      position: absolute;
      right: -18px;
      bottom: -18px;
      width: 38px;
      height: 38px;
      border: 1px solid rgba(102, 212, 231, .45);
      transform: rotate(45deg);
      content: "";
    }
    .result-portrait img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center top;
    }
    .result-identity h1 {
      min-width: 0;
      margin: 0;
      overflow: hidden;
      color: #fff;
      font-size: clamp(22px, 2.1vw, 31px);
      line-height: 1.15;
      letter-spacing: -.025em;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .result-rank-line {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 8px 12px;
      margin-top: 10px;
    }
    .result-rank-line strong { color: var(--public-yellow); font-size: 14px; }
    .result-rank-line span { color: #dce5eb; font-size: 13px; font-weight: 800; }
    .result-location { margin: 6px 0 0; color: var(--public-muted); font-size: 11px; }
    .result-metrics {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      min-width: 0;
    }
    .result-metric {
      min-width: 0;
      padding: 12px 18px;
      border-left: 1px solid #263a4a;
    }
    .result-metric span { display: block; color: var(--public-muted); font-size: 11px; white-space: nowrap; }
    .result-metric strong { display: block; margin-top: 7px; color: #fff; font-size: 24px; line-height: 1; }
    .result-metric strong.positive { color: var(--public-green); }
    .result-metric strong.negative { color: var(--public-loss); }
    .rank-timeline,
    .agent-overview { margin-top: 10px; padding: 17px 18px 18px; }
    .result-section-title {
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      gap: 24px;
      margin-bottom: 14px;
    }
    .result-section-title h2 {
      margin: 0;
      color: #f5f7f9;
      font-size: 15px;
      line-height: 1.2;
    }
    .result-section-title > span { color: var(--public-muted); font-size: 10px; }
    .rank-timeline-scroll,
    .agent-card-scroll { min-width: 0; overflow-x: auto; scrollbar-width: thin; scrollbar-color: #3e5668 transparent; }
    .rank-timeline-track {
      position: relative;
      min-width: 860px;
      display: grid;
      grid-template-columns: repeat(10, minmax(78px, 1fr));
      gap: 8px;
      padding: 8px 0 2px;
    }
    .rank-timeline-track::before {
      position: absolute;
      top: 17px;
      right: 26px;
      left: 26px;
      height: 1px;
      background: #344a5a;
      content: "";
    }
    .rank-step {
      --step-color: #7a8791;
      position: relative;
      z-index: 1;
      display: grid;
      justify-items: center;
      gap: 5px;
      color: var(--public-muted);
      text-align: center;
    }
    .rank-step.win { --step-color: var(--public-green); }
    .rank-step.loss { --step-color: var(--public-loss); }
    .rank-step-dot {
      width: 19px;
      height: 19px;
      display: block;
      border: 4px solid #0c1721;
      border-radius: 50%;
      background: var(--step-color);
      box-shadow: 0 0 0 1px var(--step-color);
    }
    .rank-step strong { color: #e7edf2; font-size: 11px; }
    .rank-step > span:last-child { color: var(--step-color); font-size: 10px; font-weight: 800; }
    .agent-card-grid {
      min-width: max-content;
      display: flex;
      gap: 8px;
    }
    .agent-card {
      width: 230px;
      display: grid;
      grid-template-columns: 72px minmax(0, 1fr);
      gap: 12px;
      overflow: hidden;
      border: 1px solid #2c4252;
      border-radius: 6px;
      background: #101d28;
    }
    .agent-card-portrait {
      position: relative;
      width: 72px;
      height: 82px;
      display: grid;
      place-items: center;
      overflow: hidden;
      background: #09131c;
      color: var(--public-coral);
      font-size: 11px;
      font-weight: 900;
    }
    .agent-card-portrait img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center top;
    }
    .agent-card-copy {
      min-width: 0;
      display: grid;
      align-content: center;
      gap: 4px;
      padding-right: 10px;
    }
    .agent-card-copy > strong { overflow: hidden; color: #fff; font-size: 14px; text-overflow: ellipsis; white-space: nowrap; }
    .agent-card-copy > span { color: var(--public-muted); font-size: 10px; }
    .agent-card-copy > div { color: var(--public-muted); font-size: 10px; white-space: nowrap; }
    .agent-card-copy b { color: var(--public-cyan); font-size: 11px; }
    .public-data-note {
      margin-top: 10px;
      overflow: hidden;
      background: #0b161f;
    }
    .public-data-note summary {
      min-height: 48px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 20px;
      padding: 8px 16px;
      color: #d5dee5;
      cursor: pointer;
      list-style: none;
    }
    .public-data-note summary::-webkit-details-marker { display: none; }
    .public-data-note summary > span:first-child {
      min-width: 0;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .public-data-note summary > span:first-child::before {
      width: 7px;
      height: 7px;
      flex: 0 0 auto;
      border: 1px solid var(--public-cyan);
      border-radius: 50%;
      box-shadow: 0 0 0 4px rgba(102, 212, 231, .06);
      content: "";
    }
    .public-data-note summary strong { color: #dce5eb; font-size: 12px; }
    .public-data-note summary small { color: var(--public-muted); font-size: 11px; }
    .data-note-action { flex: 0 0 auto; color: var(--public-cyan); font-size: 11px; font-weight: 800; }
    .data-note-action::after {
      display: inline-block;
      width: 7px;
      height: 7px;
      margin-left: 8px;
      border-right: 1px solid currentColor;
      border-bottom: 1px solid currentColor;
      transform: translateY(-2px) rotate(45deg);
      transition: transform .2s;
      content: "";
    }
    .public-data-note[open] .data-note-action::after { transform: translateY(2px) rotate(225deg); }
    .public-data-note-body {
      padding: 14px 16px 16px;
      border-top: 1px solid #263948;
      color: var(--public-muted);
    }
    .public-data-note-body p { margin: 0 0 12px; font-size: 12px; line-height: 1.7; }
    .public-data-note .notice-actions { display: flex; flex-wrap: wrap; gap: 8px; }
    .public-data-note .notice-btn {
      min-height: 34px;
      display: inline-flex;
      align-items: center;
      padding: 0 13px;
      border: 1px solid var(--public-coral);
      border-radius: 4px;
      background: var(--public-coral);
      color: #fff;
      font-size: 11px;
      font-weight: 900;
      cursor: pointer;
    }
    .public-data-note .notice-btn.secondary { border-color: #3c5669; background: #111f2b; color: #d9e3ea; }
    .public-data-note .data-note-intro { margin: 0 0 10px; color: #b6c3cd; font-size: 12px; line-height: 1.6; }
    .public-data-note .data-note-layout { display: flex; gap: 14px; align-items: flex-start; }
    .public-data-note .data-note-main { flex: 1; min-width: 0; }
    .public-data-note .data-note-features {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(128px, 1fr));
      gap: 8px;
      margin: 0 0 12px;
    }
    .public-data-note .feat-block {
      display: flex;
      flex-direction: column;
      gap: 2px;
      padding: 9px 12px;
      border: 1px solid #263948;
      border-left: 3px solid var(--feat-color, #66d4e7);
      border-radius: 5px;
      background: #0d1923;
      background: color-mix(in srgb, var(--feat-color, #66d4e7) 9%, #0d1923);
      transition: border-color .18s, transform .18s;
    }
    .public-data-note .feat-block:hover { border-color: var(--feat-color, #66d4e7); transform: translateY(-1px); }
    .public-data-note .feat-block strong { color: #eef4f8; font-size: 11px; font-weight: 800; line-height: 1.3; }
    .public-data-note .feat-block small { color: var(--public-muted); font-size: 10px; line-height: 1.3; }
    .public-data-note .feat-block:nth-child(1) { --feat-color: #66d4e7; }
    .public-data-note .feat-block:nth-child(2) { --feat-color: #4ade80; }
    .public-data-note .feat-block:nth-child(3) { --feat-color: #a78bfa; }
    .public-data-note .feat-block:nth-child(4) { --feat-color: #f472b6; }
    .public-data-note .feat-block:nth-child(5) { --feat-color: #fbbf24; }
    .public-data-note .feat-block:nth-child(6) { --feat-color: #60a5fa; }
    .public-data-note .feat-block:nth-child(7) { --feat-color: #f87171; }
    .public-data-note .feat-block:nth-child(8) { --feat-color: #818cf8; }
    .public-data-note .feat-block:nth-child(9) { --feat-color: #34d399; }
    .public-data-note .data-note-qr {
      flex: 0 0 auto;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
      padding: 8px 8px 6px;
      border: 1px solid #263948;
      border-radius: 6px;
      background: #0d1923;
      text-align: center;
    }
    .public-data-note .data-note-qr img {
      width: 96px;
      height: 96px;
      object-fit: cover;
      border-radius: 4px;
      background: #fff;
    }
    .public-data-note .data-note-qr span { color: var(--public-muted); font-size: 10px; line-height: 1.3; }
    .public-ad-banner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin: 14px 0 4px;
      padding: 10px 14px;
      border: 1px solid #3a2a2f;
      border-left: 3px solid var(--public-coral);
      border-radius: 8px;
      background: linear-gradient(90deg, #1a1216, #0d1923);
    }
    .public-ad-banner .ad-text { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
    .public-ad-banner .ad-text strong { color: #ffe1a8; font-size: 14px; line-height: 1.4; }
    .public-ad-banner .ad-text span { color: var(--public-muted); font-size: 12px; line-height: 1.4; }
    .public-ad-banner .ad-cta {
      flex: 0 0 auto;
      padding: 8px 14px;
      border: 1px solid var(--public-coral);
      border-radius: 6px;
      background: var(--public-coral);
      color: #fff;
      font-weight: 700;
      font-size: 13px;
      cursor: pointer;
      white-space: nowrap;
    }
    @media (max-width: 820px) {
      .public-ad-banner { flex-direction: column; align-items: stretch; text-align: left; }
      .public-ad-banner .ad-cta { text-align: center; }
    }
    .match-history { margin-top: 10px; padding: 18px; }
    .match-history-title { margin-bottom: 14px; }
    .public-match-list { display: grid; gap: 7px; }
    .public-match-card {
      --match-accent: #75838e;
      overflow: hidden;
      border: 1px solid #2b4050;
      border-left: 3px solid var(--match-accent);
      border-radius: 6px;
      background: #0d1923;
      transition: border-color .18s, background .18s, transform .18s;
    }
    .public-match-card:hover {
      border-color: #3c5669;
      border-left-color: var(--match-accent);
      background: #101e29;
      transform: translateY(-1px);
    }
    .public-match-card.win { --match-accent: var(--public-green); }
    .public-match-card.loss { --match-accent: var(--public-loss); }
    .match-card-main {
      position: relative;
      isolation: isolate;
      min-height: 86px;
      display: grid;
      grid-template-columns: 78px 96px minmax(125px, .7fr) 72px minmax(160px, 1fr) 120px 126px 28px;
      gap: 14px;
      align-items: center;
      padding: 0 14px 0 0;
    }
    .match-card-main > * { position: relative; z-index: 1; min-width: 0; }
    .match-agent {
      align-self: stretch;
      display: grid;
      grid-template-rows: minmax(0, 1fr) auto;
      overflow: hidden;
      border-right: 1px solid #2a3c4a;
      background: #09131c;
    }
    .match-agent-portrait {
      min-height: 0;
      display: grid;
      place-items: center;
      overflow: hidden;
      color: var(--public-coral);
      font-size: 10px;
      font-weight: 900;
    }
    .match-agent-portrait img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center top;
    }
    .match-agent > span {
      padding: 4px 4px 5px;
      overflow: hidden;
      background: rgba(6, 14, 21, .94);
      color: #dce5eb;
      font-size: 10px;
      font-weight: 800;
      text-align: center;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .match-outcome { display: grid; gap: 4px; }
    .match-result { color: var(--match-accent); font-size: 12px; font-weight: 900; }
    .match-outcome strong { color: #fff; font-size: 23px; line-height: 1; letter-spacing: .02em; }
    .match-metric,
    .match-map,
    .match-rank,
    .match-time { display: grid; gap: 5px; }
    .match-metric span,
    .match-map > span,
    .match-rank > span,
    .match-time > span { color: var(--public-muted); font-size: 9px; letter-spacing: .04em; }
    .match-metric strong { color: #f4f7f9; font-size: 17px; white-space: nowrap; }
    .match-acs strong { font-size: 19px; }
    .match-map {
      position: relative;
      isolation: isolate;
      align-self: stretch;
      justify-content: center;
      padding: 0 18px;
      overflow: hidden;
      border-right: 1px solid #2a3c4a;
      border-left: 1px solid #2a3c4a;
    }
    .match-map::before {
      position: absolute;
      z-index: -2;
      inset: 0;
      background: var(--match-map-art) center / cover no-repeat;
      opacity: .34;
      content: "";
    }
    .match-map::after {
      position: absolute;
      z-index: -1;
      inset: 0;
      background: linear-gradient(90deg, #0d1923 0%, rgba(13, 25, 35, .65) 34%, rgba(13, 25, 35, .76) 68%, #0d1923 100%);
      content: "";
    }
    .match-map strong { overflow: hidden; color: #fff; font-size: 14px; text-overflow: ellipsis; white-space: nowrap; }
    .match-highlight {
      width: fit-content;
      max-width: 100%;
      overflow: hidden;
      color: var(--public-yellow) !important;
      font-size: 9px !important;
      font-weight: 800;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .match-rank strong { overflow: hidden; color: #e1e8ed; font-size: 13px; text-overflow: ellipsis; white-space: nowrap; }
    .match-rank b { color: var(--match-accent); font-size: 13px; }
    .match-time strong { color: #d8e1e7; font-size: 11px; }
    .match-time > span { letter-spacing: 0; }
    .match-index { color: #4e6170; font: 900 11px/1 "Segoe UI", Arial, sans-serif; text-align: right; }
    .public-detail-button {
      width: 100%;
      min-height: 38px;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 10px;
      padding: 0 16px;
      border: 0;
      border-top: 1px solid #263a49;
      border-radius: 0;
      background: #0b161f;
      color: #adc0ce;
      font-size: 10px;
      font-weight: 800;
      cursor: pointer;
    }
    .public-detail-button:hover,
    .public-detail-button[aria-expanded="true"] { border-color: #304757; background: #101e29; color: var(--public-cyan); }
    .detail-chevron {
      width: 7px;
      height: 7px;
      border-right: 1px solid currentColor;
      border-bottom: 1px solid currentColor;
      transform: translateY(-2px) rotate(45deg);
      transition: transform .2s;
    }
    .public-detail-button[aria-expanded="true"] .detail-chevron { transform: translateY(2px) rotate(225deg); }
    .match-detail-unavailable { min-height: 34px; display: flex; align-items: center; justify-content: flex-end; padding: 0 16px; border-top: 1px solid #263a49; color: #667887; font-size: 10px; }
    .battle-detail-row { background: #09131c; }
    .battle-detail-row[hidden] { display: none; }
    .public-battle-detail { min-height: 88px; border-top: 1px solid #2e4657; }
    .public-detail-state { padding: 22px 20px; }
    .public-detail-head { padding: 15px 18px; background: #0d1a24; }
    .public-detail-grid {
      grid-template-columns: repeat(6, minmax(100px, 1fr));
      background: #293e4e;
    }
    .public-detail-stat { background: #0e1b25; }
    .public-detail-team { border-top: 1px solid #2b4050; }
    .public-detail-team-title { padding: 11px 16px; background: #0b161f; }
    .public-detail-player-list { padding: 5px 12px 12px; }
    .public-detail-player {
      display: grid;
      grid-template-columns: 42px minmax(170px, 1fr) minmax(95px, .6fr) minmax(120px, .8fr) minmax(70px, .45fr);
      gap: 12px;
      align-items: center;
      min-height: 52px;
      padding: 5px 8px;
      border-bottom: 1px solid #223543;
      color: #dce4ea;
    }
    .public-detail-player:last-child { border-bottom: 0; }
    .public-detail-player.target-player { background: rgba(245, 196, 83, .055); box-shadow: inset 2px 0 0 var(--public-yellow); }
    .detail-player-agent {
      width: 38px;
      height: 38px;
      display: grid;
      place-items: center;
      overflow: hidden;
      border: 1px solid #375064;
      border-radius: 4px;
      background: #071018;
      color: var(--public-coral);
      font-size: 8px;
      font-weight: 900;
    }
    .detail-player-agent img { width: 100%; height: 100%; object-fit: cover; object-position: center top; }
    .detail-player-identity { min-width: 0; display: grid; gap: 3px; }
    .detail-player-identity > strong { overflow: hidden; color: #f5f7f9; font-size: 12px; text-overflow: ellipsis; white-space: nowrap; }
    .detail-player-identity > span { color: var(--public-muted); font-size: 9px; }
    .target-badge { margin-left: 6px; color: var(--public-yellow); font-size: 8px; font-weight: 900; }
    .detail-player-metric { min-width: 0; display: grid; gap: 3px; }
    .detail-player-metric > span { color: var(--public-muted); font-size: 8px; }
    .detail-player-metric > strong { overflow: hidden; color: #e4ebef; font-size: 11px; text-overflow: ellipsis; white-space: nowrap; }
    .result-note { margin-top: 14px; text-align: center; }
    .site-footer { border-top: 1px solid rgba(63, 87, 106, .32); }

    @media (max-width: 1120px) {
      .result-profile { grid-template-columns: minmax(300px, .8fr) minmax(430px, 1.2fr); }
      .match-card-main {
        grid-template-columns: 72px 88px minmax(118px, .75fr) 66px minmax(140px, 1fr) 104px 110px;
        gap: 10px;
      }
      .match-index { display: none; }
      .home-demo-match { grid-template-columns: 54px 72px 1fr 58px minmax(104px, .9fr) 48px; gap: 8px; }
    }

    @media (max-width: 820px) {
      .site-header-inner,
      .site-footer,
      .public-main { width: calc(100% - 24px); }
      .site-header-inner { min-height: 64px; }
      .brand-mark { width: 36px; height: 36px; }
      .brand-copy strong { font-size: 15px; }
      .site-nav { gap: 0; }
      .site-nav a { min-height: 64px; }
      .site-nav a:not(.live-link) { display: none; }
      .site-nav .live-link { font-size: 13px; }

      .public-home-page .query-hero { padding: 42px 0 32px; }
      .public-home-page .query-hero::before,
      .public-home-page .query-hero::after { display: none; }
      .public-home-page .eyebrow { margin-bottom: 14px; padding: 8px 11px; font-size: 10px; }
      .public-home-page .query-hero h1 { max-width: 560px; font-size: clamp(32px, 8vw, 42px); }
      .public-home-page .query-lead { margin-top: 13px; font-size: 13px; line-height: 1.65; }
      .public-home-page .query-form { margin-top: 22px; }
      .public-home-page .query-form .search-row {
        grid-template-columns: minmax(0, 1fr) 104px;
        gap: 5px;
      }
      .public-home-page .query-input,
      .public-home-page .query-button { height: 52px; }
      .public-home-page .query-input { padding: 0 13px; font-size: 14px; }
      .public-home-page .query-button { width: auto; font-size: 13px; }
      .public-home-page .query-meta { gap: 8px 14px; font-size: 10px; }
      .home-product-preview { margin-top: 2px; padding-top: 28px; }
      .home-preview-heading { grid-template-columns: 1fr; gap: 10px; margin-bottom: 16px; }
      .home-preview-heading h2 { font-size: 22px; }
      .home-preview-heading p { font-size: 12px; line-height: 1.65; }
      .home-demo-profile { grid-template-columns: 1fr; gap: 14px; padding: 18px; }
      .home-demo-profile > div:first-child > strong { font-size: 20px; }
      .home-demo-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1px; background: #263846; }
      .home-demo-stats > span { padding: 12px; border: 0; background: #0d1923; }
      .home-demo-stats strong { font-size: 16px; }
      .home-demo-body { grid-template-columns: 1fr; }
      .home-demo-agents,
      .home-demo-history { padding: 15px; }
      .home-demo-agents { overflow-x: auto; white-space: nowrap; }
      .home-demo-agent {
        width: 152px;
        display: inline-grid;
        grid-template-columns: 48px 92px;
        margin: 0 6px 0 0;
        vertical-align: top;
        white-space: normal;
      }
      .home-demo-agent img { width: 48px; height: 48px; }
      .home-demo-match {
        grid-template-columns: 48px 64px minmax(74px, 1fr) 48px minmax(92px, 1fr);
        min-height: 62px;
      }
      .home-demo-match > img { width: 48px; height: 60px; }
      .home-demo-match > span:last-child { display: none; }
      .home-demo-match strong { font-size: 12px; }
      .home-demo-result strong { font-size: 16px; }
      .home-value-grid { grid-template-columns: 1fr; }
      .home-value-grid > div { min-height: 0; padding: 17px 18px; }

      .public-results-page .result-main { padding-top: 12px; }
      .public-results-page .result-search { position: relative; z-index: 5; margin-bottom: 8px; }
      .public-results-page .result-search .search-row {
        grid-template-columns: minmax(0, 1fr) 88px;
        gap: 5px;
      }
      .public-results-page .result-search .query-button { width: auto; }
      .result-profile { grid-template-columns: minmax(0, 1fr) 148px; gap: 9px; padding: 13px; }
      .result-identity { grid-template-columns: 62px minmax(0, 1fr); gap: 9px; }
      .result-portrait { width: 62px; height: 68px; }
      .result-identity h1 {
        display: -webkit-box;
        overflow: hidden;
        font-size: 17px;
        line-height: 1.2;
        white-space: normal;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
      }
      .result-identity .section-kicker { margin-bottom: 5px; font-size: 8px; }
      .result-rank-line { gap: 5px 8px; margin-top: 6px; }
      .result-rank-line strong,
      .result-rank-line span { font-size: 11px; }
      .result-location { display: none; }
      .result-metrics { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1px; background: #263a49; }
      .result-metric { min-height: 54px; padding: 9px 10px; border: 0; background: #0d1a24; }
      .result-metric span { font-size: 8px; }
      .result-metric strong { margin-top: 5px; font-size: 18px; }
      .rank-timeline,
      .agent-overview { padding: 12px 11px; }
      .result-section-title { align-items: center; margin-bottom: 10px; }
      .result-section-title .section-kicker { margin-bottom: 5px; font-size: 8px; }
      .result-section-title h2 { font-size: 14px; }
      .result-section-title > span { display: none; }
      .rank-timeline-track { min-width: 720px; grid-template-columns: repeat(10, 64px); padding-top: 4px; }
      .rank-timeline-track::before { top: 13px; }
      .rank-step { gap: 3px; }
      .rank-step-dot { width: 17px; height: 17px; }
      .rank-step strong,
      .rank-step > span:last-child { font-size: 9px; }
      .agent-card { width: 162px; grid-template-columns: 56px minmax(0, 1fr); gap: 8px; }
      .agent-card-portrait { width: 56px; height: 66px; }
      .agent-card-copy > strong { font-size: 12px; }
      .agent-card-copy > span,
      .agent-card-copy > div { font-size: 8px; }
      .public-data-note summary { min-height: 46px; padding: 7px 12px; }
      .public-data-note summary > span:first-child { gap: 8px; }
      .public-data-note summary small { display: none; }
      .data-note-action { font-size: 10px; }
      .public-data-note .data-note-qr { display: none; }
      .match-history { padding: 14px 10px; }
      .match-card-main {
        grid-template-columns: 62px minmax(76px, .8fr) minmax(92px, 1fr) 64px;
        grid-template-areas:
          "agent outcome kda acs"
          "agent map map map"
          "rank rank time time";
        gap: 0 10px;
        min-height: 132px;
        padding: 0 10px 8px 0;
      }
      .match-agent { grid-area: agent; }
      .match-outcome { grid-area: outcome; }
      .match-kda { grid-area: kda; }
      .match-acs { grid-area: acs; }
      .match-map { grid-area: map; align-self: center; min-height: 35px; padding: 5px 12px; border: 1px solid #2b4050; border-radius: 4px; }
      .match-rank { grid-area: rank; align-self: center; grid-template-columns: auto auto auto; align-items: center; justify-content: start; gap: 8px; padding-top: 7px; }
      .match-time { grid-area: time; align-self: center; grid-template-columns: auto auto auto; justify-content: end; gap: 7px; padding-top: 7px; text-align: right; }
      .match-index { display: none; }
      .match-agent { min-height: 123px; }
      .match-outcome strong { font-size: 20px; }
      .match-metric strong { font-size: 15px; }
      .match-map::after { background: linear-gradient(90deg, rgba(13, 25, 35, .9), rgba(13, 25, 35, .46), rgba(13, 25, 35, .84)); }
      .match-map strong { font-size: 12px; }
      .match-map > span { display: none; }
      .match-highlight { justify-self: end; }
      .match-rank > span,
      .match-time > span { font-size: 8px; }
      .match-rank strong,
      .match-rank b { font-size: 11px; }
      .match-time strong { font-size: 9px; }
      .public-detail-button { min-height: 44px; justify-content: center; }
      .public-detail-head { align-items: flex-start; padding: 13px; }
      .public-detail-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .public-detail-stat { padding: 10px 12px; }
      .public-detail-team-title { padding: 10px 12px; }
      .public-detail-player-list { padding: 4px 7px 9px; }
      .public-detail-player {
        grid-template-columns: 40px minmax(0, 1fr) auto;
        grid-template-areas:
          "avatar identity kda"
          "avatar acs hs";
        gap: 4px 9px;
        min-height: 62px;
        padding: 7px 5px;
      }
      .detail-player-agent { grid-area: avatar; }
      .detail-player-identity { grid-area: identity; }
      .public-detail-player .detail-player-metric:not(.detail-player-acs):not(.detail-player-hs) { grid-area: kda; text-align: right; }
      .detail-player-acs { grid-area: acs; }
      .detail-player-hs { grid-area: hs; text-align: right; }
      .detail-player-metric > strong { font-size: 10px; }
      .detail-player-acs > strong { max-width: 150px; }
    }

    @media (max-width: 430px) {
      .brand-copy small { display: none; }
      .public-home-page .query-hero { padding-top: 32px; }
      .public-home-page .query-hero h1 { font-size: 34px; line-height: 1.16; }
      .public-home-page .query-meta { justify-content: flex-start; padding-left: 2px; }
      .home-demo-match { grid-template-columns: 44px 58px minmax(74px, 1fr) 45px minmax(82px, .9fr); gap: 6px; }
      .home-demo-match > img { width: 44px; }
      .home-demo-match::before { inset: 0 0 0 44%; }
      .public-results-page .result-search .query-input { padding: 0 11px; font-size: 13px; }
      .public-results-page .result-search .query-button { font-size: 13px; }
      .result-profile { grid-template-columns: minmax(0, 1fr) 142px; padding: 12px; }
      .result-identity h1 { font-size: 16px; }
      .result-metric strong { font-size: 17px; }
      .match-card-main {
        grid-template-columns: 58px minmax(68px, .75fr) minmax(86px, 1fr) 54px;
        gap: 0 8px;
      }
      .match-agent { min-height: 123px; }
      .match-agent > span { font-size: 9px; }
      .match-result { font-size: 11px; }
      .match-outcome strong { font-size: 18px; }
      .match-metric strong { font-size: 14px; }
      .match-acs strong { font-size: 16px; }
      .match-rank { gap: 6px; }
      .match-time { gap: 5px; }
      .match-highlight { max-width: 112px; }
    }
"""


def esc(value: Any) -> str:
    return "" if value is None else html.escape(str(value), quote=True)


def public_battle_detail_script() -> str:
    return """<script>
document.addEventListener('click', async event => {
  const button = event.target.closest('[data-battle-detail-ref]');
  if (!button || button.dataset.loading === 'true') return;
  const detailId = button.getAttribute('aria-controls');
  const detailRow = detailId ? document.getElementById(detailId) : null;
  const panel = detailRow ? detailRow.querySelector('[data-detail-panel]') : null;
  if (!detailRow || !panel) return;

  const willOpen = detailRow.hidden;
  detailRow.hidden = !willOpen;
  button.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
  const buttonLabel = button.querySelector('span:first-child');
  const nextLabel = willOpen
    ? (button.dataset.detailOpenLabel || '收起')
    : (button.dataset.detailClosedLabel || '详情');
  if (buttonLabel) buttonLabel.textContent = nextLabel;
  else button.textContent = nextLabel;
  if (!willOpen || panel.dataset.loaded === 'true') return;

  button.dataset.loading = 'true';
  button.disabled = true;
  panel.setAttribute('aria-busy', 'true');
  const loading = document.createElement('div');
  loading.className = 'public-detail-state';
  loading.textContent = '正在查询这局的详细记录…';
  panel.replaceChildren(loading);
  try {
    const ref = button.dataset.battleDetailRef || '';
    const response = await fetch(`/api/public/battle-detail?ref=${encodeURIComponent(ref)}`, {
      cache: 'no-store',
      headers: {accept: 'application/json'}
    });
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error(payload.error || '详情查询失败');
    panel.innerHTML = payload.html;
    panel.dataset.loaded = 'true';
  } catch (error) {
    const message = document.createElement('div');
    message.className = 'public-detail-state error';
    message.textContent = error instanceof Error ? error.message : '详情查询失败，请稍后重试。';
    panel.replaceChildren(message);
  } finally {
    panel.removeAttribute('aria-busy');
    button.disabled = false;
    button.dataset.loading = 'false';
  }
});
</script>"""


def public_head(
    title: str,
    description: str,
    canonical_path: str = "/public",
    *,
    index: bool = True,
    schema: dict[str, Any] | None = None,
) -> str:
    canonical_url = f"{PUBLIC_SITE_URL}{canonical_path}"
    verification_code = os.getenv("BAIDU_SITE_VERIFICATION", "").strip()
    verification_meta = ""
    if re.fullmatch(r"[A-Za-z0-9_-]{3,128}", verification_code):
        verification_meta = (
            f'<meta name="baidu-site-verification" content="{esc(verification_code)}">'
        )
    schema_html = ""
    if schema:
        schema_json = json.dumps(schema, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
        schema_html = f'<script type="application/ld+json">{schema_json}</script>'
    robots = "index, follow, max-image-preview:large" if index else "noindex, follow"
    return f"""
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="applicable-device" content="pc,mobile">
  <meta name="format-detection" content="telephone=no">
  <meta name="robots" content="{robots}">
  {verification_meta}
  <title>{esc(title)}</title>
  <meta name="description" content="{esc(description)}">
  <link rel="canonical" href="{esc(canonical_url)}">
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <meta name="theme-color" content="#0d1218">
  <meta property="og:locale" content="zh_CN">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="WGame VAL Query">
  <meta property="og:title" content="{esc(title)}">
  <meta property="og:description" content="{esc(description)}">
  <meta property="og:url" content="{esc(canonical_url)}">
  <meta property="og:image" content="{PUBLIC_SITE_URL}/assets/public-query-preview-20260723.png">
  {schema_html}"""


def public_robots_txt() -> str:
    return f"""User-agent: *
Allow: /public
Allow: /public-query
Allow: /live
Allow: /privacy
Allow: /assets/public-query-preview-20260723.png
Allow: /favicon.svg
Allow: /baidu_verify_
Disallow: /api/
Disallow: /owner-login
Disallow: /live-sessions
Disallow: /live/select
Disallow: /live/agreement
Disallow: /live/agree
Disallow: /live/revoke
Disallow: /live/room
Disallow: /live/match
Disallow: /teammates-live
Disallow: /assistant
Disallow: /query
Disallow: /pages/
Disallow: /battle
Disallow: /probe-current-match
Disallow: /launch-chrome
Disallow: /import-default
Disallow: /scan-alias-captures

Sitemap: {PUBLIC_SITE_URL}/sitemap.xml
"""


def public_sitemap_xml() -> str:
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>{PUBLIC_SITE_URL}/public</loc>
    <lastmod>{PUBLIC_PAGE_UPDATED}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>{PUBLIC_SITE_URL}/live</loc>
    <lastmod>{PUBLIC_PAGE_UPDATED}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>{PUBLIC_SITE_URL}/privacy</loc>
    <lastmod>{PUBLIC_PAGE_UPDATED}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.4</priority>
  </url>
  <url>
    <loc>{PUBLIC_SITE_URL}/party-analysis-demo</loc>
    <lastmod>{PUBLIC_PAGE_UPDATED}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
</urlset>
"""


def public_favicon_svg() -> str:
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <rect width="64" height="64" rx="8" fill="#111820"/>
  <path d="M15 15h10l7 23 7-23h10L37 50H27L15 15z" fill="#ff5d68"/>
  <path d="M27 15h10l-5 16-5-16z" fill="#55c7d9"/>
</svg>"""


def to_int(value: Any, default: int | None = None) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def normalize_name(value: str) -> str:
    return re.sub(r"\s+", "", value or "").lower()


def rank_name(value: Any) -> str:
    tier = to_int(value)
    if tier is None:
        return "-"
    return RANK_NAMES.get(tier, str(tier))


def agent_name(character_id: Any) -> str:
    cid = str(character_id or "").lower()
    display = AGENTS.get(cid)
    if display:
        return display.split(" / ", 1)[0]
    return cid[:8] + "..." if cid else "-"


def agent_icon_href(character_id: Any) -> str:
    cid = str(character_id or "").strip().lower()
    return f"/assets/agent-icon/{cid}.png" if SUBJECT_RE.match(cid) else ""


def agent_icon_bytes(character_id: str) -> bytes:
    cid = str(character_id or "").strip().lower()
    if not SUBJECT_RE.match(cid):
        raise ValueError("英雄 UUID 格式不正确")
    path = AGENT_ICON_DIR / f"{cid}.png"
    with AGENT_ICON_LOCK:
        if path.exists():
            data = path.read_bytes()
            if data.startswith(b"\x89PNG\r\n\x1a\n"):
                return data
        response = requests.get(
            f"https://media.valorant-api.com/agents/{cid}/displayicon.png",
            timeout=12,
        )
        response.raise_for_status()
        data = bytes(response.content)
        if len(data) > 2 * 1024 * 1024 or not data.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("英雄头像响应不是有效 PNG")
        AGENT_ICON_DIR.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_bytes(data)
        tmp.replace(path)
        return data


def map_name(map_id: Any) -> str:
    if not map_id:
        return "-"
    text = str(map_id).strip("/")
    short_name = text.split("/")[-1]
    return MAP_NAMES.get(short_name.lower(), short_name)


def map_asset_key(map_id: Any) -> str:
    text = str(map_id or "").strip("/")
    return text.split("/")[-1].lower()


def map_art_href(map_id: Any) -> str:
    key = map_asset_key(map_id)
    return f"/assets/map-art/{key}.png" if key in MAP_ASSET_UUIDS else ""


def map_art_bytes(map_key: str) -> bytes:
    key = str(map_key or "").strip().lower()
    asset_uuid = MAP_ASSET_UUIDS.get(key)
    if not asset_uuid:
        raise ValueError("地图素材标识不存在")
    path = MAP_ART_DIR / f"{key}.png"
    with MAP_ART_LOCK:
        if path.exists():
            data = path.read_bytes()
            if data.startswith(b"\x89PNG\r\n\x1a\n"):
                return data
        response = requests.get(
            f"https://media.valorant-api.com/maps/{asset_uuid}/listviewicon.png",
            timeout=15,
        )
        response.raise_for_status()
        data = bytes(response.content)
        if len(data) > 8 * 1024 * 1024 or not data.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("地图素材响应不是有效 PNG")
        MAP_ART_DIR.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_bytes(data)
        tmp.replace(path)
        return data


def result_name(value: Any) -> str:
    if value in (1, "1", True):
        return "胜利"
    if value in (0, "0", False):
        return "失败"
    return "-"


def score_text(battle: dict[str, Any]) -> str:
    won = to_int(battle.get("roundsWon"))
    played = to_int(battle.get("roundsPlayed"))
    if won is None or played is None:
        return "-"
    return f"{won}:{max(played - won, 0)}"


def rr_text(value: Any) -> str:
    number = to_int(value)
    if number is None:
        return "-" if value is None else str(value)
    return f"+{number}" if number > 0 else str(number)


def kda_text(battle: dict[str, Any]) -> str:
    return f"{battle.get('statsKills', '-')}/{battle.get('statsDeaths', '-')}/{battle.get('statsAssists', '-')}"


def detail_kda_text(player: dict[str, Any]) -> str:
    kills = player.get("statsKills", player.get("kill", "-"))
    deaths = player.get("statsDeaths", player.get("death", "-"))
    assists = player.get("statsAssists", player.get("assist", "-"))
    if kills == deaths == assists == "-":
        return "-"
    return f"{kills}/{deaths}/{assists}"


def acs_text(battle: dict[str, Any]) -> str:
    score = to_int(battle.get("statsScore"))
    rounds = to_int(battle.get("statsRoundsPlayed") or battle.get("roundsPlayed"))
    if score is None or not rounds:
        return "-"
    return str(round(score / rounds))


def duration_text(millis: Any) -> str:
    value = to_int(millis)
    if value is None:
        return "-"
    return f"{round(value / 60000)}分钟"


def highlights_text(battle: dict[str, Any]) -> str:
    parts = []
    if battle.get("isMatchMvp"):
        parts.append("全场MVP")
    elif battle.get("isTeamMvp"):
        parts.append("队伍MVP")
    first_kill = to_int(battle.get("firstKillCount"), 0)
    quad = to_int(battle.get("quadraKillCount"), 0)
    penta = to_int(battle.get("pentaKillCount"), 0)
    six = to_int(battle.get("sixKillCount"), 0)
    if first_kill:
        parts.append(f"一血x{first_kill}")
    if quad:
        parts.append(f"四杀x{quad}")
    if penta:
        parts.append(f"五杀x{penta}")
    if six:
        parts.append(f"六杀x{six}")
    return " / ".join(parts) or "-"


def init_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    PAGES_DIR.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as db:
        db.execute(
            """
            create table if not exists subjects (
                key text primary key,
                display_name text not null,
                subject text not null,
                source text,
                updated_at integer not null
            )
            """
        )
        db.execute("create index if not exists idx_subjects_subject on subjects(subject)")
        db.execute(
            """
            create table if not exists live_risk_acceptances (
                acceptance_id text primary key,
                agreement_version text not null,
                agreement_sha256 text not null,
                accepted_at integer not null,
                expires_at integer not null,
                viewer_hash text not null,
                user_agent_hash text not null,
                client_hash text not null default '',
                revoked_at integer
            )
            """
        )
        columns = {
            str(row[1])
            for row in db.execute("pragma table_info(live_risk_acceptances)").fetchall()
        }
        if "client_hash" not in columns:
            db.execute(
                "alter table live_risk_acceptances "
                "add column client_hash text not null default ''"
            )
        if "revoked_at" not in columns:
            db.execute(
                "alter table live_risk_acceptances add column revoked_at integer"
            )
        db.execute(
            "create index if not exists idx_live_risk_expires "
            "on live_risk_acceptances(expires_at)"
        )
        db.execute(
            "create index if not exists idx_live_risk_client "
            "on live_risk_acceptances(client_hash, revoked_at)"
        )


def upsert_subject(name: str, subject: str, source: str) -> bool:
    if not name or not subject or not SUBJECT_RE.match(subject):
        return False
    key = normalize_name(name)
    if not key:
        return False
    with sqlite3.connect(DB_PATH) as db:
        db.execute(
            """
            insert into subjects(key, display_name, subject, source, updated_at)
            values(?, ?, ?, ?, ?)
            on conflict(key) do update set
                display_name=excluded.display_name,
                subject=excluded.subject,
                source=excluded.source,
                updated_at=excluded.updated_at
            """,
            (key, name, subject.lower(), source, int(time.time())),
        )
    return True


def lookup_subject(query: str) -> tuple[str | None, str | None]:
    query = (query or "").strip()
    if SUBJECT_RE.match(query):
        return query.lower(), query.lower()
    key = normalize_name(query)
    if not key:
        return None, None
    with sqlite3.connect(DB_PATH) as db:
        row = db.execute(
            "select display_name, subject from subjects where key=?",
            (key,),
        ).fetchone()
    if not row:
        return None, None
    return row[1], row[0]


def split_name_tag(query: str) -> tuple[str, str] | None:
    match = NAME_TAG_RE.match((query or "").strip())
    if not match:
        return None
    game_name = match.group(1).strip()
    tag_line = match.group(2).strip()
    if not game_name or not tag_line:
        return None
    return game_name, tag_line


def alias_lookup_headers() -> tuple[dict[str, str], str | None, str | None]:
    import current_match_probe as probe_mod

    paths = probe_mod.latest_capture_files()[:12]
    headers, self_subject, source = probe_mod.extract_latest_game_headers(paths)
    if not headers:
        raise RuntimeError("没有抓到游戏侧 token。需要启动 Proxifier 抓包并让游戏客户端产生一次登录/配置请求。")
    bearer = headers.get("Authorization", "").removeprefix("Bearer").strip()
    payload = probe_mod.decode_jwt_payload(bearer)
    exp = payload.get("exp")
    if isinstance(exp, int):
        ttl = exp - int(time.time())
        if ttl <= 15:
            raise RuntimeError(f"游戏 token 已过期或即将过期（ttl={ttl}s）。请保持游戏客户端在线，或重启/进入游戏触发刷新。")
    return headers, self_subject, str(source) if source else None


def alias_request_headers() -> tuple[dict[str, str], str | None]:
    headers, _, source = alias_lookup_headers()
    request_headers = {
        "Authorization": headers["Authorization"],
        "Accept": "application/json",
        "User-Agent": headers.get(
            "User-Agent",
            "RiotGamesApi/26.5.1.0 player-account (Windows;10;;Professional, x64) "
            "valorant/release-china-13.01-shipping-14-5026731",
        ),
    }
    for key in ("X-Riot-ClientVersion", "X-Riot-ClientPlatform"):
        if headers.get(key):
            request_headers[key] = headers[key]
    return request_headers, source


def alias_api_items(
    game_name: str,
    tag_line: str | None = None,
    request_headers: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    headers = request_headers
    if headers is None:
        headers, _ = alias_request_headers()
    query = {"gameName": game_name}
    if tag_line is not None:
        query["tagLine"] = tag_line
    url = (
        "https://alpha1-rso.val.qq.com:3001/aliases/v1/aliases?"
        + urllib.parse.urlencode(query)
    )
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read().decode("utf-8", errors="replace"))
    if not isinstance(data, list):
        raise RuntimeError("aliases 接口响应格式不符合预期")
    return [item for item in data if isinstance(item, dict)]


def alias_item_identity(item: dict[str, Any]) -> tuple[str, str, str] | None:
    alias = item.get("alias") if isinstance(item.get("alias"), dict) else {}
    game_name = str(alias.get("game_name") or alias.get("gameName") or "").strip()
    tag_line = str(alias.get("tag_line") or alias.get("tagLine") or "").strip()
    subject = str(item.get("puuid") or item.get("subject") or "").lower()
    if not game_name or not tag_line or not SUBJECT_RE.fullmatch(subject):
        return None
    return game_name, tag_line, subject


def exact_alias_item(
    items: list[dict[str, Any]],
    game_name: str,
    tag_line: str,
) -> tuple[str, str, str] | None:
    lowered_name = game_name.casefold()
    lowered_tag = tag_line.casefold()
    for item in items:
        identity = alias_item_identity(item)
        if not identity:
            continue
        item_name, item_tag, subject = identity
        if item_name.casefold() == lowered_name and item_tag.casefold() == lowered_tag:
            return item_name, item_tag, subject
    return None


def search_aliases_by_nickname(nickname: str) -> dict[str, Any]:
    nickname = re.sub(r"\s+", " ", (nickname or "").strip())
    if "#" in nickname:
        raise ValueError("这里只输入昵称，不要包含 #数字 ID")
    if not nickname or len(nickname) > 32:
        raise ValueError("昵称长度应为 1–32 个字符")
    request_headers, source = alias_request_headers()
    items = alias_api_items(nickname, request_headers=request_headers)
    found: dict[tuple[str, str], dict[str, Any]] = {}
    exact_name_count = 0
    for item in items:
        identity = alias_item_identity(item)
        if not identity:
            continue
        game_name, tag_line, subject = identity
        if game_name.casefold() != nickname.casefold():
            continue
        exact_name_count += 1
        display = f"{game_name}#{tag_line}"
        found[(game_name.casefold(), tag_line)] = {
            "name": display,
            "nickname": game_name,
            "tag": tag_line,
            "subject": subject,
        }
        upsert_subject(display, subject, f"nickname-search:{source or 'capture'}")
    escaped_name = nickname.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    with sqlite3.connect(DB_PATH) as db:
        cached_rows = db.execute(
            """
            select display_name, subject from subjects
            where display_name like ? escape '\\'
            """,
            (f"{escaped_name}#%",),
        ).fetchall()
    cached_exact_count = 0
    for display_name, subject in cached_rows:
        cached_parts = str(display_name or "").rsplit("#", 1)
        if len(cached_parts) != 2 or cached_parts[0].casefold() != nickname.casefold():
            continue
        if not cached_parts[1] or not SUBJECT_RE.fullmatch(str(subject or "")):
            continue
        cached_exact_count += 1
        found.setdefault(
            (cached_parts[0].casefold(), cached_parts[1]),
            {
                "name": str(display_name),
                "nickname": cached_parts[0],
                "tag": cached_parts[1],
                "subject": str(subject).lower(),
            },
        )
    results = sorted(
        found.values(),
        key=lambda item: (
            0 if str(item["tag"]).isdigit() else 1,
            int(str(item["tag"])) if str(item["tag"]).isdigit() else str(item["tag"]).casefold(),
            str(item["subject"]),
        ),
    )
    return {
        "ok": True,
        "nickname": nickname,
        "returned_count": len(items),
        "exact_name_count": exact_name_count,
        "cached_exact_count": cached_exact_count,
        "merged_extra_count": max(0, len(results) - exact_name_count),
        "count": len(results),
        "truncated": len(items) >= 500,
        "results": results,
    }


def nickname_rank_task_snapshot(task_id: str) -> dict[str, Any] | None:
    with NICKNAME_RANK_TASK_LOCK:
        task = NICKNAME_RANK_TASKS.get(task_id)
        if not task:
            return None
        ranks = {
            subject: dict(item)
            for subject, item in (task.get("ranks") or {}).items()
        }
        return {
            "ok": True,
            "id": task_id,
            "status": task.get("status"),
            "total": task.get("total", 0),
            "completed": task.get("completed", 0),
            "error": task.get("error", ""),
            "ranks": ranks,
        }


def run_nickname_rank_task(task_id: str) -> None:
    try:
        with NICKNAME_RANK_TASK_LOCK:
            task = NICKNAME_RANK_TASKS.get(task_id)
            if not task:
                return
            subjects = list(task.get("subjects") or [])
        season_id = browser_current_season_id()
        if not season_id:
            raise RuntimeError("没有读取到当前赛季，请确认专用 WeGame Chrome 页面已加载")
        batch_size = 20
        for offset in range(0, len(subjects), batch_size):
            batch = subjects[offset : offset + batch_size]
            reports = browser_battle_reports(batch, season_id)
            with NICKNAME_RANK_TASK_LOCK:
                task = NICKNAME_RANK_TASKS.get(task_id)
                if not task:
                    return
                for subject in batch:
                    season = reports.get(subject) or {}
                    overview = (
                        season.get("overview")
                        if isinstance(season.get("overview"), dict)
                        else {}
                    )
                    tier = to_int(overview.get("itier_rank"))
                    task["ranks"][subject] = {
                        "status": "ok" if tier is not None else "unavailable",
                        "tier": tier,
                        "rank": rank_name(tier) if tier is not None else "暂未获取",
                    }
                task["completed"] = min(offset + len(batch), len(subjects))
        with NICKNAME_RANK_TASK_LOCK:
            task = NICKNAME_RANK_TASKS.get(task_id)
            if task:
                task["status"] = "completed"
                task["updated_at"] = int(time.time())
    except Exception as exc:
        with NICKNAME_RANK_TASK_LOCK:
            task = NICKNAME_RANK_TASKS.get(task_id)
            if task:
                task["status"] = "error"
                task["error"] = f"{type(exc).__name__}: {exc}"
                task["updated_at"] = int(time.time())


def start_nickname_rank_task(results: list[dict[str, Any]]) -> dict[str, Any]:
    subjects = list(dict.fromkeys(
        str(item.get("subject") or "").lower()
        for item in results
        if SUBJECT_RE.fullmatch(str(item.get("subject") or ""))
    ))
    task_id = uuid.uuid4().hex
    now = int(time.time())
    with NICKNAME_RANK_TASK_LOCK:
        # 只保留最近 8 个任务，防止管理页反复搜索后长期占用内存。
        old_ids = sorted(
            NICKNAME_RANK_TASKS,
            key=lambda key: NICKNAME_RANK_TASKS[key].get("created_at", 0),
        )
        for old_id in old_ids[:-7]:
            if NICKNAME_RANK_TASKS[old_id].get("status") != "running":
                NICKNAME_RANK_TASKS.pop(old_id, None)
        NICKNAME_RANK_TASKS[task_id] = {
            "id": task_id,
            "status": "running" if subjects else "completed",
            "subjects": subjects,
            "total": len(subjects),
            "completed": 0,
            "ranks": {
                subject: {"status": "pending", "tier": None, "rank": "查询中…", "last_game_time": ""}
                for subject in subjects
            },
            "error": "",
            "created_at": now,
            "updated_at": now,
        }
    if subjects:
        threading.Thread(
            target=run_nickname_rank_task,
            args=(task_id,),
            daemon=True,
            name=f"nickname-ranks-{task_id[:8]}",
        ).start()
    return nickname_rank_task_snapshot(task_id) or {
        "ok": False,
        "error": "段位任务创建失败",
    }


def page_rank_query(subjects: list[str]) -> dict[str, Any]:
    """仅查询指定 subjects 的段位和最近游戏时间。"""
    clean: list[str] = [
        s.lower() for s in subjects if SUBJECT_RE.fullmatch(s or "")
    ]
    if not clean:
        return {"ok": True, "ranks": {}}
    season_id = browser_current_season_id()
    if not season_id:
        return {"ok": False, "error": "没有读取到当前赛季，请确认专用 WeGame Chrome 页面已加载"}
    reports = browser_battle_reports(clean, season_id)
    try:
        last_matches = browser_get_last_matches(clean)
    except Exception:
        last_matches = {}
    ranks: dict[str, dict[str, Any]] = {}
    for subject in clean:
        season = reports.get(subject) or {}
        overview = (
            season.get("overview") if isinstance(season.get("overview"), dict) else {}
        )
        tier = to_int(overview.get("itier_rank"))
        ranks[subject] = {
            "status": "ok" if tier is not None else "unavailable",
            "tier": tier,
            "rank": rank_name(tier) if tier is not None else "暂未获取",
            "last_game_time": last_matches.get(subject) or "",
        }
    return {"ok": True, "ranks": ranks}


def resolve_alias_subject(query: str) -> dict[str, Any]:
    parts = split_name_tag(query)
    if not parts:
        return {"ok": False, "error": "请输入 昵称#ID 才能在线解析 subject"}
    game_name, tag_line = parts
    headers, self_subject, source = alias_lookup_headers()
    params = urllib.parse.urlencode({"gameName": game_name, "tagLine": tag_line})
    url = f"https://alpha1-rso.val.qq.com:3001/aliases/v1/aliases?{params}"
    req_headers = {
        "Authorization": headers["Authorization"],
        "Accept": "application/json",
        "User-Agent": headers.get("User-Agent", "RiotGamesApi/26.5.1.0 player-account (Windows;10;;Professional, x64) valorant/release-china-13.01-shipping-14-5026731"),
    }
    for key in ("X-Riot-ClientVersion", "X-Riot-ClientPlatform"):
        if headers.get(key):
            req_headers[key] = headers[key]
    req = urllib.request.Request(url, headers=req_headers, method="GET")
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read().decode("utf-8", errors="replace"))
    if not isinstance(data, list) or not data:
        return {"ok": False, "error": "aliases 接口没有返回玩家", "raw": data}

    lowered_game = game_name.lower()
    lowered_tag = tag_line.lower()
    selected = None
    for item in data:
        if not isinstance(item, dict):
            continue
        alias = item.get("alias") if isinstance(item.get("alias"), dict) else {}
        item_game = str(alias.get("game_name") or alias.get("gameName") or game_name)
        item_tag = str(alias.get("tag_line") or alias.get("tagLine") or tag_line)
        if item_game.lower() == lowered_game and item_tag.lower() == lowered_tag:
            selected = item
            break
    if selected is None:
        selected = next((item for item in data if isinstance(item, dict)), None)
    if not isinstance(selected, dict):
        return {"ok": False, "error": "aliases 响应格式不符合预期", "raw": data}

    subject = str(selected.get("puuid") or selected.get("subject") or "").lower()
    if not SUBJECT_RE.match(subject):
        return {"ok": False, "error": "aliases 响应没有 puuid/subject", "raw": data}
    alias = selected.get("alias") if isinstance(selected.get("alias"), dict) else {}
    display = f"{alias.get('game_name') or alias.get('gameName') or game_name}#{alias.get('tag_line') or alias.get('tagLine') or tag_line}"
    upsert_subject(display, subject, f"alias-api:{source or 'capture'}")
    return {
        "ok": True,
        "name": display,
        "subject": subject,
        "self_subject": self_subject,
        "source": source,
    }


def resolve_subject(query: str) -> tuple[str | None, str | None, str]:
    subject, display = lookup_subject(query)
    if subject:
        return subject, display, "cache"
    alias_result = resolve_alias_subject(query)
    if alias_result.get("ok"):
        return alias_result["subject"], alias_result.get("name") or query, "alias-api"
    raise RuntimeError(str(alias_result.get("error") or alias_result))


def list_subjects(limit: int = 80) -> list[dict[str, Any]]:
    with sqlite3.connect(DB_PATH) as db:
        rows = db.execute(
            "select display_name, subject, source, updated_at from subjects order by updated_at desc limit ?",
            (limit,),
        ).fetchall()
    return [
        {"name": row[0], "subject": row[1], "source": row[2], "updated_at": row[3]}
        for row in rows
    ]


def load_location_cache() -> dict[str, Any]:
    if not LOCATION_CACHE_PATH.exists():
        return {}
    try:
        data = json.loads(LOCATION_CACHE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def save_location_cache(data: dict[str, Any]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = LOCATION_CACHE_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(LOCATION_CACHE_PATH)


def fmt_short_ts(ts: Any) -> str:
    try:
        n = int(ts)
    except (TypeError, ValueError):
        return ""
    if n <= 0:
        return ""
    return time.strftime("%m-%d %H:%M", time.localtime(n))


def mobile_lookup_module() -> Any:
    if not MVAL_SCRIPT_DIR.exists():
        raise RuntimeError(f"IP属地数据源目录不存在：{MVAL_SCRIPT_DIR}")
    path_text = str(MVAL_SCRIPT_DIR)
    if path_text not in sys.path:
        sys.path.insert(0, path_text)
    return importlib.import_module("mobile_val_player_lookup")


def fetch_mobile_location(name: str) -> dict[str, Any]:
    mval = mobile_lookup_module()
    auth, auth_source = mval.resolve_auth(None, None)
    session = mval.session_from_auth(auth, None)
    selected_user = mval.search_user(session, name)
    target_uuid = selected_user.get("userId") or selected_user.get("uuid")
    if not target_uuid:
        raise RuntimeError("IP属地搜索结果缺少 userId")
    profile = mval.query_profile(session, auth["user_id"], str(target_uuid))
    location = str(profile.get("latestLocation") or "").strip()
    ip_update_ts = profile.get("ip_update_ts")
    nick = str(profile.get("nickName") or selected_user.get("userName") or name).strip()
    return {
        "ok": bool(location),
        "name": name,
        "matched_name": str(selected_user.get("userName") or name),
        "nick": nick,
        "uuid": str(profile.get("uuid") or target_uuid),
        "location": location or "未返回",
        "ip_update_ts": ip_update_ts,
        "auth_source": auth_source,
        "updated_at": int(time.time()),
    }


def player_location_info(name: Any, allow_query: bool = True) -> dict[str, Any]:
    display_name = str(name or "").strip()
    key = normalize_name(display_name)
    if not key or "#" not in display_name:
        return {"ok": False, "location": "缺少昵称", "error": "需要 昵称#ID 才能查询 IP属地"}

    now = int(time.time())
    with LOCATION_LOCK:
        cache = load_location_cache()
        cached = cache.get(key)
        if isinstance(cached, dict):
            ttl = LOCATION_CACHE_TTL if cached.get("ok") else LOCATION_ERROR_TTL
            if now - int(cached.get("updated_at") or 0) < ttl:
                return cached

    if not allow_query:
        return cached if isinstance(cached, dict) else {"ok": False, "location": "未缓存"}

    try:
        info = fetch_mobile_location(display_name)
    except Exception as exc:
        info = {
            "ok": False,
            "name": display_name,
            "location": "未获取",
            "error": f"{type(exc).__name__}: {exc}",
            "updated_at": now,
        }

    with LOCATION_LOCK:
        cache = load_location_cache()
        cache[key] = info
        save_location_cache(cache)
    return info


def location_text(info: dict[str, Any]) -> str:
    location = str(info.get("location") or "未获取")
    if info.get("ok") and info.get("ip_update_ts"):
        update = fmt_short_ts(info.get("ip_update_ts"))
        if update:
            return f"{location} / {update}"
    if not info.get("ok") and info.get("error"):
        return f"{location}"
    return location


def body_json(record: dict[str, Any], side: str) -> Any:
    body = ((record.get(side) or {}).get("body") or {})
    if isinstance(body, dict):
        return body.get("json")
    return None


def import_subjects_from_json(data: Any, source: str) -> int:
    count = 0
    if isinstance(data, dict):
        for key in ("current_match_players", "players"):
            rows = data.get(key)
            if isinstance(rows, list):
                for item in rows:
                    if not isinstance(item, dict):
                        continue
                    name = item.get("name") or item.get("name_service") or item.get("nickname")
                    subject = item.get("subject") or item.get("Subject")
                    if upsert_subject(str(name or ""), str(subject or ""), source):
                        count += 1
        role = data.get("role_info")
        if isinstance(role, dict):
            if upsert_subject(str(role.get("name") or ""), str(role.get("subject") or ""), source):
                count += 1

    if isinstance(data, list):
        for item in data:
            if not isinstance(item, dict):
                continue
            if item.get("Subject") and item.get("GameName"):
                full = f"{item.get('GameName')}#{item.get('TagLine')}" if item.get("TagLine") else str(item.get("GameName"))
                if upsert_subject(full, str(item.get("Subject")), source):
                    count += 1
            else:
                name = item.get("name") or item.get("nickname") or item.get("user_name")
                subject = item.get("subject") or item.get("role_id")
                if upsert_subject(str(name or ""), str(subject or ""), source):
                    count += 1
    return count


def import_file(path: Path) -> int:
    if not path.exists():
        return 0
    count = 0
    if path.suffix.lower() == ".jsonl":
        with path.open("r", encoding="utf-8") as stream:
            for line in stream:
                if not line.strip():
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                endpoint = record.get("endpoint") or ""
                resp = body_json(record, "response")
                if endpoint.endswith("name-service/v2/players") and isinstance(resp, list):
                    count += import_subjects_from_json(resp, str(path.name))
                elif isinstance(resp, dict):
                    count += import_subjects_from_json(resp, str(path.name))
    else:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return 0
        count += import_subjects_from_json(data, str(path.name))
    return count


def find_chrome() -> str:
    candidates = [
        os.environ.get("CHROME_PATH", ""),
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        str(Path.home() / r"AppData\Local\Google\Chrome\Application\chrome.exe"),
    ]
    for item in candidates:
        if item and Path(item).exists():
            return item
    raise RuntimeError("没有找到 chrome.exe")


def activate_target(target_id: str) -> None:
    get_json_url(f"http://127.0.0.1:{CHROME_PORT}/json/activate/{urllib.parse.quote(target_id, safe='')}")


def check_chrome_login() -> str:
    """检查专用 Chrome 登录态是否有效。返回状态描述字符串。"""
    try:
        target = ensure_dedicated_chrome_target()
        target_id = str(target.get("id", ""))
        if not target_id:
            return "专用 Chrome 运行中但未检测到 WeGame 助手页。"

        try:
            client = CDPClient(target.get("webSocketDebuggerUrl", ""))
            result = client.call("Runtime.evaluate", {
                "expression": """
(function() {
    var bodyText = document.body ? document.body.innerText : '';
    var hasLoginBtn = document.querySelector('a[href*="login"], button[class*="login"], .login-btn') !== null;
    var userName = document.querySelector('.user-name, .nick-name, [class*="user-info"] .name');
    var hasLogout = document.querySelector('a[href*="logout"], [class*="logout"]') !== null;
    var title = document.title || '';
    return JSON.stringify({
        hasLoginBtn: hasLoginBtn,
        hasLogout: hasLogout,
        userName: userName ? userName.textContent.trim() : '',
        title: title,
        bodyPreview: bodyText.substring(0, 300)
    });
""",
                "returnByValue": True,
            })
            client.ws.close()
            login_info = json.loads(result.get("result", {}).get("value", "{}"))
            if login_info.get("userName") or login_info.get("hasLogout"):
                return f"登录态有效，用户：{login_info.get('userName', '已登录')}"
            if login_info.get("hasLoginBtn"):
                return "检测到登录按钮，请在 Chrome 中完成登录。"
            return f"页面正常但无法确认登录状态：{login_info.get('title', '')}"
        except Exception:
            return f"专用 Chrome 助手页已打开（ID: {target_id}），请手动确认登录状态。"
    except RuntimeError as e:
        return f"登录态无效：{e}"
    except Exception as e:
        return f"检查登录态失败：{e}"


def launch_chrome() -> str:
    try:
        target = ensure_dedicated_chrome_target()
        if target.get("id"):
            try:
                activate_target(str(target["id"]))
            except Exception:
                pass
            status = check_chrome_login()
            return f"已复用现有专用 Chrome。{status}"
    except Exception:
        pass

    CHROME_PROFILE.mkdir(parents=True, exist_ok=True)
    chrome = find_chrome()
    args = [
        chrome,
        f"--remote-debugging-port={CHROME_PORT}",
        "--remote-allow-origins=*",
        f"--user-data-dir={CHROME_PROFILE}",
        "--no-first-run",
        "--disable-features=Translate",
        "--disable-popup-blocking",
        "--new-window",
        HELPER_URL,
    ]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(3)
    status = check_chrome_login()
    return f"已启动新的专用 Chrome。{status}"


def get_json_url(url: str, timeout: int = 3) -> Any:
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def chrome_targets() -> list[dict[str, Any]]:
    return get_json_url(f"http://127.0.0.1:{CHROME_PORT}/json")


def find_helper_target(targets: list[dict[str, Any]]) -> dict[str, Any] | None:
    for target in targets:
        if target.get("type") == "page" and "wegame.com.cn/helper/valorant" in (target.get("url") or ""):
            return target
    return None


def ensure_dedicated_chrome_target() -> dict[str, Any]:
    """只在专用 Chrome 端口上查找或创建助手页，不回退到 WeGame 客户端。"""
    try:
        targets = chrome_targets()
    except Exception as exc:
        raise RuntimeError(f"专用 Chrome :{CHROME_PORT} 不可用") from exc

    target = find_helper_target(targets)
    if target:
        return target

    try:
        url = urllib.parse.quote(HELPER_URL, safe="")
        get_json_url(f"http://127.0.0.1:{CHROME_PORT}/json/new?{url}")
        time.sleep(1)
        target = find_helper_target(chrome_targets())
        if target:
            return target
    except Exception as exc:
        raise RuntimeError(f"无法在专用 Chrome :{CHROME_PORT} 打开 WeGame 助手页") from exc

    raise RuntimeError(f"专用 Chrome :{CHROME_PORT} 没有可用的 WeGame 助手页")


def ensure_wegame_target() -> dict[str, Any]:
    """优先使用专用 Chrome（登录态可控），不可用时尝试 WeGame 客户端 CDP。"""
    try:
        return ensure_dedicated_chrome_target()
    except Exception:
        pass

    # 回退 WeGame 客户端 CDP
    try:
        wg_targets = get_json_url(f"http://127.0.0.1:{WEGAME_CDP_PORT}/json")
        target = find_helper_target(wg_targets)
        if target:
            return target
        url = urllib.parse.quote(HELPER_URL, safe="")
        get_json_url(f"http://127.0.0.1:{WEGAME_CDP_PORT}/json/new?{url}")
        time.sleep(1)
        target = find_helper_target(get_json_url(f"http://127.0.0.1:{WEGAME_CDP_PORT}/json"))
        if target:
            return target
    except Exception:
        pass

    raise RuntimeError("没有可用的 CDP 源。请通过 /launch-chrome 启动专用 Chrome 并登录 WeGame，或确保 WeGame 客户端已打开无畏契约助手页")


class CDPClient:
    def __init__(self, ws_url: str):
        self.ws = websocket.create_connection(ws_url, timeout=20)
        self.next_id = 1
        self.lock = threading.Lock()

    def call(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        with self.lock:
            msg_id = self.next_id
            self.next_id += 1
            self.ws.send(json.dumps({"id": msg_id, "method": method, "params": params or {}}))
            while True:
                msg = json.loads(self.ws.recv())
                if msg.get("id") == msg_id:
                    if "error" in msg:
                        raise RuntimeError(msg["error"])
                    return msg.get("result") or {}

    def close(self) -> None:
        self.ws.close()


# ---------- WeGame 登录态保活（逆向发现：导航到首页自动刷新 token） ----------

WEGAME_HEARTBEAT_INTERVAL = 30 * 60  # 健康时每 30 分钟刷新
WEGAME_RECOVERY_INTERVAL = 30  # Chrome/登录态异常时每 30 秒重试
WEGAME_LOGIN_EXPIRED_CODE = 8025004
_wegame_keep_alive_running = False
_wegame_keep_alive_ok = False
_wegame_keep_alive_lock = threading.Lock()
_wegame_cdp_operation_lock = threading.RLock()


def _refresh_token_via_home(client: "CDPClient") -> bool:
    """通过导航到 WeGame 首页来刷新 pt4_token（逆向发现的关键机制）。"""
    try:
        client.call("Page.enable", {})
        # 导航到首页触发 token 刷新
        client.call("Page.navigate", {"url": "https://www.wegame.com.cn/home/"})
        time.sleep(8)
        # 导航回助手页
        client.call("Page.navigate", {"url": HELPER_URL})
        time.sleep(5)
        return True
    except Exception as exc:
        print(f"[wegame-keepalive] token 刷新失败: {exc}", file=sys.stderr)
        return False


def _wegame_session_valid(client: "CDPClient") -> bool:
    """检查 WeGame 登录态是否仍然有效。"""
    try:
        result = client.call(
            "Runtime.evaluate",
            {
                "expression": """
                (async () => {
                  try {
                    const res = await fetch('/api/v1/wegame.pallas.game.ValBattle/GetBattleList', {
                      method: 'POST',
                      credentials: 'include',
                      headers: {
                        'content-type': 'application/json',
                        'trpc-caller': 'wegame.pallas.web.Valorant'
                      },
                      body: JSON.stringify({"from_src": "valorant_web", "size": 1, "subject": "01b6550e-e5b4-5068-9a90-21e26aaccd1a", "queueID": "competitive"})
                    });
                    const data = await res.json();
                    const code = data && data.result ? data.result.error_code : -1;
                    return { code: code, ok: code === 0 };
                  } catch(e) {
                    return { ok: false, code: -1, error: e.message };
                  }
                })()
                """,
                "awaitPromise": True,
                "returnByValue": True,
                "timeout": 15000,
            },
        )
        ok = bool((result.get("result") or {}).get("value", {}).get("ok"))
        print(f"[wegame-keepalive] session check: ok={ok}", file=sys.stderr)
        return ok
    except Exception as exc:
        print(f"[wegame-keepalive] session check failed: {exc}", file=sys.stderr)
        return False


def _wegame_keep_alive_loop() -> None:
    """后台线程：定期通过导航到首页刷新 token，保持登录态。"""
    global _wegame_keep_alive_running, _wegame_keep_alive_ok
    _wegame_keep_alive_running = True
    print(
        f"[wegame-keepalive] 保活线程已启动（健康 {WEGAME_HEARTBEAT_INTERVAL}s / 异常 {WEGAME_RECOVERY_INTERVAL}s）",
        file=sys.stderr,
    )

    while _wegame_keep_alive_running:
        with _wegame_keep_alive_lock:
            current_ok = _wegame_keep_alive_ok
        time.sleep(WEGAME_HEARTBEAT_INTERVAL if current_ok else WEGAME_RECOVERY_INTERVAL)
        if not _wegame_keep_alive_running:
            break

        client = None
        try:
            with _wegame_cdp_operation_lock:
                target = ensure_wegame_target()
                client = CDPClient(target["webSocketDebuggerUrl"])

                # 刷新 token（导航到首页 → 回助手页）
                print("[wegame-keepalive] 刷新 pt4_token...", file=sys.stderr)
                _refresh_token_via_home(client)

                # 验证是否成功
                ok = _wegame_session_valid(client)
            with _wegame_keep_alive_lock:
                _wegame_keep_alive_ok = ok
            if ok:
                print("[wegame-keepalive] token 刷新成功，登录态正常", file=sys.stderr)
            else:
                print("[wegame-keepalive] token 刷新后仍无效，请在专用 Chrome 中重新登录 WeGame", file=sys.stderr)
        except Exception as exc:
            print(f"[wegame-keepalive] 异常: {exc}", file=sys.stderr)
            with _wegame_keep_alive_lock:
                _wegame_keep_alive_ok = False
        finally:
            if client:
                try:
                    client.close()
                except Exception:
                    pass


def start_wegame_keep_alive() -> None:
    """启动 WeGame 登录态保活后台线程，并立即执行首次检查。"""
    global _wegame_keep_alive_ok
    with _wegame_keep_alive_lock:
        # 服务刚启动时必须先验证，不能用乐观初值让恢复线程先睡 30 分钟。
        _wegame_keep_alive_ok = False
    t = threading.Thread(target=_wegame_keep_alive_loop, daemon=True, name="wegame-keepalive")
    t.start()
    # 立即执行一次检查，不等第一个间隔
    t2 = threading.Thread(target=_do_initial_health_check, daemon=True, name="wegame-init-check")
    t2.start()


def _do_initial_health_check() -> None:
    """启动后立即刷新 token 并检查登录态。"""
    global _wegame_keep_alive_ok
    time.sleep(3)
    try:
        with _wegame_cdp_operation_lock:
            target = ensure_wegame_target()
            client = CDPClient(target["webSocketDebuggerUrl"])
            try:
                # 先刷新 token
                _refresh_token_via_home(client)
                # 再验证
                ok = _wegame_session_valid(client)
                with _wegame_keep_alive_lock:
                    _wegame_keep_alive_ok = ok
                if ok:
                    print("[wegame-keepalive] 初始检查: token 刷新成功，登录态正常", file=sys.stderr)
                else:
                    print("[wegame-keepalive] 初始检查: token 刷新后仍无效，请在专用 Chrome 中重新登录 WeGame", file=sys.stderr)
            finally:
                client.close()
    except Exception as exc:
        print(f"[wegame-keepalive] 初始检查失败: {exc}", file=sys.stderr)
        with _wegame_keep_alive_lock:
            _wegame_keep_alive_ok = False


def wegame_session_healthy() -> bool:
    """查询当前 WeGame 登录态是否健康。"""
    with _wegame_keep_alive_lock:
        return _wegame_keep_alive_ok


def browser_context_query(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    with _wegame_cdp_operation_lock:
        target = ensure_wegame_target()
        client = CDPClient(target["webSocketDebuggerUrl"])
        try:
            expression = f"""
            (async () => {{
              const res = await fetch({json.dumps(path)}, {{
                method: 'POST',
                credentials: 'include',
                headers: {{
                  'content-type': 'application/json',
                  'trpc-caller': 'wegame.pallas.web.Valorant'
                }},
                body: JSON.stringify({json.dumps(payload, ensure_ascii=False)})
              }});
              const data = await res.json();
              return {{ http: res.status, data }};
            }})()
            """
            result = client.call(
                "Runtime.evaluate",
                {
                    "expression": expression,
                    "awaitPromise": True,
                    "returnByValue": True,
                    "timeout": 30000,
                },
            )
            if result.get("exceptionDetails"):
                raise RuntimeError(result["exceptionDetails"])
            value = ((result.get("result") or {}).get("value") or {})
            return value.get("data") or {}
        finally:
            client.close()


def direct_api_query(subject: str, size: int = 10) -> dict[str, Any]:
    if curl_requests is None:
        return {"result": {"error_code": -1, "error_message": "curl_cffi not installed"}}
    headers = {
        "content-type": "application/json",
        "accept": "*/*",
        "origin": BASE_URL,
        "referer": f"{BASE_URL}/helper/valorant/ai-strategy?subject={subject}",
        "trpc-caller": "wegame.pallas.web.Valorant",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
    }
    payload = {"from_src": "valorant_web", "size": size, "subject": subject, "queueID": "competitive"}
    try:
        resp = curl_requests.post(
            f"{BASE_URL}/api/v1/wegame.pallas.game.ValBattle/GetBattleList",
            headers=headers,
            json=payload,
            impersonate="chrome136",
            timeout=15,
        )
        return resp.json()
    except Exception as exc:
        return {"result": {"error_code": -2, "error_message": f"{type(exc).__name__}: {exc}"}}


def direct_api_query_all(subject: str, size: int = 20) -> dict[str, Any]:
    """直接 API 查询，不限制 queueID，用于兜底获取所有模式战绩"""
    if curl_requests is None:
        return {"result": {"error_code": -1, "error_message": "curl_cffi not installed"}}
    headers = {
        "content-type": "application/json",
        "accept": "*/*",
        "origin": BASE_URL,
        "referer": f"{BASE_URL}/helper/valorant/ai-strategy?subject={subject}",
        "trpc-caller": "wegame.pallas.web.Valorant",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
    }
    payload = {"from_src": "valorant_web", "size": size, "subject": subject}
    try:
        resp = curl_requests.post(
            f"{BASE_URL}/api/v1/wegame.pallas.game.ValBattle/GetBattleList",
            headers=headers,
            json=payload,
            impersonate="chrome136",
            timeout=15,
        )
        return resp.json()
    except Exception as exc:
        return {"result": {"error_code": -2, "error_message": f"{type(exc).__name__}: {exc}"}}


def browser_api_query(subject: str, size: int = 10) -> dict[str, Any]:
    payload = {"from_src": "valorant_web", "size": size, "subject": subject}
    return browser_context_query("/api/v1/wegame.pallas.game.ValBattle/GetBattleList", payload)


def browser_competitive_query(subject: str, size: int = 10) -> dict[str, Any]:
    payload = {
        "from_src": "valorant_web",
        "size": size,
        "subject": subject,
        "queueID": "competitive",
    }
    return browser_context_query("/api/v1/wegame.pallas.game.ValBattle/GetBattleList", payload)


def browser_battle_detail(ap_event_id: str, subject: str) -> dict[str, Any]:
    payload = {"apEventId": ap_event_id, "from_src": "valorant_web", "subject": subject}
    return browser_context_query("/api/v1/wegame.pallas.game.ValBattle/GetBattleDetail", payload)


def browser_role_infos(subjects: list[str]) -> dict[str, dict[str, Any]]:
    clean_subjects = list(dict.fromkeys(
        subject.lower()
        for subject in subjects
        if SUBJECT_RE.fullmatch(subject or "")
    ))
    if not clean_subjects:
        return {}
    with _wegame_cdp_operation_lock:
        target = ensure_wegame_target()
        client = CDPClient(target["webSocketDebuggerUrl"])
        try:
            expression = f"""
            (async () => {{
              const subjects = {json.dumps(clean_subjects)};
              const rows = await Promise.all(subjects.map(async subject => {{
                try {{
                  const res = await fetch('/api/v1/wegame.pallas.game.ValBattle/GetRoleInfo', {{
                    method: 'POST',
                    credentials: 'include',
                    headers: {{
                      'content-type': 'application/json',
                      'trpc-caller': 'wegame.pallas.web.Valorant'
                    }},
                    body: JSON.stringify({{from_src: 'valorant_web', subject}})
                  }});
                  const data = await res.json();
                  return [subject, data && data.role_info ? data.role_info : null];
                }} catch (error) {{
                  return [subject, null];
                }}
              }}));
              return Object.fromEntries(rows);
            }})()
            """
            result = client.call(
                "Runtime.evaluate",
                {
                    "expression": expression,
                    "awaitPromise": True,
                    "returnByValue": True,
                    "timeout": 30000,
                },
            )
            if result.get("exceptionDetails"):
                raise RuntimeError(result["exceptionDetails"])
            value = ((result.get("result") or {}).get("value") or {})
            return {
                str(key).lower(): item
                for key, item in value.items()
                if isinstance(item, dict)
            }
        finally:
            client.close()


def browser_current_season_id() -> str:
    with _wegame_cdp_operation_lock:
        target = ensure_wegame_target()
        client = CDPClient(target["webSocketDebuggerUrl"])
        try:
            result = client.call(
                "Runtime.evaluate",
                {
                    "expression": """
                    (() => {
                      const pinia = document.querySelector('#app')?.__vue_app__?.config?.globalProperties?.$pinia;
                      const seasons = pinia?.state?.value?.wiki?.seasons || [];
                      return seasons.find(item => item && item.current)?.id || '';
                    })()
                    """,
                    "returnByValue": True,
                },
            )
            return str(((result.get("result") or {}).get("value") or "")).strip()
        finally:
            client.close()


def browser_battle_reports(subjects: list[str], season_id: str) -> dict[str, dict[str, Any]]:
    clean_subjects = list(dict.fromkeys(
        subject.lower()
        for subject in subjects
        if SUBJECT_RE.fullmatch(subject or "")
    ))
    if not clean_subjects or not season_id:
        return {}
    with _wegame_cdp_operation_lock:
        target = ensure_wegame_target()
        client = CDPClient(target["webSocketDebuggerUrl"])
        try:
            expression = f"""
            (async () => {{
              const subjects = {json.dumps(clean_subjects)};
              const seasonId = {json.dumps(season_id)};
              const rows = await Promise.all(subjects.map(async subject => {{
                try {{
                  const res = await fetch('/api/v1/wegame.pallas.game.ValBattle/GetBattleReport', {{
                    method: 'POST',
                    credentials: 'include',
                    headers: {{
                      'content-type': 'application/json',
                      'trpc-caller': 'wegame.pallas.web.Valorant'
                    }},
                    body: JSON.stringify({{
                      from_src: 'valorant_web',
                      queueID: '255',
                      sid: seasonId,
                      subject
                    }})
                  }});
                  const data = await res.json();
                  return [subject, data && data.season ? data.season : null];
                }} catch (error) {{
                  return [subject, null];
                }}
              }}));
              return Object.fromEntries(rows);
            }})()
            """
            result = client.call(
                "Runtime.evaluate",
                {
                    "expression": expression,
                    "awaitPromise": True,
                    "returnByValue": True,
                    "timeout": 30000,
                },
            )
            if result.get("exceptionDetails"):
                raise RuntimeError(result["exceptionDetails"])
            value = ((result.get("result") or {}).get("value") or {})
            return {
                str(key).lower(): item
                for key, item in value.items()
                if isinstance(item, dict)
            }
        finally:
            client.close()


def browser_get_last_matches(subjects: list[str]) -> dict[str, str | None]:
    """获取每个 subject 最近一场排位的时间 (dtEventTime)。"""
    clean_subjects = list(dict.fromkeys(
        subject.lower()
        for subject in subjects
        if SUBJECT_RE.fullmatch(subject or "")
    ))
    if not clean_subjects:
        return {}
    with _wegame_cdp_operation_lock:
        target = ensure_wegame_target()
        client = CDPClient(target["webSocketDebuggerUrl"])
        try:
            expression = f"""
            (async () => {{
              const subjects = {json.dumps(clean_subjects)};
              const rows = await Promise.all(subjects.map(async subject => {{
                try {{
                  const res = await fetch('/api/v1/wegame.pallas.game.ValBattle/GetBattleList', {{
                    method: 'POST',
                    credentials: 'include',
                    headers: {{
                      'content-type': 'application/json',
                      'trpc-caller': 'wegame.pallas.web.Valorant'
                    }},
                    body: JSON.stringify({{
                      from_src: 'valorant_web',
                      queueID: 'competitive',
                      size: 1,
                      subject
                    }})
                  }});
                  const data = await res.json();
                  const battles = data && data.battles ? data.battles : [];
                  const last = battles.length > 0 ? battles[0] : null;
                  return [subject, last ? last.dtEventTime || null : null];
                }} catch (error) {{
                  return [subject, null];
                }}
              }}));
              return Object.fromEntries(rows);
            }})()
            """
            result = client.call(
                "Runtime.evaluate",
                {
                    "expression": expression,
                    "awaitPromise": True,
                    "returnByValue": True,
                    "timeout": 30000,
                },
            )
            if result.get("exceptionDetails"):
                raise RuntimeError(result["exceptionDetails"])
            value = ((result.get("result") or {}).get("value") or {})
            return {
                str(key).lower(): val
                for key, val in value.items()
            }
        finally:
            client.close()


def merge_player_season_report(player: dict[str, Any], season: dict[str, Any] | None) -> dict[str, Any]:
    merged = dict(player)
    if not isinstance(season, dict):
        return merged
    overview = season.get("overview") if isinstance(season.get("overview"), dict) else {}
    stats = season.get("stats") if isinstance(season.get("stats"), dict) else {}
    values = {
        "game_num": stats.get("gamenum"),
        "win_rate": overview.get("win_rate", stats.get("winrate")),
        "kda": overview.get("kda", stats.get("statsKda")),
        "head_shot_rate": overview.get("head_shot_rate"),
        "headshots": overview.get("headshots"),
        "body_shot_rate": overview.get("body_shot_rate"),
        "bodyshots": overview.get("bodyshots"),
        "leg_shot_rate": overview.get("leg_shot_rate"),
        "legshots": overview.get("legshots"),
        "score_avg": stats.get("scoreAvg"),
        "itier_rank": overview.get("itier_rank"),
    }
    for key, value in values.items():
        if value is not None:
            merged[key] = value
    return merged


def browser_matchup_detail(
    ap_event_id: str,
    subject: str,
    known_battle: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = {"apEventId": ap_event_id, "from_src": "valorant_web", "subject": subject}
    matchup = browser_context_query("/api/v1/wegame.pallas.game.ValBattle/GetMatchup", payload)
    result = matchup.get("result") if isinstance(matchup, dict) else None
    code = result.get("error_code") if isinstance(result, dict) else result
    roster = matchup.get("players") if isinstance(matchup, dict) else None
    if code not in (0, None) or not isinstance(roster, list):
        return matchup if isinstance(matchup, dict) else {}

    # 直接查 size=50，覆盖大部分玩家的近期战绩；未命中说明对局太久远，无需重试
    INTER_PLAYER_DELAY = 1.0  # 玩家间延迟

    players: list[dict[str, Any]] = []
    resolved_count = 0
    for roster_player in roster[:12]:
        player_subject = str(roster_player.get("subject") or "").strip().lower()
        if not SUBJECT_RE.fullmatch(player_subject):
            continue
        matched: dict[str, Any] | None = None
        if (
            player_subject == subject.lower()
            and isinstance(known_battle, dict)
            and str(known_battle.get("apEventId") or "") == ap_event_id
        ):
            matched = known_battle
        else:
            battle_list = browser_api_query(player_subject, 50)
            battles = battle_list.get("battles") if isinstance(battle_list, dict) else None
            if isinstance(battles, list):
                matched = next(
                    (battle for battle in battles if str(battle.get("apEventId") or "") == ap_event_id),
                    None,
                )
            time.sleep(INTER_PLAYER_DELAY)

        if matched:
            resolved_count += 1
        player = dict(matched or {})
        player["subject"] = player_subject
        player["teamId"] = roster_player.get("teamId") or player.get("teamId")
        player["characterId"] = roster_player.get("characterId") or player.get("characterId")
        player["name"] = player.get("name") or display_for_subject(player_subject)
        players.append(player)

    # 用 GetRoleInfo 补齐缺失的玩家名
    missing_subjects = [
        str(player.get("subject") or "")
        for player in players
        if not player.get("name")
    ]
    if missing_subjects:
        role_infos = browser_role_infos(missing_subjects)
        for player in players:
            if player.get("name"):
                continue
            player_subject = str(player.get("subject") or "").lower()
            role = role_infos.get(player_subject) or {}
            name = str(role.get("name") or "").strip()
            if name:
                player["name"] = name
                upsert_subject(name, player_subject, "wegame-role-info")

    detail = dict(known_battle) if isinstance(known_battle, dict) else {}
    detail["players"] = players
    detail["player_count"] = len(players)
    detail["resolved_count"] = resolved_count
    return {
        "result": {"error_code": 0, "error_message": "success"},
        "battle_detail": detail,
        "detail_source": f"matchup+battle-lists (resolved={resolved_count}/{len(players)})",
    }
























def query_battles(subject: str, size: int = 10) -> tuple[str, dict[str, Any]]:
    api_data = direct_api_query(subject, size)
    result = api_data.get("result") if isinstance(api_data, dict) else None
    code = result.get("error_code") if isinstance(result, dict) else result
    if code == 0 and isinstance(api_data.get("battles"), list):
        return "direct-api", api_data

    return "browser-context-competitive", browser_competitive_query(subject, size)


def game_match_headshot_stats(match_id: str) -> dict[str, dict[str, Any]]:
    normalized_match_id = str(match_id or "").strip().lower()
    if not SUBJECT_RE.fullmatch(normalized_match_id):
        return {}
    now = time.time()
    with MATCH_HEADSHOT_CACHE_LOCK:
        cached = MATCH_HEADSHOT_CACHE.get(normalized_match_id)
        if cached and float(cached.get("expires_at") or 0) > now:
            players = cached.get("players")
            return dict(players) if isinstance(players, dict) else {}

    import current_match_probe as probe_mod

    headers, _, _ = probe_mod.extract_latest_game_headers(probe_mod.latest_capture_files()[:12])
    if not headers:
        return {}
    status, data = probe_mod.http_json(
        "GET",
        f"https://{probe_mod.NAME_HOST}/match-details/v1/matches/{normalized_match_id}",
        headers,
    )
    if status != 200 or not isinstance(data, dict):
        return {}

    totals: dict[str, dict[str, int]] = {}
    rounds = data.get("roundResults") if isinstance(data.get("roundResults"), list) else []
    for round_result in rounds:
        player_stats = round_result.get("playerStats") if isinstance(round_result, dict) else None
        if not isinstance(player_stats, list):
            continue
        for player_stat in player_stats:
            if not isinstance(player_stat, dict):
                continue
            player_subject = str(player_stat.get("subject") or "").strip().lower()
            if not SUBJECT_RE.fullmatch(player_subject):
                continue
            counter = totals.setdefault(player_subject, {"headshots": 0, "bodyshots": 0, "legshots": 0})
            damage_rows = player_stat.get("damage") if isinstance(player_stat.get("damage"), list) else []
            for damage in damage_rows:
                if not isinstance(damage, dict):
                    continue
                counter["headshots"] += to_int(damage.get("headshots"), 0) or 0
                counter["bodyshots"] += to_int(damage.get("bodyshots"), 0) or 0
                counter["legshots"] += to_int(damage.get("legshots"), 0) or 0

    output: dict[str, dict[str, Any]] = {}
    for player_subject, counter in totals.items():
        total_hits = counter["headshots"] + counter["bodyshots"] + counter["legshots"]
        output[player_subject] = {
            **counter,
            "total_hits": total_hits,
            "head_shot_rate": counter["headshots"] / total_hits if total_hits else None,
        }

    with MATCH_HEADSHOT_CACHE_LOCK:
        expired = [
            key
            for key, value in MATCH_HEADSHOT_CACHE.items()
            if float(value.get("expires_at") or 0) <= now
        ]
        for key in expired:
            MATCH_HEADSHOT_CACHE.pop(key, None)
        while len(MATCH_HEADSHOT_CACHE) >= MATCH_HEADSHOT_CACHE_LIMIT:
            oldest = min(
                MATCH_HEADSHOT_CACHE,
                key=lambda key: float(MATCH_HEADSHOT_CACHE[key].get("created_at") or 0),
            )
            MATCH_HEADSHOT_CACHE.pop(oldest, None)
        MATCH_HEADSHOT_CACHE[normalized_match_id] = {
            "players": output,
            "created_at": now,
            "expires_at": now + MATCH_HEADSHOT_CACHE_TTL,
        }
    return output


def enrich_battle_detail_headshots(
    detail: dict[str, Any],
    battle: dict[str, Any],
) -> dict[str, Any]:
    players = detail.get("players") if isinstance(detail.get("players"), list) else None
    if not isinstance(players, list):
        return detail
    try:
        headshot_stats = game_match_headshot_stats(str(battle.get("matchId") or ""))
    except Exception:
        headshot_stats = {}
    if not headshot_stats:
        return detail
    enriched_players = []
    for player in players:
        enriched = dict(player)
        player_subject = str(enriched.get("subject") or "").lower()
        match_stats = headshot_stats.get(player_subject)
        if isinstance(match_stats, dict):
            enriched["match_head_shot_rate"] = match_stats.get("head_shot_rate")
            enriched["match_headshots"] = match_stats.get("headshots")
            enriched["match_bodyshots"] = match_stats.get("bodyshots")
            enriched["match_legshots"] = match_stats.get("legshots")
            enriched["match_total_hits"] = match_stats.get("total_hits")
        enriched_players.append(enriched)
    return {**detail, "players": enriched_players}


def load_cached_battle_details() -> dict[str, Any]:
    for path in (APP_DIR / BATTLE_DETAIL_CACHE.name, BATTLE_DETAIL_CACHE):
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        details = data.get("battle_details") if isinstance(data, dict) else None
        if isinstance(details, dict):
            return details
    return {}


def teammates_html(subject: str, battle: dict[str, Any], battle_details: dict[str, Any] | None = None) -> str:
    detail = (battle_details or {}).get(battle.get("apEventId"))
    if not detail:
        return '<span class="muted">未抓到单局详情</span>'

    players = detail.get("players") if isinstance(detail, dict) else None
    if not isinstance(players, list):
        return '<span class="muted">详情无玩家列表</span>'

    target = next((item for item in players if item.get("subject") == subject), None)
    if not target:
        return '<span class="muted">详情里未匹配到该玩家</span>'

    team_id = target.get("teamId") or battle.get("teamId")
    teammates = [
        item for item in players
        if item.get("teamId") == team_id and item.get("subject") != subject
    ]
    if not teammates:
        return '<span class="muted">无队友数据</span>'

    parts = []
    for item in teammates:
        name = item.get("name") or item.get("subject")
        hero = agent_name(item.get("characterId"))
        kda = detail_kda_text(item)
        kda_part = f"，KDA {kda}" if kda else ""
        parts.append(f'<span class="mate">{esc(name)}<small>{esc(hero)}{esc(kda_part)}</small></span>')
    return "".join(parts)


def issue_public_battle_detail_ref(subject: str, battle: dict[str, Any]) -> str:
    ap_event_id = str(battle.get("apEventId") or "").strip()
    if not SUBJECT_RE.fullmatch(subject or "") or not ap_event_id:
        return ""

    now = time.time()
    detail_ref = secrets.token_urlsafe(24)
    with PUBLIC_BATTLE_DETAIL_REF_LOCK:
        expired = [
            key
            for key, value in PUBLIC_BATTLE_DETAIL_REFS.items()
            if float(value.get("expires_at") or 0) <= now
        ]
        for key in expired:
            PUBLIC_BATTLE_DETAIL_REFS.pop(key, None)
        while len(PUBLIC_BATTLE_DETAIL_REFS) >= PUBLIC_BATTLE_DETAIL_REF_LIMIT:
            oldest = min(
                PUBLIC_BATTLE_DETAIL_REFS,
                key=lambda key: float(PUBLIC_BATTLE_DETAIL_REFS[key].get("created_at") or 0),
            )
            PUBLIC_BATTLE_DETAIL_REFS.pop(oldest, None)
        PUBLIC_BATTLE_DETAIL_REFS[detail_ref] = {
            "subject": subject,
            "ap_event_id": ap_event_id,
            "battle": dict(battle),
            "created_at": now,
            "expires_at": now + PUBLIC_BATTLE_DETAIL_REF_TTL,
        }
    return detail_ref


def resolve_public_battle_detail_ref(detail_ref: str) -> dict[str, Any] | None:
    if not re.fullmatch(r"[A-Za-z0-9_-]{24,64}", detail_ref or ""):
        return None
    now = time.time()
    with PUBLIC_BATTLE_DETAIL_REF_LOCK:
        item = PUBLIC_BATTLE_DETAIL_REFS.get(detail_ref)
        if not item:
            return None
        if float(item.get("expires_at") or 0) <= now:
            PUBLIC_BATTLE_DETAIL_REFS.pop(detail_ref, None)
            return None
        return dict(item)


def cache_public_battle_detail_ref(detail_ref: str, detail: dict[str, Any]) -> None:
    with PUBLIC_BATTLE_DETAIL_REF_LOCK:
        item = PUBLIC_BATTLE_DETAIL_REFS.get(detail_ref)
        if item and float(item.get("expires_at") or 0) > time.time():
            item["detail"] = detail


def battle_rows(
    battles: list[dict[str, Any]],
    subject: str = "",
    battle_details: dict[str, Any] | None = None,
    include_detail_links: bool = True,
    include_event_ids: bool = True,
    include_public_details: bool = False,
) -> str:
    rows = []
    for idx, battle in enumerate(battles[:10], 1):
        result_text = result_name(battle.get("wonMatch"))
        result_class = "win" if result_text == "胜利" else "loss" if result_text == "失败" else ""
        detail_html = ""
        if include_event_ids:
            detail_html = (
                f"""<a class="detail-link" href="{esc(battle_detail_href(subject, battle.get('apEventId')))}">详情</a><br>
                    <code>{esc(battle.get('apEventId'))}</code>"""
                if include_detail_links
                else f"<code>{esc(battle.get('apEventId'))}</code>"
            )
        event_cell = f'<td class="event-col">{detail_html}</td>' if include_event_ids else ""
        detail_row = ""
        if include_public_details:
            detail_ref = issue_public_battle_detail_ref(subject, battle)
            if detail_ref:
                detail_id = f"battle-detail-{detail_ref}"
                event_cell = f'''<td class="detail-col">
                  <button class="public-detail-button" type="button" data-battle-detail-ref="{esc(detail_ref)}"
                    aria-expanded="false" aria-controls="{esc(detail_id)}">详情</button>
                </td>'''
                detail_row = f'''<tr id="{esc(detail_id)}" class="battle-detail-row" hidden>
                  <td class="battle-detail-cell" colspan="13">
                    <div class="public-battle-detail" data-detail-panel></div>
                  </td>
                </tr>'''
            else:
                event_cell = '<td class="detail-col"><span class="muted">-</span></td>'
        rows.append(
            f"""<tr>
              <td class="idx">{idx}</td>
              <td class="time">{esc(battle.get('dtEventTime'))}</td>
              <td class="result-col"><span class="result {result_class}">{esc(result_text)}</span></td>
              <td class="hero hero-col">{esc(agent_name(battle.get('characterId')))}</td>
              <td class="score-col">{esc(score_text(battle))}</td>
              <td class="kda-col">{esc(kda_text(battle))}</td>
              <td class="acs-col">{esc(acs_text(battle))}</td>
              <td class="map-col">{esc(map_name(battle.get('mapId')))}</td>
              <td class="rank-col">{esc(rank_name(battle.get('competitiveTier')))}</td>
              <td class="rr-col">{esc(rr_text(battle.get('CompetitiveTierRankedRatingEarned')))}</td>
              <td class="duration-col">{esc(duration_text(battle.get('gameLengthMillis')))}</td>
              <td class="highlight-col">{esc(highlights_text(battle))}</td>
              {event_cell}
            </tr>{detail_row}"""
        )
    if not rows:
        column_count = 13 if include_event_ids or include_public_details else 12
        return f'<tr><td colspan="{column_count}" class="empty">没有拿到近期战绩。</td></tr>'
    return "".join(rows)


def battles_table(
    battles: list[dict[str, Any]],
    subject: str = "",
    battle_details: dict[str, Any] | None = None,
    include_detail_links: bool = True,
    include_event_ids: bool = True,
    include_public_details: bool = False,
) -> str:
    event_header = (
        '<th class="event-col">apEventId</th>'
        if include_event_ids
        else '<th class="detail-col">详情</th>' if include_public_details else ""
    )
    return f"""<div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th class="idx">#</th>
            <th class="time">时间</th>
            <th class="result-col">结果</th>
            <th class="hero-col">英雄</th>
            <th class="score-col">比分</th>
            <th class="kda-col">K/D/A</th>
            <th class="acs-col">ACS</th>
            <th class="map-col">地图</th>
            <th class="rank-col">段位</th>
            <th class="rr-col">RR</th>
            <th class="duration-col">时长</th>
            <th class="highlight-col">亮点</th>
            {event_header}
          </tr>
        </thead>
        <tbody>{battle_rows(battles, subject, battle_details, include_detail_links, include_event_ids, include_public_details)}</tbody>
      </table>
    </div>"""


def player_record_text(battles: list[dict[str, Any]]) -> str:
    wins = sum(1 for battle in battles[:10] if battle.get("wonMatch") in (1, "1", True))
    losses = sum(1 for battle in battles[:10] if battle.get("wonMatch") in (0, "0", False))
    return f"{wins}胜 {losses}负"


def public_recent_metrics(battles: list[dict[str, Any]]) -> dict[str, str]:
    recent = battles[:10]
    wins = sum(1 for battle in recent if battle.get("wonMatch") in (1, "1", True))
    losses = sum(1 for battle in recent if battle.get("wonMatch") in (0, "0", False))
    decided = wins + losses
    kills = sum(to_int(battle.get("statsKills"), 0) or 0 for battle in recent)
    deaths = sum(to_int(battle.get("statsDeaths"), 0) or 0 for battle in recent)
    assists = sum(to_int(battle.get("statsAssists"), 0) or 0 for battle in recent)
    score = sum(to_int(battle.get("statsScore"), 0) or 0 for battle in recent)
    rounds = sum(
        to_int(battle.get("statsRoundsPlayed") or battle.get("roundsPlayed"), 0) or 0
        for battle in recent
    )
    rr_values = [
        to_int(battle.get("CompetitiveTierRankedRatingEarned"))
        for battle in recent
    ]
    rr_total = sum(value for value in rr_values if value is not None)
    current_tier = next(
        (
            battle.get("competitiveTier")
            for battle in recent
            if (to_int(battle.get("competitiveTier")) or 0) >= 3
        ),
        None,
    )
    if current_tier is None:
        current_tier = next(
        (
            battle.get("competitiveTier")
            for battle in recent
            if battle.get("competitiveTier") is not None
        ),
        None,
        )
    return {
        "rank": rank_name(current_tier),
        "record": f"{wins}胜 {losses}负",
        "win_rate": f"{wins / decided * 100:.0f}%" if decided else "-",
        "kda": f"{(kills + assists) / max(deaths, 1):.2f}" if recent else "-",
        "acs": str(round(score / rounds)) if rounds else "-",
        "rr": f"{rr_total:+d}" if any(value is not None for value in rr_values) else "-",
    }


def public_rank_timeline_html(battles: list[dict[str, Any]]) -> str:
    items = []
    for idx, battle in enumerate(reversed(battles[:10]), 1):
        result = result_name(battle.get("wonMatch"))
        result_class = "win" if result == "胜利" else "loss" if result == "失败" else ""
        rank = rank_name(battle.get("competitiveTier"))
        rr = rr_text(battle.get("CompetitiveTierRankedRatingEarned"))
        items.append(
            f"""<div class="rank-step {result_class}" aria-label="第{idx}场，{esc(result)}，{esc(rank)}，RR {esc(rr)}">
              <span class="rank-step-dot" aria-hidden="true"></span>
              <strong>{esc(rank)}</strong>
              <span>{esc(rr)} RR</span>
            </div>"""
        )
    return f"""<section class="rank-timeline" aria-labelledby="rank-timeline-title">
      <div class="result-section-title">
        <div><span class="section-kicker">RECENT FORM</span><h2 id="rank-timeline-title">近 10 场段位变化</h2></div>
        <span>从左到右按对局时间排列</span>
      </div>
      <div class="rank-timeline-scroll"><div class="rank-timeline-track">{''.join(items)}</div></div>
    </section>"""


def public_agent_cards_html(battles: list[dict[str, Any]]) -> str:
    grouped: dict[str, dict[str, int]] = {}
    for battle in battles[:10]:
        character_id = str(battle.get("characterId") or "").lower()
        if not character_id:
            continue
        stats = grouped.setdefault(
            character_id,
            {"games": 0, "wins": 0, "kills": 0, "deaths": 0, "assists": 0},
        )
        stats["games"] += 1
        stats["wins"] += int(battle.get("wonMatch") in (1, "1", True))
        stats["kills"] += to_int(battle.get("statsKills"), 0) or 0
        stats["deaths"] += to_int(battle.get("statsDeaths"), 0) or 0
        stats["assists"] += to_int(battle.get("statsAssists"), 0) or 0
    ordered = sorted(
        grouped.items(),
        key=lambda item: (-item[1]["games"], -item[1]["wins"], agent_name(item[0])),
    )[:5]
    cards = []
    for character_id, stats in ordered:
        win_rate = stats["wins"] / max(stats["games"], 1) * 100
        kda = (stats["kills"] + stats["assists"]) / max(stats["deaths"], 1)
        icon_href = agent_icon_href(character_id)
        image_html = (
            f'<img src="{esc(icon_href)}" alt="{esc(agent_name(character_id))}" loading="lazy">'
            if icon_href
            else '<span class="agent-card-fallback" aria-hidden="true">VAL</span>'
        )
        cards.append(
            f"""<article class="agent-card">
              <div class="agent-card-portrait">{image_html}</div>
              <div class="agent-card-copy">
                <strong>{esc(agent_name(character_id))}</strong>
                <span>出场 {stats['games']} 场</span>
                <div><b>{win_rate:.0f}%</b> 胜率 <b>{kda:.2f}</b> KDA</div>
              </div>
            </article>"""
        )
    if not cards:
        cards.append('<div class="result-empty">暂无常用英雄统计。</div>')
    return f"""<section class="agent-overview" aria-labelledby="agent-overview-title">
      <div class="result-section-title">
        <div><span class="section-kicker">AGENT POOL</span><h2 id="agent-overview-title">近 10 场常用英雄</h2></div>
        <span>按出场次数排序</span>
      </div>
      <div class="agent-card-scroll"><div class="agent-card-grid">{''.join(cards)}</div></div>
    </section>"""


def battle_time_parts(value: Any) -> tuple[str, str]:
    text = str(value or "-").strip()
    parts = text.split(None, 1)
    return parts[0], parts[1] if len(parts) > 1 else ""


def public_battle_cards_html(
    battles: list[dict[str, Any]],
    subject: str,
) -> str:
    cards = []
    for idx, battle in enumerate(battles[:10], 1):
        result = result_name(battle.get("wonMatch"))
        result_class = "win" if result == "胜利" else "loss" if result == "失败" else ""
        character_id = battle.get("characterId")
        agent = agent_name(character_id)
        icon_href = agent_icon_href(character_id)
        map_art = map_art_href(battle.get("mapId"))
        date_text, clock_text = battle_time_parts(battle.get("dtEventTime"))
        highlight = highlights_text(battle)
        highlight_html = (
            f'<span class="match-highlight">{esc(highlight)}</span>'
            if highlight != "-"
            else ""
        )
        image_html = (
            f'<img src="{esc(icon_href)}" alt="{esc(agent)}" loading="lazy">'
            if icon_href
            else '<span aria-hidden="true">VAL</span>'
        )
        detail_ref = issue_public_battle_detail_ref(subject, battle)
        detail_html = ""
        if detail_ref:
            detail_id = f"battle-detail-{detail_ref}"
            detail_html = f"""<button class="public-detail-button" type="button"
                data-battle-detail-ref="{esc(detail_ref)}" aria-expanded="false"
                data-detail-open-label="收起双方 10 人详情"
                data-detail-closed-label="查看双方 10 人详情"
                aria-controls="{esc(detail_id)}">
                <span>查看双方 10 人详情</span><span class="detail-chevron" aria-hidden="true"></span>
              </button>
              <div id="{esc(detail_id)}" class="battle-detail-row" hidden>
                <div class="public-battle-detail" data-detail-panel></div>
              </div>"""
        else:
            detail_html = '<div class="match-detail-unavailable">本局暂无可查询详情</div>'
        style = f' style="--match-map-art:url(&quot;{esc(map_art)}&quot;)"' if map_art else ""
        cards.append(
            f"""<article class="public-match-card {result_class}"{style}>
              <div class="match-card-main">
                <div class="match-agent">
                  <div class="match-agent-portrait">{image_html}</div>
                  <span>{esc(agent)}</span>
                </div>
                <div class="match-outcome">
                  <span class="match-result">{esc(result)}</span>
                  <strong>{esc(score_text(battle))}</strong>
                </div>
                <div class="match-metric match-kda"><span>K / D / A</span><strong>{esc(kda_text(battle))}</strong></div>
                <div class="match-metric match-acs"><span>ACS</span><strong>{esc(acs_text(battle))}</strong></div>
                <div class="match-map">
                  <span>地图</span><strong>{esc(map_name(battle.get('mapId')))}</strong>
                  {highlight_html}
                </div>
                <div class="match-rank">
                  <span>段位 / RR</span>
                  <strong>{esc(rank_name(battle.get('competitiveTier')))}</strong>
                  <b>{esc(rr_text(battle.get('CompetitiveTierRankedRatingEarned')))}</b>
                </div>
                <div class="match-time">
                  <strong>{esc(date_text)}</strong><span>{esc(clock_text)}</span><span>{esc(duration_text(battle.get('gameLengthMillis')))}</span>
                </div>
                <span class="match-index" aria-label="第 {idx} 场">{idx:02d}</span>
              </div>
              {detail_html}
            </article>"""
        )
    if not cards:
        return '<div class="result-empty">没有拿到近期排位战绩。</div>'
    return f"""<section class="match-history" aria-labelledby="match-history-title">
      <div class="result-section-title match-history-title">
        <div><span class="section-kicker">MATCH HISTORY</span><h2 id="match-history-title">最近 10 场排位</h2></div>
        <span>点击任意场次查看双方玩家详情</span>
      </div>
      <div class="public-match-list">{''.join(cards)}</div>
    </section>"""


def public_results_overview_html(
    display_name: str,
    query: str,
    battles: list[dict[str, Any]],
    location: str = "",
) -> str:
    metrics = public_recent_metrics(battles)
    recent_agent = battles[0].get("characterId") if battles else ""
    agent = agent_name(recent_agent)
    icon_href = agent_icon_href(recent_agent)
    portrait = (
        f'<img src="{esc(icon_href)}" alt="最近一场使用英雄：{esc(agent)}">'
        if icon_href
        else '<span aria-hidden="true">WV</span>'
    )
    metric_items = [
        ("近 10 场胜率", metrics["win_rate"], ""),
        ("近 10 场 KDA", metrics["kda"], ""),
        ("近 10 场 ACS", metrics["acs"], ""),
        ("近 10 场 RR", metrics["rr"], " positive" if metrics["rr"].startswith("+") else " negative" if metrics["rr"].startswith("-") else ""),
    ]
    return f"""<section class="result-profile" aria-labelledby="result-player-name">
      <div class="result-identity">
        <div class="result-portrait">{portrait}</div>
        <div>
          <span class="section-kicker">PLAYER SNAPSHOT</span>
          <h1 id="result-player-name">{esc(display_name or query)}</h1>
          <div class="result-rank-line"><strong>{esc(metrics['rank'])}</strong><span>{esc(metrics['record'])}</span></div>
          <p class="result-location">近 10 场排位 · IP属地 {esc(location or '未获取')}</p>
        </div>
      </div>
      <div class="result-metrics">
        {''.join(f'<div class="result-metric"><span>{esc(label)}</span><strong class="{css_class.strip()}">{esc(value)}</strong></div>' for label, value, css_class in metric_items)}
      </div>
    </section>
    {public_rank_timeline_html(battles)}
    {public_agent_cards_html(battles)}"""


def page_stem(value: str) -> str:
    stem = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", value or "").strip(" ._")
    stem = re.sub(r"\s+", "_", stem)
    return (stem[:96] or "player")


def page_href(path: Path) -> str:
    return "/pages/" + urllib.parse.quote(path.name)


def query_href(value: str) -> str:
    return "/query?" + urllib.parse.urlencode({"q": value})


def battle_detail_href(subject: str, ap_event_id: Any) -> str:
    return "/battle?" + urllib.parse.urlencode({"subject": subject, "apEventId": str(ap_event_id or "")})


def save_html_page(stem: str, body: str) -> Path:
    PAGES_DIR.mkdir(parents=True, exist_ok=True)
    path = PAGES_DIR / f"{page_stem(stem)}.html"
    path.write_text(body, encoding="utf-8")
    return path


def query_dict(record: dict[str, Any]) -> dict[str, Any]:
    req = record.get("request") or {}
    output: dict[str, Any] = {}
    for pair in req.get("query") or []:
        if isinstance(pair, dict) and "key" in pair:
            output[str(pair["key"])] = pair.get("value")
    return output


def capture_files(limit: int = 12) -> list[Path]:
    patterns = ["proxifier-game-*.jsonl", "friend-search-*.jsonl", "wegame-*.jsonl"]
    files: list[Path] = []
    for pattern in patterns:
        files.extend(CAPTURE_DIR.glob(pattern))
    old_dir = CAPTURE_DIR
    if old_dir.exists():
        files.extend(old_dir.glob("wegame-*.jsonl"))
    unique = {str(path.resolve()).lower(): path for path in files if path.exists()}
    return sorted(unique.values(), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]


def scan_alias_captures(paths: list[Path] | None = None) -> list[dict[str, Any]]:
    found: dict[str, dict[str, Any]] = {}
    for path in paths or capture_files():
        try:
            lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        except Exception:
            continue
        for line in lines:
            if "aliases/v1/aliases" not in line:
                continue
            try:
                record = json.loads(line)
            except Exception:
                continue
            resp = body_json(record, "response")
            if not isinstance(resp, list):
                continue
            req_query = query_dict(record)
            for item in resp:
                if not isinstance(item, dict):
                    continue
                subject = str(item.get("puuid") or item.get("subject") or "").lower()
                if not SUBJECT_RE.match(subject):
                    continue
                alias = item.get("alias") if isinstance(item.get("alias"), dict) else {}
                game_name = alias.get("game_name") or alias.get("gameName") or req_query.get("gameName")
                tag_line = alias.get("tag_line") or alias.get("tagLine") or req_query.get("tagLine")
                display = f"{game_name}#{tag_line}" if game_name and tag_line else str(game_name or subject)
                key = normalize_name(display) or subject
                found[key] = {
                    "name": display,
                    "subject": subject,
                    "source": path.name,
                    "captured_at": record.get("captured_at"),
                }
    rows = sorted(found.values(), key=lambda item: (item.get("captured_at") or "", item["name"]), reverse=True)
    for row in rows:
        upsert_subject(row["name"], row["subject"], f"alias-capture:{row['source']}")
    return rows


def build_player_page(display_name: str, subject: str, source: str = "browser-context") -> dict[str, Any]:
    api_source, data = query_battles(subject, 10)
    html_body = render_battles(display_name, display_name, subject, api_source, data)
    path = save_html_page(f"{display_name}-近期战绩", html_body)
    battles = data.get("battles") if isinstance(data, dict) else []
    return {
        "name": display_name,
        "subject": subject,
        "source": source,
        "api_source": api_source,
        "battle_count": len(battles) if isinstance(battles, list) else 0,
        "page": path,
        "href": page_href(path),
    }


def scan_aliases_and_build_pages() -> list[dict[str, Any]]:
    rows = scan_alias_captures()
    output = []
    for row in rows:
        try:
            output.append(build_player_page(row["name"], row["subject"], row["source"]))
        except Exception as exc:
            output.append(
                {
                    "name": row["name"],
                    "subject": row["subject"],
                    "source": row["source"],
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
    return output


def battles_response_ok(data: dict[str, Any]) -> bool:
    result = data.get("result") if isinstance(data, dict) else None
    code = result.get("error_code") if isinstance(result, dict) else result
    return code == 0 and isinstance(data.get("battles"), list)


def render_scan_results(results: list[dict[str, Any]]) -> str:
    rows = []
    for item in results:
        page = item.get("page")
        link = f'<a href="{esc(item.get("href"))}">打开页面</a>' if page else '<span class="muted">未生成</span>'
        status = item.get("error") or f"{item.get('battle_count', 0)} 场 / {item.get('api_source', '-')}"
        rows.append(
            f"""<tr>
              <td>{esc(item.get('name'))}</td>
              <td><code>{esc(item.get('subject'))}</code></td>
              <td>{esc(item.get('source'))}</td>
              <td>{esc(status)}</td>
              <td>{link}</td>
            </tr>"""
        )
    if not rows:
        rows.append('<tr><td colspan="5" class="empty">没有在最近抓包里发现好友别名接口。先启动 Proxifier 抓包，再在客户端添加好友。</td></tr>')
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>好友别名扫描结果</title>
  <style>{APP_CSS}</style>
</head>
<body>
<main>
  <div class="topbar"><a href="/">返回查询</a><a href="/assistant">助手页</a></div>
  <section class="panel">
    <div class="player-head">
      <div>
        <h1>好友别名扫描结果</h1>
        <p>从本地抓包抽取 昵称#ID -> subject，并用 WeGame 登录态实时查询近期战绩。</p>
      </div>
      <div class="record">{len(results)} 个 subject</div>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>昵称</th><th>subject</th><th>来源</th><th>查询状态</th><th>页面</th></tr></thead>
        <tbody>{''.join(rows)}</tbody>
      </table>
    </div>
  </section>
</main>
</body>
</html>"""


def display_for_subject(subject: str) -> str:
    if not SUBJECT_RE.match(subject or ""):
        return ""
    try:
        with sqlite3.connect(DB_PATH) as db:
            row = db.execute(
                "select display_name from subjects where subject = ? order by updated_at desc limit 1",
                (subject.lower(),),
            ).fetchone()
    except Exception:
        return ""
    return str(row[0]) if row and row[0] else ""


def live_session_id(source: str, subject: str) -> str:
    return hashlib.sha1(f"{source}|{subject}".encode("utf-8")).hexdigest()[:16]


def pushed_game_sessions(limit: int = 80) -> list[dict[str, Any]]:
    import current_match_probe as probe_mod

    sessions: dict[str, dict[str, Any]] = {}
    all_capture_files = probe_mod.latest_capture_files()
    # pushed-game-token-*（历史远端推送）+ proxifier-game-*（本机抓包）
    files = [
        path
        for path in all_capture_files
        if path.name.startswith("pushed-game-token-") or path.name.startswith("proxifier-game-")
    ][:8]
    for path in files:
        try:
            lines = probe_mod.tail_text_lines(path, 500)
        except Exception:
            continue
        for line in lines:
            try:
                item = json.loads(line)
            except Exception:
                continue
            headers = ((item.get("request") or {}).get("headers") or {})
            lowered = {str(k).lower(): str(v) for k, v in headers.items()}
            auth = lowered.get("authorization")
            if not auth:
                continue
            subject = decode_bearer_subject(auth)
            if not subject:
                continue
            source = str(item.get("source") or "")
            if not source and path.name.startswith("proxifier-game-"):
                source = "local-capture:127.0.0.1"
            if not source:
                source = "unknown"
            ts = float(item.get("ts_start") or item.get("captured_at") or 0)
            sid = live_session_id(source, subject)
            old = sessions.get(sid)
            if old and float(old.get("ts") or 0) >= ts:
                continue
            payload = probe_mod.decode_jwt_payload(auth.removeprefix("Bearer").strip())
            exp = payload.get("exp")
            sessions[sid] = {
                "id": sid,
                "source": source,
                "subject": subject,
                "ts": ts,
                "updated_at": time.strftime("%m-%d %H:%M:%S", time.localtime(ts)) if ts else "",
                "expires_in": int(exp - time.time()) if isinstance(exp, int) else None,
                "path": str(path),
            }
    rows = sorted(sessions.values(), key=lambda row: float(row.get("ts") or 0), reverse=True)[:limit]
    for row in rows:
        row["display"] = display_for_subject(str(row.get("subject") or ""))
    return rows


def live_session_by_id(session_id: str) -> dict[str, Any] | None:
    for session in pushed_game_sessions(200):
        if session.get("id") == session_id:
            return session
    return None


def live_session_header_lookup(
    probe_mod: Any,
    session: dict[str, Any] | None,
) -> tuple[list[Path], str | None]:
    paths = probe_mod.latest_capture_files()[:12]
    if not session:
        return paths, None

    source = str(session.get("source") or "")
    session_path = Path(str(session.get("path") or ""))
    if source.startswith("local-capture:"):
        # A capture restart can split one valid local credential set across
        # files: the new RSO Authorization may arrive before the next
        # Entitlement response/header. Search only local Proxifier captures and
        # let the caller's subject_filter keep the account fixed. Never include
        # pushed/remote files in this fallback, preserving source isolation.
        local_paths = [
            path
            for path in probe_mod.latest_capture_files()
            if path.name.startswith("proxifier-game-")
        ][:8]
        if session_path.is_file():
            local_paths = [session_path] + [
                path for path in local_paths if path.resolve() != session_path.resolve()
            ]
        return local_paths, None
    if session_path.is_file():
        paths = [session_path]
    source_filter = source or None
    return paths, source_filter


def netbar_connection_commands() -> dict[str, str]:
    unavailable = (
        'Write-Host "此公开本地包不包含远程中继配置。" -ForegroundColor Yellow\r\n'
        'Write-Host "请使用随包的本机抓包流程，不要把 token 发送到第三方服务器。" -ForegroundColor Yellow'
    )
    restore = (
        'netsh winhttp reset proxy\r\n'
        'reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v AutoConfigURL /f\r\n'
        'reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v ProxyEnable /t REG_DWORD /d 0 /f\r\n'
        'Write-Host "网络代理已恢复。" -ForegroundColor Green'
    )
    return {
        "cert": unavailable,
        "connect": unavailable,
        "verify": unavailable,
        "restore": restore,
    }


def netbar_powershell_script(kind: str) -> bytes:
    commands = netbar_connection_commands()
    if kind == "connect":
        title = "WGame VAL 远程网吧代理已停用"
        success = "未修改本机网络设置。"
        powershell_body = commands["connect"]
    elif kind == "restore":
        title = "WGame VAL 恢复网络"
        success = "网络代理已恢复。建议重新启动 WeGame、Riot Client 和无畏契约。"
        powershell_body = commands["restore"]
    else:
        raise ValueError("unsupported script kind")
    powershell_script = (
        "#requires -Version 5.1\r\n"
        "$ErrorActionPreference = 'Stop'\r\n"
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8\r\n"
        "$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)\r\n"
        "if (-not $isAdmin) {\r\n"
        "  Write-Host '正在请求管理员权限...' -ForegroundColor Yellow\r\n"
        "  $arguments = '-NoProfile -ExecutionPolicy Bypass -File `\"' + $PSCommandPath + '`\"'\r\n"
        "  Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $arguments\r\n"
        "  exit\r\n"
        "}\r\n"
        f"Write-Host {json.dumps(title, ensure_ascii=False)} -ForegroundColor Cyan\r\n"
        "try {\r\n"
        f"{powershell_body}\r\n"
        f"Write-Host {json.dumps(success, ensure_ascii=False)} -ForegroundColor Green\r\n"
        "} catch {\r\n"
        "Write-Host ('执行失败：' + $_.Exception.Message) -ForegroundColor Red\r\n"
        "exit 1\r\n"
        "}\r\n"
        "Write-Host '按回车键关闭窗口。' -ForegroundColor DarkGray\r\n"
        "[void](Read-Host)\r\n"
    )
    return powershell_script.encode("utf-8-sig")


def render_live_sessions(message: str = "") -> str:
    sessions = pushed_game_sessions(200)
    reset_cmd = netbar_connection_commands()["restore"]
    rows = []
    active_count = 0
    for session in sessions:
        expires = session.get("expires_in")
        if isinstance(expires, int):
            expires_text = f"{expires}s" if expires >= 0 else "已过期"
            is_active = expires >= 0
        else:
            expires_text = "-"
            is_active = True
        if is_active:
            active_count += 1
        title = session.get("display") or session.get("subject")
        quoted_session = urllib.parse.quote(str(session.get("id") or ""))
        teammate_href = f"/teammates-live?session={quoted_session}&t={int(time.time())}"
        open_href = f"/assistant-live?session={quoted_session}&t={int(time.time())}"
        source = str(session.get("source") or "")
        source_ip = session_source_ip(session)
        match_text = "等待检测" if is_active else "会话已过期"
        rows.append(
            f"""<tr>
              <td><strong>{esc(title)}</strong><br><code>{esc(session.get('subject'))}</code></td>
              <td><strong><code>{esc(source_ip or '-')}</code></strong><br><span>{esc(source)}</span></td>
              <td><strong data-live-status data-session="{esc(session.get('id'))}" data-active="{'1' if is_active else '0'}">{esc(match_text)}</strong><br><code data-live-hint></code></td>
              <td>{esc(session.get('updated_at'))}</td>
              <td>{esc(expires_text)}</td>
              <td>
                <a class="detail-link" href="{esc(teammate_href)}">房间/匹配近3场</a>
                <a class="detail-link" href="{esc(open_href)}">全部10人</a>
              </td>
            </tr>"""
        )
    if not rows:
        rows.append('<tr><td colspan="6" class="empty">当前没有可用会话。远程网吧代理已停用；这里只保留历史记录与本机抓包产生的会话。</td></tr>')
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>管理员 · 全部实时对局</title>
  <style>{APP_CSS}</style>
  <style>
    .cmd-grid {{ display: grid; grid-template-columns: 1fr; gap: 10px; padding: 14px 18px; }}
    .cmd-box {{ border: 1px solid var(--line); background: #101923; border-radius: 6px; overflow: hidden; }}
    .cmd-box header {{ display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 9px 10px; border-bottom: 1px solid var(--line); color: var(--cyan); font-weight: 900; }}
    .cmd-box pre {{ margin: 0; padding: 10px; min-height: 132px; color: #d9f3ff; white-space: pre-wrap; word-break: break-all; font: 12px/1.45 Consolas, "Cascadia Mono", monospace; }}
    body > main {{ display: flex; flex-direction: column; }}
    body > main > .topbar {{ order: 0; }}
    .sessions-panel {{ order: 1; }}
    .commands-panel {{ order: 2; }}
    @media (max-width: 1100px) {{ .cmd-grid {{ grid-template-columns: 1fr; }} }}
  </style>
</head>
<body>
<main>
  <div class="topbar"><a href="/">返回查询</a><a href="/admin/live">刷新全部对局</a></div>
  <section class="panel commands-panel">
    <div class="player-head">
      <div>
        <h2>远程网吧代理已停用</h2>
        <p>服务器不再提供远程 PAC、证书或游戏流量代理。这里仅保留恢复命令，供曾经配置过代理的电脑清理 WinHTTP、PAC 和环境变量。</p>
      </div>
      <div class="record">已关闭</div>
    </div>
    <div class="cmd-grid">
      <div class="cmd-box">
        <header><span>恢复网络</span><button class="small-link" type="button" data-copy="{esc(reset_cmd)}">复制</button></header>
        <pre>{esc(reset_cmd)}</pre>
      </div>
    </div>
  </section>
  <section class="panel sessions-panel">
    <div class="player-head">
      <div>
        <h1>管理员 · 全部实时对局</h1>
        <p>这里显示所有来源 IP 和账号的实时会话，不按管理员当前访问 IP 筛选。近 3 场页面会先显示房间成员，匹配成功后自动补入其他我方玩家。</p>
      </div>
      <div class="record">有效 {active_count} / 全部 {len(sessions)}</div>
    </div>
    <p class="msg" style="padding:0 18px">{esc(message)}</p>
    <div class="table-wrap">
      <table>
        <thead><tr><th>账号</th><th>来源 IP</th><th>当前对局</th><th>更新时间</th><th>token剩余</th><th>操作</th></tr></thead>
        <tbody>{''.join(rows)}</tbody>
      </table>
    </div>
  </section>
</main>
<script>
document.addEventListener('click', async (event) => {{
  const button = event.target.closest('[data-copy]');
  if (!button) return;
  await navigator.clipboard.writeText(button.dataset.copy);
  const old = button.textContent;
  button.textContent = '已复制';
  setTimeout(() => button.textContent = old, 1200);
}});

const liveRows = Array.from(document.querySelectorAll('[data-live-status][data-active="1"]'));
let liveCursor = 0;
async function loadLiveStatus() {{
  while (liveCursor < liveRows.length) {{
    const status = liveRows[liveCursor++];
    const hint = status.parentElement.querySelector('[data-live-hint]');
    status.textContent = '正在检测...';
    try {{
      const response = await fetch(`/api/admin/live-status?session=${{encodeURIComponent(status.dataset.session)}}`, {{cache:'no-store'}});
      const data = await response.json();
      status.textContent = data.text || (data.ok ? '未检测到当前局' : '探测异常');
      if (hint) hint.textContent = data.hint || '';
    }} catch (error) {{
      status.textContent = '探测异常';
      if (hint) hint.textContent = '请稍后刷新';
    }}
  }}
}}
for (let index = 0; index < Math.min(4, liveRows.length); index += 1) loadLiveStatus();
</script>
</body>
</html>"""


def probe_current_match(subject: str, session_id: str = "") -> dict[str, Any]:
    import current_match_probe as probe_mod

    session = live_session_by_id(session_id) if session_id else None
    paths, source_filter = live_session_header_lookup(probe_mod, session)
    headers, self_subject, source = probe_mod.extract_latest_game_headers(
        paths,
        source_filter=source_filter,
        subject_filter=session.get("subject") if session else None,
    )
    if not headers:
        return {
            "ok": False,
            "error": "没有找到这个会话的游戏侧 Authorization / Entitlement 头。可能 token 已过期，或用户还没有重新进游戏加载数据。",
            "captureSource": None,
            "session": session,
        }
    target_subject = subject or self_subject
    if not target_subject:
        return {
            "ok": False,
            "error": "找到了游戏侧登录头，但没有可探测的 subject。",
            "captureSource": str(source) if source else None,
            "session": session,
        }
    result = probe_mod.probe(headers, target_subject)
    result["selfSubject"] = self_subject
    result["targetSubject"] = target_subject
    result["captureSource"] = str(source) if source else None
    result["session"] = session
    return result


def admin_live_status_payload(session_id: str) -> dict[str, Any]:
    session = live_session_by_id(session_id)
    if not session:
        return {
            "ok": False,
            "text": "会话已失效",
            "hint": "刷新管理员列表后重试",
        }
    try:
        result = probe_current_match("", session_id=session_id)
    except Exception as exc:
        return {
            "ok": False,
            "text": "探测异常",
            "hint": f"{type(exc).__name__}: {exc}"[:180],
        }
    match = result.get("match")
    if result.get("ok") and isinstance(match, dict):
        return {
            "ok": True,
            "in_match": True,
            "text": (
                f"{map_name(match.get('mapId'))} / "
                f"{match.get('state') or '-'} / {match.get('playerCount') or '-'}人"
            ),
            "hint": str(match.get("matchId") or ""),
        }
    attempts = result.get("attempts") or []
    hint = str(result.get("error") or "")
    if attempts:
        hint = json.dumps(attempts[-1], ensure_ascii=False)[:180]
    return {
        "ok": True,
        "in_match": False,
        "text": "未检测到当前局",
        "hint": hint[:180],
    }


def probe_current_party(session_id: str = "", include_names: bool = True) -> dict[str, Any]:
    import current_match_probe as probe_mod

    session = live_session_by_id(session_id) if session_id else None
    paths, source_filter = live_session_header_lookup(probe_mod, session)
    headers, self_subject, source = probe_mod.extract_latest_game_headers(
        paths,
        source_filter=source_filter,
        subject_filter=session.get("subject") if session else None,
    )
    if not headers:
        return {
            "ok": False,
            "error": "没有找到这个会话的游戏侧 Authorization / Entitlement 头。可能 token 已过期，或用户还没有重新启动游戏。",
            "captureSource": None,
            "session": session,
        }
    target_subject = self_subject or (session.get("subject") if session else None)
    if not target_subject:
        return {
            "ok": False,
            "error": "找到了游戏侧登录头，但没有可探测的 subject。",
            "captureSource": str(source) if source else None,
            "session": session,
        }
    result = probe_mod.probe_party(headers, str(target_subject), include_names=include_names)
    if not result.get("ok") and not result.get("error"):
        result["error"] = "没有检测到当前组队房间，请先进入组队大厅。"
    result["selfSubject"] = str(target_subject).lower()
    result["captureSource"] = str(source) if source else None
    result["session"] = session
    return result


def probe_current_roster(session_id: str = "", include_names: bool = True) -> dict[str, Any]:
    import current_match_probe as probe_mod

    session = live_session_by_id(session_id) if session_id else None
    paths, source_filter = live_session_header_lookup(probe_mod, session)
    headers, self_subject, source = probe_mod.extract_latest_game_headers(
        paths,
        source_filter=source_filter,
        subject_filter=session.get("subject") if session else None,
    )
    if not headers:
        return {
            "ok": False,
            "error": "没有找到这个会话的游戏侧 Authorization / Entitlement 头。可能 token 已过期，或用户还没有重新启动游戏。",
            "session": session,
        }
    target_subject = self_subject or (session.get("subject") if session else None)
    if not target_subject:
        return {
            "ok": False,
            "error": "找到了游戏侧登录头，但没有可探测的 subject。",
            "session": session,
        }
    party_result = probe_mod.probe_party(
        headers,
        str(target_subject),
        include_names=include_names,
    )
    match_result = probe_mod.probe(
        headers,
        str(target_subject),
        include_names=include_names,
    )
    if not party_result.get("ok") and not match_result.get("ok"):
        return {
            "ok": False,
            "error": "没有检测到组队房间或当前匹配队伍。",
            "partyResult": party_result,
            "matchResult": match_result,
            "session": session,
        }
    return {
        "ok": True,
        "selfSubject": str(target_subject).lower(),
        "captureSource": str(source) if source else None,
        "partyResult": party_result,
        "matchResult": match_result,
        "session": session,
    }


def merged_current_roster(result: dict[str, Any]) -> dict[str, Any]:
    party_result = result.get("partyResult") if isinstance(result.get("partyResult"), dict) else {}
    match_result = result.get("matchResult") if isinstance(result.get("matchResult"), dict) else {}
    party = party_result.get("party") if isinstance(party_result.get("party"), dict) else {}
    match = match_result.get("match") if isinstance(match_result.get("match"), dict) else {}
    party_players = party.get("players") if isinstance(party.get("players"), list) else []
    match_players = match.get("players") if isinstance(match.get("players"), list) else []
    self_subject = str(result.get("selfSubject") or "").lower()

    merged: dict[str, dict[str, Any]] = {}
    for player in party_players:
        if not isinstance(player, dict):
            continue
        subject = str(player.get("subject") or "").lower()
        if not SUBJECT_RE.match(subject):
            continue
        merged[subject] = {
            **player,
            "subject": subject,
            "member_kind": "party",
            "team": "Party",
        }

    self_team = ""
    for player in match_players:
        if not isinstance(player, dict):
            continue
        if str(player.get("subject") or "").lower() == self_subject:
            self_team = str(player.get("team") or "")
            break
    if not self_team and match_result.get("phase") == "pregame" and match_players:
        self_team = str((match_players[0] or {}).get("team") or "Ally")

    if self_team:
        for player in match_players:
            if not isinstance(player, dict):
                continue
            subject = str(player.get("subject") or "").lower()
            team = str(player.get("team") or "")
            if not SUBJECT_RE.match(subject) or team.lower() != self_team.lower():
                continue
            existing = merged.get(subject)
            if existing:
                if player.get("name"):
                    existing["name"] = player.get("name")
                existing["match_team"] = team
                existing["characterId"] = player.get("characterId")
                existing["match_member"] = True
            else:
                merged[subject] = {
                    **player,
                    "subject": subject,
                    "member_kind": "matched",
                    "team": team,
                    "match_team": team,
                    "match_member": True,
                }
    return {
        "party": party,
        "match": match,
        "match_phase": match_result.get("phase"),
        "self_subject": self_subject,
        "self_team": self_team,
        "players": list(merged.values()),
    }


def session_source_ip(session: dict[str, Any]) -> str:
    source = str(session.get("source") or "").strip()
    candidate = source.rsplit(":", 1)[-1].strip("[]")
    try:
        return str(ipaddress.ip_address(candidate))
    except ValueError:
        return ""


def active_live_sessions_for_client(
    client_ip: str = "",
    *,
    allow_fallback: bool = False,
) -> list[dict[str, Any]]:
    sessions = pushed_game_sessions(80)
    if client_ip:
        sessions = [
            session
            for session in sessions
            if session_source_ip(session) == client_ip
        ]
    elif not allow_fallback:
        return []
    return [
        session
        for session in sessions
        if not isinstance(session.get("expires_in"), int)
        or int(session.get("expires_in") or 0) > 0
    ]


def latest_active_live_session(
    client_ip: str = "",
    *,
    allow_fallback: bool = True,
    include_expired: bool = True,
) -> dict[str, Any] | None:
    sessions = pushed_game_sessions(20)
    if client_ip:
        sessions = [
            session
            for session in sessions
            if session_source_ip(session) == client_ip
        ]
    if not sessions and not allow_fallback:
        return None
    if not sessions:
        sessions = pushed_game_sessions(20)
    for session in sessions:
        expires = session.get("expires_in")
        if not isinstance(expires, int) or expires > 0:
            return session
    return sessions[0] if include_expired and sessions else None


def public_viewer_key(client_ip: str) -> str:
    normalized = client_ip or "local-preview"
    return hashlib.sha256(f"public-live|{normalized}".encode("utf-8")).hexdigest()


def public_session_choice_token(session_id: str, viewer_key: str) -> str:
    return hashlib.sha256(
        f"public-session|{viewer_key}|{session_id}".encode("utf-8")
    ).hexdigest()[:24]


def live_risk_agreement_sha256() -> str:
    return hashlib.sha256(LIVE_RISK_AGREEMENT_TEXT.encode("utf-8")).hexdigest()


def live_risk_user_agent_hash(user_agent: str) -> str:
    return hashlib.sha256(
        f"live-risk-agent|{user_agent.strip()}".encode("utf-8")
    ).hexdigest()


def live_risk_client_hash(client_id: str) -> str:
    return hashlib.sha256(
        f"live-risk-client|{client_id}".encode("utf-8")
    ).hexdigest()


def create_live_risk_acceptance(viewer_key: str, user_agent: str, client_id: str) -> str:
    now = int(time.time())
    acceptance_id = secrets.token_hex(16)
    with LIVE_RISK_LOCK, sqlite3.connect(DB_PATH) as db:
        db.execute(
            "delete from live_risk_acceptances where revoked_at is null and accepted_at < ?",
            (now - LIVE_RISK_RECORD_TTL,),
        )
        db.execute(
            """
            insert into live_risk_acceptances(
                acceptance_id, agreement_version, agreement_sha256,
                accepted_at, expires_at, viewer_hash, user_agent_hash, client_hash
            ) values(?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                acceptance_id,
                LIVE_RISK_AGREEMENT_VERSION,
                live_risk_agreement_sha256(),
                now,
                now + LIVE_RISK_CONSENT_TTL,
                hashlib.sha256(f"live-risk-viewer|{viewer_key}".encode("utf-8")).hexdigest(),
                live_risk_user_agent_hash(user_agent),
                live_risk_client_hash(client_id),
            ),
        )
    return acceptance_id


def live_risk_acceptance_valid(acceptance_id: str, user_agent: str, client_id: str) -> bool:
    if not re.fullmatch(r"[0-9a-f]{32}", acceptance_id or "") or not re.fullmatch(
        r"[0-9a-f]{32}", client_id or ""
    ):
        return False
    try:
        with sqlite3.connect(DB_PATH) as db:
            row = db.execute(
                """
                select agreement_version, agreement_sha256, expires_at,
                       user_agent_hash, client_hash, revoked_at
                from live_risk_acceptances where acceptance_id = ?
                """,
                (acceptance_id,),
            ).fetchone()
    except Exception:
        return False
    if not row:
        return False
    version, agreement_hash, expires_at, agent_hash, client_hash, revoked_at = row
    return (
        secrets.compare_digest(str(version), LIVE_RISK_AGREEMENT_VERSION)
        and secrets.compare_digest(str(agreement_hash), live_risk_agreement_sha256())
        and int(expires_at or 0) >= int(time.time())
        and secrets.compare_digest(str(agent_hash), live_risk_user_agent_hash(user_agent))
        and secrets.compare_digest(str(client_hash), live_risk_client_hash(client_id))
        and revoked_at is None
    )


def live_risk_client_locked(client_id: str) -> bool:
    if not re.fullmatch(r"[0-9a-f]{32}", client_id or ""):
        return False
    try:
        with sqlite3.connect(DB_PATH) as db:
            row = db.execute(
                """
                select 1 from live_risk_acceptances
                where client_hash = ? and revoked_at is not null
                limit 1
                """,
                (live_risk_client_hash(client_id),),
            ).fetchone()
    except Exception:
        return False
    return bool(row)


def revoke_live_risk_acceptance(acceptance_id: str, client_id: str) -> bool:
    if not re.fullmatch(r"[0-9a-f]{32}", acceptance_id or "") or not re.fullmatch(
        r"[0-9a-f]{32}", client_id or ""
    ):
        return False
    with LIVE_RISK_LOCK, sqlite3.connect(DB_PATH) as db:
        cursor = db.execute(
            """
            update live_risk_acceptances
            set revoked_at = coalesce(revoked_at, ?)
            where acceptance_id = ? and client_hash = ?
            """,
            (int(time.time()), acceptance_id, live_risk_client_hash(client_id)),
        )
    return bool(cursor.rowcount)


def roster_member_signature(players: list[dict[str, Any]]) -> str:
    members = sorted(
        f"{str(player.get('subject') or '').lower()}:{player.get('member_kind') or 'party'}"
        for player in players
        if isinstance(player, dict) and SUBJECT_RE.match(str(player.get("subject") or ""))
    )
    return hashlib.sha1("|".join(members).encode("utf-8")).hexdigest()[:16]


def current_party_room_status(session_id: str = "") -> dict[str, Any]:
    session = live_session_by_id(session_id) if session_id else latest_active_live_session()
    if session_id and not session:
        raise ValueError("实时会话不存在或已过期")
    if not session:
        raise ValueError("还没有可用的实时会话")
    resolved_session_id = str(session.get("id") or "")
    result = probe_current_roster(resolved_session_id, include_names=False)
    if not result.get("ok"):
        raise RuntimeError(str(result.get("error") or "当前没有检测到组队房间或匹配队伍"))
    roster = merged_current_roster(result)
    party = roster["party"]
    players = roster["players"]
    self_subject = roster["self_subject"]
    other_players = [
        player
        for player in players
        if str(player.get("subject") or "").lower() != self_subject
    ]
    return {
        "ok": True,
        "session_id": resolved_session_id,
        "room": {
            "party_id": party.get("partyId"),
            "state": party.get("state"),
            "previous_state": party.get("previousState"),
            "accessibility": party.get("accessibility"),
            "queue_id": party.get("queueId"),
            "member_count": party.get("memberCount") or sum(
                1 for player in players if player.get("member_kind") == "party"
            ),
            "matched_member_count": sum(
                1 for player in other_players if player.get("member_kind") == "matched"
            ),
            "other_member_count": len(other_players),
            "match_phase": roster.get("match_phase"),
            "match_state": roster["match"].get("state"),
            "member_signature": roster_member_signature(players),
        },
    }


def start_current_room_teammates_task(
    session_id: str = "",
    *,
    public: bool = False,
    viewer_key: str = "",
) -> dict[str, Any]:
    session = live_session_by_id(session_id) if session_id else latest_active_live_session()
    if session_id and not session:
        raise ValueError("实时会话不存在或已过期")
    if not session:
        raise ValueError("还没有可用的实时会话")

    resolved_session_id = str(session.get("id") or "")
    result = probe_current_roster(session_id=resolved_session_id)
    if not result.get("ok"):
        raise RuntimeError(str(result.get("error") or "当前没有检测到组队房间或匹配队伍"))
    roster = merged_current_roster(result)
    party = roster["party"]
    players = roster["players"]
    self_subject = roster["self_subject"]
    if not any(
        isinstance(player, dict) and str(player.get("subject") or "").lower() == self_subject
        for player in players
    ):
        raise RuntimeError("组队房间或匹配队伍中没有识别到当前账号")

    teammates: list[dict[str, Any]] = []
    seen: set[str] = set()
    for player in players:
        if not isinstance(player, dict):
            continue
        subject = str(player.get("subject") or "").lower()
        if not SUBJECT_RE.match(subject) or subject == self_subject or subject in seen:
            continue
        seen.add(subject)
        display_name = str(player.get("name") or subject)
        member_kind = str(player.get("member_kind") or "party")
        upsert_subject(display_name, subject, "party-room" if member_kind == "party" else "matched-team")
        character = player.get("characterId") or player.get("character")
        teammates.append(
            {
                "subject": subject,
                "name": display_name,
                "team": player.get("team") or "Party",
                "member_kind": member_kind,
                "itier_rank": player.get("competitiveTier"),
                "account_level": player.get("accountLevel"),
                "is_owner": bool(player.get("isOwner")),
                "is_ready": bool(player.get("isReady")),
                "character": character,
                "agent": agent_name(character) if character else "-",
            }
        )
    party_member_count = party.get("memberCount") or sum(
        1 for player in players if player.get("member_kind") == "party"
    )
    matched_member_count = sum(
        1 for player in teammates if player.get("member_kind") == "matched"
    )
    meta = {
        "session_id": resolved_session_id,
        "party_id": party.get("partyId"),
        "state": party.get("state"),
        "previous_state": party.get("previousState"),
        "accessibility": party.get("accessibility"),
        "queue_id": party.get("queueId"),
        "self_subject": self_subject,
        "member_count": party_member_count,
        "matched_member_count": matched_member_count,
        "other_member_count": len(teammates),
        "match_phase": roster.get("match_phase"),
        "match_state": roster["match"].get("state"),
        "teammate_count": len(teammates),
        "member_signature": roster_member_signature(players),
    }
    task_id = new_task(
        teammates,
        f"组队房间与匹配队友近3场 {party.get('partyId') or ''}".strip(),
        "Party",
        battle_limit=3,
        kind="teammates",
        meta=meta,
        public=public,
        viewer_key=viewer_key,
    )
    return {
        "ok": True,
        "task_id": task_id,
        "task_url": f"/api/task/{task_id}",
        "room_status_url": f"/api/current-room-status?session={urllib.parse.quote(resolved_session_id)}",
        "page_url": f"/teammates-live?session={urllib.parse.quote(resolved_session_id)}",
        "session": session,
        "room": meta,
        "teammates": [player_public_dict(player) for player in teammates],
    }


def render_probe_result(
    subject: str,
    result: dict[str, Any],
    *,
    public: bool = False,
    viewer_key: str = "",
) -> str:
    if result.get("ok"):
        match = result.get("match") or {}
        players = match.get("players") if isinstance(match, dict) else []
        if isinstance(players, list) and players:
            normalized = []
            target_subject = str(result.get("targetSubject") or subject or "").lower()
            self_subject = str(result.get("selfSubject") or "").lower()
            self_team = ""
            for player in players:
                if not isinstance(player, dict):
                    continue
                player_subject = str(player.get("subject") or "").lower()
                player_team = str(player.get("team") or "-")
                if player_subject and player_subject in {target_subject, self_subject} and not self_team:
                    self_team = player_team
                normalized.append(
                    {
                        "subject": player_subject,
                        "name": player.get("name") or player.get("subject"),
                        "team": player_team,
                        "character": player.get("characterId") or player.get("character"),
                    }
                )
            label = "当前实时对局" if public else f"当前实时对局 {match.get('matchId') or ''}".strip()
            task_id = new_task(
                normalized,
                label,
                self_team,
                public=public,
                viewer_key=viewer_key,
            )
            session = result.get("session") if isinstance(result.get("session"), dict) else {}
            return render_assistant_live(
                normalized,
                task_id,
                str(session.get("id") or ""),
                self_team,
                public=public,
            )

    if public:
        session = result.get("session") if isinstance(result.get("session"), dict) else None
        return render_public_live(
            session,
            "暂未检测到正在进行的选人或对局，请进入匹配后再刷新。",
            index=False,
        )

    attempts = result.get("attempts")
    attempts_text = json.dumps(attempts or result, ensure_ascii=False, indent=2)
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>当前对局探测</title>
  <style>{APP_CSS}</style>
</head>
<body>
<main>
  <div class="topbar"><a href="/">返回查询</a><a href="/assistant">助手页</a></div>
  <section class="panel">
    <div class="player-head">
      <div>
        <h1>当前对局探测失败</h1>
        <p>{esc(result.get('error') or '接口没有返回可用对局。')}</p>
      </div>
      <div class="record">subject</div>
    </div>
    <div style="padding:16px 18px">
      <p class="muted">目标 subject：<code>{esc(subject)}</code></p>
      <pre style="white-space:pre-wrap;color:#bde4ff;font-size:12px">{esc(attempts_text)}</pre>
    </div>
  </section>
</main>
</body>
</html>"""


def percent_text(value: Any) -> str:
    if value is None:
        return "-"
    try:
        return f"{float(value) * 100:.1f}%"
    except (TypeError, ValueError):
        return str(value)


def hit_distribution_text(head_rate: Any, body_rate: Any, leg_rate: Any) -> str:
    try:
        rates = {
            "头部": float(head_rate),
            "身体": float(body_rate),
            "腿部": float(leg_rate),
        }
    except (TypeError, ValueError):
        return "-"
    preferred = max(rates, key=rates.get)
    return (
        f"偏{preferred}｜头 {rates['头部'] * 100:.0f}% / "
        f"身 {rates['身体'] * 100:.0f}% / 腿 {rates['腿部'] * 100:.0f}%"
    )


def match_hit_distribution_text(player: dict[str, Any]) -> str:
    headshots = to_int(player.get("match_headshots"), 0) or 0
    bodyshots = to_int(player.get("match_bodyshots"), 0) or 0
    legshots = to_int(player.get("match_legshots"), 0) or 0
    total_hits = headshots + bodyshots + legshots
    if total_hits <= 0:
        return "-"
    return hit_distribution_text(
        headshots / total_hits,
        bodyshots / total_hits,
        legshots / total_hits,
    )


def fixed_text(value: Any, digits: int = 1) -> str:
    if value is None:
        return "-"
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if digits <= 0:
        return str(round(number))
    return f"{number:.{digits}f}"


def load_assistant_players() -> list[dict[str, Any]]:
    if CURRENT_MATCH_CACHE.exists():
        try:
            data = json.loads(CURRENT_MATCH_CACHE.read_text(encoding="utf-8"))
        except Exception:
            data = {}
        rows = data.get("current_match_players") if isinstance(data, dict) else None
        if not isinstance(rows, list):
            rows = data.get("players") if isinstance(data, dict) else None
        output = []
        seen = set()
        for item in rows or []:
            if not isinstance(item, dict):
                continue
            subject = str(item.get("subject") or item.get("Subject") or "").lower()
            if not SUBJECT_RE.match(subject) or subject in seen:
                continue
            seen.add(subject)
            name = item.get("name") or item.get("name_service") or item.get("nickname")
            if not name and item.get("GameName"):
                name = f"{item.get('GameName')}#{item.get('TagLine')}" if item.get("TagLine") else item.get("GameName")
            player = dict(item)
            player["subject"] = subject
            player["name"] = str(name or subject)
            player["team"] = player.get("team") or "-"
            if upsert_subject(player["name"], subject, "assistant-cache"):
                pass
            output.append(player)
        if output:
            return output

    return [
        {"name": row["name"], "subject": row["subject"], "team": "Cached", "source": row["source"]}
        for row in list_subjects(10)
    ]


def recent_battle_summary_stats(battles: list[dict[str, Any]]) -> list[tuple[str, str]]:
    recent = battles[:10]
    wins = sum(1 for battle in recent if battle.get("wonMatch") in (1, "1", True))
    losses = sum(1 for battle in recent if battle.get("wonMatch") in (0, "0", False))
    decided = wins + losses
    kills = sum(to_int(battle.get("statsKills"), 0) or 0 for battle in recent)
    deaths = sum(to_int(battle.get("statsDeaths"), 0) or 0 for battle in recent)
    assists = sum(to_int(battle.get("statsAssists"), 0) or 0 for battle in recent)
    score = sum(to_int(battle.get("statsScore"), 0) or 0 for battle in recent)
    rounds = sum(
        to_int(battle.get("statsRoundsPlayed") or battle.get("roundsPlayed"), 0) or 0
        for battle in recent
    )
    win_rate = f"{wins / decided * 100:.0f}%" if decided else "-"
    kda = f"{(kills + assists) / max(deaths, 1):.2f}" if recent else "-"
    average_acs = str(round(score / rounds)) if rounds else "-"
    return [
        (f"近{len(recent)}场胜率", win_rate),
        (f"近{len(recent)}场 KDA", kda),
        (f"近{len(recent)}场 ACS", average_acs),
    ]


def assistant_summary_html(
    player: dict[str, Any],
    battles: list[dict[str, Any]],
    subject: str = "",
    live_context: bool = False,
) -> str:
    tier = player.get("itier_rank")
    if tier is None and battles:
        tier = battles[0].get("competitiveTier")
    if live_context:
        stats: list[tuple[str, Any] | None] = [
            ("当前段位", rank_name(tier)),
            *recent_battle_summary_stats(battles),
            (
                "赛季爆头率",
                percent_text(player.get("head_shot_rate")),
            ) if player.get("head_shot_rate") is not None else None,
            (
                "赛季命中习惯",
                hit_distribution_text(
                    player.get("head_shot_rate"),
                    player.get("body_shot_rate"),
                    player.get("leg_shot_rate"),
                ),
            ) if all(
                player.get(key) is not None
                for key in ("head_shot_rate", "body_shot_rate", "leg_shot_rate")
            ) else None,
        ]
        return "<div class=\"summary-grid live-summary-grid\">" + "".join(
            f'<div class="stat">{esc(label)}<strong>{esc(value)}</strong></div>'
            for item in stats
            if item is not None
            for label, value in [item]
        ) + "</div>"
    loc_info = player_location_info(player.get("name"), allow_query=True)
    stats = [
        ("subject", subject) if subject else None,
        ("当前段位", rank_name(tier)),
        ("IP属地", location_text(loc_info)),
        ("赛季场次", player.get("game_num", "-")),
        ("胜率", percent_text(player.get("win_rate"))),
        ("KDA", fixed_text(player.get("kda"), 2)),
        ("HS / ACS", f"{percent_text(player.get('head_shot_rate'))} / {fixed_text(player.get('score_avg'), 0)}"),
    ]
    return "<div class=\"summary-grid\">" + "".join(
        f'<div class="stat {"subject-stat" if label == "subject" else ""}">{esc(label)}<strong>{esc(value)}</strong></div>'
        for item in stats
        if item is not None
        for label, value in [item]
    ) + "</div>"


def render_assistant_player(
    player: dict[str, Any],
    battles: list[dict[str, Any]],
    source: str,
    battle_details: dict[str, Any],
    error: str = "",
    self_team: str = "",
    room_context: bool = False,
    public: bool = False,
    dom_id: str = "",
    inline_details: bool = False,
) -> str:
    subject = str(player.get("subject") or "")
    name = player.get("name") or subject
    team = str(player.get("team") or "-")
    use_inline_details = public or inline_details
    if room_context:
        side_text = "匹配队友" if player.get("member_kind") == "matched" else "组队房间"
    else:
        side_text = team_side_text(team, self_team)
    loc_info = player_location_info(name, allow_query=True)
    loc_text = str(loc_info.get("location") or "未获取") if use_inline_details else location_text(loc_info)
    current_agent = agent_name(player.get("character")) if player.get("character") else player.get("agent") or "-"
    team_class = "team-red" if team.lower() == "red" else "team-blue" if team.lower() == "blue" else ""
    if error and use_inline_details:
        status = "查询暂时不可用"
    elif error:
        status = f"查询异常：{error}"
    elif use_inline_details and room_context:
        status = "近 3 场已加载"
    elif use_inline_details:
        status = f"当前英雄 {current_agent} / 近 10 场已加载"
    elif room_context:
        status = source
    else:
        status = f"{source} / 当前英雄 {current_agent}"
    identity_line = (
        f"{esc(side_text)} / IP属地 {esc(loc_text)} / {esc(status)}"
        if use_inline_details
        else f"{esc(side_text)} / IP属地 {esc(loc_text)} / {esc(status)} / <code>{esc(subject)}</code>"
    )
    section_id = dom_id or f"player-{subject}"
    return f"""<section id="{esc(section_id)}" class="panel {team_class} scroll-target">
    <div class="player-head">
      <div>
        <h2>{esc(name)}</h2>
        <p>{identity_line}</p>
      </div>
      <div class="record">{esc(player_record_text(battles) if battles else "0胜 0负")}</div>
    </div>
    {assistant_summary_html(player, battles, live_context=use_inline_details)}
    {battles_table(
        battles,
        subject,
        battle_details,
        include_detail_links=not use_inline_details,
        include_event_ids=not use_inline_details,
        include_public_details=use_inline_details,
    )}
  </section>"""


def render_assistant(players: list[dict[str, Any]]) -> str:
    battle_details = load_cached_battle_details()
    sections = []
    found = 0
    for player in players:
        subject = str(player.get("subject") or "")
        battles: list[dict[str, Any]] = []
        source = "-"
        error = ""
        if SUBJECT_RE.match(subject):
            try:
                data = browser_api_query(subject, 10)
                result = data.get("result") if isinstance(data, dict) else None
                code = result.get("error_code") if isinstance(result, dict) else result
                if code == 0 and isinstance(data.get("battles"), list):
                    battles = data["battles"]
                    source = "browser-context"
                    found += 1
                else:
                    message = result.get("error_message") if isinstance(result, dict) else ""
                    error = f"code={code} {message}".strip()
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"
        sections.append(render_assistant_player(player, battles, source, battle_details, error))

    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>当前对局助手页</title>
  <style>{APP_CSS}</style>
</head>
<body>
<main>
  <div class="topbar"><a href="/">返回查询</a><span>当前对局助手页</span></div>
  <section class="panel">
    <div class="player-head">
      <div>
        <h1>当前对局玩家近期战绩</h1>
        <p>从助手缓存读取玩家 subject，再用登录态页面环境查询每名玩家最近 10 场竞技模式。</p>
      </div>
      <div class="record">{found}/{len(players)} 已加载</div>
    </div>
  </section>
  {''.join(sections)}
</main>
</body>
</html>"""


def player_public_dict(player: dict[str, Any]) -> dict[str, Any]:
    return {
        "subject": player.get("subject"),
        "name": player.get("name") or player.get("subject"),
        "team": player.get("team") or "-",
        "agent": player.get("agent") or "-",
        "character": player.get("character"),
        "game_num": player.get("game_num"),
        "win_rate": player.get("win_rate"),
        "itier_rank": player.get("itier_rank"),
        "kda": player.get("kda"),
        "head_shot_rate": player.get("head_shot_rate"),
        "body_shot_rate": player.get("body_shot_rate"),
        "leg_shot_rate": player.get("leg_shot_rate"),
        "score_avg": player.get("score_avg"),
        "account_level": player.get("account_level"),
        "display_rank": player.get("display_rank") or rank_name(player.get("itier_rank")),
        "member_kind": player.get("member_kind"),
        "is_owner": bool(player.get("is_owner")),
        "is_ready": bool(player.get("is_ready")),
    }


def team_side_label(team: str, self_team: str = "") -> str:
    raw_team = str(team or "-")
    if not self_team or raw_team == "-":
        return raw_team
    return "我方" if raw_team.lower() == str(self_team).lower() else "敌方"


def team_side_text(team: str, self_team: str = "") -> str:
    return team_side_label(team, self_team)


def new_task(
    players: list[dict[str, Any]],
    label: str,
    self_team: str = "",
    battle_limit: int = 10,
    kind: str = "assistant",
    meta: dict[str, Any] | None = None,
    public: bool = False,
    viewer_key: str = "",
) -> str:
    task_id = uuid.uuid4().hex
    battle_limit = max(1, min(int(battle_limit), 10))
    rows = [
        {
            "index": idx,
            "player": player_public_dict(player),
            "status": "pending",
            "html": "",
            "error": "",
            "battle_count": 0,
        }
        for idx, player in enumerate(players)
    ]
    with TASK_LOCK:
        TASKS[task_id] = {
            "id": task_id,
            "label": label,
            "status": "done" if not rows else "running",
            "created_at": time.time(),
            "updated_at": time.time(),
            "total": len(rows),
            "done": 0,
            "rows": rows,
            "self_team": self_team,
            "battle_limit": battle_limit,
            "kind": kind,
            "meta": meta or {},
            "public": public,
            "viewer_key": viewer_key if public else "",
        }
    if rows:
        thread = threading.Thread(target=run_battle_task, args=(task_id,), daemon=True)
        thread.start()
    return task_id


def update_task_row(task_id: str, index: int, patch: dict[str, Any]) -> None:
    with TASK_LOCK:
        task = TASKS.get(task_id)
        if not task:
            return
        row = task["rows"][index]
        old_status = row.get("status")
        row.update(patch)
        if old_status not in ("done", "error") and row.get("status") in ("done", "error"):
            task["done"] += 1
        task["updated_at"] = time.time()
        if task["done"] >= task["total"]:
            task["status"] = "done"


def run_battle_task(task_id: str) -> None:
    battle_details = load_cached_battle_details()
    with TASK_LOCK:
        task = TASKS.get(task_id)
        rows = list(task.get("rows", [])) if task else []
        self_team = str(task.get("self_team") or "") if task else ""
        battle_limit = int(task.get("battle_limit") or 10) if task else 10
        room_context = task.get("kind") == "teammates" if task else False
        public = bool(task.get("public")) if task else False
    season_reports: dict[str, dict[str, Any]] = {}
    try:
        season_id = browser_current_season_id()
        season_reports = browser_battle_reports(
            [str(row.get("player", {}).get("subject") or "") for row in rows],
            season_id,
        )
    except Exception:
        season_reports = {}
    for row in rows:
        idx = int(row["index"])
        player = dict(row["player"])
        subject = str(player.get("subject") or "")
        player = merge_player_season_report(player, season_reports.get(subject.lower()))
        update_task_row(task_id, idx, {"status": "loading"})
        battles: list[dict[str, Any]] = []
        source = "-"
        error = ""
        if not SUBJECT_RE.match(subject):
            update_task_row(task_id, idx, {"status": "error", "error": "subject 格式不正确"})
            continue
        try:
            data = browser_api_query(subject, battle_limit)
            result = data.get("result") if isinstance(data, dict) else None
            code = result.get("error_code") if isinstance(result, dict) else result
            if code == 0 and isinstance(data.get("battles"), list):
                battles = data["battles"]
                source = "browser-context"
            else:
                message = result.get("error_message") if isinstance(result, dict) else ""
                error = f"code={code} {message}".strip()
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
        tier = player.get("itier_rank")
        if tier is None and battles:
            tier = battles[0].get("competitiveTier")
        player["display_rank"] = rank_name(tier)
        if error:
            html_part = render_assistant_player(
                player,
                battles,
                source,
                battle_details,
                error,
                self_team,
                room_context=room_context,
                public=public,
                dom_id=f"player-{idx}",
                inline_details=True,
            )
            update_task_row(
                task_id,
                idx,
                {
                    "status": "error",
                    "error": error,
                    "html": html_part,
                    "battle_count": 0,
                    "battles": [],
                    "player": player,
                },
            )
        else:
            html_part = render_assistant_player(
                player,
                battles,
                source,
                battle_details,
                self_team=self_team,
                room_context=room_context,
                public=public,
                dom_id=f"player-{idx}",
                inline_details=True,
            )
            public_battles = [
                {
                    **(
                        {
                            "eventKey": hashlib.sha256(
                                str(battle.get("apEventId") or "").encode("utf-8")
                            ).hexdigest()[:16]
                        }
                        if public
                        else {"apEventId": battle.get("apEventId")}
                    ),
                    "time": battle.get("dtEventTime"),
                    "agent": agent_name(battle.get("characterId")),
                    "result": result_name(battle.get("wonMatch")),
                    "score": score_text(battle),
                    "kda": kda_text(battle),
                    "acs": acs_text(battle),
                    "map": map_name(battle.get("mapId")),
                    "rank": rank_name(battle.get("competitiveTier")),
                    "rr": rr_text(battle.get("CompetitiveTierRankedRatingEarned")),
                }
                for battle in battles[:battle_limit]
                if battle.get("apEventId")
            ]
            update_task_row(
                task_id,
                idx,
                {
                    "status": "done",
                    "html": html_part,
                    "battle_count": len(public_battles),
                    "battles": public_battles,
                    "player": player,
                },
            )


def teammate_task_reply(task: dict[str, Any]) -> str:
    meta = task.get("meta") if isinstance(task.get("meta"), dict) else {}
    lines = [
        "组队房间与匹配队友近3场",
        (
            f"房间 {meta.get('member_count') or '-'}人 / "
            f"匹配补充 {meta.get('matched_member_count') or 0}人"
        ),
    ]
    for row in task.get("rows") or []:
        player = row.get("player") if isinstance(row.get("player"), dict) else {}
        name = str(player.get("name") or player.get("subject") or "未知玩家")
        identity = ["匹配队友" if player.get("member_kind") == "matched" else "房间成员"]
        if player.get("is_owner"):
            identity.append("房主")
        player_rank = rank_name(player.get("itier_rank"))
        if player_rank != "-":
            identity.append(player_rank)
        identity_text = " / ".join(identity) or "房间成员"
        battles = row.get("battles") if isinstance(row.get("battles"), list) else []
        if row.get("status") == "error":
            lines.extend(["", f"{name}（{identity_text}）", f"查询异常：{row.get('error') or '未知错误'}"])
            continue
        wins = sum(1 for battle in battles if battle.get("result") == "胜利")
        losses = sum(1 for battle in battles if battle.get("result") == "失败")
        lines.extend(["", f"{name}（{identity_text}）", f"近{len(battles)}场 {wins}胜{losses}负"])
        for idx, battle in enumerate(battles, 1):
            lines.append(
                f"{idx}. {battle.get('result') or '-'} | {battle.get('agent') or '-'} | "
                f"{battle.get('score') or '-'} | {battle.get('kda') or '-'} | "
                f"ACS {battle.get('acs') or '-'} | {battle.get('map') or '-'}"
            )
    return "\n".join(lines)


def task_snapshot(task_id: str) -> dict[str, Any] | None:
    with TASK_LOCK:
        task = TASKS.get(task_id)
        if not task:
            return None
        snapshot = json.loads(json.dumps(task, ensure_ascii=False))
    if snapshot.get("kind") == "teammates" and snapshot.get("status") == "done":
        snapshot["reply"] = teammate_task_reply(snapshot)
    return snapshot


def public_task_snapshot(task_id: str, viewer_key: str) -> dict[str, Any] | None:
    snapshot = task_snapshot(task_id)
    if (
        not snapshot
        or not snapshot.get("public")
        or not secrets.compare_digest(str(snapshot.get("viewer_key") or ""), viewer_key)
    ):
        return None
    safe_rows = []
    for row in snapshot.get("rows") or []:
        player = row.get("player") if isinstance(row.get("player"), dict) else {}
        safe_player = {
            key: value
            for key, value in player.items()
            if key not in {"subject"}
        }
        battles = []
        for battle in row.get("battles") or []:
            if not isinstance(battle, dict):
                continue
            battles.append(
                {
                    key: value
                    for key, value in battle.items()
                    if key != "apEventId"
                }
            )
        safe_rows.append(
            {
                "index": row.get("index"),
                "player": safe_player,
                "status": row.get("status"),
                "html": row.get("html") or "",
                "error": "查询暂时不可用" if row.get("status") == "error" else "",
                "battle_count": row.get("battle_count") or 0,
                "battles": battles,
            }
        )
    safe = {
        "status": snapshot.get("status"),
        "done": snapshot.get("done") or 0,
        "total": snapshot.get("total") or 0,
        "rows": safe_rows,
    }
    if snapshot.get("kind") == "teammates" and snapshot.get("status") == "done":
        safe["reply"] = teammate_task_reply({**snapshot, "rows": safe_rows})
    return safe


def task_html(task_id: str) -> str:
    snap = task_snapshot(task_id)
    if not snap:
        return render_index("异步任务不存在或已过期。")
    body = "".join(row.get("html") or "" for row in snap.get("rows", []))
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>{esc(snap.get('label'))}</title>
  <style>{APP_CSS}</style>
</head>
<body>
<main>
  <div class="topbar"><a href="/">返回查询</a><span>{esc(snap.get('label'))}</span></div>
  <section class="panel">
    <div class="player-head">
      <div><h1>{esc(snap.get('label'))}</h1><p>异步查询完成快照。</p></div>
      <div class="record">{snap.get('done')}/{snap.get('total')} 已加载</div>
    </div>
  </section>
  {body}
</main>
</body>
</html>"""


def render_assistant_live(
    players: list[dict[str, Any]],
    task_id: str,
    session_id: str = "",
    self_team: str = "",
    *,
    public: bool = False,
) -> str:
    refresh_href = "/live/match" if public else "/assistant-live"
    if session_id and not public:
        refresh_href = f"/assistant-live?session={urllib.parse.quote(session_id)}"
    placeholders = []
    sidebar_groups: dict[str, list[str]] = {"我方": [], "敌方": [], "其他": []}
    for idx, player in enumerate(players):
        team = str(player.get("team") or "-")
        side_text = team_side_text(team, self_team)
        side_label = team_side_label(team, self_team)
        side_key = side_label if side_label in ("我方", "敌方") else "其他"
        team_class = "team-red" if team.lower() == "red" else "team-blue" if team.lower() == "blue" else ""
        subject = str(player.get("subject") or "")
        display_name = player.get("name") or subject
        current_agent = agent_name(player.get("character")) if player.get("character") else player.get("agent") or "-"
        avatar_href = agent_icon_href(player.get("character"))
        avatar_fallback = current_agent.split(" / ", 1)[0][:3] if current_agent != "-" else "?"
        avatar_image = (
            f'<img src="{esc(avatar_href)}" alt="" loading="eager" onerror="this.remove()">'
            if avatar_href
            else ""
        )
        nav_class = "own" if side_key == "我方" else "enemy" if side_key == "敌方" else ""
        sidebar_groups.setdefault(side_key, []).append(
            f"""<button id="nav-{idx}" class="nav-player {nav_class}" type="button" data-index="{idx}">
              <span class="nav-avatar" aria-hidden="true">
                <span class="nav-avatar-fallback">{esc(avatar_fallback)}</span>
                {avatar_image}
              </span>
              <span class="nav-hero">{esc(current_agent)}</span>
              <span class="nav-identity">
                <span class="nav-name">{esc(display_name)}</span>
                <span class="nav-rank pending" title="段位加载中">段位…</span>
              </span>
              <span class="nav-state">
                <span class="nav-state-text">等待查询</span>
                <span class="nav-party-label"></span>
              </span>
            </button>"""
        )
        waiting_text = f"{esc(side_text)} / 当前英雄 {esc(current_agent)} / 等待查询"
        placeholders.append(
            f"""<section id="slot-{idx}" class="panel {team_class}">
              <div class="player-head">
                <div>
                  <h2>{esc(display_name)}</h2>
                  <p>{waiting_text}</p>
                </div>
                <div class="record">等待</div>
              </div>
              <div class="empty">排队中，查到后会自动替换这里。</div>
            </section>"""
        )
    sidebar_sections = []
    for label in ("我方", "敌方", "其他"):
        items = sidebar_groups.get(label) or []
        if not items:
            continue
        sidebar_sections.append(
            f"""<div class="side-group" data-side="{esc(label)}">
              <div class="side-title"><span>{esc(label)}</span><span>{len(items)}</span></div>
            {''.join(items)}
            </div>"""
        )
    if public:
        head_html = public_head(
            "无畏契约当前对局10人战绩_WGame VAL",
            "实时查看当前无畏契约对局双方10名玩家的近期战绩、英雄、KDA、ACS、段位和公开省级属地。",
            canonical_path="/live",
            index=False,
        )
        style = PUBLIC_CSS
        body_class = ' class="public-page public-live-shell"'
        site_header = public_site_header("live")
        topbar = (
            f'<div class="topbar"><a href="/live">实时功能</a>'
            f'<a href="{esc(refresh_href)}">刷新这一场</a>'
            '<a href="/live/room">房间队友近 3 场</a></div>'
        )
        intro_text = "页面会先展示本场阵容，玩家近期战绩将在后台依次查询并自动更新，无需手动刷新。"
        party_text = "根据同队玩家近期共同对局辅助推断，仅供参考，并非官方组队信息。点击后才会显示分析结果。"
        task_path = f"/api/public/task/{task_id}"
    else:
        head_html = '<meta charset="utf-8"><title>助手页实时加载</title>'
        style = PUBLIC_CSS
        body_class = ""
        site_header = ""
        topbar = (
            f'<div class="topbar"><a href="/">返回查询</a><a href="/admin/live">全部实时对局</a>'
            f'<a href="{esc(refresh_href)}">刷新这一场</a><a href="/assistant">缓存助手页</a></div>'
        )
        intro_text = "页面会先展示本场阵容，玩家近期战绩将在后台依次查询并自动更新，无需手动刷新。"
        party_text = "根据同队玩家近期共同对局辅助推断，仅供参考，并非官方组队信息。点击后才会显示分析结果。"
        task_path = f"/api/task/{task_id}"
    save_task_line = (
        ""
        if public
        else "fetch(`/api/task/${taskId}/save`, {cache: 'no-store'}).catch(() => null);"
    )
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
{head_html}
  <style>{style}</style>
</head>
<body{body_class}>
{site_header}
<div class="live-layout">
<aside class="live-sidebar">
  <div class="live-sidebar-head">
    <strong>当前对局</strong>
    <span>点击玩家跳到战绩</span>
  </div>
  {''.join(sidebar_sections)}
</aside>
<main class="live-main">
  {topbar}
  <section class="panel">
    <div class="player-head">
      <div>
        <h1>当前对局玩家近期战绩</h1>
        <p>{esc(intro_text)}</p>
      </div>
      <div id="progress" class="record">0/{len(players)} 已加载</div>
    </div>
  </section>
  <section id="party-panel" class="panel">
    <div class="player-head">
      <div>
        <h2>疑似组队</h2>
        <p>{esc(party_text)}</p>
      </div>
      <button id="party-toggle" class="btn" type="button" aria-expanded="false" disabled>分析中</button>
    </div>
    <div id="party-body" class="empty" hidden>等待近期战绩加载完成后分析。</div>
  </section>
  <div id="slots">{''.join(placeholders)}</div>
</main>
</div>
<script>
const taskId = {json.dumps(task_id)};
const taskPath = {json.dumps(task_path)};
const publicView = {json.dumps(public)};
const selfTeam = {json.dumps(self_team, ensure_ascii=False)};
const filled = new Set();
const partyPalette = ['#ffb347', '#d58cff', '#43e6a8', '#ff6f91', '#62d6ff', '#f6e05e'];
let latestPartyGroups = [];
let partyRevealed = false;
let partyAnalysisReady = false;
function esc(value) {{
  return String(value ?? '').replace(/[&<>"']/g, ch => ({{
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }}[ch]));
}}
function inferParties(rows) {{
  const ready = rows.filter(row => row.status === 'done' && Array.isArray(row.battles) && row.battles.length);
  const groups = [];
  for (let i = 0; i < ready.length; i++) {{
    for (let j = i + 1; j < ready.length; j++) {{
      const a = ready[i];
      const b = ready[j];
      const pa = a.player || {{}};
      const pb = b.player || {{}};
      if ((pa.team || '-') !== (pb.team || '-')) continue;
      const amap = new Map(a.battles.map(battle => [battle.eventKey || battle.apEventId, battle]));
      const shared = [];
      for (const battle of b.battles) {{
        const eventKey = battle.eventKey || battle.apEventId;
        if (!amap.has(eventKey)) continue;
        const left = amap.get(eventKey);
        const right = battle;
        let relation = '未知';
        if (left.result && right.result) {{
          relation = left.result === right.result ? '友方' : '敌方';
        }}
        shared.push({{left, right, relation}});
      }}
      if (!shared.length) continue;
      groups.push({{
        aIndex: Number(a.index),
        bIndex: Number(b.index),
        a: pa.name || pa.subject,
        b: pb.name || pb.subject,
        team: pa.team || '-',
        count: shared.length,
        allyCount: shared.filter(item => item.relation === '友方').length,
        enemyCount: shared.filter(item => item.relation === '敌方').length,
        samples: shared.slice(0, 4).map(item => ({{
          relation: item.relation,
          time: item.left.time || item.right.time || '-',
          leftAgent: item.left.agent || '-',
          leftResult: item.left.result || '-',
          rightAgent: item.right.agent || '-',
          rightResult: item.right.result || '-'
        }}))
      }});
    }}
  }}
  groups.sort((a, b) => b.count - a.count || a.team.localeCompare(b.team));
  return groups;
}}
function buildPartyClusters(groups) {{
  const likelyEdges = groups.filter(group => group.allyCount > 0 && group.allyCount >= group.enemyCount);
  const adjacency = new Map();
  const names = new Map();
  const teams = new Map();
  for (const edge of likelyEdges) {{
    if (!Number.isInteger(edge.aIndex) || !Number.isInteger(edge.bIndex)) continue;
    if (!adjacency.has(edge.aIndex)) adjacency.set(edge.aIndex, new Set());
    if (!adjacency.has(edge.bIndex)) adjacency.set(edge.bIndex, new Set());
    adjacency.get(edge.aIndex).add(edge.bIndex);
    adjacency.get(edge.bIndex).add(edge.aIndex);
    names.set(edge.aIndex, edge.a);
    names.set(edge.bIndex, edge.b);
    teams.set(edge.aIndex, edge.team);
    teams.set(edge.bIndex, edge.team);
  }}
  const visited = new Set();
  const clusters = [];
  for (const start of [...adjacency.keys()].sort((a, b) => a - b)) {{
    if (visited.has(start)) continue;
    const stack = [start];
    const members = [];
    visited.add(start);
    while (stack.length) {{
      const current = stack.pop();
      members.push(current);
      for (const next of adjacency.get(current) || []) {{
        if (visited.has(next)) continue;
        visited.add(next);
        stack.push(next);
      }}
    }}
    members.sort((a, b) => a - b);
    if (members.length < 2) continue;
    const memberSet = new Set(members);
    clusters.push({{
      members,
      names: members.map(index => names.get(index) || `玩家 ${{index + 1}}`),
      team: teams.get(members[0]) || '-',
      evidence: likelyEdges.filter(edge => memberSet.has(edge.aIndex) && memberSet.has(edge.bIndex))
    }});
  }}
  return clusters;
}}
function clearSidebarPartyLinks() {{
  document.querySelectorAll('.party-link-line, .party-link-branch').forEach(element => element.remove());
  document.querySelectorAll('.nav-player.party-linked').forEach(nav => {{
    nav.classList.remove('party-linked');
    nav.style.removeProperty('--party-color');
    nav.removeAttribute('data-party-group');
    nav.removeAttribute('title');
    const label = nav.querySelector('.nav-party-label');
    if (label) label.textContent = '';
  }});
}}
function renderSidebarPartyLinks(groups) {{
  clearSidebarPartyLinks();
  const clusters = buildPartyClusters(groups);
  clusters.forEach((cluster, clusterIndex) => {{
    const color = partyPalette[clusterIndex % partyPalette.length];
    const groupNumber = clusterIndex + 1;
    const navs = cluster.members
      .map(index => document.getElementById(`nav-${{index}}`))
      .filter(Boolean);
    if (navs.length < 2) return;
    const sideGroup = navs[0].closest('.side-group');
    if (!sideGroup || navs.some(nav => nav.closest('.side-group') !== sideGroup)) return;
    const groupTitle = `疑似组队 ${{groupNumber}}：${{cluster.names.join('、')}}`;
    navs.forEach(nav => {{
      nav.classList.add('party-linked');
      nav.style.setProperty('--party-color', color);
      nav.dataset.partyGroup = String(groupNumber);
      nav.title = groupTitle;
      const label = nav.querySelector('.nav-party-label');
      if (label) label.textContent = `组队 ${{groupNumber}}`;
    }});
    const groupRect = sideGroup.getBoundingClientRect();
    const avatars = navs
      .map(nav => nav.querySelector('.nav-avatar'))
      .filter(Boolean)
      .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
    if (avatars.length < 2) return;
    const firstRect = avatars[0].getBoundingClientRect();
    const lastRect = avatars[avatars.length - 1].getBoundingClientRect();
    const lane = clusterIndex % 2;
    const lineX = firstRect.left - groupRect.left - 14 - lane * 4;
    const lineTop = firstRect.top - groupRect.top + firstRect.height / 2;
    const lineBottom = lastRect.top - groupRect.top + lastRect.height / 2;
    const line = document.createElement('span');
    line.className = 'party-link-line';
    line.setAttribute('aria-hidden', 'true');
    line.style.setProperty('--party-color', color);
    line.style.left = `${{lineX}}px`;
    line.style.top = `${{lineTop}}px`;
    line.style.height = `${{Math.max(3, lineBottom - lineTop)}}px`;
    sideGroup.appendChild(line);
    avatars.forEach(avatar => {{
      const avatarRect = avatar.getBoundingClientRect();
      const branch = document.createElement('span');
      branch.className = 'party-link-branch';
      branch.setAttribute('aria-hidden', 'true');
      branch.style.setProperty('--party-color', color);
      branch.style.left = `${{lineX}}px`;
      branch.style.top = `${{avatarRect.top - groupRect.top + avatarRect.height / 2}}px`;
      branch.style.width = `${{Math.max(5, avatarRect.left - groupRect.left - lineX + 2)}}px`;
      sideGroup.appendChild(branch);
    }});
  }});
}}
function teamSideLabel(team) {{
  const raw = String(team || '-');
  if (!selfTeam || raw === '-') return raw;
  return raw.toLowerCase() === String(selfTeam).toLowerCase() ? '我方' : '敌方';
}}
function teamSideText(team) {{
  const raw = String(team || '-');
  return teamSideLabel(raw);
}}
function scrollToPlayer(index) {{
  const target = document.getElementById(`player-${{index}}`) || document.getElementById(`slot-${{index}}`);
  if (target) target.scrollIntoView({{behavior: 'smooth', block: 'start'}});
}}
function updateNavState(row) {{
  const nav = document.getElementById(`nav-${{row.index}}`);
  if (!nav) return;
  nav.classList.remove('loaded', 'error');
  const state = nav.querySelector('.nav-state-text');
  const rank = nav.querySelector('.nav-rank');
  const loadedRank = String(
    row.player?.display_rank ||
    (Array.isArray(row.battles) ? row.battles.find(battle => battle?.rank && battle.rank !== '-')?.rank : '') ||
    '-'
  );
  if (row.status === 'done') {{
    nav.classList.add('loaded');
    if (state) state.textContent = `${{row.battle_count || 0}} 场已加载`;
    if (rank) {{
      const known = loadedRank !== '-';
      rank.textContent = known ? loadedRank : '暂无段位';
      rank.title = known ? `当前段位：${{loadedRank}}` : '暂未获取到当前段位';
      rank.classList.remove('pending');
      rank.classList.toggle('unknown', !known);
    }}
  }} else if (row.status === 'error') {{
    nav.classList.add('error');
    if (state) state.textContent = '查询异常';
    if (rank) {{
      const known = loadedRank !== '-';
      rank.textContent = known ? loadedRank : '段位未知';
      rank.title = known ? `当前段位：${{loadedRank}}` : '段位查询暂时不可用';
      rank.classList.remove('pending');
      rank.classList.toggle('unknown', !known);
    }}
  }} else if (row.status === 'loading') {{
    if (state) state.textContent = '查询中';
    if (rank) {{
      rank.textContent = '段位…';
      rank.title = '段位加载中';
      rank.classList.add('pending');
      rank.classList.remove('unknown');
    }}
  }}
}}
function renderPartyInference(data) {{
  const toggleEl = document.getElementById('party-toggle');
  const bodyEl = document.getElementById('party-body');
  if (!toggleEl || !bodyEl) return;
  if (data.status !== 'done') {{
    partyAnalysisReady = false;
    toggleEl.disabled = true;
    toggleEl.textContent = '分析中';
    bodyEl.textContent = '等待近期战绩加载完成后分析。';
    return;
  }}
  const groups = inferParties(data.rows || []);
  const partyGroups = groups.filter(group => group.allyCount > 0 && group.allyCount >= group.enemyCount);
  const clusters = buildPartyClusters(partyGroups);
  latestPartyGroups = partyGroups;
  partyAnalysisReady = true;
  toggleEl.disabled = false;
  toggleEl.textContent = partyRevealed ? '收起组队分析' : '查看疑似组队';
  requestAnimationFrame(() => renderSidebarPartyLinks(latestPartyGroups));
  if (!clusters.length) {{
    bodyEl.className = 'empty';
    bodyEl.textContent = '近 10 场没有发现同队共同对局，暂未推断出组队关系。';
    return;
  }}
  bodyEl.className = 'table-wrap';
  bodyEl.innerHTML = `<table style="min-width:1080px">
    <thead><tr><th>队伍</th><th>疑似组队</th><th>共同场次</th><th>友/敌</th><th>共同对局样例</th></tr></thead>
    <tbody>${{partyGroups.map(group => `<tr>
      <td>${{esc(teamSideText(group.team))}}</td>
      <td><strong>${{esc(group.a)}}</strong> <span class="muted">和</span> <strong>${{esc(group.b)}}</strong></td>
      <td>${{group.count}}</td>
      <td>友方 ${{group.allyCount}} / 敌方 ${{group.enemyCount}}</td>
      <td>${{group.samples.map(item => `<div><strong>${{esc(item.relation)}}</strong>｜${{esc(item.time)}}｜${{esc(item.leftAgent)}}（${{esc(item.leftResult)}}） vs ${{esc(item.rightAgent)}}（${{esc(item.rightResult)}}）</div>`).join('')}}</td>
    </tr>`).join('')}}</tbody>
  </table>`;
}}
function setPartyRevealed(revealed) {{
  if (!partyAnalysisReady) return;
  partyRevealed = Boolean(revealed);
  const toggleEl = document.getElementById('party-toggle');
  const bodyEl = document.getElementById('party-body');
  if (!toggleEl || !bodyEl) return;
  toggleEl.setAttribute('aria-expanded', String(partyRevealed));
  toggleEl.textContent = partyRevealed ? '收起组队分析' : '查看疑似组队';
  bodyEl.hidden = !partyRevealed;
  if (partyRevealed) {{
    requestAnimationFrame(() => renderSidebarPartyLinks(latestPartyGroups));
  }}
}}
async function tick() {{
  try {{
    const res = await fetch(taskPath, {{cache: 'no-store'}});
    const data = await res.json();
    document.getElementById('progress').textContent = `${{data.done}}/${{data.total}} 已加载`;
    for (const row of data.rows) {{
      updateNavState(row);
      const el = document.getElementById(`slot-${{row.index}}`);
      if (!el || !row.html || filled.has(row.index)) continue;
      el.outerHTML = row.html;
      filled.add(row.index);
    }}
    renderPartyInference(data);
    if (data.status === 'done') {{
      clearInterval(timer);
      {save_task_line}
    }}
  }} catch (err) {{
    document.getElementById('progress').textContent = '连接本地服务失败';
  }}
}}
const timer = setInterval(tick, 1000);
window.addEventListener('resize', () => {{
  if (partyAnalysisReady && latestPartyGroups.length) renderSidebarPartyLinks(latestPartyGroups);
}});
document.getElementById('party-toggle')?.addEventListener('click', () => {{
  setPartyRevealed(!partyRevealed);
}});
document.querySelectorAll('.nav-player').forEach(button => {{
  button.addEventListener('click', () => scrollToPlayer(button.dataset.index));
}});
tick();
</script>
{public_battle_detail_script()}
</body>
</html>"""


def render_teammates_live(started: dict[str, Any], *, public: bool = False) -> str:
    task_id = str(started.get("task_id") or "")
    teammates = started.get("teammates") if isinstance(started.get("teammates"), list) else []
    room = started.get("room") if isinstance(started.get("room"), dict) else {}
    session = started.get("session") if isinstance(started.get("session"), dict) else {}
    session_id = str(room.get("session_id") or session.get("id") or "")
    quoted_session = urllib.parse.quote(session_id)
    if public:
        refresh_href = "/live/room"
        all_players_href = "/live/match"
        room_status_url = "/api/public/current-room-status"
        task_path = f"/api/public/task/{task_id}"
    else:
        refresh_href = f"/teammates-live?session={quoted_session}" if session_id else "/teammates-live"
        all_players_href = f"/assistant-live?session={quoted_session}" if session_id else "/admin/live"
        room_status_url = str(started.get("room_status_url") or "")
        task_path = f"/api/task/{task_id}"
    placeholders = []
    for idx, player in enumerate(teammates):
        subject = str(player.get("subject") or "")
        name = player.get("name") or subject
        identity = ["匹配队友" if player.get("member_kind") == "matched" else "房间成员"]
        if player.get("is_owner"):
            identity.append("房主")
        player_rank = rank_name(player.get("itier_rank"))
        if player_rank != "-":
            identity.append(player_rank)
        identity_text = " / ".join(identity) or "房间成员"
        waiting_text = (
            f"{esc(identity_text)} / 等待查询"
            if public
            else f"{esc(identity_text)} / 等待查询 / <code>{esc(subject)}</code>"
        )
        placeholders.append(
            f"""<section id="slot-{idx}" class="panel">
              <div class="player-head">
                <div>
                  <h2>{esc(name)}</h2>
                  <p>{waiting_text}</p>
                </div>
                <div class="record">等待</div>
              </div>
              <div class="empty">正在读取最近 3 场战绩。</div>
            </section>"""
        )
    if not placeholders:
        placeholders.append(
            """<section class="panel">
              <div class="empty">当前只有你。页面会持续监听，房间成员加入或匹配补进队友后自动加载近 3 场。</div>
            </section>"""
        )
    room_text = (
        f"房间 {room.get('member_count') or 1} 人 / "
        f"匹配补充 {room.get('matched_member_count') or 0} 人"
    )
    if public:
        head_html = public_head(
            "无畏契约房间队友近3场_WGame VAL",
            "实时查看无畏契约组队房间成员近3场战绩，成员加入退出自动同步，匹配后补齐同阵营玩家。",
            canonical_path="/live",
            index=False,
        )
        style = PUBLIC_CSS
        body_class = ' class="public-page"'
        site_header = public_site_header("live")
        topbar = (
            f'<div class="topbar"><a href="/live">实时功能</a>'
            f'<a href="{esc(refresh_href)}">刷新房间</a>'
            f'<a href="{esc(all_players_href)}">当前对局 10 人</a></div>'
        )
    else:
        head_html = '<meta charset="utf-8"><title>组队房间与匹配队友近3场</title>'
        style = PUBLIC_CSS
        body_class = ""
        site_header = ""
        topbar = (
            f'<div class="topbar"><a href="/">返回查询</a><a href="/admin/live">全部实时对局</a>'
            f'<a href="{esc(refresh_href)}">刷新房间</a>'
            f'<a href="{esc(all_players_href)}">全部10人</a></div>'
        )
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
{head_html}
  <style>{style}</style>
  <style>
    .reply-box {{ margin: 0 18px 18px; padding: 14px; border: 1px solid var(--line); background: #101923; color: #d9f3ff; white-space: pre-wrap; word-break: break-word; font: 13px/1.65 Consolas, "Cascadia Mono", monospace; }}
    .reply-actions {{ display: flex; justify-content: flex-end; padding: 0 18px 12px; }}
  </style>
</head>
<body{body_class}>
{site_header}
<main>
  {topbar}
  <section class="panel">
    <div class="player-head">
      <div>
        <h1>组队房间与匹配队友近3场</h1>
        <p id="room-status">{esc(room_text)} / 已排除自己；匹配前后持续同步。</p>
      </div>
      <div id="progress" class="record">0/{len(teammates)} 已加载</div>
    </div>
  </section>
  <section id="reply-panel" class="panel" hidden>
    <div class="player-head">
      <div><h2>群聊回复</h2><p>全部查询完成后生成。</p></div>
      <div class="record">可复制</div>
    </div>
    <div class="reply-actions"><button id="copy-reply" class="small-link" type="button">复制回复</button></div>
    <pre id="reply" class="reply-box"></pre>
  </section>
  <div id="slots">{''.join(placeholders)}</div>
</main>
<script>
const taskId = {json.dumps(task_id)};
const taskPath = {json.dumps(task_path)};
const roomStatusUrl = {json.dumps(room_status_url)};
const initialMemberSignature = {json.dumps(room.get("member_signature") or "")};
const refreshHref = {json.dumps(refresh_href)};
const filled = new Set();
let replyText = '';
async function tick() {{
  try {{
    const res = await fetch(taskPath, {{cache: 'no-store'}});
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '任务读取失败');
    document.getElementById('progress').textContent = `${{data.done}}/${{data.total}} 已加载`;
    for (const row of data.rows || []) {{
      const slot = document.getElementById(`slot-${{row.index}}`);
      if (!slot || !row.html || filled.has(row.index)) continue;
      slot.outerHTML = row.html;
      filled.add(row.index);
    }}
    if (data.status === 'done') {{
      clearInterval(timer);
      replyText = data.reply || '';
      if (replyText && data.total > 0) {{
        document.getElementById('reply').textContent = replyText;
        document.getElementById('reply-panel').hidden = false;
      }}
    }}
  }} catch (err) {{
    document.getElementById('progress').textContent = '查询连接失败';
  }}
}}
async function checkRoom() {{
  try {{
    const res = await fetch(roomStatusUrl, {{cache: 'no-store'}});
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data.error || '房间状态读取失败');
    const current = data.room || {{}};
    document.getElementById('room-status').textContent =
      `房间 ${{current.member_count ?? '-'}} 人 / 匹配补充 ${{current.matched_member_count || 0}} 人 / 已排除自己；正在监听成员变化。`;
    if (current.member_signature && current.member_signature !== initialMemberSignature) {{
      clearInterval(timer);
      clearInterval(roomTimer);
      document.getElementById('progress').textContent = '成员有变化，正在同步';
      const separator = refreshHref.includes('?') ? '&' : '?';
      setTimeout(() => location.replace(`${{refreshHref}}${{separator}}t=${{Date.now()}}`), 500);
    }}
  }} catch (err) {{
    document.getElementById('room-status').textContent = '房间连接暂时中断，正在等待恢复。';
  }}
}}
document.getElementById('copy-reply').addEventListener('click', async event => {{
  if (!replyText) return;
  await navigator.clipboard.writeText(replyText);
  event.currentTarget.textContent = '已复制';
  setTimeout(() => event.currentTarget.textContent = '复制回复', 1200);
}});
const timer = setInterval(tick, 1000);
const roomTimer = setInterval(checkRoom, 3000);
tick();
checkRoom();
</script>
{public_battle_detail_script()}
</body>
</html>"""


def recent_cache_rows_html(limit: int = 50) -> str:
    rows = []
    for row in list_subjects(limit):
        updated = ""
        try:
            updated = time.strftime("%m-%d %H:%M", time.localtime(int(row.get("updated_at") or 0)))
        except Exception:
            updated = "-"
        query_link = query_href(row["name"])
        loc_info = player_location_info(row["name"], allow_query=False)
        rows.append(
            f"""<tr>
              <td class="cache-name"><a href="{esc(query_link)}">{esc(row['name'])}</a></td>
              <td class="cache-subject"><code>{esc(row['subject'])}</code></td>
              <td class="cache-location">{esc(location_text(loc_info))}</td>
              <td class="cache-source">{esc(row.get('source'))}</td>
              <td class="cache-time">{esc(updated)}</td>
              <td class="cache-actions">
                <a class="small-link" href="{esc(query_link)}">打开战绩</a>
                <button class="small-link" type="button" data-copy="{esc(row['subject'])}">复制</button>
              </td>
            </tr>"""
        )
    if not rows:
        return '<tr><td colspan="6" class="empty">还没有缓存。先添加好友或导入抓包。</td></tr>'
    return "".join(rows)


def detail_score_text(player: dict[str, Any]) -> str:
    score = player.get("statsScore", player.get("score"))
    rounds = to_int(player.get("statsRoundsPlayed") or player.get("roundsPlayed"))
    if score is None:
        return "-"
    if rounds:
        try:
            return f"{round(float(score) / rounds)} ACS / {score} 分"
        except (TypeError, ValueError):
            pass
    return str(score)


def detail_player_row(player: dict[str, Any], subject: str) -> str:
    is_target = player.get("subject") == subject
    name = player.get("name") or player.get("nickname") or player.get("subject")
    marker = " / 查询目标" if is_target else ""
    return f"""<tr>
      <td class="hero">{esc(name)}{esc(marker)}</td>
      <td>{esc(agent_name(player.get('characterId') or player.get('character')))}</td>
      <td>{esc(rank_name(player.get('competitiveTier')))}</td>
      <td>{esc(detail_kda_text(player))}</td>
      <td>{esc(detail_score_text(player))}</td>
    </tr>"""


def detail_players_table(players: list[dict[str, Any]], subject: str, team_id: str) -> str:
    rows = "".join(
        detail_player_row(player, subject)
        for player in players
        if str(player.get("teamId") or player.get("team") or "-").lower() == team_id.lower()
    )
    if not rows:
        rows = '<tr><td colspan="5" class="empty">没有这一队的玩家数据。</td></tr>'
    team_label = "蓝方" if team_id.lower() == "blue" else "红方" if team_id.lower() == "red" else team_id
    return f"""<div class="team-title">{esc(team_label)}</div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>玩家</th><th>英雄</th><th>段位</th><th>K/D/A</th><th>分数</th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </div>"""


def public_detail_player_row(player: dict[str, Any], subject: str) -> str:
    is_target = str(player.get("subject") or "").lower() == subject.lower()
    name = player.get("name") or player.get("nickname") or "未知玩家"
    character_id = player.get("characterId") or player.get("character")
    agent = agent_name(character_id)
    icon_href = agent_icon_href(character_id)
    image_html = (
        f'<img src="{esc(icon_href)}" alt="{esc(agent)}" loading="lazy">'
        if icon_href
        else '<span aria-hidden="true">VAL</span>'
    )
    target_class = " target-player" if is_target else ""
    marker = '<span class="target-badge">查询目标</span>' if is_target else ""
    headshot = percent_text(player.get("match_head_shot_rate"))
    return f"""<div class="public-detail-player{target_class}">
      <div class="detail-player-agent">{image_html}</div>
      <div class="detail-player-identity">
        <strong>{esc(name)}{marker}</strong>
        <span>{esc(agent)} · {esc(rank_name(player.get('competitiveTier')))}</span>
      </div>
      <div class="detail-player-metric"><span>K / D / A</span><strong>{esc(detail_kda_text(player))}</strong></div>
      <div class="detail-player-metric detail-player-acs"><span>ACS / 分数</span><strong>{esc(detail_score_text(player))}</strong></div>
      <div class="detail-player-metric detail-player-hs"><span>爆头率</span><strong>{esc(headshot)}</strong></div>
    </div>"""


def public_detail_team_name(team_id: str) -> str:
    normalized = team_id.strip().lower()
    if normalized == "blue":
        return "蓝方"
    if normalized == "red":
        return "红方"
    return team_id or "队伍"


def public_detail_team_table(players: list[dict[str, Any]], subject: str, team_id: str) -> str:
    team_players = [
        player
        for player in players
        if str(player.get("teamId") or player.get("team") or "-").lower() == team_id.lower()
    ]
    outcome = result_name(team_players[0].get("wonMatch")) if team_players else "-"
    outcome_class = "loss" if outcome == "失败" else ""
    rows = "".join(public_detail_player_row(player, subject) for player in team_players)
    if not rows:
        rows = '<div class="result-empty">没有这一队的玩家数据。</div>'
    return f"""<section class="public-detail-team">
      <div class="public-detail-team-title">
        <span>{esc(public_detail_team_name(team_id))}</span>
        <span class="{outcome_class}">{esc(outcome)} · {len(team_players)} 人</span>
      </div>
      <div class="public-detail-player-list">{rows}</div>
    </section>"""


def render_public_battle_detail_fragment(
    subject: str,
    battle: dict[str, Any],
    detail: dict[str, Any],
) -> str:
    players = detail.get("players") if isinstance(detail.get("players"), list) else []
    target = next(
        (player for player in players if str(player.get("subject") or "").lower() == subject.lower()),
        {},
    )
    teams: list[str] = []
    for player in players:
        team_id = str(player.get("teamId") or player.get("team") or "-")
        if team_id not in teams:
            teams.append(team_id)

    stats = [
        ("地图", map_name(detail.get("mapId") or detail.get("mapID") or detail.get("MapID") or battle.get("mapId"))),
        ("结果", result_name(battle.get("wonMatch"))),
        ("比分", score_text(battle)),
        ("时长", duration_text(battle.get("gameLengthMillis"))),
        ("查询玩家英雄", agent_name(target.get("characterId") or target.get("character") or battle.get("characterId"))),
        ("查询玩家 K/D/A", detail_kda_text(target) or kda_text(battle)),
    ]
    tables = "".join(public_detail_team_table(players, subject, team_id) for team_id in teams)
    return f"""<div class="public-detail-head">
      <div><strong>单局详细记录</strong><span>{esc(battle.get('dtEventTime'))}</span></div>
      <span>{len(players)} 名玩家</span>
    </div>
    <div class="public-detail-grid">
      {''.join(f'<div class="public-detail-stat">{esc(label)}<strong>{esc(value)}</strong></div>' for label, value in stats)}
    </div>
    {tables}"""


def public_battle_detail_payload(detail_ref: str) -> tuple[dict[str, Any], int]:
    item = resolve_public_battle_detail_ref(detail_ref)
    if not item:
        return {"ok": False, "error": "详情引用已失效，请重新查询该玩家后再试。"}, 404

    subject = str(item.get("subject") or "")
    ap_event_id = str(item.get("ap_event_id") or "")
    battle = item.get("battle") if isinstance(item.get("battle"), dict) else {}
    ref_detail = item.get("detail")
    cached = load_cached_battle_details().get(ap_event_id)
    detail = ref_detail if isinstance(ref_detail, dict) else cached if isinstance(cached, dict) else None
    data: dict[str, Any] = {}
    if detail is None:
        data = browser_battle_detail(ap_event_id, subject)
        candidate = data.get("battle_detail") if isinstance(data, dict) else None
        if isinstance(candidate, dict):
            detail = candidate

    players = detail.get("players") if isinstance(detail, dict) else None
    if not isinstance(players, list) or not players:
        try:
            fallback = browser_matchup_detail(ap_event_id, subject, battle)
            candidate = fallback.get("battle_detail") if isinstance(fallback, dict) else None
            fallback_players = candidate.get("players") if isinstance(candidate, dict) else None
            if isinstance(fallback_players, list) and fallback_players:
                detail = candidate
                players = fallback_players
                data = fallback
        except Exception:
            pass
    if not isinstance(players, list) or not players:
        result = data.get("result") if isinstance(data, dict) else None
        code = result.get("error_code") if isinstance(result, dict) else result
        if to_int(code) == 8025004:
            message = "WeGame 登录态已失效，管理员重新登录后即可恢复单局详情。"
        elif to_int(code) == 8000009:
            message = "WeGame 当前只开放了这局的基础战绩，完整 10 人详情暂不可用。"
        else:
            message = "该局完整详情暂时没有返回，请稍后重试。"
        return {"ok": False, "error": message}, 409

    detail = enrich_battle_detail_headshots(detail, battle)
    cache_public_battle_detail_ref(detail_ref, detail)
    return {
        "ok": True,
        "html": render_public_battle_detail_fragment(subject, battle, detail),
    }, 200


def battle_summary_from_list(subject: str, ap_event_id: str) -> dict[str, Any] | None:
    """从战绩列表查找目标对局，带重试和递增查询量"""
    for retry, size in enumerate([10, 20, 30]):
        try:
            data = browser_api_query(subject, size)
        except Exception:
            if retry < 2:
                time.sleep(1.0 * (retry + 1))
                continue
            return None
        battles = data.get("battles") if isinstance(data, dict) else None
        if not isinstance(battles, list):
            if retry < 2:
                time.sleep(1.0 * (retry + 1))
                continue
            return None
        match = next((battle for battle in battles if battle.get("apEventId") == ap_event_id), None)
        if match:
            return match
        if retry < 2:
            time.sleep(1.0 * (retry + 1))
    return None


def render_battle_detail_limited(subject: str, ap_event_id: str, code: Any, message: Any) -> str:
    battle = battle_summary_from_list(subject, ap_event_id) or {}
    login_expired = to_int(code) == 8025004 or "登录信息过期" in str(message)
    title = "WeGame 登录信息过期" if login_expired else "单局详情受限"
    record = "需要重新登录" if login_expired else "基础数据"
    help_text = (
        "这不是单局详情权限问题，而是专用 Chrome 里的 WeGame 登录态失效。点“启动登录 Chrome”重新登录后，回到这个页面刷新即可重新请求单局详情。"
        if login_expired
        else "这局的完整 10 人详情接口没有放行；如果你在 WeGame 页面里点开过这局并被抓包，工具会优先显示缓存到的完整详情。"
    )
    action_html = (
        f"""<div class="topbar" style="justify-content:flex-start;margin:12px 18px 0">
      <a class="btn primary" href="/launch-chrome">启动登录 Chrome</a>
      <a class="btn" href="/battle?subject={esc(urllib.parse.quote(subject))}&apEventId={esc(urllib.parse.quote(ap_event_id))}">刷新本页</a>
    </div>"""
        if login_expired
        else ""
    )
    detail_grid = [
        ("subject", subject),
        ("apEventId", ap_event_id),
        ("结果", result_name(battle.get("wonMatch"))),
        ("比分", score_text(battle) if battle else "-"),
        ("英雄", agent_name(battle.get("characterId")) if battle else "-"),
        ("K/D/A", kda_text(battle) if battle else "-"),
        ("地图", map_name(battle.get("mapId")) if battle else "-"),
        ("段位", rank_name(battle.get("competitiveTier")) if battle else "-"),
        ("RR", rr_text(battle.get("CompetitiveTierRankedRatingEarned")) if battle else "-"),
    ]
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>{esc(title)} - {esc(ap_event_id)}</title>
  <style>{APP_CSS}</style>
</head>
<body>
<main>
  <div class="topbar"><a href="javascript:history.back()">返回上一页</a><a href="/">返回查询</a></div>
  <section class="panel">
    <div class="player-head">
      <div>
        <h1>{esc(title)}</h1>
        <p>WeGame 返回：code={esc(code)} {esc(message)}</p>
      </div>
      <div class="record">{esc(record)}</div>
    </div>
    {action_html}
    <div class="detail-grid">
      {''.join(f'<div class="stat">{esc(k)}<strong>{esc(v)}</strong></div>' for k, v in detail_grid)}
    </div>
    <div class="empty">{esc(help_text)}</div>
  </section>
</main>
</body>
</html>"""


def render_battle_detail(subject: str, ap_event_id: str, data: dict[str, Any]) -> str:
    result = data.get("result") if isinstance(data, dict) else None
    code = result.get("error_code") if isinstance(result, dict) else result
    message = result.get("error_message") if isinstance(result, dict) else ""
    detail = data.get("battle_detail") if isinstance(data, dict) else None
    if code not in (0, None) or not isinstance(detail, dict):
        return render_battle_detail_limited(subject, ap_event_id, code, message)

    players = detail.get("players") if isinstance(detail.get("players"), list) else []
    teams = []
    for player in players:
        team = str(player.get("teamId") or player.get("team") or "-")
        if team not in teams:
            teams.append(team)
    if not teams:
        teams = ["Blue", "Red"]

    target = next((player for player in players if player.get("subject") == subject), {})
    detail_grid = [
        ("地图", map_name(detail.get("mapId") or detail.get("mapID") or detail.get("MapID"))),
        ("查询玩家", target.get("name") or target.get("subject") or subject),
        ("英雄", agent_name(target.get("characterId") or target.get("character"))),
    ]
    tables = "".join(detail_players_table(players, subject, team) for team in teams)
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>单局详情</title>
  <style>{APP_CSS}</style>
</head>
<body>
<main>
  <div class="topbar"><a href="javascript:history.back()">返回上一页</a><a href="/">返回查询</a></div>
  <section class="panel">
    <div class="player-head">
      <div>
        <h1>单局详情</h1>
      </div>
      <div class="record">{len(players)} 名玩家</div>
    </div>
    <div class="detail-grid">
      {''.join(f'<div class="stat">{esc(k)}<strong>{esc(v)}</strong></div>' for k, v in detail_grid)}
    </div>
    {tables}
  </section>
</main>
</body>
</html>"""


def render_index(message: str = "") -> str:
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>无畏契约战绩查询</title>
  <style>{APP_CSS}</style>
</head>
<body>
<main>
  <div class="topbar"><a href="/admin/live">全部实时对局</a><span>WeGame VAL 查询 <span id="wg-status" style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#8fa5ba;vertical-align:middle;margin-left:6px" title="检测中..."></span></span></div>
  <form class="panel" method="get" action="/query">
    <h1>无畏契约战绩查询</h1>
    <input name="q" placeholder="输入 昵称#数字 或 subject" autofocus>
    <button class="primary" type="submit">查询近 10 场</button>
    <a class="btn" href="/admin/name-search">只知道昵称？搜索全部 #ID</a>
    <a class="btn" href="/admin/live">全部实时对局</a>
    <a class="btn" href="/teammates-live">房间/匹配近3场</a>
    <a class="btn" href="/assistant">缓存助手页</a>
    <a class="btn" href="/scan-alias-captures">扫描好友添加抓包</a>
    <a class="btn" href="/launch-chrome">启动登录 Chrome</a>
    <a class="btn" href="/import-default">导入缓存</a>
    <p class="msg">{esc(message)}</p>
  </form>
  <script>
  (function checkWegame() {{
    fetch('/api/wegame-session-status')
      .then(r => r.json())
      .then(d => {{
        var dot = document.getElementById('wg-status');
        if (dot) {{
          dot.style.background = d.healthy ? '#31f08c' : '#ff3f68';
          dot.title = d.message;
        }}
      }})
      .catch(() => {{}});
    setTimeout(checkWegame, 60000);
  }})();
  </script>
  <form class="panel" method="get" action="/probe-current-match">
    <h2>subject 当前对局探测</h2>
    <input name="subject" placeholder="输入另一个 QQ 的 subject">
    <button type="submit">探测并生成助手页</button>
  </form>
  <div class="panel">
    <div class="player-head">
      <div><h2>最近缓存</h2><p>已识别过的 昵称#ID 和 subject。这里会自动刷新。</p></div>
      <div class="record">最新 50 条</div>
    </div>
    <div class="table-wrap">
      <table class="cache-table">
        <thead><tr><th class="cache-name">昵称</th><th class="cache-subject">subject</th><th class="cache-location">IP属地</th><th class="cache-source">来源</th><th class="cache-time">更新时间</th><th class="cache-actions">操作</th></tr></thead>
        <tbody id="recent-cache">{recent_cache_rows_html()}</tbody>
      </table>
    </div>
  </div>
</main>
<script>
async function refreshRecentCache() {{
  try {{
    const res = await fetch('/api/recent-cache', {{cache: 'no-store'}});
    document.getElementById('recent-cache').innerHTML = await res.text();
  }} catch (err) {{}}
}}
document.addEventListener('click', async (event) => {{
  const button = event.target.closest('[data-copy]');
  if (!button) return;
  await navigator.clipboard.writeText(button.dataset.copy);
  button.textContent = '已复制';
  setTimeout(() => button.textContent = '复制', 1000);
}});
setInterval(refreshRecentCache, 2000);
</script>
</body>
</html>"""




def render_nickname_scan_admin() -> str:
    return """<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow,noarchive">
  <title>管理员 · 同昵称账号搜索</title>
  <style>""" + APP_CSS + """
  .search-shell{max-width:880px;margin:0 auto}
  .name-search{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;margin-top:18px}
  .name-search input{width:100%;box-sizing:border-box;font-size:17px;padding:13px 15px}
  .name-search button{min-width:138px}
  .summary-grid{display:grid;grid-template-columns:repeat(4,minmax(120px,1fr));gap:10px;margin:16px 0}
  .summary-card{padding:14px;border:1px solid #2b4052;border-radius:9px;background:#0b151f;color:#8fa5ba;font-size:12px}
  .summary-card strong{display:block;color:#eef8ff;font-size:22px;margin-top:5px}
  .results-toolbar{display:flex;align-items:flex-end;justify-content:space-between;gap:12px;flex-wrap:wrap;margin:14px 0}
  .filter-controls{display:flex;align-items:flex-end;gap:10px;flex:1;flex-wrap:wrap}
  .filter-controls input{width:min(260px,100%);margin:0}
  .filter-control{display:grid;gap:5px;color:#8fa5ba;font-size:12px}
  .filter-control select{min-width:150px;margin:0}
  .pager{display:flex;align-items:center;gap:9px;color:#91a9bb}
  .cap-note{padding:12px 14px;border:1px solid #735e2c;border-radius:8px;background:#18150c;color:#ffd36e;line-height:1.6}
  .result-name{font-size:15px;color:#eef8ff}
  .copy-button{white-space:nowrap}
  @media(max-width:650px){.name-search{grid-template-columns:1fr}.name-search button{width:100%}.summary-grid{grid-template-columns:1fr}.results-toolbar,.filter-controls{align-items:stretch;flex-direction:column}.filter-controls input,.filter-control,.filter-control select{width:100%}.pager{justify-content:space-between}}
  </style>
</head>
<body>
<main>
  <div class="topbar"><a href="/">返回管理首页</a><span>管理员 · 同昵称账号搜索</span></div>
  <section class="panel search-shell">
    <h1>输入昵称，找出同名的全部账号</h1>
    <p>只比较 <strong>#</strong> 前面的昵称，要求与输入完全一致；<strong>#ID</strong> 不限制数字、字母或位数。搜索到的映射会自动写入本地缓存。</p>
    <form id="name-search" class="name-search">
      <input id="nickname" maxlength="32" placeholder="例如：小苹果" autocomplete="off" required autofocus>
      <button id="search-button" class="primary" type="submit">搜索同名账号</button>
    </form>
    <p id="message" class="msg"></p>
  </section>

  <section id="results-panel" class="panel" hidden>
    <div class="player-head">
      <div><h2 id="result-title">搜索结果</h2><p id="result-subtitle"></p></div>
      <button id="copy-all" type="button">复制当前结果</button>
    </div>
    <div class="summary-grid">
      <div class="summary-card">接口返回<strong id="returned-count">0</strong></div>
      <div class="summary-card">昵称完全一致<strong id="exact-count">0</strong></div>
      <div class="summary-card">合并缓存后<strong id="result-count">0</strong></div>
      <div class="summary-card">段位查询<strong id="rank-progress">0 / 0</strong></div>
    </div>
    <p id="cap-note" class="cap-note" hidden></p>
    <div class="results-toolbar">
      <div class="filter-controls">
        <label class="filter-control"><span>筛选 #ID</span><input id="result-filter" placeholder="输入部分或完整 #ID"></label>
        <label class="filter-control"><span>段位</span><select id="rank-filter"><option value="all">全部段位</option><option value="ranked">仅已定级</option><option value="unranked">仅未定级</option><option value="unavailable">暂未获取</option></select></label>
        <label class="filter-control"><span>排序</span><select id="sort-order"><option value="id-asc">#ID 从小到大</option><option value="id-desc">#ID 从大到小</option><option value="rank-desc">段位从高到低</option><option value="rank-asc">段位从低到高</option></select></label>
        <button id="load-game-times" type="button">加载本页游戏时间</button>
        <button id="reset-filter" type="button">重置</button>
      </div>
      <div class="pager"><button id="prev-page" type="button">上一页</button><span id="page-text">1 / 1</span><button id="next-page" type="button">下一页</button></div>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>#</th><th>完整游戏 ID</th><th>当前段位</th><th>最近游戏</th><th>操作</th></tr></thead>
        <tbody id="result-rows"></tbody>
      </table>
    </div>
  </section>
</main>
<script>
let allResults=[],filteredResults=[],page=1,rankTaskId='',rankBySubject={},rankTimer=null;const pageSize=50;
const esc=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const tagCollator=new Intl.Collator('zh-CN',{numeric:true,sensitivity:'base'});
function rankTier(item){
  const value=(rankBySubject[item.subject]||{}).tier;
  return value===null||value===undefined||value===''?null:Number(value);
}
function refreshRankOptions(){
  const select=document.getElementById('rank-filter'),current=select.value;
  const tiers=new Map();
  Object.values(rankBySubject).forEach(item=>{if(item&&item.tier!==null&&item.tier!==undefined)tiers.set(Number(item.tier),item.rank);});
  const exact=[...tiers.entries()].sort((a,b)=>b[0]-a[0]).map(([tier,name])=>`<option value="tier:${tier}">${esc(name)}</option>`).join('');
  select.innerHTML='<option value="all">全部段位</option><option value="ranked">仅已定级</option><option value="unranked">仅未定级</option><option value="unavailable">暂未获取</option>'+exact;
  select.value=[...select.options].some(option=>option.value===current)?current:'all';
}
function applyFilter(resetPage=true){
  const query=document.getElementById('result-filter').value.trim().toLocaleLowerCase();
  const rankFilter=document.getElementById('rank-filter').value;
  const sortOrder=document.getElementById('sort-order').value;
  filteredResults=allResults.filter(item=>{
    if(query&&!item.tag.toLocaleLowerCase().includes(query)&&!item.name.toLocaleLowerCase().includes(query))return false;
    const tier=rankTier(item),rank=rankBySubject[item.subject]||{};
    if(rankFilter==='ranked'&&!(tier!==null&&tier>0))return false;
    if(rankFilter==='unranked'&&tier!==0)return false;
    if(rankFilter==='unavailable'&&rank.status!=='unavailable'&&rank.status!=='pending')return false;
    if(rankFilter.startsWith('tier:')&&tier!==Number(rankFilter.slice(5)))return false;
    return true;
  });
  filteredResults.sort((a,b)=>{
    const idCompare=tagCollator.compare(a.tag,b.tag);
    if(sortOrder==='id-desc')return -idCompare;
    if(sortOrder==='id-asc')return idCompare;
    const aTier=rankTier(a),bTier=rankTier(b);
    if(aTier===null&&bTier!==null)return 1;if(aTier!==null&&bTier===null)return -1;
    if(aTier!==null&&bTier!==null&&aTier!==bTier)return sortOrder==='rank-desc'?bTier-aTier:aTier-bTier;
    return idCompare;
  });
  if(resetPage)page=1;renderRows();
}
function renderRows(){
  const pages=Math.max(1,Math.ceil(filteredResults.length/pageSize));page=Math.min(Math.max(1,page),pages);
  const start=(page-1)*pageSize,rows=filteredResults.slice(start,start+pageSize);
  document.getElementById('result-rows').innerHTML=rows.length?rows.map((item,index)=>`<tr>
    <td>${start+index+1}</td><td class="result-name"><strong>${esc(item.name)}</strong></td>
    <td><strong>${esc((rankBySubject[item.subject]||{}).rank||'查询中…')}</strong></td>
    <td>${esc((rankBySubject[item.subject]||{}).last_game_time||'')}</td>
    <td><button class="copy-button" type="button" data-copy="${esc(item.name)}">复制</button> <a class="btn" href="/query?q=${encodeURIComponent(item.name)}">战绩</a></td></tr>`).join('')
    :'<tr><td colspan="5" class="empty">没有符合当前筛选的结果。</td></tr>';
  document.getElementById('page-text').textContent=`${page} / ${pages}（${filteredResults.length} 条）`;
  document.getElementById('prev-page').disabled=page<=1;document.getElementById('next-page').disabled=page>=pages;
}
function applyRankTask(task){
  rankBySubject=task.ranks||{};
  document.getElementById('rank-progress').textContent=`${task.completed||0} / ${task.total||0}`;
  if(task.error)document.getElementById('message').textContent=`段位查询：${task.error}`;
  refreshRankOptions();applyFilter(false);
  if(task.status!=='running'&&rankTimer){clearTimeout(rankTimer);rankTimer=null;}
}
async function pollRanks(){
  if(!rankTaskId)return;
  try{const response=await fetch(`/api/admin/name-search-ranks?id=${encodeURIComponent(rankTaskId)}`,{cache:'no-store'});const task=await response.json();if(response.ok&&task.ok){applyRankTask(task);if(task.status==='running')rankTimer=setTimeout(pollRanks,1200);}}
  catch(error){rankTimer=setTimeout(pollRanks,2500);}
}
async function loadPageGameTimes(){
  const button=document.getElementById('load-game-times');
  if(button.disabled)return;
  const pageSubjects=filteredResults.slice((page-1)*pageSize,page*pageSize).map(item=>item.subject).filter(Boolean);
  if(!pageSubjects.length)return;
  button.disabled=true;button.textContent='加载中…';
  try{
    const response=await fetch('/api/admin/name-search-page-game-times',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({subjects:pageSubjects})});
    const data=await response.json();
    if(!response.ok||!data.ok)throw new Error(data.error||'加载失败');
    const times=data.game_times||{};
    for(const [subject,time] of Object.entries(times)){
      if(rankBySubject[subject])rankBySubject[subject].last_game_time=time||'';
      else rankBySubject[subject]={last_game_time:time||''};
    }
    applyFilter(false);
  }catch(error){
    document.getElementById('message').textContent=error.message;
  }finally{
    button.disabled=false;button.textContent='加载本页游戏时间';
  }
}
document.getElementById('name-search').addEventListener('submit',async event=>{
  event.preventDefault();const nickname=document.getElementById('nickname').value.trim();
  const button=document.getElementById('search-button'),message=document.getElementById('message');
  button.disabled=true;button.textContent='正在搜索…';message.textContent='';
  try{
    const response=await fetch('/api/admin/name-search',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({nickname})});
    const data=await response.json();if(!response.ok||!data.ok)throw new Error(data.error||'搜索失败');
    if(rankTimer){clearTimeout(rankTimer);rankTimer=null;}
    allResults=data.results||[];filteredResults=allResults.slice();page=1;rankTaskId=data.rank_task_id||'';rankBySubject={};
    document.getElementById('result-filter').value='';document.getElementById('rank-filter').value='all';document.getElementById('sort-order').value='id-asc';
    document.getElementById('results-panel').hidden=false;
    document.getElementById('result-title').textContent=`“${data.nickname}”的同名账号`;
    document.getElementById('result-subtitle').textContent=allResults.length?'点击“战绩”可直接查询对应账号。':'接口没有返回昵称完全一致的账号。';
    document.getElementById('returned-count').textContent=data.returned_count;
    document.getElementById('exact-count').textContent=data.exact_name_count;
    document.getElementById('result-count').textContent=data.count;
    const note=document.getElementById('cap-note');note.hidden=!data.truncated;
    note.textContent=data.truncated?`接口本次返回了 500 条，已达到单次返回上限。上游没有分页参数，因此不能证明这是该昵称在全服的绝对全部结果。${data.merged_extra_count?` 已额外合并本地缓存中的 ${data.merged_extra_count} 条记录。`:''}`:'';
    applyRankTask(data.rank_task||{ranks:{},completed:0,total:allResults.length,status:'completed'});
    if(rankTaskId&&(data.rank_task||{}).status==='running')rankTimer=setTimeout(pollRanks,500);
  }catch(error){message.textContent=error.message;}
  finally{button.disabled=false;button.textContent='搜索同名账号';}
});
document.getElementById('result-filter').addEventListener('input',applyFilter);
document.getElementById('rank-filter').addEventListener('change',applyFilter);
document.getElementById('sort-order').addEventListener('change',applyFilter);
document.getElementById('reset-filter').addEventListener('click',()=>{document.getElementById('result-filter').value='';document.getElementById('rank-filter').value='all';document.getElementById('sort-order').value='id-asc';applyFilter();});
document.getElementById('load-game-times').addEventListener('click',loadPageGameTimes);
document.getElementById('prev-page').addEventListener('click',()=>{page--;renderRows();});
document.getElementById('next-page').addEventListener('click',()=>{page++;renderRows();});
document.getElementById('result-rows').addEventListener('click',async event=>{const button=event.target.closest('[data-copy]');if(!button)return;await navigator.clipboard.writeText(button.dataset.copy);button.textContent='已复制';setTimeout(()=>button.textContent='复制',1200);});
document.getElementById('copy-all').addEventListener('click',async()=>{await navigator.clipboard.writeText(filteredResults.map(item=>item.name).join('\\n'));const button=document.getElementById('copy-all');button.textContent=`已复制 ${filteredResults.length} 条`;setTimeout(()=>button.textContent='复制当前结果',1500);});
</script>
</body>
</html>"""


def public_site_header(active: str = "") -> str:
    public_current = ' aria-current="page"' if active == "public" else ""
    live_current = ' aria-current="page"' if active == "live" else ""
    privacy_current = ' aria-current="page"' if active == "privacy" else ""
    return f"""<header class="site-header">
  <div class="site-header-inner">
    <a class="brand" href="/public" aria-label="WGame VAL Query 首页">
      <span class="brand-mark" aria-hidden="true">WV</span>
      <span class="brand-copy">
        <strong>WGame VAL Query</strong>
        <small>国服战绩查询</small>
      </span>
    </a>
    <nav class="site-nav" aria-label="主导航">
      <a href="/public"{public_current}>战绩查询</a>
      <a href="/privacy"{privacy_current}>隐私说明</a>
      <a class="live-link" href="/live"{live_current}>实时对局</a>
      <a href="/public">本地首页</a>
    </nav>
  </div>
</header>"""


def public_site_footer() -> str:
    return """<footer class="site-footer">
  <span>WGame VAL Query · 国服无畏契约战绩查询工具</span>
  <span><a href="/public">公共查询</a> · <a href="/live">实时对局</a> · <a href="/privacy">隐私说明</a> · <a href="/public">本地首页</a> · 非官方社区工具，不公开展示玩家真实 IP。</span>
</footer>"""


def render_public_privacy() -> str:
    retention = audit_retention_days()
    title = "隐私说明_WGame VAL Query"
    description = "WGame VAL Query 公共查询与实时对局功能的数据处理、保存期限和用户权利说明。"
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
{public_head(title, description, canonical_path="/privacy")}
  <style>{PUBLIC_CSS}</style>
</head>
<body class="public-page">
{public_site_header("privacy")}
<main id="main-content" class="public-main">
  <section class="query-intro" aria-labelledby="privacy-page-title">
    <p class="eyebrow">数据处理说明</p>
    <h1 id="privacy-page-title">隐私说明</h1>
    <p class="query-lead">这里说明公共查询和实时对局会记录哪些数据、为何记录、保存多久，以及如何联系我们处理相关请求。</p>
  </section>
  <section class="content-band" aria-labelledby="privacy-data-title">
    <div class="section-heading">
      <h2 id="privacy-data-title">记录的数据</h2>
      <p>数据仅用于提供功能、服务安全、滥用排查、故障定位和使用统计，不在公共页面展示访问者真实 IP。</p>
    </div>
    <table class="field-table">
      <tbody>
        <tr><th scope="row">公共查询</th><td>查询时间、访问 IP、提交的昵称#ID、解析到的游戏昵称和账号标识、查询成功或失败状态。</td></tr>
        <tr><th scope="row">实时对局</th><td>使用时间、访问 IP、游戏会话来源 IP、用户主动选择的游戏昵称和账号标识、访问的实时功能及处理结果。</td></tr>
        <tr><th scope="row">风险确认</th><td>协议版本、正文摘要、确认时间、随机确认编号以及经哈希处理的网络和浏览器环境摘要；该确认记录不保存原始 IP。</td></tr>
      </tbody>
    </table>
  </section>
  <section class="content-band" aria-labelledby="privacy-retention-title">
    <div class="section-heading">
      <h2 id="privacy-retention-title">保存与访问</h2>
      <p>公共查询和实时功能使用记录默认保存 {retention} 天，期限届满后自动删除。风险确认记录按照风险协议约定处理。</p>
    </div>
    <div class="privacy-note">使用审计数据库仅由运行本项目的本机控制中心访问，不通过公共查询页面或公开接口提供。项目维护者应限制电脑账户权限、及时安装安全更新并妥善保护备份。</div>
  </section>
  <section class="content-band" aria-labelledby="privacy-rights-title">
    <div class="section-heading">
      <h2 id="privacy-rights-title">查询、更正与删除</h2>
      <p>对个人信息处理有疑问，或需要依法查询、更正、删除相关记录，可通过 GitHub Issues 联系项目维护者。提出请求时请勿公开提交 Cookie、Token、抓包文件或其他登录凭据。</p>
    </div>
    <a class="live-cta" href="/privacy" rel="noopener noreferrer">联系项目维护者</a>
  </section>
</main>
{public_site_footer()}
</body>
</html>"""


def render_public_index(message: str = "", query: str = "") -> str:
    title = "无畏契约国服战绩查询_WGame VAL"
    description = (
        "无需添加游戏好友，输入无畏契约国服玩家昵称#ID，即可查询近10场排位的胜负、英雄、KDA、ACS、地图、段位和RR变化。"
        "WGame VAL Query 当前专注排位数据。"
    )
    schema = {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "WGame VAL Query",
        "url": f"{PUBLIC_SITE_URL}/public",
        "description": description,
        "applicationCategory": "GameApplication",
        "operatingSystem": "Web",
        "inLanguage": "zh-CN",
        "isAccessibleForFree": True,
        "potentialAction": {
            "@type": "SearchAction",
            "target": {
                "@type": "EntryPoint",
                "urlTemplate": f"{PUBLIC_SITE_URL}/public-query?q={{search_term_string}}",
            },
            "query-input": "required name=search_term_string",
        },
    }
    message_html = (
        f'<p class="query-message" role="alert">{esc(message)}</p>'
        if message
        else ""
    )
    demo_agents = [
        ("a3bfb853-43b2-7238-a4f1-ad90e9e46bcc", "芮娜", "4 场 · KDA 1.31"),
        ("add6443a-41bd-e414-f6ad-e58d267f4e95", "捷风", "3 场 · KDA 1.18"),
        ("320b2a48-4d9b-a075-30f1-1f93a9b638fa", "猎枭", "2 场 · KDA 1.42"),
    ]
    demo_agent_cards = "".join(
        f"""<div class="home-demo-agent">
          <img src="{esc(agent_icon_href(character_id))}" alt="{esc(name)}" loading="lazy">
          <span><strong>{esc(name)}</strong><small>{esc(meta)}</small></span>
        </div>"""
        for character_id, name, meta in demo_agents
    )
    demo_matches = [
        ("win", "add6443a-41bd-e414-f6ad-e58d267f4e95", "捷风", "胜利", "13:5", "23/11/6", "284", "juliett", "日落之城", "+22"),
        ("loss", "320b2a48-4d9b-a075-30f1-1f93a9b638fa", "猎枭", "失败", "8:13", "15/15/4", "200", "foxtrot", "微风岛屿", "-17"),
    ]
    demo_match_rows = "".join(
        f"""<div class="home-demo-match {result_class}" style="--match-map-art:url(&quot;{esc(map_art_href(map_key))}&quot;)">
          <img src="{esc(agent_icon_href(character_id))}" alt="{esc(agent)}" loading="lazy">
          <span class="home-demo-result"><b>{esc(result)}</b><strong>{esc(score)}</strong></span>
          <span><small>K / D / A</small><strong>{esc(kda)}</strong></span>
          <span><small>ACS</small><strong>{esc(acs)}</strong></span>
          <span class="home-demo-map"><small>地图</small><strong>{esc(map_label)}</strong></span>
          <span><small>RR</small><strong>{esc(rr)}</strong></span>
        </div>"""
        for result_class, character_id, agent, result, score, kda, acs, map_key, map_label, rr in demo_matches
    )
    preview_html = f"""
  <section class="home-product-preview" aria-labelledby="home-preview-title">
    <div class="home-preview-heading">
      <div><span class="section-kicker">WHAT YOU GET</span><h2 id="home-preview-title">查询后，一眼看懂近期状态</h2></div>
      <p>胜负、段位变化、常用英雄和每一场关键表现集中展示；详情可继续查看双方 10 名玩家。</p>
    </div>
    <div class="home-demo-shell" aria-label="战绩结果样式预览">
      <div class="home-demo-profile">
        <div><span class="section-kicker">示例结果</span><strong>示例玩家#12345</strong><small>近 10 场排位</small></div>
        <div class="home-demo-stats">
          <span><small>当前段位</small><strong>超凡 3</strong></span>
          <span><small>近期战绩</small><strong>5胜 5负</strong></span>
          <span><small>KDA</small><strong>1.32</strong></span>
          <span><small>ACS</small><strong>198</strong></span>
        </div>
      </div>
      <div class="home-demo-body">
        <div class="home-demo-agents"><span class="home-demo-label">常用英雄</span>{demo_agent_cards}</div>
        <div class="home-demo-history"><span class="home-demo-label">最近比赛</span>{demo_match_rows}</div>
      </div>
    </div>
    <div class="home-value-grid">
      <div><strong>无需好友关系</strong><span>知道完整昵称#ID即可查询，不要求先加好友。</span></div>
      <div><strong>只看排位重点</strong><span>近 10 场按时间排列，胜负、KDA、ACS、RR 清晰对比。</span></div>
      <div><strong>继续展开单局</strong><span>数据可用时，直接查看该局双方 10 人的英雄与表现。</span></div>
    </div>
  </section>
    """.strip()
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
{public_head(title, description, schema=schema)}
  <style>{PUBLIC_CSS}</style>
</head>
<body class="public-page public-home-page">
<a class="skip-link" href="#main-content">跳到查询</a>
{public_site_header("public")}
<main id="main-content" class="public-main">
  <section class="query-intro query-hero" aria-labelledby="query-title">
    <div class="query-hero-inner">
      <p class="eyebrow">无需添加好友 · 国服排位战绩查询</p>
      <h1 id="query-title">输入昵称<span class="query-title-accent">#ID</span>，立即看懂近期状态</h1>
      <p class="query-lead">无需登录，也不要求好友关系。只加载排位数据，快速查看近 10 场与每局双方详情。</p>
      <form class="query-form" method="get" action="/public-query">
        <label class="visually-hidden" for="player-query">玩家昵称#ID</label>
        <div class="search-row">
          <input
            class="query-input"
            id="player-query"
            name="q"
            value="{esc(query)}"
            placeholder="例如 示例玩家#12345"
            maxlength="80"
            autocomplete="off"
            spellcheck="false"
            aria-describedby="query-help"
            pattern=".+#[^#]+"
            title="请完整输入昵称、# 号和数字 ID，例如 示例玩家#12345"
            required
          >
          <button class="query-button" type="submit">查询战绩</button>
        </div>
        {message_html}
      </form>
      <div class="query-meta" id="query-help" aria-label="查询说明">
        <span>无需好友关系</span>
        <span>近 10 场排位</span>
        <span>支持双方 10 人详情</span>
      </div>
    </div>
  </section>

{preview_html}

</main>
{public_site_footer()}
</body>
</html>"""


def render_live_risk_agreement(
    nonce: str,
    next_path: str = "/live",
    message: str = "",
    *,
    index: bool = False,
    locked: bool = False,
) -> str:
    title = "实时对局风险知情与使用协议_WGame VAL"
    description = (
        "使用实时对局功能前，请阅读并确认网络流量处理、游戏账号限制或封禁、"
        "代理配置和用户行为责任等重要风险。"
    )
    message_html = (
        f'<p class="risk-form-message" role="alert">{esc(message)}</p>'
        if message
        else ""
    )
    if locked:
        confirm_panel = """<aside class="risk-confirm risk-locked" aria-labelledby="confirm-title">
      <div class="risk-locked-body">
        <p class="risk-locked-kicker">撤回已生效</p>
        <h2 id="confirm-title">当前浏览器已永久锁定实时功能</h2>
        <p>你此前选择了“一键撤回并永久锁定”。原确认记录已保留并追加撤回时间，本站不会再次向这个浏览器提供风险确认或实时对局入口。</p>
        <p>该锁定依赖当前浏览器保存的独立标识。本站没有账号体系，无法跨浏览器或在站点数据被主动清除后继续识别同一设备。</p>
        <a class="risk-decline risk-locked-return" href="/public">返回公共查询</a>
      </div>
    </aside>"""
    else:
        confirm_panel = f"""<aside class="risk-confirm" aria-labelledby="confirm-title">
      <form method="post" action="/live/agree" id="risk-consent-form">
        <h2 id="confirm-title">主动确认</h2>
        <p>以下三项必须由你本人逐项勾选。不同意不会影响公共战绩查询，但不能使用实时对局功能。</p>
        {message_html}
        <input type="hidden" name="nonce" value="{esc(nonce)}">
        <input type="hidden" name="next" value="{esc(next_path)}">
        <input type="hidden" name="version" value="{esc(LIVE_RISK_AGREEMENT_VERSION)}">
        <label class="risk-check">
          <input type="checkbox" name="capacity" value="yes" required>
          <span>我已年满 18 周岁并具备相应民事行为能力；我只会在本人所有或已获充分授权的账号、设备和网络上使用。</span>
        </label>
        <label class="risk-check">
          <input type="checkbox" name="ban_risk" value="yes" required>
          <span>我已理解本功能会处理网络流量，且即使有限测试中暂未发现封号，仍可能发生账号限制、临时或永久封禁及其他损失。</span>
        </label>
        <label class="risk-check">
          <input type="checkbox" name="responsibility" value="yes" required>
          <span>我已完整阅读并理解本协议，自愿使用本功能，并同意在法律允许的范围内自行承担因本人行为、配置及第三方处罚产生的风险和后果。</span>
        </label>
        <button class="risk-submit" type="submit" disabled>确认同意并进入实时对局</button>
        <a class="risk-decline" href="/public">不同意，返回公共查询</a>
        <p class="risk-record-note">提交后将生成版本化确认记录，有效期 180 天。本勾选确认不代表本站可以排除依法不得免责的责任。</p>
      </form>
    </aside>"""
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
{public_head(title, description, canonical_path="/live", index=index)}
  <style>{PUBLIC_CSS}</style>
</head>
<body class="public-page">
<a class="skip-link" href="#risk-agreement">跳到风险协议</a>
{public_site_header("live")}
<main id="risk-agreement" class="public-main risk-main">
  <section class="risk-hero" aria-labelledby="risk-title">
    <p class="eyebrow">使用前必须确认</p>
    <h1 id="risk-title">实时对局功能风险知情与使用协议</h1>
    <p class="risk-version">版本 {esc(LIVE_RISK_AGREEMENT_VERSION)} · 生效日期 {esc(LIVE_RISK_AGREEMENT_EFFECTIVE_DATE)}</p>
    <div class="risk-critical" role="alert">
      <strong>重要：有限测试中暂未发现封号，不代表使用本功能没有封号风险。</strong>
      <p>实时对局需要配置代理或证书，并采集、转发、读取和分析有关网络请求。游戏运营方或反作弊系统可能将其识别为异常，并可能采取警告、强制下线、功能限制、临时或永久封禁、设备限制等措施。</p>
    </div>
  </section>

  <section class="risk-layout" aria-label="协议正文与确认">
    <article class="risk-document">
      <div class="risk-document-head">
        <div>
          <span>完整协议</span>
          <strong>请逐条阅读，尤其是加粗的风险和责任范围</strong>
        </div>
        <button class="risk-print" type="button" onclick="window.print()">打印协议</button>
      </div>

      <section>
        <h2>一、重要风险提示</h2>
        <p>截至本协议版本发布日，本站仅在有限测试范围内暂未发现因使用实时对局功能直接导致游戏账号被封禁的情况。<strong>该测试结果不构成零风险承诺、安全保证、官方认可证明或对未来结果的预测。</strong></p>
        <p>实时对局功能需要在用户设备上配置代理或证书，并采集、转发、读取和分析与游戏实时状态有关的网络请求。此类行为可能被游戏运营方、反作弊系统、网络服务商或其他第三方识别为异常，并可能导致警告、强制下线、功能限制、数据异常、临时封禁、永久封禁、设备限制、网络故障或其他不利后果。</p>
      </section>

      <section>
        <h2>二、用户自主决定与合规义务</h2>
        <p>用户应当在充分理解风险后自主决定是否启用本功能，并自行核对、遵守游戏运营方现行的用户协议、反作弊规则及其他适用规则。用户仅可在本人所有或已获得充分授权的设备、网络和游戏账号上使用本功能。</p>
        <p><strong>用户不得将本功能用于作弊、篡改游戏、绕过安全机制、干扰服务、截取他人通信、侵犯他人权益或实施任何违法违规行为。</strong>用户对其安装证书、配置代理、使用查询结果以及其他操作行为独立负责。</p>
      </section>

      <section>
        <h2>三、责任范围</h2>
        <p>在适用法律允许的最大范围内，因用户主动启用或使用本功能、配置错误、未及时恢复网络设置、违反游戏运营方协议或规则、第三方检测或处罚、网络及设备环境变化等原因产生的账号限制或封禁、数据丢失、网络中断、财产损失及其他后果，由用户自行承担。</p>
        <p><strong>本站不保证功能持续可用、结果绝对准确、操作不会被识别或账号不会受到处罚，也不对游戏运营方或其他第三方独立作出的处理决定负责。</strong></p>
        <p>前述责任限制不适用于依法不得排除或限制的责任，包括因本站故意或重大过失造成的财产损失、造成用户人身损害的责任，以及法律法规规定不得免责的其他情形。本站将对自身依法应当承担的责任负责。</p>
      </section>

      <section>
        <h2>四、网络流量、确认记录与使用审计</h2>
        <p>为提供实时对局功能，相关游戏网络请求可能经过本站指定的代理链路并被自动处理。本站应按照功能所需的最小范围处理数据，不以本功能收集游戏账号密码。</p>
        <p>为证明用户已收到显著风险提示并作出主动确认，本站会保存协议版本、协议正文摘要、确认时间、随机确认编号，以及经哈希处理的网络和浏览器环境摘要；<strong>确认记录不保存原始 IP 地址</strong>。未撤回的确认记录最长保存 365 天，用于安全审计、争议处理和防止确认凭证被滥用，期限届满后删除或匿名化。</p>
        <p>为关联用户主动选择的实时游戏账号、保障服务安全、排查滥用并统计功能使用情况，本站另行保存使用时间、访问 IP、游戏会话来源 IP、所选游戏昵称和账号标识、访问的实时功能及处理结果，默认保存 {audit_retention_days()} 天。该使用审计记录与风险确认记录分开保存，仅限本机控制中心管理使用，不在公共页面展示。详情见<a href="/privacy">隐私说明</a>。</p>
      </section>

      <section>
        <h2>五、确认期限、更新与停止使用</h2>
        <p>本次确认有效期为 180 天。协议内容、数据处理方式或风险发生重要变化时，本站会要求用户重新确认。用户不同意本协议的，应停止使用实时对局功能且无需继续提交。</p>
        <p>用户可以随时点击实时页面的“一键撤回并永久锁定”。撤回后原确认记录不会删除，而会追加撤回时间并保留当前浏览器标识的哈希摘要，在实时功能持续提供期间用于执行不可恢复锁定和证明撤回事实。撤回后当前浏览器不能再次确认或使用实时功能，撤回不影响此前已完成处理的效力。</p>
        <p>由于本站没有用户账号体系，永久锁定依赖当前浏览器保存的独立标识；用户主动清除全部站点数据后，本站可能无法继续识别该浏览器。</p>
      </section>

      <section>
        <h2>六、第三方关系与联系</h2>
        <p>本站为非官方社区工具，与游戏开发商、发行商及运营方不存在隶属、授权、担保或背书关系。游戏名称及相关商标归各自权利人所有。</p>
        <p>本站运营者为 WGame VAL 项目维护者。对协议、确认记录或个人信息处理有疑问，可通过 <a href="/privacy" rel="noopener noreferrer">GitHub Issues</a> 联系。</p>
      </section>
    </article>

    {confirm_panel}
  </section>

  <section class="content-band live-preview-section" aria-labelledby="preview-title">
    <div class="section-heading live-section-heading">
      <div><span class="live-section-kicker">PREVIEW</span><h2 id="preview-title">功能效果预览</h2></div>
      <p>安装成功后，即可在浏览器中实时查看当前对局与玩家近期战绩。</p>
    </div>
    <ul class="live-preview-tabs" role="tablist" aria-label="效果预览">
      <li><button type="button" class="active" role="tab" aria-selected="true" data-preview-tab="0">桌面端对局</button></li>
      <li><button type="button" role="tab" aria-selected="false" data-preview-tab="1">手机端对局</button></li>
      <li><button type="button" role="tab" aria-selected="false" data-preview-tab="2">单局详情</button></li>
      <li><button type="button" role="tab" aria-selected="false" data-preview-tab="3">命中分析</button></li>
    </ul>
    <div class="live-preview-panels">
      <div class="live-preview-panel active" role="tabpanel" data-preview-panel="0">
        <div class="live-preview-frame"><p class="deploy-note">本地运行后，此处显示当前环境的功能结果。</p></div>
        <p class="live-preview-caption">桌面端浏览器中查看当前对局 10 人近期战绩</p>
      </div>
      <div class="live-preview-panel" role="tabpanel" data-preview-panel="1">
        <div class="live-preview-frame"><p class="deploy-note">本地运行后，此处显示当前环境的功能结果。</p></div>
        <p class="live-preview-caption">手机端同一网络下访问，查看双方阵容</p>
      </div>
      <div class="live-preview-panel" role="tabpanel" data-preview-panel="2">
        <div class="live-preview-frame"><p class="deploy-note">本地运行后，此处显示当前环境的功能结果。</p></div>
        <p class="live-preview-caption">单局 10 人完整数据，包括段位、K/D/A、ACS 与命中习惯</p>
      </div>
      <div class="live-preview-panel" role="tabpanel" data-preview-panel="3">
        <div class="live-preview-frame"><p class="deploy-note">本地运行后，此处显示当前环境的功能结果。</p></div>
        <p class="live-preview-caption">单局爆头率与击中部位分布（头 / 身 / 腿）</p>
      </div>
    </div>
  </section>
</main>
{public_site_footer()}
<script>
(() => {{
  const form = document.getElementById('risk-consent-form');
  if (!form) return;
  const boxes = Array.from(form.querySelectorAll('input[type="checkbox"]'));
  const submit = form.querySelector('button[type="submit"]');
  const update = () => {{ submit.disabled = !boxes.every(box => box.checked); }};
  boxes.forEach(box => box.addEventListener('change', update));
  update();
}})();

(function(){{
  const tabs = document.querySelectorAll('[data-preview-tab]');
  const panels = document.querySelectorAll('[data-preview-panel]');
  if (!tabs.length) return;
  tabs.forEach(tab => {{
    tab.addEventListener('click', () => {{
      const idx = tab.dataset.previewTab;
      tabs.forEach(t => {{
        t.classList.toggle('active', t === tab);
        t.setAttribute('aria-selected', t === tab ? 'true' : 'false');
      }});
      panels.forEach(p => {{
        p.classList.toggle('active', p.dataset.previewPanel === idx);
      }});
    }});
  }});
}})();
</script>
</body>
</html>"""


def render_public_live(
    session: dict[str, Any] | None = None,
    message: str = "",
    *,
    index: bool = True,
    sessions: list[dict[str, Any]] | None = None,
    viewer_key: str = "",
) -> str:
    title = "无畏契约实时排位查询_队友近3场_WGame VAL"
    description = (
        "无畏契约国服实时排位查询：开局前查看组队房间成员近3场排位，"
        "成员加入退出自动同步，匹配后补齐队友，并可查看当前对局10名玩家近期排位表现。"
    )
    schema = {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "WGame VAL 实时对局",
        "url": f"{PUBLIC_SITE_URL}/live",
        "description": description,
        "applicationCategory": "GameApplication",
        "operatingSystem": "Web",
        "inLanguage": "zh-CN",
        "isAccessibleForFree": True,
        "featureList": [
            "组队房间成员近3场排位战绩",
            "房间成员加入退出自动同步",
            "匹配后补齐同阵营玩家",
            "当前对局10名玩家近期排位战绩",
        ],
    }
    available_sessions = list(sessions) if sessions is not None else ([session] if session else [])
    message_html = (
        f'<p class="query-message" role="status">{esc(message)}</p>'
        if message
        else ""
    )
    session_rows = []
    selected_id = str(session.get("id") or "") if session else ""
    for item in available_sessions:
        session_id = str(item.get("id") or "")
        choice = public_session_choice_token(session_id, viewer_key)
        room_href = "/live/select?" + urllib.parse.urlencode(
            {"choice": choice, "next": "/live/room"}
        )
        match_href = "/live/select?" + urllib.parse.urlencode(
            {"choice": choice, "next": "/live/match"}
        )
        is_selected = bool(selected_id and session_id == selected_id)
        row_class = "session-choice selected" if is_selected else "session-choice"
        display = str(item.get("display") or "未识别昵称的游戏账号")
        expires = item.get("expires_in")
        if isinstance(expires, int):
            freshness = f"预计 {max(1, expires // 60)} 分钟内有效"
        else:
            freshness = "游戏连接有效"
        selected_badge = '<span class="session-badge">当前已选择</span>' if is_selected else ""
        session_rows.append(
            f"""<article class="{row_class}">
              <div>
                <h3>{esc(display)}{selected_badge}</h3>
                <p>最近更新 {esc(item.get('updated_at') or '-')} · {esc(freshness)}</p>
              </div>
              <div class="session-choice-actions">
                <a class="live-action primary" href="{esc(room_href)}">房间近 3 场</a>
                <a class="live-action" href="{esc(match_href)}">当前对局 10 人</a>
              </div>
            </article>"""
        )
    session_list_html = (
        '<div class="session-list">' + "".join(session_rows) + "</div>"
        if session_rows
        else (
            '<div class="session-empty">当前网络下还没有未过期的游戏会话。'
            '先完成下方连接步骤，再完全退出并重新启动客户端和游戏；捕获到新会话后刷新本页。</div>'
        )
    )
    has_sessions = bool(available_sessions)

    if has_sessions:
        sessions_el = f"""  <section class="content-band has-sessions" id="sessions" aria-labelledby="sessions-title">
    <div class="section-heading live-section-heading">
      <div><span class="live-section-kicker">SESSION</span><h2 id="sessions-title">选择我的游戏账号</h2></div>
      <p>这里只列出与当前访问网络匹配且尚未过期的游戏会话。同一网吧出口 IP 可能对应多个玩家，请按游戏昵称选择自己的账号；选择结果会保存在当前浏览器中。</p>
    </div>
    {session_list_html}
  </section>"""
    else:
        sessions_el = ""

    # Feature detail section for configured users
    if has_sessions:
        views_html = """  <section class="content-band" id="views" aria-labelledby="modes-title">
    <div class="section-heading live-section-heading">
      <div><span class="live-section-kicker">VIEWS</span><h2 id="modes-title">进入需要的实时视图</h2></div>
      <p>房间视图适合组队和匹配前判断排位状态；当前对局视图适合进入选人或游戏后快速浏览双方玩家的近期排位数据。</p>
    </div>
    <div class="feature-grid">
      <article class="feature-item">
        <span class="feature-number">ROOM</span>
        <h3>组队房间与匹配队友</h3>
        <p>排除当前账号，读取房间成员近 3 场排位。匹配成功后只补充我方玩家，不会把敌方混入队友列表。</p>
      </article>
      <article class="feature-item">
        <span class="feature-number">MATCH</span>
        <h3>当前对局双方玩家</h3>
        <p>查看 10 名玩家近期排位、当前英雄和公开省级属地，并用蓝色、红色头像边框区分双方阵营。</p>
      </article>
      <article class="feature-item">
        <span class="feature-number">SYNC</span>
        <h3>房间成员实时变化</h3>
        <p>页面持续监听成员签名，检测到玩家加入、退出或匹配补齐时自动重建列表。</p>
      </article>
      <article class="feature-item">
        <span class="feature-number">PARTY</span>
        <h3>疑似组队关系</h3>
        <p>通过同队玩家近期共同对局进行辅助推断，结果仅作选人和沟通参考，不冒充官方组队信息。</p>
      </article>
    </div>
  </section>"""
    else:
        views_html = ""

    if has_sessions:
        main_content = f"""{sessions_el}
{views_html}"""
    else:
        preview_section = """
  <section class="content-band deploy-main" aria-labelledby="deploy-title">
    <div class="deploy-header">
      <p class="eyebrow">国服排位 · 本地安装</p>
      <h1 id="deploy-title">实时对局查询</h1>
      <p class="deploy-intro">将工具安装到你的电脑，即可拉取更全面的战绩和实时对局数据。在同一局域网内通过手机或电脑浏览器查看，数据不经过第三方服务器，保护你的游戏隐私。</p>
      <div class="deploy-capabilities">
        <span>房间队友近 3 场</span>
        <span>当前对局 10 人</span>
        <span>成员变化自动同步</span>
        <span>段位 · KDA · ACS</span>
        <span>单局详情 · 命中分析</span>
      </div>
    </div>
  </section>

  <section class="content-band live-preview-section" aria-labelledby="preview-title">
    <div class="section-heading live-section-heading">
      <div><span class="live-section-kicker">PREVIEW</span><h2 id="preview-title">功能效果预览</h2></div>
      <p>安装成功后，即可在浏览器中实时查看当前对局与玩家近期战绩。</p>
    </div>
    <ul class="live-preview-tabs" role="tablist" aria-label="效果预览">
      <li><button type="button" class="active" role="tab" aria-selected="true" data-preview-tab="0">桌面端对局</button></li>
      <li><button type="button" role="tab" aria-selected="false" data-preview-tab="1">手机端对局</button></li>
      <li><button type="button" role="tab" aria-selected="false" data-preview-tab="2">单局详情</button></li>
      <li><button type="button" role="tab" aria-selected="false" data-preview-tab="3">命中分析</button></li>
    </ul>
    <div class="live-preview-panels">
      <div class="live-preview-panel active" role="tabpanel" data-preview-panel="0">
        <div class="live-preview-frame"><p class="deploy-note">本地运行后，此处显示当前环境的功能结果。</p></div>
        <p class="live-preview-caption">桌面端浏览器中查看当前对局 10 人近期战绩</p>
      </div>
      <div class="live-preview-panel" role="tabpanel" data-preview-panel="1">
        <div class="live-preview-frame"><p class="deploy-note">本地运行后，此处显示当前环境的功能结果。</p></div>
        <p class="live-preview-caption">手机端同一网络下访问，查看双方阵容</p>
      </div>
      <div class="live-preview-panel" role="tabpanel" data-preview-panel="2">
        <div class="live-preview-frame"><p class="deploy-note">本地运行后，此处显示当前环境的功能结果。</p></div>
        <p class="live-preview-caption">单局 10 人完整数据，包括段位、K/D/A、ACS 与命中习惯</p>
      </div>
      <div class="live-preview-panel" role="tabpanel" data-preview-panel="3">
        <div class="live-preview-frame"><p class="deploy-note">本地运行后，此处显示当前环境的功能结果。</p></div>
        <p class="live-preview-caption">单局爆头率与击中部位分布（头 / 身 / 腿）</p>
      </div>
    </div>
  </section>

  <section class="content-band" aria-labelledby="features-title">
    <div class="section-heading live-section-heading">
      <div><span class="live-section-kicker">FEATURES</span><h2 id="features-title">完整功能清单</h2></div>
    </div>
    <div class="deploy-features">
      <ul>
        <li>远程协助完成项目安装与代理证书配置</li>
        <li>昵称搜索近 10 场排位战绩与单局详情</li>
        <li>房间队友近 3 场排位数据</li>
        <li>当前对局双方 10 人近期排位</li>
        <li>玩家段位、KDA、ACS、爆头率展示</li>
        <li>击中部位分布（头/身/腿）</li>
        <li>公开 IP 属地信息</li>
        <li>房间成员变化自动同步</li>
        <li>疑似组队关系辅助分析</li>
        <li>同一局域网手机 / 电脑均可访问</li>
        <li>功能随项目更新持续迭代</li>
      </ul>
      <div class="deploy-actions">
        <a class="live-action primary" href="#" onclick="openContactModal(); return false;">本地部署说明</a>
        <p class="deploy-note">订阅后由维护者远程协助安装，一次配置长期使用。安装后如更换电脑、重装系统或网络环境重大变更，需另行配置。</p>
      </div>
    </div>
  </section>

  <section class="content-band" aria-labelledby="self-deploy-title">
    <div class="section-heading live-section-heading">
      <div><span class="live-section-kicker">OPEN SOURCE</span><h2 id="self-deploy-title">自己动手安装</h2></div>
    </div>
    <div class="self-deploy-content">
      <p>本项目已开源，你可以下载源码在自己的电脑上安装。前提条件：Windows 10/11 系统，安装 Python 3.9 和 mitmproxy。</p>
      <div class="self-deploy-actions">
        <a class="live-action primary" href="/public" target="_blank" rel="noopener noreferrer">返回本地查询首页</a>
        <a class="live-action" href="#" onclick="openContactModal(); return false;">联系作者协助安装</a>
      </div>
      <p class="deploy-note">详细安装指南已包含在项目仓库的 docs 目录中。如遇问题，欢迎阅读随包文档自行排查。</p>
    </div>
  </section>"""
        main_content = preview_section

    return f"""<!doctype html>
<html lang="zh-CN">
<head>
{public_head(title, description, canonical_path="/live", index=index, schema=schema if index else None)}
  <style>{PUBLIC_CSS}</style>
</head>
<body class="public-page">
<a class="skip-link" href="#main-content">跳到实时对局</a>
{public_site_header("live")}
<main id="main-content" class="public-main live-home">
{main_content}
  {message_html}
  <div id="contact-modal" class="modal-overlay" role="dialog" aria-labelledby="modal-title" aria-modal="true">
    <div class="modal-content">
      <button class="modal-close" type="button" aria-label="关闭弹窗">×</button>
      <div class="modal-body">
        <h3 id="modal-title">本地部署说明</h3>
        <p>请阅读随包文档完成本机部署。此版本不包含作者联系方式。</p>
        <div class="modal-qr-container">
          <div class="qq-qr-placeholder">
            <p>本地部署文档位于解压目录的 docs 文件夹。</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>
{public_site_footer()}
<script>
function openContactModal() {{
  const modal = document.getElementById('contact-modal');
  if (modal) {{
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }}
}}

function closeContactModal() {{
  const modal = document.getElementById('contact-modal');
  if (modal) {{
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }}
}}

document.addEventListener('click', async event => {{
  const closeBtn = event.target.closest('.modal-close');
  if (closeBtn) {{
    closeContactModal();
    return;
  }}
  const modalOverlay = event.target.closest('.modal-overlay');
  if (modalOverlay && !event.target.closest('.modal-content')) {{
    closeContactModal();
    return;
  }}
  const directCopy = event.target.closest('[data-copy-text]');
  if (directCopy) {{
    const oldText = directCopy.textContent;
    try {{
      await navigator.clipboard.writeText(directCopy.dataset.copyText || '');
      directCopy.textContent = 'QQ 已复制';
    }} catch (error) {{
      directCopy.textContent = '复制失败，请手动输入';
    }}
    setTimeout(() => directCopy.textContent = oldText, 1600);
    return;
  }}
  const button = event.target.closest('[data-copy-target]');
  if (!button) return;
  const source = document.getElementById(button.dataset.copyTarget);
  if (!source) return;
  const oldText = button.textContent;
  try {{
    await navigator.clipboard.writeText(source.textContent);
    button.textContent = '已复制';
  }} catch (error) {{
    button.textContent = '复制失败';
  }}
  setTimeout(() => button.textContent = oldText, 1400);
}});

(function(){{
  const tabs = document.querySelectorAll('[data-preview-tab]');
  const panels = document.querySelectorAll('[data-preview-panel]');
  if (!tabs.length) return;
  tabs.forEach(tab => {{
    tab.addEventListener('click', () => {{
      const idx = tab.dataset.previewTab;
      tabs.forEach(t => {{
        t.classList.toggle('active', t === tab);
        t.setAttribute('aria-selected', t === tab ? 'true' : 'false');
      }});
      panels.forEach(p => {{
        p.classList.toggle('active', p.dataset.previewPanel === idx);
      }});
    }});
  }});
}})();
</script>
</body>
</html>"""


def render_battles(
    query: str,
    display_name: str,
    subject: str,
    source: str,
    data: dict[str, Any],
    public: bool = False,
) -> str:
    result = data.get("result") if isinstance(data, dict) else None
    code = result.get("error_code") if isinstance(result, dict) else result
    message = result.get("error_message") if isinstance(result, dict) else ""
    battles = data.get("battles") if isinstance(data, dict) else None
    if code != 0 or not isinstance(battles, list):
        if public:
            return render_public_index(f"查询失败：code={code} {message}", query)
        return render_index(f"查询失败：code={code} {message}。如果 Chrome 未登录，请点“启动登录 Chrome”登录 WeGame 后再试。")

    loc_text = location_text(player_location_info(display_name, allow_query=True))
    if public:
        title = f"{display_name or query}近期战绩_WGame VAL"
        description = (
            f"查看{display_name or query}近10场无畏契约国服战绩，包括胜负、英雄、KDA、ACS、"
            "地图、段位和RR变化。"
        )
        return f"""<!doctype html>
<html lang="zh-CN">
<head>
{public_head(title, description, index=False)}
  <style>{PUBLIC_CSS}</style>
</head>
<body class="public-page public-results-page">
<a class="skip-link" href="#main-content">跳到战绩</a>
{public_site_header("public")}
<main id="main-content" class="public-main result-main">
  <form class="result-search" method="get" action="/public-query" aria-label="查询其他玩家">
    <div class="search-row">
      <input class="query-input" name="q" value="{esc(query)}" maxlength="80" autocomplete="off" spellcheck="false" aria-label="玩家昵称#ID" placeholder="输入完整昵称#ID" required>
      <button class="query-button" type="submit">查询</button>
    </div>
  </form>
  {public_results_overview_html(display_name, query, battles, loc_text)}
  <details class="public-data-note" data-default-open="desktop">
    <summary>
      <span><strong>公共查询只加载排位数据</strong><small>本地安装解锁全部能力</small></span>
      <span class="data-note-action">查看完整功能</span>
    </summary>
    <div class="public-data-note-body">
      <div class="data-note-layout">
        <div class="data-note-main">
          <p class="data-note-intro">在自己电脑上安装本项目，即可拉取更多战绩、解锁以下全部能力。数据本地读取，不经过第三方服务器。</p>
          <div class="data-note-features">
            <span class="feat-block"><strong>实时对局</strong><small>10人·房间同步</small></span>
            <span class="feat-block"><strong>全模式战绩</strong><small>匹配/极速/死斗</small></span>
            <span class="feat-block"><strong>AI历史回溯</strong><small>数百场·数月数据</small></span>
            <span class="feat-block"><strong>组队关系分析</strong><small>PartyID识车队</small></span>
            <span class="feat-block"><strong>昵称搜索</strong><small>搜全部#ID</small></span>
            <span class="feat-block"><strong>单局深度详情</strong><small>段位/KDA/ACS</small></span>
            <span class="feat-block"><strong>命中分析</strong><small>爆头率/部位</small></span>
            <span class="feat-block"><strong>完整玩家标识</strong><small>内部标识/事件</small></span>
            <span class="feat-block"><strong>IP属地</strong><small>地区识别</small></span>
          </div>
          <div class="notice-actions">
            <span class="notice-btn secondary">离线分析工具见随包 docs/TOOLS.md</span>
            <button class="notice-btn" type="button" onclick="openContactModal()">本地部署说明</button>
          </div>
        </div>
        <div class="data-note-qr">
          <p>本地部署文档位于解压目录的 docs 文件夹。</p>
          <span>扫码本地部署说明</span>
        </div>
      </div>
    </div>
  </details>
  <div class="public-ad-banner">
    <div class="ad-text">
      <strong>本机安装版已解锁全部能力</strong>
      <span>实时对局 / 全模式战绩 / 历史回溯 / 组队分析 / 昵称搜索</span>
    </div>
    <button class="ad-cta" type="button" onclick="openContactModal()">查看本地部署说明</button>
  </div>
  {public_battle_cards_html(battles, subject)}
  <p class="result-note">战绩数据可能存在同步延迟；本页面不展示内部玩家标识、事件 ID 或真实 IP。如需更多数据，请扫码联系作者本地安装。</p>
  <div id="contact-modal" class="modal-overlay" role="dialog" aria-labelledby="modal-title" aria-modal="true">
    <div class="modal-content">
      <button class="modal-close" type="button" aria-label="关闭弹窗">×</button>
      <div class="modal-body">
        <h3 id="modal-title">本地部署说明</h3>
        <p>请阅读随包文档完成本机部署。此版本不包含作者联系方式。</p>
        <div class="modal-qr-container">
          <div class="qq-qr-placeholder">
            <p>本地部署文档位于解压目录的 docs 文件夹。</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>
{public_site_footer()}
<script>
function openContactModal() {{
  const modal = document.getElementById('contact-modal');
  if (modal) {{
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }}
}}
function closeContactModal() {{
  const modal = document.getElementById('contact-modal');
  if (modal) {{
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }}
}}
document.addEventListener('click', async event => {{
  const closeBtn = event.target.closest('.modal-close');
  if (closeBtn) {{ closeContactModal(); return; }}
  const modalOverlay = event.target.closest('.modal-overlay');
  if (modalOverlay && !event.target.closest('.modal-content')) {{ closeContactModal(); return; }}
}});
document.addEventListener('keydown', event => {{
  if (event.key === 'Escape') {{ closeContactModal(); }}
}});
(function() {{
  const note = document.querySelector('.public-data-note[data-default-open="desktop"]');
  if (note) {{ note.open = window.innerWidth >= 820; }}
}})();
(function() {{
  const banner = document.querySelector('.public-ad-banner');
  if (!banner) {{ return; }}
  let userScrolled = false;
  const onScroll = () => {{ userScrolled = true; window.removeEventListener('scroll', onScroll); }};
  window.addEventListener('scroll', onScroll, {{ passive: true }});
  setTimeout(() => {{
    if (userScrolled) {{ return; }}
    const rect = banner.getBoundingClientRect();
    const header = document.querySelector('.site-header');
    const offset = header ? header.getBoundingClientRect().height : 0;
    const targetY = window.scrollY + rect.top - offset - 10;
    if (targetY > window.scrollY + 4) {{
      window.scrollTo({{ top: Math.max(0, targetY), behavior: 'smooth' }});
    }}
  }}, 3000);
}})();
</script>
{public_battle_detail_script()}
</body>
</html>"""

    summary = assistant_summary_html({"name": display_name}, battles, subject)
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>{esc(display_name or query)} - 近期战绩</title>
  <style>{APP_CSS}</style>
</head>
<body>
<main>
  <div class="topbar"><a href="/">返回查询</a><a href="/assistant">助手页</a></div>
  <section class="panel">
    <div class="player-head">
      <div>
        <h1>{esc(display_name or query)}</h1>
        <p>IP属地 {esc(loc_text)} / {esc(source)} / <code>{esc(subject)}</code></p>
      </div>
      <div class="record">{esc(player_record_text(battles))}</div>
    </div>
    {summary}
    {battles_table(battles, subject)}
  </section>
</main>
</body>
</html>"""


def qq_battle_line(idx: int, battle: dict[str, Any]) -> str:
    return (
        f"{idx}. {result_name(battle.get('wonMatch'))} {score_text(battle)} "
        f"{agent_name(battle.get('characterId'))} "
        f"KDA {kda_text(battle)} ACS {acs_text(battle)} "
        f"{map_name(battle.get('mapId'))} {rank_name(battle.get('competitiveTier'))} "
        f"RR {rr_text(battle.get('CompetitiveTierRankedRatingEarned'))}"
    ).strip()


def qq_summary_payload(query: str, limit: int = 5) -> dict[str, Any]:
    query = (query or "").strip()
    if not query:
        return {"ok": False, "error": "请输入昵称#ID，例如 示例玩家#12345"}

    subject, display, resolve_source = resolve_subject(query)
    if not subject:
        return {"ok": False, "error": f"没有解析到 subject：{query}"}

    source, data = query_battles(subject, max(1, min(limit, 10)))
    result = data.get("result") if isinstance(data, dict) else None
    code = result.get("error_code") if isinstance(result, dict) else result
    message = result.get("error_message") if isinstance(result, dict) else ""
    battles = data.get("battles") if isinstance(data, dict) else None
    if code != 0 or not isinstance(battles, list):
        return {
            "ok": False,
            "query": query,
            "display": display or query,
            "subject": subject,
            "error": f"战绩查询失败：code={code} {message}".strip(),
            "resolve_source": resolve_source,
            "battle_source": source,
        }

    rows = []
    for idx, battle in enumerate(battles[:limit], 1):
        rows.append(
            {
                "index": idx,
                "time": battle.get("dtEventTime"),
                "result": result_name(battle.get("wonMatch")),
                "score": score_text(battle),
                "agent": agent_name(battle.get("characterId")),
                "kda": kda_text(battle),
                "acs": acs_text(battle),
                "map": map_name(battle.get("mapId")),
                "rank": rank_name(battle.get("competitiveTier")),
                "rr": rr_text(battle.get("CompetitiveTierRankedRatingEarned")),
                "duration": duration_text(battle.get("gameLengthMillis")),
                "highlights": highlights_text(battle),
                "apEventId": battle.get("apEventId"),
            }
        )

    loc_info = player_location_info(display or query, allow_query=False)
    header = [
        f"无畏契约战绩：{display or query}",
        f"近{min(limit, len(battles))}场 / {player_record_text(battles)}",
    ]
    loc = location_text(loc_info)
    if loc and loc not in ("未缓存", "缺少昵称"):
        header.append(f"IP属地：{loc}")
    lines = header + [qq_battle_line(i, battle) for i, battle in enumerate(battles[:limit], 1)]
    return {
        "ok": True,
        "query": query,
        "display": display or query,
        "subject": subject,
        "resolve_source": resolve_source,
        "battle_source": source,
        "record": player_record_text(battles),
        "limit": limit,
        "battles": rows,
        "reply": "\n".join(lines),
    }


def default_import() -> int:
    candidates = [
        APP_DIR / "wegame-20260717-203101.subjects.json",
        DATA_DIR / "current-match.subjects.json",
        CAPTURE_DIR / "wegame-import.subjects.json",
    ]
    total = 0
    for path in candidates:
        total += import_file(path)
    captures = CAPTURE_DIR
    if captures.exists():
        for path in sorted(captures.glob("wegame-*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)[:6]:
            total += import_file(path)
    return total


def public_token() -> str:
    try:
        token = PUBLIC_TOKEN_PATH.read_text(encoding="utf-8").strip()
    except Exception:
        token = ""
    return token or "root"


def query_token_ok(params: dict[str, list[str]]) -> bool:
    return (params.get("k") or [""])[0] == public_token()


def normalize_push_token(item: dict[str, Any]) -> dict[str, Any]:
    last_push = item.get("last_push")
    try:
        last_push = int(last_push) if last_push is not None else None
    except (TypeError, ValueError):
        last_push = None
    try:
        created_at = int(item.get("created_at") or 0)
    except (TypeError, ValueError):
        created_at = 0
    blocked = item.get("blocked_ips") or []
    if not isinstance(blocked, list):
        blocked = []
    return {
        "token": str(item.get("token") or ""),
        "remark": str(item.get("remark") or ""),
        "created_at": created_at,
        "enabled": bool(item.get("enabled", True)),
        "blocked_ips": [str(ip).strip() for ip in blocked if str(ip).strip()],
        "last_push": last_push,
        "last_ip": str(item.get("last_ip") or ""),
    }


def load_push_tokens() -> list[dict[str, Any]]:
    """读取 data/push-tokens.json。首次访问时把旧的单 token
    (captures/public-query-token.txt) 迁移为首条记录，保持已有网吧推送可用。"""
    try:
        data = json.loads(PUSH_TOKENS_PATH.read_text(encoding="utf-8"))
        if isinstance(data, list):
            tokens = [normalize_push_token(item) for item in data if isinstance(item, dict)]
            tokens = [t for t in tokens if t["token"]]
            if tokens:
                return tokens
    except FileNotFoundError:
        pass
    except Exception:
        pass
    # 首次访问：把旧的单 token 迁移为首条 push token
    legacy = public_token()
    if legacy and legacy != "root":
        migrated = normalize_push_token({
            "token": legacy,
            "remark": "migrated-default",
            "created_at": int(time.time()),
            "enabled": True,
            "blocked_ips": [],
            "last_push": None,
            "last_ip": "",
        })
        save_push_tokens([migrated])
        return [migrated]
    return []


def save_push_tokens(tokens: list[dict[str, Any]]) -> None:
    PUSH_TOKENS_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = PUSH_TOKENS_PATH.with_suffix(".tmp")
    tmp.write_text(
        json.dumps(tokens, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    tmp.replace(PUSH_TOKENS_PATH)


def find_push_token(token: str) -> dict[str, Any] | None:
    if not token:
        return None
    for item in load_push_tokens():
        if item["token"] == token:
            return item
    return None


def update_push_token_record(
    token: str,
    *,
    last_push: int | None = None,
    last_ip: str | None = None,
) -> None:
    """更新某 token 的 last_push / last_ip，不改动其它字段。"""
    with PUSH_TOKENS_LOCK:
        tokens = load_push_tokens()
        changed = False
        for item in tokens:
            if item["token"] == token:
                if last_push is not None:
                    item["last_push"] = last_push
                    changed = True
                if last_ip is not None:
                    item["last_ip"] = last_ip
                    changed = True
                break
        if changed:
            save_push_tokens(tokens)


def push_token_masked(token: str) -> str:
    if not token:
        return ""
    if len(token) <= 8:
        return token[:2] + "••••"
    return token[:4] + "••••" + token[-4:]


def log_push_event(event: str, token: str, client_ip: str, detail: str = "") -> None:
    """记录 push token 验证事件到 captures/push-token-events-YYYYMMDD.jsonl。
    只写入脱敏后的 token，避免凭据进入运维日志。"""
    try:
        CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
        path = CAPTURE_DIR / f"push-token-events-{time.strftime('%Y%m%d')}.jsonl"
        item = {
            "ts": int(time.time()),
            "event": event,
            "token_masked": push_token_masked(token) if token else "",
            "client_ip": client_ip,
            "detail": detail,
        }
        with path.open("a", encoding="utf-8") as fp:
            fp.write(json.dumps(item, ensure_ascii=False) + "\n")
    except Exception:
        pass


def decode_bearer_subject(auth: str) -> str | None:
    token = auth.removeprefix("Bearer").strip()
    parts = token.split(".")
    if len(parts) < 2:
        return None
    try:
        padding = "=" * (-len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode((parts[1] + padding).encode("ascii")).decode("utf-8"))
    except Exception:
        return None
    subject = payload.get("sub")
    return str(subject).lower() if subject else None


# 昵称解析冷却集合：防止同一 subject 短时间重复解析
_resolve_cooldown: set[str] = set()
_resolve_cooldown_lock = threading.Lock()


def _resolve_subject_nickname_async(subject: str, lowered_headers: dict[str, str]) -> None:
    """后台线程：用 name-service API 解析 subject 的昵称并存入数据库。
    
    带冷却机制：同一 subject 解析中或 5 分钟内已尝试过不会重复创建线程。
    """
    with _resolve_cooldown_lock:
        if subject in _resolve_cooldown:
            return
        _resolve_cooldown.add(subject)
    
    def _resolve():
        try:
            import current_match_probe as probe_mod
            
            auth = lowered_headers.get("authorization", "")
            ent = lowered_headers.get("x-riot-entitlements-jwt")
            if not auth:
                print(f"[nickname-resolver] 缺少 Authorization: {subject[:16]}...", file=sys.stderr)
                return
            
            # 复用 base_game_headers() 构建请求头
            game_headers = probe_mod.base_game_headers(lowered_headers, auth, ent)
            
            names = probe_mod.name_lookup([subject], game_headers)
            if subject in names:
                name = names[subject]
                if name and name.strip("#"):
                    upsert_subject(name, subject, "auto-name-lookup")
                    print(f"[nickname-resolver] 解析成功: ({subject[:16]}...)", file=sys.stderr)
                else:
                    print(f"[nickname-resolver] 解析结果为空: ({subject[:16]}...)", file=sys.stderr)
            else:
                print(f"[nickname-resolver] API 未返回昵称: ({subject[:16]}...)", file=sys.stderr)
        except Exception as exc:
            print(f"[nickname-resolver] 解析失败: ({subject[:16]}...)  error_type={type(exc).__name__}", file=sys.stderr)
        finally:
            # 5 分钟后解除冷却
            def _clear_cooldown():
                time.sleep(300)
                with _resolve_cooldown_lock:
                    _resolve_cooldown.discard(subject)
            threading.Thread(target=_clear_cooldown, daemon=True).start()
    
    threading.Thread(target=_resolve, daemon=True).start()


def save_pushed_game_token(payload: dict[str, Any]) -> dict[str, Any]:
    raw_headers = payload.get("headers")
    if not isinstance(raw_headers, dict):
        raise ValueError("payload.headers must be an object")

    headers: dict[str, str] = {}
    for key, value in raw_headers.items():
        lowered = str(key).lower()
        if lowered in GAME_TOKEN_HEADERS and value:
            headers[str(key)] = str(value)
    lowered_headers = {key.lower(): value for key, value in headers.items()}
    if "authorization" not in lowered_headers:
        raise ValueError("missing Authorization header")
    if "x-riot-entitlements-jwt" not in lowered_headers:
        raise ValueError("missing X-Riot-Entitlements-JWT header")

    now = time.time()
    subject = decode_bearer_subject(lowered_headers["authorization"])
    item = {
        "ts_start": now,
        "captured_at": int(now),
        "endpoint": "https://alpha1-glz-redge.val.qq.com/pushed-token",
        "source": payload.get("source") or "remote-mitm",
        "request": {
            "host": "alpha1-glz-redge.val.qq.com",
            "headers": headers,
        },
        "response": {"body": {"json": {}}},
    }
    CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
    path = CAPTURE_DIR / f"pushed-game-token-{time.strftime('%Y%m%d')}.jsonl"
    with path.open("a", encoding="utf-8") as fp:
        fp.write(json.dumps(item, ensure_ascii=False) + "\n")

    # 自动解析未知 subject 的昵称
    if subject and not display_for_subject(subject):
        _resolve_subject_nickname_async(subject, lowered_headers)

    return {"path": str(path), "subject": subject, "captured_at": int(now)}


def save_mval_session(payload: dict[str, Any]) -> dict[str, Any]:
    user_id = str(payload.get("user_id") or "").strip()
    user_agent = str(payload.get("user_agent") or "").strip() or "mval/2.8.0"
    cookie = str(payload.get("cookie") or "").strip()
    captured_at = str(payload.get("captured_at") or "").strip()

    if not user_id:
        raise ValueError("missing user_id")
    if not cookie:
        raise ValueError("missing cookie")

    session = {
        "user_id": user_id,
        "user_agent": user_agent,
        "cookie": cookie,
        "captured_at": captured_at or time.strftime("%Y-%m-%dT%H:%M:%S"),
        "saved_at": int(time.time()),
        "source": "local/api/mval/session/upsert",
    }
    MVAL_SESSION_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = MVAL_SESSION_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(session, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(MVAL_SESSION_PATH)

    # New login state can make previous short-lived location failures stale.
    with LOCATION_LOCK:
        cache = load_location_cache()
        changed = False
        for key, item in list(cache.items()):
            if isinstance(item, dict) and not item.get("ok"):
                cache.pop(key, None)
                changed = True
        if changed:
            save_location_cache(cache)

    return {
        "path": str(MVAL_SESSION_PATH),
        "user_id": user_id,
        "saved_at": session["saved_at"],
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "WGameValQuery/0.1"

    def cookie_value(self, name: str) -> str:
        raw_cookie = self.headers.get("cookie", "")
        if not raw_cookie:
            return ""
        try:
            cookie = SimpleCookie()
            cookie.load(raw_cookie)
            morsel = cookie.get(name)
            return morsel.value if morsel is not None else ""
        except Exception:
            return ""

    def public_client_ip(self) -> str:
        forwarded = self.headers.get("x-forwarded-for", "")
        for candidate in reversed(forwarded.split(",")):
            value = candidate.strip().strip("[]")
            if not value:
                continue
            try:
                address = ipaddress.ip_address(value)
            except ValueError:
                continue
            if address.is_global:
                return str(address)
        return ""

    def audit_client_ip(self) -> str:
        client_ip = self.public_client_ip()
        if client_ip:
            return client_ip
        if not self.headers.get("x-forwarded-for", "").strip():
            return normalize_ip(self.client_address[0])
        return ""

    def audit_public_query(
        self,
        query: str,
        result_status: str,
        *,
        display: str = "",
        subject: str = "",
    ) -> None:
        record_public_query(
            client_ip=self.audit_client_ip(),
            query_text=query,
            result_status=result_status,
            account_display=display,
            account_subject=subject,
        )

    def audit_live_session(
        self,
        action: str,
        session: dict[str, Any],
        endpoint: str,
        result_status: str = "ok",
    ) -> None:
        record_live_usage(
            action=action,
            client_ip=self.audit_client_ip(),
            session=session,
            endpoint=endpoint,
            result_status=result_status,
        )

    def public_live_sessions(self) -> list[dict[str, Any]]:
        forwarded = self.headers.get("x-forwarded-for", "")
        client_ip = self.audit_client_ip()
        return active_live_sessions_for_client(
            client_ip,
            allow_fallback=not bool(forwarded),
        )

    def public_live_viewer_key(self) -> str:
        return public_viewer_key(self.public_client_ip())

    def public_live_choice(self) -> str:
        value = self.cookie_value(PUBLIC_LIVE_COOKIE)
        return value if re.fullmatch(r"[0-9a-f]{24}", value or "") else ""

    def live_risk_client_id(self) -> str:
        value = self.cookie_value(PUBLIC_LIVE_RISK_CLIENT_COOKIE).lower()
        return value if re.fullmatch(r"[0-9a-f]{32}", value or "") else ""

    def live_risk_locked(self) -> bool:
        return live_risk_client_locked(self.live_risk_client_id())

    def live_risk_accepted(self) -> bool:
        acceptance_id = self.cookie_value(PUBLIC_LIVE_RISK_COOKIE)
        client_id = self.live_risk_client_id()
        if live_risk_client_locked(client_id):
            return False
        return live_risk_acceptance_valid(
            acceptance_id,
            self.headers.get("user-agent", ""),
            client_id,
        )

    @staticmethod
    def safe_live_next(value: str) -> str:
        candidate = (value or "/live").strip() or "/live"
        parsed = urllib.parse.urlsplit(candidate)
        allowed = {"/live", "/live/select", "/live/room", "/live/match"}
        if parsed.scheme or parsed.netloc or parsed.path not in allowed:
            return "/live"
        return urllib.parse.urlunsplit(("", "", parsed.path, parsed.query, ""))

    def send_live_risk_agreement(
        self,
        next_path: str = "/live",
        message: str = "",
        *,
        status: int = 200,
        index: bool = False,
    ) -> None:
        nonce = secrets.token_hex(16)
        client_id = self.live_risk_client_id() or secrets.token_hex(16)
        locked = live_risk_client_locked(client_id)
        body = render_live_risk_agreement(
            nonce,
            self.safe_live_next(next_path),
            message,
            index=index,
            locked=locked,
        )
        encoded = body.encode("utf-8")
        self.send_response(status)
        self.send_header("content-type", "text/html; charset=utf-8")
        self.send_header("content-length", str(len(encoded)))
        self.send_header("cache-control", "no-store")
        self.send_header("content-language", "zh-CN")
        self.send_header("x-content-type-options", "nosniff")
        self.send_header("referrer-policy", "strict-origin-when-cross-origin")
        if not index:
            self.send_header("x-robots-tag", "noindex, follow")
        self.send_header(
            "set-cookie",
            f"{PUBLIC_LIVE_RISK_NONCE_COOKIE}={nonce}; Path=/live; Max-Age=900; HttpOnly; SameSite=Strict; Secure",
        )
        self.send_header(
            "set-cookie",
            f"{PUBLIC_LIVE_RISK_CLIENT_COOKIE}={client_id}; Path=/; "
            "Max-Age=315360000; HttpOnly; SameSite=Lax; Secure",
        )
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(encoded)

    def send_live_risk_consent_redirect(self, target: str, acceptance_id: str) -> None:
        self.send_response(303)
        self.send_header("location", self.safe_live_next(target))
        self.send_header("cache-control", "no-store")
        self.send_header(
            "set-cookie",
            f"{PUBLIC_LIVE_RISK_COOKIE}={acceptance_id}; Path=/; "
            f"Max-Age={LIVE_RISK_CONSENT_TTL}; HttpOnly; SameSite=Lax; Secure",
        )
        self.send_header(
            "set-cookie",
            f"{PUBLIC_LIVE_RISK_NONCE_COOKIE}=; Path=/live; Max-Age=0; HttpOnly; SameSite=Strict; Secure",
        )
        self.end_headers()

    def send_live_risk_revoked_redirect(self) -> None:
        self.send_response(303)
        self.send_header("location", "/live")
        self.send_header("cache-control", "no-store")
        self.send_header(
            "set-cookie",
            f"{PUBLIC_LIVE_RISK_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax; Secure",
        )
        self.end_headers()

    def public_live_session(
        self,
        sessions: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any] | None:
        choice = self.public_live_choice()
        if not choice:
            return None
        viewer_key = self.public_live_viewer_key()
        for session in (sessions if sessions is not None else self.public_live_sessions()):
            expected = public_session_choice_token(str(session.get("id") or ""), viewer_key)
            if secrets.compare_digest(expected, choice):
                return session
        return None

    def send_public_live_redirect(self, target: str, choice: str) -> None:
        safe_target = target if target in {"/live", "/live/room", "/live/match"} else "/live"
        self.send_response(303)
        self.send_header("location", safe_target)
        self.send_header("cache-control", "no-store")
        self.send_header(
            "set-cookie",
            f"{PUBLIC_LIVE_COOKIE}={choice}; Path=/; Max-Age=14400; HttpOnly; SameSite=Lax; Secure",
        )
        self.end_headers()

    def send_html(
        self,
        body: str,
        status: int = 200,
        cache_control: str = "no-store",
        x_robots: str | None = None,
    ) -> None:
        encoded = body.encode("utf-8")
        self.send_response(status)
        self.send_header("content-type", "text/html; charset=utf-8")
        self.send_header("content-length", str(len(encoded)))
        self.send_header("cache-control", cache_control)
        self.send_header("content-language", "zh-CN")
        self.send_header("x-content-type-options", "nosniff")
        self.send_header("referrer-policy", "strict-origin-when-cross-origin")
        if x_robots:
            self.send_header("x-robots-tag", x_robots)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(encoded)

    def send_json(self, data: Any, status: int = 200) -> None:
        encoded = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(encoded)))
        self.send_header("cache-control", "no-store")
        self.send_header("x-content-type-options", "nosniff")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(encoded)

    def read_json_body(self, max_bytes: int = 65536) -> dict[str, Any]:
        try:
            length = int(self.headers.get("content-length") or "0")
        except ValueError as exc:
            raise ValueError("请求体长度不正确") from exc
        if length <= 0 or length > max_bytes:
            raise ValueError("请求体为空或过大")
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception as exc:
            raise ValueError("请求体不是有效 JSON") from exc
        if not isinstance(payload, dict):
            raise ValueError("请求体必须是 JSON 对象")
        return payload

    def send_text(
        self,
        body: str,
        content_type: str = "text/plain; charset=utf-8",
        status: int = 200,
        cache_control: str = "public, max-age=3600",
    ) -> None:
        encoded = body.encode("utf-8")
        self.send_response(status)
        self.send_header("content-type", content_type)
        self.send_header("content-length", str(len(encoded)))
        self.send_header("cache-control", cache_control)
        self.send_header("x-content-type-options", "nosniff")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(encoded)

    def send_binary(
        self,
        data: bytes,
        content_type: str,
        status: int = 200,
        cache_control: str = "public, max-age=604800",
    ) -> None:
        self.send_response(status)
        self.send_header("content-type", content_type)
        self.send_header("content-length", str(len(data)))
        self.send_header("cache-control", cache_control)
        self.send_header("x-content-type-options", "nosniff")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def send_download(self, data: bytes, content_type: str, filename: str) -> None:
        self.send_response(200)
        self.send_header("content-type", content_type)
        self.send_header("content-length", str(len(data)))
        self.send_header("content-disposition", f'attachment; filename="{filename}"')
        self.send_header("cache-control", "no-store")
        self.send_header("x-content-type-options", "nosniff")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def send_page_file(self, name: str) -> None:
        try:
            target = (PAGES_DIR / name).resolve()
            root = PAGES_DIR.resolve()
            if target.parent != root or not target.exists() or target.suffix.lower() != ".html":
                self.send_html(render_index("页面文件不存在。"), 404)
                return
            encoded = target.read_bytes()
            self.send_response(200)
            self.send_header("content-type", "text/html; charset=utf-8")
            self.send_header("content-length", str(len(encoded)))
            self.send_header("cache-control", "no-store")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(encoded)
        except Exception as exc:
            self.send_html(render_index(f"读取页面失败：{type(exc).__name__}: {exc}"), 500)

    def send_baidu_verification(self, name: str) -> None:
        if not BAIDU_VERIFY_RE.fullmatch(name):
            self.send_text("not found\n", status=404, cache_control="no-store")
            return
        target = BAIDU_VERIFY_DIR / name
        if not target.is_file():
            self.send_text("not found\n", status=404, cache_control="no-store")
            return
        data = target.read_bytes()
        if len(data) > 65536:
            self.send_text("invalid verification file\n", status=400, cache_control="no-store")
            return
        self.send_binary(data, "text/html; charset=utf-8", cache_control="public, max-age=300")

    def do_POST(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        if parsed.path == "/api/push-tokens":
            try:
                payload = self.read_json_body()
                remark = str(payload.get("remark") or "").strip()[:120]
                with PUSH_TOKENS_LOCK:
                    tokens = load_push_tokens()
                    new_token = secrets.token_urlsafe(24)
                    record = normalize_push_token({
                        "token": new_token,
                        "remark": remark,
                        "created_at": int(time.time()),
                        "enabled": True,
                        "blocked_ips": [],
                        "last_push": None,
                        "last_ip": "",
                    })
                    tokens.append(record)
                    save_push_tokens(tokens)
                log_push_event("created", new_token, self.audit_client_ip(), remark)
                self.send_json({
                    "ok": True,
                    "token": new_token,
                    "token_masked": push_token_masked(new_token),
                    "remark": remark,
                })
            except Exception as exc:
                self.send_json({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, 400)
            return
        if parsed.path == "/api/admin/name-search":
            try:
                payload = self.read_json_body()
                result = search_aliases_by_nickname(str(payload.get("nickname") or ""))
                rank_task = start_nickname_rank_task(result.get("results") or [])
                result["rank_task_id"] = rank_task.get("id")
                result["rank_task"] = rank_task
                self.send_json(result)
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, 400)
            return
        if parsed.path == "/api/admin/name-search-page-game-times":
            try:
                payload = self.read_json_body()
                subjects = payload.get("subjects")
                if not isinstance(subjects, list):
                    self.send_json({"ok": False, "error": "subjects 必须是数组"}, 400)
                    return
                clean = [s.lower() for s in subjects if SUBJECT_RE.fullmatch(s or "")]
                if not clean:
                    self.send_json({"ok": True, "game_times": {}})
                    return
                last_matches = browser_get_last_matches(clean)
                self.send_json({"ok": True, "game_times": last_matches})
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, 500)
            return
        if parsed.path == "/live/revoke":
            acceptance_id = self.cookie_value(PUBLIC_LIVE_RISK_COOKIE)
            client_id = self.live_risk_client_id()
            try:
                revoke_live_risk_acceptance(acceptance_id, client_id)
            finally:
                self.send_live_risk_revoked_redirect()
            return
        if parsed.path == "/live/agree":
            client_id = self.live_risk_client_id()
            if live_risk_client_locked(client_id):
                self.send_live_risk_agreement(
                    "/live",
                    status=403,
                )
                return
            try:
                length = int(self.headers.get("content-length") or "0")
            except ValueError:
                length = 0
            if length <= 0 or length > 16384:
                self.send_live_risk_agreement(
                    "/live",
                    "提交内容不完整，请重新逐项确认。",
                    status=400,
                )
                return
            raw = self.rfile.read(length).decode("utf-8", errors="replace")
            form = urllib.parse.parse_qs(raw, keep_blank_values=True)
            next_path = self.safe_live_next((form.get("next") or ["/live"])[0])
            supplied_nonce = (form.get("nonce") or [""])[0].strip().lower()
            expected_nonce = self.cookie_value(PUBLIC_LIVE_RISK_NONCE_COOKIE).lower()
            nonce_ok = (
                bool(re.fullmatch(r"[0-9a-f]{32}", supplied_nonce))
                and bool(re.fullmatch(r"[0-9a-f]{32}", expected_nonce))
                and secrets.compare_digest(supplied_nonce, expected_nonce)
            )
            confirmations_ok = all(
                (form.get(name) or [""])[0] == "yes"
                for name in ("capacity", "ban_risk", "responsibility")
            )
            version_ok = secrets.compare_digest(
                (form.get("version") or [""])[0],
                LIVE_RISK_AGREEMENT_VERSION,
            )
            if (
                not re.fullmatch(r"[0-9a-f]{32}", client_id or "")
                or not nonce_ok
                or not confirmations_ok
                or not version_ok
            ):
                self.send_live_risk_agreement(
                    next_path,
                    "请阅读完整协议，并由本人逐项勾选三项确认后再提交。",
                    status=400,
                )
                return
            try:
                acceptance_id = create_live_risk_acceptance(
                    self.public_live_viewer_key(),
                    self.headers.get("user-agent", ""),
                    client_id,
                )
            except Exception:
                self.send_live_risk_agreement(
                    next_path,
                    "确认记录暂时无法保存，请稍后重试。",
                    status=500,
                )
                return
            self.send_live_risk_consent_redirect(next_path, acceptance_id)
            return
        if parsed.path == "/api/mval/session/upsert":
            local_proxy = self.client_address[0] in ("127.0.0.1", "::1")
            if not query_token_ok(params) and not local_proxy:
                self.send_json({"ok": False, "code": 4030, "message": "bad token"}, 403)
                return
            try:
                length = int(self.headers.get("content-length") or "0")
            except ValueError:
                length = 0
            if length <= 0 or length > 262144:
                self.send_json({"ok": False, "code": 4000, "message": "invalid body length"}, 400)
                return
            try:
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                saved = save_mval_session(payload)
                self.send_json({"ok": True, "code": 0, "message": "saved", **saved})
            except Exception as exc:
                self.send_json({"ok": False, "code": 4001, "message": f"{type(exc).__name__}: {exc}"}, 400)
            return
        if parsed.path == "/api/push-game-token":
            supplied_token = (params.get("k") or [""])[0].strip()
            client_ip = self.audit_client_ip()
            local_proxy = self.client_address[0] in ("127.0.0.1", "::1")

            token_record = None
            if supplied_token:
                token_record = find_push_token(supplied_token)
                if token_record is None:
                    log_push_event("rejected", supplied_token, client_ip, "unknown token")
                    self.send_json({"ok": False, "error": "bad token"}, 403)
                    return
                if not token_record.get("enabled", True):
                    log_push_event("rejected", supplied_token, client_ip, "token disabled")
                    self.send_json({"ok": False, "error": "token disabled"}, 403)
                    return
                blocked = token_record.get("blocked_ips") or []
                if client_ip and client_ip in blocked:
                    log_push_event("rejected", supplied_token, client_ip, "ip blocked")
                    self.send_json({"ok": False, "error": "ip blocked"}, 403)
                    return
            elif not local_proxy:
                self.send_json({"ok": False, "error": "bad token"}, 403)
                return

            try:
                length = int(self.headers.get("content-length") or "0")
            except ValueError:
                length = 0
            if length <= 0 or length > 262144:
                self.send_json({"ok": False, "error": "invalid body length"}, 400)
                return
            try:
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                saved = save_pushed_game_token(payload)
                now_ts = int(time.time())
                subject = saved.get("subject") or ""
                if token_record:
                    update_push_token_record(
                        token_record["token"],
                        last_push=now_ts,
                        last_ip=client_ip,
                    )
                    log_push_event("accepted", token_record["token"], client_ip, subject)
                else:
                    log_push_event("accepted-local", "", client_ip, subject)
                self.send_json({"ok": True, **saved})
            except Exception as exc:
                self.send_json({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, 400)
            return
        self.send_json({"ok": False, "error": "not found"}, 404)

    def _push_token_from_path(self, parsed) -> str:
        """从 /api/push-tokens/{token} 路径提取 token 段。"""
        parts = [p for p in parsed.path.split("/") if p]
        if len(parts) == 3 and parts[0] == "api" and parts[1] == "push-tokens":
            return urllib.parse.unquote(parts[2])
        return ""

    def do_DELETE(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        token = self._push_token_from_path(parsed)
        if not token:
            self.send_json({"ok": False, "error": "not found"}, 404)
            return
        with PUSH_TOKENS_LOCK:
            tokens = load_push_tokens()
            new_tokens = [t for t in tokens if t["token"] != token]
            if len(new_tokens) == len(tokens):
                self.send_json({"ok": False, "error": "token not found"}, 404)
                return
            save_push_tokens(new_tokens)
        log_push_event("deleted", token, self.audit_client_ip(), "")
        self.send_json({"ok": True})

    def do_PUT(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        token = self._push_token_from_path(parsed)
        if not token:
            self.send_json({"ok": False, "error": "not found"}, 404)
            return
        try:
            payload = self.read_json_body()
        except ValueError as exc:
            self.send_json({"ok": False, "error": str(exc)}, 400)
            return
        with PUSH_TOKENS_LOCK:
            tokens = load_push_tokens()
            target = None
            for item in tokens:
                if item["token"] == token:
                    target = item
                    break
            if target is None:
                self.send_json({"ok": False, "error": "token not found"}, 404)
                return
            if "remark" in payload:
                target["remark"] = str(payload["remark"] or "").strip()[:120]
            if "enabled" in payload:
                target["enabled"] = bool(payload["enabled"])
            if isinstance(payload.get("blocked_ips"), list):
                target["blocked_ips"] = [
                    str(ip).strip() for ip in payload["blocked_ips"] if str(ip).strip()
                ]
            add_ip = str(payload.get("add_blocked_ip") or "").strip()
            if add_ip:
                if add_ip not in target["blocked_ips"]:
                    target["blocked_ips"].append(add_ip)
            remove_ip = str(payload.get("remove_blocked_ip") or "").strip()
            if remove_ip and remove_ip in target["blocked_ips"]:
                target["blocked_ips"] = [
                    ip for ip in target["blocked_ips"] if ip != remove_ip
                ]
            save_push_tokens(tokens)
        log_push_event("updated", token, self.audit_client_ip(), "")
        self.send_json({"ok": True, "token_masked": push_token_masked(token)})

    def do_HEAD(self) -> None:
        self.do_GET()

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        if parsed.path == "/api/push-tokens":
            tokens = load_push_tokens()
            items = []
            for item in tokens:
                items.append({
                    "token": item["token"],
                    "token_masked": push_token_masked(item["token"]),
                    "remark": item["remark"],
                    "created_at": item["created_at"],
                    "enabled": item["enabled"],
                    "blocked_ips": item["blocked_ips"],
                    "last_push": item["last_push"],
                    "last_ip": item["last_ip"],
                })
            self.send_json({"ok": True, "tokens": items})
            return
        if parsed.path == "/robots.txt":
            self.send_text(public_robots_txt())
            return
        if parsed.path == "/sitemap.xml":
            self.send_text(public_sitemap_xml(), "application/xml; charset=utf-8")
            return
        if parsed.path == "/favicon.svg":
            self.send_text(public_favicon_svg(), "image/svg+xml; charset=utf-8", cache_control="public, max-age=604800")
            return
        if parsed.path == "/assets/public-query-preview-20260723.png":
            if PUBLIC_PREVIEW_PATH.is_file():
                self.send_binary(PUBLIC_PREVIEW_PATH.read_bytes(), "image/png", cache_control="public, max-age=604800")
            else:
                self.send_binary(b"", "image/png", 404, "no-store")
            return
        if parsed.path == "/assets/contact-info.png":
            if PUBLIC_CONTACT_ASSET_PATH.is_file():
                self.send_binary(PUBLIC_CONTACT_ASSET_PATH.read_bytes(), "image/png", cache_control="public, max-age=86400")
            else:
                self.send_binary(b"", "image/png", 404, "no-store")
            return
        if parsed.path in (
            "/downloads/wgame-val-connect.ps1",
            "/downloads/wgame-val-restore.ps1",
        ):
            if not self.live_risk_accepted():
                self.send_text(
                    "请先阅读并确认实时对局风险协议，再下载连接脚本。\n",
                    status=403,
                    cache_control="no-store",
                )
                return
            kind = "restore" if parsed.path.endswith("restore.ps1") else "connect"
            self.send_download(
                netbar_powershell_script(kind),
                "text/plain; charset=utf-8",
                f"wgame-val-{kind}.ps1",
            )
            return
        verification_name = urllib.parse.unquote(parsed.path.lstrip("/"))
        if BAIDU_VERIFY_RE.fullmatch(verification_name):
            self.send_baidu_verification(verification_name)
            return
        if parsed.path.startswith("/assets/agent-icon/"):
            filename = urllib.parse.unquote(parsed.path.removeprefix("/assets/agent-icon/"))
            match = re.fullmatch(
                r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\.png",
                filename,
                re.I,
            )
            if not match:
                self.send_binary(b"", "image/png", 404, "no-store")
                return
            try:
                self.send_binary(agent_icon_bytes(match.group(1)), "image/png")
            except Exception:
                self.send_binary(b"", "image/png", 404, "no-store")
            return
        if parsed.path.startswith("/assets/map-art/"):
            filename = urllib.parse.unquote(parsed.path.removeprefix("/assets/map-art/"))
            match = re.fullmatch(r"([a-z0-9_]+)\.png", filename, re.I)
            if not match:
                self.send_binary(b"", "image/png", 404, "no-store")
                return
            try:
                self.send_binary(
                    map_art_bytes(match.group(1)),
                    "image/png",
                    cache_control="public, max-age=2592000",
                )
            except Exception:
                self.send_binary(b"", "image/png", 404, "no-store")
            return
        if parsed.path == "/api/recent-cache":
            self.send_html(recent_cache_rows_html())
            return
        if parsed.path == "/api/admin/name-search-ranks":
            task_id = (params.get("id") or [""])[0].strip().lower()
            snapshot = nickname_rank_task_snapshot(task_id)
            if snapshot:
                self.send_json(snapshot)
            else:
                self.send_json({"ok": False, "error": "段位查询任务不存在或已过期"}, 404)
            return
        if parsed.path == "/api/public/battle-detail":
            detail_ref = (params.get("ref") or [""])[0].strip()
            try:
                payload, status = public_battle_detail_payload(detail_ref)
                self.send_json(payload, status)
            except Exception:
                self.send_json({"ok": False, "error": "单局详情暂时不可用，请稍后重试。"}, 500)
            return
        if (
            parsed.path == "/api/public/current-room-status"
            or parsed.path.startswith("/api/public/task/")
        ) and not self.live_risk_accepted():
            locked = self.live_risk_locked()
            self.send_json(
                {
                    "ok": False,
                    "code": (
                        "live_risk_permanently_locked"
                        if locked
                        else "live_risk_consent_required"
                    ),
                    "error": (
                        "当前浏览器已撤回确认并永久锁定实时功能"
                        if locked
                        else "请先阅读并确认实时对局风险协议"
                    ),
                    "agreement_url": "/live/agreement",
                },
                403,
            )
            return
        if parsed.path == "/api/public/current-room-status":
            available_sessions = self.public_live_sessions()
            session = self.public_live_session(available_sessions)
            if not session:
                error = "请先在实时对局页选择自己的游戏账号" if available_sessions else "暂未识别到当前网络的游戏会话"
                self.send_json({"ok": False, "error": error}, 409 if available_sessions else 404)
                return
            try:
                payload = current_party_room_status(str(session.get("id") or ""))
                room = payload.get("room") if isinstance(payload.get("room"), dict) else {}
                self.send_json(
                    {
                        "ok": True,
                        "room": {
                            "state": room.get("state"),
                            "member_count": room.get("member_count"),
                            "matched_member_count": room.get("matched_member_count"),
                            "other_member_count": room.get("other_member_count"),
                            "match_phase": room.get("match_phase"),
                            "match_state": room.get("match_state"),
                            "member_signature": room.get("member_signature"),
                        },
                    }
                )
            except Exception:
                self.send_json({"ok": False, "error": "暂未检测到组队房间或匹配队伍"}, 400)
            return
        if parsed.path.startswith("/api/public/task/"):
            parts = [part for part in parsed.path.split("/") if part]
            if len(parts) == 4:
                snap = public_task_snapshot(parts[3], self.public_live_viewer_key())
                if snap:
                    self.send_json(snap)
                    return
            self.send_json({"ok": False, "error": "任务不存在或已过期"}, 404)
            return
        if parsed.path == "/api/live-sessions":
            self.send_json({"ok": True, "sessions": pushed_game_sessions()})
            return
        if parsed.path == "/api/admin/live-status":
            session_id = (params.get("session") or [""])[0].strip().lower()
            if not re.fullmatch(r"[0-9a-f]{16}", session_id):
                self.send_json(
                    {"ok": False, "text": "会话参数不正确", "hint": ""},
                    400,
                )
                return
            payload = admin_live_status_payload(session_id)
            self.send_json(payload, 200 if payload.get("ok") else 404)
            return
        if parsed.path == "/api/current-room-teammates":
            session_id = (params.get("session") or [""])[0].strip()
            try:
                self.send_json(start_current_room_teammates_task(session_id))
            except Exception as exc:
                self.send_json({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, 400)
            return
        if parsed.path == "/api/current-room-status":
            session_id = (params.get("session") or [""])[0].strip()
            try:
                self.send_json(current_party_room_status(session_id))
            except Exception as exc:
                self.send_json({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, 400)
            return
        if parsed.path == "/api/qq-summary":
            query = (params.get("q") or [""])[0].strip()
            limit = to_int((params.get("limit") or ["5"])[0], 5) or 5
            try:
                payload = qq_summary_payload(query, max(1, min(limit, 10)))
                self.send_json(payload, 200 if payload.get("ok") else 400)
            except Exception as exc:
                self.send_json({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, 500)
            return
        if parsed.path.startswith("/api/task/"):
            parts = [part for part in parsed.path.split("/") if part]
            if len(parts) >= 3:
                task_id = parts[2]
                if len(parts) == 4 and parts[3] == "save":
                    body = task_html(task_id)
                    path = save_html_page(f"助手页-异步-{task_id[:8]}", body)
                    self.send_json({"ok": True, "href": page_href(path), "page": str(path)})
                    return
                snap = task_snapshot(task_id)
                if snap:
                    self.send_json(snap)
                    return
            self.send_json({"ok": False, "error": "task not found"}, 404)
            return
        if parsed.path.startswith("/pages/"):
            self.send_page_file(urllib.parse.unquote(parsed.path.removeprefix("/pages/")))
            return
        if parsed.path == "/api/wegame-session-status":
            healthy = wegame_session_healthy()
            self.send_json({"ok": True, "healthy": healthy, "message": "WeGame 登录态正常" if healthy else "WeGame 登录态已过期"})
            return
        if parsed.path == "/":
            self.send_html(render_index())
            return
        if parsed.path in {"/admin/name-search", "/admin/name-scan"}:
            self.send_html(
                render_nickname_scan_admin(),
                x_robots="noindex, nofollow, noarchive",
            )
            return
        if parsed.path == "/public":
            self.send_html(render_public_index(), cache_control="public, max-age=300")
            return
        if parsed.path == "/party-analysis-demo":
            if PARTY_ANALYSIS_DEMO_PATH.is_file():
                self.send_html(
                    PARTY_ANALYSIS_DEMO_PATH.read_text(encoding="utf-8"),
                    cache_control="public, max-age=300",
                )
            else:
                self.send_html("<h1>组队分析示例暂不可用</h1>", status=404)
            return
        if parsed.path == "/privacy":
            self.send_html(render_public_privacy(), cache_control="public, max-age=300")
            return
        if parsed.path == "/live/agreement":
            next_path = (params.get("next") or ["/live"])[0]
            self.send_live_risk_agreement(next_path)
            return
        if parsed.path == "/live" and not self.live_risk_accepted():
            self.send_live_risk_agreement("/live", index=True)
            return
        if parsed.path in {"/live/select", "/live/room", "/live/match"} and not self.live_risk_accepted():
            self.send_live_risk_agreement(self.path)
            return
        if parsed.path == "/live/select":
            choice = (params.get("choice") or [""])[0].strip().lower()
            next_path = (params.get("next") or ["/live"])[0].strip()
            available_sessions = self.public_live_sessions()
            viewer_key = self.public_live_viewer_key()
            selected = None
            if re.fullmatch(r"[0-9a-f]{24}", choice):
                selected = next(
                    (
                        session
                        for session in available_sessions
                        if secrets.compare_digest(
                            public_session_choice_token(str(session.get("id") or ""), viewer_key),
                            choice,
                        )
                    ),
                    None,
                )
            if not selected:
                self.send_html(
                    render_public_live(
                        None,
                        "这个游戏会话已经失效，或不属于当前访问网络，请刷新后重新选择。",
                        index=False,
                        sessions=available_sessions,
                        viewer_key=viewer_key,
                    ),
                    400,
                    x_robots="noindex, follow",
                )
                return
            self.audit_live_session("select", selected, "/live/select")
            self.send_public_live_redirect(next_path, choice)
            return
        if parsed.path == "/live":
            available_sessions = self.public_live_sessions()
            session = self.public_live_session(available_sessions)
            self.send_html(
                render_public_live(
                    session,
                    sessions=available_sessions,
                    viewer_key=self.public_live_viewer_key(),
                ),
                cache_control="no-store",
            )
            return
        if parsed.path == "/live/room":
            available_sessions = self.public_live_sessions()
            session = self.public_live_session(available_sessions)
            if not session:
                message = (
                    "请先从下方列表选择属于自己的游戏账号，再查看房间队友。"
                    if available_sessions
                    else "暂未识别到当前网络的游戏会话。完成配套连接并启动游戏后再刷新。"
                )
                self.send_html(
                    render_public_live(
                        None,
                        message,
                        index=False,
                        sessions=available_sessions,
                        viewer_key=self.public_live_viewer_key(),
                    ),
                    x_robots="noindex, follow",
                )
                return
            try:
                started = start_current_room_teammates_task(
                    str(session.get("id") or ""),
                    public=True,
                    viewer_key=self.public_live_viewer_key(),
                )
                self.audit_live_session("room", session, "/live/room")
                self.send_html(
                    render_teammates_live(started, public=True),
                    x_robots="noindex, follow",
                )
            except Exception:
                self.audit_live_session("room", session, "/live/room", "unavailable")
                self.send_html(
                    render_public_live(
                        session,
                        "暂未检测到组队房间或匹配队伍，请进入组队大厅后再刷新。",
                        index=False,
                        sessions=available_sessions,
                        viewer_key=self.public_live_viewer_key(),
                    ),
                    x_robots="noindex, follow",
                )
            return
        if parsed.path == "/live/match":
            available_sessions = self.public_live_sessions()
            session = self.public_live_session(available_sessions)
            if not session:
                message = (
                    "请先从下方列表选择属于自己的游戏账号，再查看当前对局。"
                    if available_sessions
                    else "暂未识别到当前网络的游戏会话。完成配套连接并启动游戏后再刷新。"
                )
                self.send_html(
                    render_public_live(
                        None,
                        message,
                        index=False,
                        sessions=available_sessions,
                        viewer_key=self.public_live_viewer_key(),
                    ),
                    x_robots="noindex, follow",
                )
                return
            try:
                result = probe_current_match("", session_id=str(session.get("id") or ""))
                result_status = "ok" if result.get("ok") else "unavailable"
                self.audit_live_session("match", session, "/live/match", result_status)
                body = render_probe_result(
                    "",
                    result,
                    public=True,
                    viewer_key=self.public_live_viewer_key(),
                )
                self.send_html(body, x_robots="noindex, follow")
            except Exception:
                self.audit_live_session("match", session, "/live/match", "error")
                self.send_html(
                    render_public_live(
                        session,
                        "暂未检测到正在进行的选人或对局，请进入匹配后再刷新。",
                        index=False,
                        sessions=available_sessions,
                        viewer_key=self.public_live_viewer_key(),
                    ),
                    x_robots="noindex, follow",
                )
            return
        if parsed.path == "/launch-chrome":
            try:
                message = launch_chrome()
                self.send_html(render_index(f"{message} 请在专用 Chrome 里确认 WeGame 登录状态，然后回来查询。"))
            except Exception as exc:
                self.send_html(render_index(f"启动 Chrome 失败：{exc}"), 500)
            return
        if parsed.path == "/import-default":
            count = default_import()
            self.send_html(render_index(f"导入完成，写入/更新 {count} 条 subject 映射。"))
            return
        if parsed.path == "/scan-alias-captures":
            try:
                self.send_html(render_scan_results(scan_aliases_and_build_pages()))
            except Exception as exc:
                self.send_html(render_index(f"扫描好友添加抓包失败：{type(exc).__name__}: {exc}"), 500)
            return
        if parsed.path == "/assistant":
            try:
                body = render_assistant(load_assistant_players())
                save_html_page("助手页-当前对局", body)
                self.send_html(body)
            except Exception as exc:
                self.send_html(render_index(f"助手页生成失败：{type(exc).__name__}: {exc}"), 500)
            return
        if parsed.path in {"/admin/live", "/live-sessions"}:
            self.send_html(
                render_live_sessions(),
                x_robots="noindex, nofollow, noarchive",
            )
            return
        if parsed.path == "/teammates-live":
            session_id = (params.get("session") or [""])[0].strip()
            try:
                self.send_html(render_teammates_live(start_current_room_teammates_task(session_id)))
            except Exception as exc:
                self.send_html(render_live_sessions(f"队友近 3 场启动失败：{type(exc).__name__}: {exc}"), 400)
            return
        if parsed.path == "/assistant-live":
            session_id = (params.get("session") or [""])[0].strip()
            if not session_id:
                self.send_html(render_live_sessions("请选择要查看的实时对局。"))
                return
            try:
                self.send_html(render_probe_result("", probe_current_match("", session_id=session_id)))
            except Exception as exc:
                self.send_html(render_index(f"实时助手页启动失败：{type(exc).__name__}: {exc}"), 500)
            return
        if parsed.path == "/probe-current-match":
            subject = (params.get("subject") or [""])[0].strip().lower()
            session_id = (params.get("session") or [""])[0].strip()
            try:
                self.send_html(render_probe_result(subject, probe_current_match(subject, session_id=session_id)))
            except Exception as exc:
                self.send_html(render_index(f"当前对局探测异常：{type(exc).__name__}: {exc}"), 500)
            return
        if parsed.path == "/battle":
            subject = (params.get("subject") or [""])[0].strip().lower()
            ap_event_id = (params.get("apEventId") or [""])[0].strip()
            if not SUBJECT_RE.match(subject) or not ap_event_id:
                self.send_html(render_index("单局详情参数不完整，需要 subject 和 apEventId。"), 400)
                return
            try:
                data = browser_battle_detail(ap_event_id, subject)
                if not isinstance(data.get("battle_detail"), dict):
                    cached = load_cached_battle_details().get(ap_event_id)
                    if isinstance(cached, dict):
                        data = {"result": {"error_code": 0}, "battle_detail": cached, "detail_source": "local-cache"}
                if not isinstance(data.get("battle_detail"), dict):
                    known_battle = battle_summary_from_list(subject, ap_event_id)
                    fallback = browser_matchup_detail(ap_event_id, subject, known_battle)
                    fallback_detail = fallback.get("battle_detail") if isinstance(fallback, dict) else None
                    fallback_players = fallback_detail.get("players") if isinstance(fallback_detail, dict) else None
                    if isinstance(fallback_players, list) and fallback_players:
                        data = fallback
                self.send_html(render_battle_detail(subject, ap_event_id, data))
            except Exception as exc:
                self.send_html(render_index(f"单局详情异常：{type(exc).__name__}: {exc}"), 500)
            return
        if parsed.path == "/query":
            query = (params.get("q") or [""])[0].strip()
            if not query:
                self.send_html(render_index("请输入 昵称#数字 或 subject。"))
                return
            try:
                subject, display, resolve_source = resolve_subject(query)
            except Exception as exc:
                self.send_html(render_index(f"没有解析到 {query} 的 subject：{exc}"))
                return
            if not subject:
                self.send_html(render_index(f"没有找到 {query} 的 subject。请保持游戏客户端在线，或先导入缓存。"))
                return
            try:
                source, data = query_battles(subject, 10)
                body = render_battles(query, display or query, subject, f"{source} / {resolve_source}", data)
                if battles_response_ok(data):
                    save_html_page(f"{display or query}-近期战绩", body)
                self.send_html(body)
            except Exception as exc:
                self.send_html(render_index(f"查询异常：{type(exc).__name__}: {exc}"), 500)
            return
        if parsed.path == "/public-query":
            query = (params.get("q") or [""])[0].strip()
            if not query:
                self.send_html(render_public_index("请输入 昵称#ID。"), x_robots="noindex, follow")
                return
            try:
                subject, display, resolve_source = resolve_subject(query)
            except Exception as exc:
                self.audit_public_query(query, "not_found")
                self.send_html(
                    render_public_index(f"没有找到该玩家，请检查昵称和数字 ID。", query),
                    x_robots="noindex, follow",
                )
                return
            if not subject:
                self.audit_public_query(query, "not_found")
                self.send_html(
                    render_public_index("没有找到该玩家，请检查昵称和数字 ID。", query),
                    x_robots="noindex, follow",
                )
                return
            try:
                source, data = query_battles(subject, 10)
                result_status = "ok" if battles_response_ok(data) else "upstream_error"
                self.audit_public_query(
                    query,
                    result_status,
                    display=display or query,
                    subject=subject,
                )
                body = render_battles(query, display or query, subject, f"{source} / {resolve_source}", data, public=True)
                self.send_html(body, x_robots="noindex, follow")
            except Exception as exc:
                session_healthy = wegame_session_healthy()
                self.audit_public_query(
                    query,
                    "error" if session_healthy else "unavailable",
                    display=display or query,
                    subject=subject,
                )
                print(
                    f"[public-query] unavailable: {type(exc).__name__}: {exc}",
                    file=sys.stderr,
                )
                self.send_html(
                    render_public_index(
                        "查询服务正在恢复，请稍后再试。"
                        if not session_healthy
                        else "查询暂时不可用，请稍后重试。",
                        query,
                    ),
                    503 if not session_healthy else 500,
                    x_robots="noindex, follow",
                )
            return
        self.send_html(render_index("未知路径。"), 404)

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))


def run_server(port: int) -> None:
    init_db()
    init_audit_db()
    start_wegame_keep_alive()
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"Open http://127.0.0.1:{port}/")
    httpd.serve_forever()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=SERVER_PORT)
    parser.add_argument("--import-file", type=Path)
    parser.add_argument("--launch-chrome", action="store_true")
    args = parser.parse_args()
    init_db()
    if args.import_file:
        print(json.dumps({"imported": import_file(args.import_file)}, ensure_ascii=False))
        return
    if args.launch_chrome:
        launch_chrome()
        return
    run_server(args.port)


if __name__ == "__main__":
    main()
