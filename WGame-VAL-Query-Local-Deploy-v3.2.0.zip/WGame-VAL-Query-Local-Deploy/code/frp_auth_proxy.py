from __future__ import annotations

import argparse
import html
import http.client
import json
import re
import secrets
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit


HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
}

PUBLIC_GET_PATHS = {
    "/",
    "/public",
    "/public-query",
    "/privacy",
    "/party-analysis-demo",
    "/live",
    "/live/agreement",
    "/live/select",
    "/live/room",
    "/live/match",
    "/api/public/current-room-status",
    "/api/public/battle-detail",
    "/robots.txt",
    "/sitemap.xml",
    "/favicon.svg",
    "/assets/public-query-preview.jpg",
    "/assets/public-query-preview-20260723.png",
    "/assets/contact-info.png",
    "/downloads/wgame-val-connect.ps1",
    "/downloads/wgame-val-restore.ps1",
}
PUBLIC_POST_PATHS = {
    "/live/agree",
    "/live/revoke",
    "/api/push-game-token",
}
BAIDU_VERIFY_PATH_RE = re.compile(r"^/baidu_verify_[A-Za-z0-9_-]+\.html$")
PUBLIC_TASK_PATH_RE = re.compile(r"^/api/public/task/[0-9a-f]{32}$")
PUBLIC_AGENT_ICON_PATH_RE = re.compile(
    r"^/assets/agent-icon/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.png$",
    re.I,
)
PUBLIC_MAP_ART_PATH_RE = re.compile(
    r"^/assets/map-art/[a-z0-9_]+\.png$",
    re.I,
)

LOGIN_PATHS = {
    "/owner-login",
    "/login",
}

LOGOUT_PATH = "/logout"
OWNER_SHORTCUT_PATHS = {
    "/me": "/admin/live",
    "/mine": "/admin/live",
    "/owner": "/admin/live",
}


def load_or_create_token(path: Path) -> str:
    if path.exists():
        token = path.read_text(encoding="utf-8").strip()
        if token:
            return token
    token = secrets.token_urlsafe(24)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(token + "\n", encoding="utf-8")
    return token


def secure_text_equal(left: str, right: str) -> bool:
    return secrets.compare_digest(
        str(left).encode("utf-8"),
        str(right).encode("utf-8"),
    )


def strip_auth_query(path: str) -> str:
    parsed = urlsplit(path)
    pairs = parse_qs(parsed.query, keep_blank_values=True)
    for key in ("k", "key", "token"):
        pairs.pop(key, None)
    query = urlencode(pairs, doseq=True)
    return urlunsplit(("", "", parsed.path, query, parsed.fragment))


class AuthProxyHandler(BaseHTTPRequestHandler):
    upstream_host = "127.0.0.1"
    upstream_port = 8787
    token = ""
    cookie_name = "wgame_query_token"

    server_version = "WGameAuthProxy/1.0"

    def handle(self) -> None:
        try:
            super().handle()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def do_GET(self) -> None:
        parsed = urlsplit(self.path)
        if parsed.path in LOGIN_PATHS:
            self._handle_login_get()
            return
        if parsed.path == LOGOUT_PATH:
            self._handle_logout()
            return
        if parsed.path in OWNER_SHORTCUT_PATHS:
            self._handle_owner_shortcut(OWNER_SHORTCUT_PATHS[parsed.path])
            return
        self._proxy()

    def do_POST(self) -> None:
        parsed = urlsplit(self.path)
        if parsed.path in LOGIN_PATHS:
            self._handle_login_post()
            return
        self._proxy()

    def do_HEAD(self) -> None:
        self._proxy()

    def _authorized(self) -> bool:
        parsed = urlsplit(self.path)
        if self.command in ("GET", "HEAD") and (
            parsed.path in PUBLIC_GET_PATHS
            or BAIDU_VERIFY_PATH_RE.fullmatch(parsed.path)
            or PUBLIC_TASK_PATH_RE.fullmatch(parsed.path)
            or PUBLIC_AGENT_ICON_PATH_RE.fullmatch(parsed.path)
            or PUBLIC_MAP_ART_PATH_RE.fullmatch(parsed.path)
        ):
            return True
        if self.command == "POST" and parsed.path in PUBLIC_POST_PATHS:
            return True
        return self._credential_authorized()

    def _credential_authorized(self) -> bool:
        supplied = self._token_from_path(self.path)
        if supplied and secure_text_equal(supplied, self.token):
            return True

        referer = self.headers.get("Referer", "")
        referer_token = self._token_from_path(referer)
        if referer_token and secure_text_equal(referer_token, self.token):
            return True

        cookie = self.headers.get("Cookie", "")
        marker = f"{self.cookie_name}={self.token}"
        return marker in cookie

    @staticmethod
    def _token_from_path(path: str) -> str:
        parsed = urlsplit(path)
        query = parse_qs(parsed.query)
        supplied = query.get("k") or query.get("key") or query.get("token")
        return supplied[0] if supplied else ""

    @staticmethod
    def _safe_next(value: str | None, default: str = "/admin/live") -> str:
        candidate = (value or default).strip() or default
        parsed = urlsplit(candidate)
        if parsed.scheme or parsed.netloc or not candidate.startswith("/") or candidate.startswith("//"):
            return default
        return candidate

    def _next_from_query(self, default: str = "/admin/live") -> str:
        parsed = urlsplit(self.path)
        query = parse_qs(parsed.query)
        return self._safe_next((query.get("next") or [""])[0], default)

    def _send_redirect(self, target: str, set_cookie: bool = False, clear_cookie: bool = False) -> None:
        self.send_response(HTTPStatus.SEE_OTHER)
        self.send_header("Location", target)
        self.send_header("Cache-Control", "no-store")
        if set_cookie:
            self.send_header("Set-Cookie", f"{self.cookie_name}={self.token}; Path=/; HttpOnly; SameSite=Lax")
        if clear_cookie:
            self.send_header("Set-Cookie", f"{self.cookie_name}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax")
        self.end_headers()

    def _send_login_page(self, message: str = "", next_path: str = "/admin/live", status: HTTPStatus = HTTPStatus.OK) -> None:
        safe_next = self._safe_next(next_path)
        msg_html = f"<p class='msg'>{html.escape(message)}</p>" if message else ""
        body = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>管理员登录</title>
  <style>
    :root {{ color-scheme: dark; --bg:#0d151e; --panel:#141f2a; --line:#2a3948; --text:#eef7ff; --muted:#8fa5ba; --gold:#ffd166; --blue:#96d9ff; --red:#ff5476; }}
    * {{ box-sizing: border-box; }}
    body {{ margin:0; min-height:100vh; display:grid; place-items:center; background:var(--bg); color:var(--text); font-family:"Microsoft YaHei","Segoe UI",Arial,sans-serif; }}
    main {{ width:min(560px, calc(100vw - 28px)); }}
    .top {{ display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; color:var(--muted); font-size:13px; }}
    a {{ color:var(--gold); text-decoration:none; }}
    .panel {{ background:var(--panel); border:1px solid var(--line); border-radius:8px; padding:24px; box-shadow:0 18px 60px rgba(0,0,0,.22); }}
    h1 {{ margin:0 0 8px; font-size:28px; line-height:1.15; }}
    p {{ margin:0 0 18px; color:var(--muted); line-height:1.6; }}
    label {{ display:block; margin:0 0 8px; color:var(--blue); font-weight:800; }}
    input {{ width:100%; height:46px; border:1px solid #3b5165; border-radius:6px; background:#0f1822; color:#fff; padding:0 13px; font-size:16px; outline:none; }}
    input:focus {{ border-color:var(--blue); }}
    .actions {{ display:flex; gap:10px; flex-wrap:wrap; margin-top:16px; }}
    button,.btn {{ min-height:42px; border:1px solid #4b6072; border-radius:6px; background:#1d2b38; color:#fff; padding:0 16px; font-weight:900; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; }}
    button.primary {{ background:var(--gold); border-color:var(--gold); color:#111923; }}
    .msg {{ color:var(--red); margin:0 0 14px; }}
    .hint {{ margin-top:16px; color:var(--muted); font-size:13px; }}
  </style>
</head>
<body>
<main>
  <div class="top"><a href="/public">公开查询</a><span>WeGame VAL</span></div>
  <form class="panel" method="post" action="/owner-login">
    <h1>管理员登录</h1>
    <p>该入口需要管理员权限。验证通过后，浏览器会在本次登录期间记住管理状态。</p>
    {msg_html}
    <input type="hidden" name="next" value="{html.escape(safe_next, quote=True)}">
    <label for="k">访问口令</label>
    <input id="k" name="k" type="password" autocomplete="current-password" autofocus>
    <div class="actions">
      <button class="primary" type="submit">进入管理页</button>
      <a class="btn" href="/public">返回公开查询</a>
    </div>
    <div class="hint">到网吧使用时，先进入实时对局页，页面里会展示连接代理、验证和恢复命令。</div>
  </form>
</main>
</body>
</html>"""
        encoded = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Robots-Tag", "noindex, nofollow, noarchive")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(encoded)

    def _handle_login_get(self) -> None:
        next_path = self._next_from_query()
        supplied = self._token_from_path(self.path)
        if supplied and secure_text_equal(supplied, self.token):
            self._send_redirect(next_path, set_cookie=True)
            return
        if self._credential_authorized():
            self._send_redirect(next_path, set_cookie=True)
            return
        self._send_login_page(next_path=next_path)

    def _handle_login_post(self) -> None:
        try:
            length = int(self.headers.get("Content-Length") or "0")
        except ValueError:
            length = 0
        if length <= 0 or length > 8192:
            self._send_login_page("提交内容不正确。", status=HTTPStatus.BAD_REQUEST)
            return
        raw = self.rfile.read(length).decode("utf-8", errors="replace")
        form = parse_qs(raw, keep_blank_values=True)
        supplied = (form.get("k") or form.get("key") or form.get("token") or form.get("password") or [""])[0]
        next_path = self._safe_next((form.get("next") or [""])[0])
        if secure_text_equal(supplied, self.token):
            self._send_redirect(next_path, set_cookie=True)
            return
        self._send_login_page("口令不对，检查后再试。", next_path=next_path, status=HTTPStatus.UNAUTHORIZED)

    def _handle_logout(self) -> None:
        self._send_redirect("/public", clear_cookie=True)

    def _handle_owner_shortcut(self, target: str) -> None:
        if self._credential_authorized():
            self._send_redirect(target, set_cookie=True)
        else:
            self._send_login_page(next_path=target, status=HTTPStatus.UNAUTHORIZED)

    def _deny(self) -> None:
        parsed = urlsplit(self.path)
        if parsed.path.startswith("/api/"):
            data = json.dumps({"ok": False, "error": "auth required"}, ensure_ascii=False).encode("utf-8")
            self.send_response(HTTPStatus.UNAUTHORIZED)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(data)
            return
        next_path = self._safe_next(self.path)
        self._send_login_page("这个入口需要访问口令。", next_path=next_path, status=HTTPStatus.UNAUTHORIZED)

    def _legacy_deny(self) -> None:
        self.send_response(HTTPStatus.UNAUTHORIZED)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(
            (
                "<!doctype html><meta charset='utf-8'>"
                "<title>需要口令</title>"
                "<body style='font-family:system-ui;background:#101923;color:#dbeafe;padding:32px'>"
                "<h1>需要访问口令</h1>"
                "<p>在地址后加 <code>?k=你的口令</code> 访问。</p>"
                "</body>"
            ).encode("utf-8")
        )

    def _proxy(self) -> None:
        if not self._authorized():
            self._deny()
            return

        parsed = urlsplit(self.path)
        if parsed.path == "/api/push-game-token":
            upstream_path = self.path
        else:
            upstream_path = strip_auth_query(self.path)
        if self.command in ("GET", "HEAD") and parsed.path == "/":
            upstream_path = "/public"
        refresh_cookie = self._credential_authorized()
        body = None
        length = self.headers.get("Content-Length")
        if length:
            body = self.rfile.read(int(length))

        headers = {
            key: value
            for key, value in self.headers.items()
            if key.lower() not in HOP_BY_HOP_HEADERS and key.lower() != "host"
        }
        headers["Host"] = f"{self.upstream_host}:{self.upstream_port}"
        incoming_forwarded = self.headers.get("X-Forwarded-For", "").strip()
        peer = self.client_address[0]
        if incoming_forwarded and peer in ("127.0.0.1", "::1"):
            headers["X-Forwarded-For"] = incoming_forwarded
        elif incoming_forwarded:
            headers["X-Forwarded-For"] = f"{incoming_forwarded}, {peer}"
        else:
            headers["X-Forwarded-For"] = peer

        try:
            conn = http.client.HTTPConnection(self.upstream_host, self.upstream_port, timeout=30)
            conn.request(self.command, upstream_path, body=body, headers=headers)
            resp = conn.getresponse()
            data = b"" if self.command == "HEAD" else resp.read()
        except Exception as exc:
            self.send_response(HTTPStatus.BAD_GATEWAY)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            try:
                self.wfile.write(
                    f"Upstream error: {type(exc).__name__}: {exc}".encode("utf-8")
                )
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
            return
        finally:
            try:
                conn.close()
            except Exception:
                pass

        self.send_response(resp.status, resp.reason)
        for key, value in resp.getheaders():
            if key.lower() in HOP_BY_HOP_HEADERS:
                continue
            self.send_header(key, value)
        if refresh_cookie:
            self.send_header("Set-Cookie", f"{self.cookie_name}={self.token}; Path=/; HttpOnly; SameSite=Lax")
        self.end_headers()
        if data:
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"{self.address_string()} - {fmt % args}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--listen-host", default="127.0.0.1")
    parser.add_argument("--listen-port", type=int, default=8790)
    parser.add_argument("--upstream-host", default="127.0.0.1")
    parser.add_argument("--upstream-port", type=int, default=8787)
    parser.add_argument("--token-file", type=Path, default=Path("captures/public-query-token.txt"))
    args = parser.parse_args()

    token = load_or_create_token(args.token_file)
    AuthProxyHandler.upstream_host = args.upstream_host
    AuthProxyHandler.upstream_port = args.upstream_port
    AuthProxyHandler.token = token

    server = ThreadingHTTPServer((args.listen_host, args.listen_port), AuthProxyHandler)
    print(f"Auth proxy listening on http://{args.listen_host}:{args.listen_port}", flush=True)
    print(f"Token file: {args.token_file.resolve()}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
