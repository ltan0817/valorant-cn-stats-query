from __future__ import annotations

import argparse
import csv
import html
import json
import re
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any


PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

import wgame_query_server as server


BATTLE_LIST_PATH = "/api/v1/wegame.pallas.game.ValBattle/GetBattleList"


def compact_cursor(value: Any) -> str:
    digits = re.sub(r"\D", "", str(value or ""))
    return digits[:14]


def battle_key(battle: dict[str, Any]) -> str:
    return str(
        battle.get("apEventId")
        or battle.get("matchId")
        or f"{battle.get('dtEventTime')}:{battle.get('queueId')}:{battle.get('characterId')}"
    )


def normalized_row(battle: dict[str, Any]) -> dict[str, Any]:
    rounds_played = int(battle.get("roundsPlayed") or battle.get("statsRoundsPlayed") or 0)
    rounds_won = int(battle.get("roundsWon") or 0)
    rounds_lost = max(0, rounds_played - rounds_won)
    score = int(battle.get("statsScore") or 0)
    acs = round(score / rounds_played) if rounds_played else ""
    won = battle.get("wonMatch")
    result = "胜利" if won in (1, "1", True) else "失败" if won in (0, "0", False) else "未知"
    queue_id = str(battle.get("queueId") or "")
    rank_before = battle.get("CompetitiveTierBefore") or battle.get("competitiveTier") or ""
    rank_after = battle.get("CompetitiveTierAfter") or battle.get("competitiveTier") or ""
    return {
        "时间": battle.get("dtEventTime") or "",
        "模式": queue_id,
        "结果": result,
        "比分": f"{rounds_won}:{rounds_lost}" if rounds_played else "",
        "英雄": server.agent_name(battle.get("characterId")),
        "击杀": battle.get("statsKills") or 0,
        "死亡": battle.get("statsDeaths") or 0,
        "助攻": battle.get("statsAssists") or 0,
        "ACS": acs,
        "地图": server.map_name(battle.get("mapId")),
        "段位前": server.rank_name(rank_before) if rank_before != "" else "",
        "段位后": server.rank_name(rank_after) if rank_after != "" else "",
        "RR变化": battle.get("CompetitiveTierRankedRatingEarned") or "",
        "时长分钟": round(int(battle.get("gameLengthMillis") or 0) / 60000, 1),
        "队伍MVP": bool(battle.get("isTeamMvp")),
        "全场MVP": bool(battle.get("isMatchMvp")),
        "首杀": battle.get("firstKillCount") or 0,
        "四杀": battle.get("quadraKillCount") or 0,
        "五杀": battle.get("pentaKillCount") or 0,
        "apEventId": battle.get("apEventId") or "",
        "matchId": battle.get("matchId") or "",
        "partyId": battle.get("partyId") or "",
    }


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8-sig")
        return
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_html(path: Path, display_name: str, rows: list[dict[str, Any]]) -> None:
    headers = list(rows[0]) if rows else []
    table_headers = "".join(f"<th>{html.escape(str(header))}</th>" for header in headers)
    table_rows = "".join(
        "<tr>" + "".join(f"<td>{html.escape(str(row.get(header, '')))}</td>" for header in headers) + "</tr>"
        for row in rows
    )
    path.write_text(
        f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{html.escape(display_name)} · 历史战绩</title>
  <style>
    body{{margin:0;background:#071019;color:#e8f4ff;font:14px/1.5 system-ui,"Microsoft YaHei",sans-serif}}
    main{{max-width:1600px;margin:auto;padding:28px}}
    h1{{margin:0 0 8px}} p{{color:#8fa5ba}}
    .table{{overflow:auto;border:1px solid #26394a;border-radius:10px}}
    table{{width:100%;border-collapse:collapse;white-space:nowrap}}
    th,td{{padding:9px 11px;border-bottom:1px solid #213240;text-align:left}}
    th{{position:sticky;top:0;background:#11202d;color:#70d8ff}}
    tr:hover td{{background:#0d1c28}}
  </style>
</head>
<body><main>
  <h1>{html.escape(display_name)} · 历史战绩</h1>
  <p>共 {len(rows)} 场；由 WeGame GetBattleList 分页采集，按时间倒序。</p>
  <div class="table"><table><thead><tr>{table_headers}</tr></thead><tbody>{table_rows}</tbody></table></div>
</main></body></html>
""",
        encoding="utf-8",
    )


def write_summary(
    path: Path,
    display_name: str,
    subject: str,
    rows: list[dict[str, Any]],
    stop_reason: str,
    requests_made: int,
) -> None:
    by_month = Counter(str(row.get("时间") or "")[:7] for row in rows if row.get("时间"))
    by_mode = Counter(str(row.get("模式") or "未知") for row in rows)
    by_result = Counter(str(row.get("结果") or "未知") for row in rows)
    newest = rows[0]["时间"] if rows else "-"
    oldest = rows[-1]["时间"] if rows else "-"
    lines = [
        f"# {display_name} · WeGame 历史战绩采集",
        "",
        f"- subject：`{subject}`",
        f"- 总场次：{len(rows)}",
        f"- 时间范围：{oldest} ～ {newest}",
        f"- 请求次数：{requests_made}",
        f"- 停止原因：{stop_reason}",
        "",
        "## 按月统计",
        "",
        "| 月份 | 场次 |",
        "|---|---:|",
    ]
    lines.extend(f"| {month} | {count} |" for month, count in sorted(by_month.items(), reverse=True))
    lines.extend(["", "## 按模式统计", "", "| 模式 | 场次 |", "|---|---:|"])
    lines.extend(f"| {mode} | {count} |" for mode, count in by_mode.most_common())
    lines.extend(["", "## 胜负统计", "", "| 结果 | 场次 |", "|---|---:|"])
    lines.extend(f"| {result} | {count} |" for result, count in by_result.most_common())
    lines.extend(
        [
            "",
            "## 文件说明",
            "",
            "- `matches.raw.json`：接口返回的原始对局记录。",
            "- `matches.csv`：整理后的全部模式记录。",
            "- `ranked.csv`：仅 `competitive` 排位记录。",
            "- `history.html`：可直接用浏览器查看的表格。",
            "- `by-month/`：按月份拆分的 CSV 与 JSON。",
            "",
            "单局完整 10 人详情未批量采集，以避免每场额外放大请求量并触发 WeGame 限流。",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def export_all(
    output_dir: Path,
    display_name: str,
    subject: str,
    battles: list[dict[str, Any]],
    stop_reason: str,
    requests_made: int,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = [normalized_row(battle) for battle in battles]
    write_json(output_dir / "matches.raw.json", battles)
    write_csv(output_dir / "matches.csv", rows)
    ranked = [row for row in rows if str(row.get("模式") or "").casefold() == "competitive"]
    write_csv(output_dir / "ranked.csv", ranked)
    write_html(output_dir / "history.html", display_name, rows)
    by_month_dir = output_dir / "by-month"
    by_month_dir.mkdir(parents=True, exist_ok=True)
    months = sorted({str(row.get("时间") or "")[:7] for row in rows if row.get("时间")}, reverse=True)
    for month in months:
        month_rows = [row for row in rows if str(row.get("时间") or "").startswith(month)]
        month_raw = [
            battle
            for battle in battles
            if str(battle.get("dtEventTime") or "").startswith(month)
        ]
        write_csv(by_month_dir / f"{month}.csv", month_rows)
        write_json(by_month_dir / f"{month}.json", month_raw)
    write_summary(
        output_dir / "README.md",
        display_name,
        subject,
        rows,
        stop_reason,
        requests_made,
    )


def fetch_page(subject: str, cursor: str) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "from_src": "valorant_web",
        "size": 10,
        "subject": subject,
    }
    if cursor:
        payload["after"] = cursor
    return server.browser_context_query(BATTLE_LIST_PATH, payload)


def main() -> int:
    parser = argparse.ArgumentParser(description="分页采集 WeGame 玩家历史战绩")
    parser.add_argument("--subject", required=True)
    parser.add_argument("--display-name", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--delay", type=float, default=3.0)
    parser.add_argument("--batch-pages", type=int, default=8)
    parser.add_argument("--cooldown", type=float, default=35.0)
    parser.add_argument("--max-pages", type=int, default=100)
    args = parser.parse_args()

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output_dir / "matches.checkpoint.json"
    request_log_path = output_dir / "collection.requests.json"
    battles: list[dict[str, Any]] = []
    if checkpoint_path.exists():
        loaded = json.loads(checkpoint_path.read_text(encoding="utf-8"))
        if isinstance(loaded, list):
            battles = [battle for battle in loaded if isinstance(battle, dict)]
    seen: set[str] = {battle_key(battle) for battle in battles}
    cursor = compact_cursor(battles[-1].get("dtEventTime")) if battles else ""
    stop_reason = "达到最大分页数"
    request_log: list[dict[str, Any]] = []
    if request_log_path.exists():
        loaded = json.loads(request_log_path.read_text(encoding="utf-8"))
        if isinstance(loaded, list):
            request_log = [item for item in loaded if isinstance(item, dict)]
    requests_made = len(request_log)
    completed_pages = max(
        (int(item.get("page") or 0) for item in request_log if item.get("error_code") == 0),
        default=0,
    )
    start_page = completed_pages + 1
    if battles:
        print(
            f"[resume] 已有 {len(battles)} 场、{completed_pages} 页，"
            f"从 cursor={cursor} 继续",
            flush=True,
        )

    for page_number in range(start_page, args.max_pages + 1):
        if page_number > 1:
            time.sleep(args.delay)
        if page_number > 1 and (page_number - 1) % args.batch_pages == 0:
            print(f"[cooldown] 已请求 {page_number - 1} 页，冷却 {args.cooldown:.0f} 秒", flush=True)
            time.sleep(args.cooldown)

        attempts = 0
        page_data: dict[str, Any] = {}
        page_battles: list[dict[str, Any]] | None = None
        while attempts < 3:
            attempts += 1
            requests_made += 1
            page_data = fetch_page(args.subject, cursor)
            result = page_data.get("result") if isinstance(page_data, dict) else None
            error_code = result.get("error_code") if isinstance(result, dict) else result
            candidate = page_data.get("battles") if isinstance(page_data, dict) else None
            request_log.append(
                {
                    "page": page_number,
                    "attempt": attempts,
                    "cursor": cursor,
                    "error_code": error_code,
                    "battle_count": len(candidate) if isinstance(candidate, list) else None,
                    "time": datetime.now().isoformat(timespec="seconds"),
                }
            )
            if error_code == 0 and isinstance(candidate, list):
                page_battles = candidate
                break
            wait_seconds = 15 * attempts
            print(
                f"[retry] 第 {page_number} 页 error={error_code!r}，{wait_seconds} 秒后重试",
                flush=True,
            )
            time.sleep(wait_seconds)

        if page_battles is None:
            result = page_data.get("result") if isinstance(page_data, dict) else None
            error_code = result.get("error_code") if isinstance(result, dict) else result
            stop_reason = f"第 {page_number} 页连续失败，error={error_code!r}"
            break
        if not page_battles:
            stop_reason = f"第 {page_number} 页返回空列表，已到可见历史末尾"
            break

        new_count = 0
        for battle in page_battles:
            if not isinstance(battle, dict):
                continue
            key = battle_key(battle)
            if key in seen:
                continue
            seen.add(key)
            battles.append(battle)
            new_count += 1

        last_time = str(page_battles[-1].get("dtEventTime") or "")
        next_cursor = compact_cursor(last_time)
        print(
            f"[page {page_number}] 返回 {len(page_battles)}，新增 {new_count}，"
            f"累计 {len(battles)}，最早 {last_time}，next={next_cursor}",
            flush=True,
        )
        write_json(checkpoint_path, battles)
        write_json(request_log_path, request_log)

        if not next_cursor or next_cursor == cursor:
            stop_reason = f"第 {page_number} 页游标未继续前进"
            break
        if new_count == 0:
            stop_reason = f"第 {page_number} 页没有新增记录"
            break
        cursor = next_cursor

    battles.sort(key=lambda item: str(item.get("dtEventTime") or ""), reverse=True)
    export_all(
        output_dir,
        args.display_name,
        args.subject,
        battles,
        stop_reason,
        requests_made,
    )
    write_json(request_log_path, request_log)
    print(
        f"[done] {len(battles)} 场，"
        f"{battles[-1].get('dtEventTime') if battles else '-'} ～ "
        f"{battles[0].get('dtEventTime') if battles else '-'}，{stop_reason}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
