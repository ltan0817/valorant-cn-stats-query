from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Any


TARGET_ALIAS = "再晚一点睡#73142"
PARTNER_ALIASES = [
    "雨停之后#48017",
    "小熊不吃糖#62135",
    "最后一颗烟#30482",
    "别催我在绕后#85714",
    "月亮失约了#19642",
    "今天不空枪#53086",
    "听风也听你#74219",
    "下一局认真#41367",
    "橘子汽水#90531",
    "慢热玩家#26854",
    "困困小队长#61803",
    "枪线借我一下#37195",
    "巷口等晚风#80426",
    "想吃火锅了#15279",
    "星河不问路#68341",
    "先别急着投#24960",
    "半糖乌龙茶#73608",
    "海盐芝士#59124",
    "今晚早点睡#32781",
    "我在B点等你#86409",
    "蓝色星期五#41863",
    "小狗不emo#97520",
    "柠檬味晚霞#20647",
    "好险差一点#65318",
    "雨天不收伞#48172",
    "再架五秒钟#73915",
    "风从海边来#31268",
    "奶油泡芙#89734",
    "先救我队友#56021",
    "没有下一把#17486",
    "雾里看花#63259",
    "今天吃什么#40573",
    "右手边有人#91824",
    "轻轻松松#25706",
    "记得买可乐#78143",
    "在等一个晴天#34692",
    "子弹会转弯#82517",
    "好想放个假#19064",
    "给我一把枪#57380",
    "松弛感选手#26419",
    "北巷听雨#70953",
    "不许偷看我#43816",
    "等风也等你#95127",
    "先稳住别送#38640",
    "小猫会开枪#61794",
    "云层有回声#24058",
    "明天再上分#87531",
    "路过你的风#50962",
    "三分钟热度#14873",
]

SUMMARY_FIELDS = (
    "总场次",
    "最早时间",
    "最近时间",
    "完整阵容场次",
    "确定组队场次",
    "确定单排场次",
    "无法判断组队场次",
    "阵容不完整场次",
    "确认组队对象数",
    "组队会话数",
    "单排会话数",
)
PARTNER_FIELDS = (
    "共同组队场次",
    "共同胜场",
    "共同胜率",
    "共同组队会话数",
    "最长单次连续场数",
    "首次组队",
    "最近组队",
    "主要模式",
    "模式构成",
)
SESSION_FIELDS = (
    "会话编号",
    "开始时间",
    "结束时间",
    "连续场数",
    "组队判定",
    "组队成员",
    "胜场",
    "负场",
    "胜率",
    "模式构成",
    "场次",
)
DAILY_FIELDS = (
    "日期",
    "总场次",
    "胜场",
    "负场",
    "胜率",
    "确定组队场次",
    "确定单排场次",
    "组队场次占比",
)
MATCH_FIELDS = (
    "场次序号",
    "时间",
    "模式",
    "结果",
    "比分",
    "地图",
    "目标英雄",
    "目标K/D/A",
    "目标ACS",
    "目标段位",
    "目标RR变化",
    "组队判定",
    "组队人数",
    "组队成员",
    "双方玩家解析",
    "阵容完整性",
)


def selected(row: dict[str, Any], fields: tuple[str, ...]) -> dict[str, Any]:
    return {field: row.get(field) for field in fields}


def anonymize_text(value: Any, replacements: dict[str, str]) -> str:
    text = str(value or "")
    for source in sorted(replacements, key=len, reverse=True):
        text = text.replace(source, replacements[source])
    return text


def public_payload(source: dict[str, Any]) -> dict[str, Any]:
    source_summary = source.get("summary") or {}
    source_partners = [
        item for item in (source.get("partners") or []) if isinstance(item, dict)
    ]
    if len(source_partners) > len(PARTNER_ALIASES):
        raise ValueError(
            f"匿名昵称不足：需要 {len(source_partners)} 个，当前 {len(PARTNER_ALIASES)} 个"
        )

    replacements = {
        str(source_summary.get("目标玩家") or ""): TARGET_ALIAS,
    }
    for index, partner in enumerate(source_partners):
        replacements[str(partner.get("昵称") or "")] = PARTNER_ALIASES[index]

    summary = selected(source_summary, SUMMARY_FIELDS)
    summary["目标玩家"] = TARGET_ALIAS

    partners = []
    for index, partner in enumerate(source_partners):
        item = selected(partner, PARTNER_FIELDS)
        item["昵称"] = PARTNER_ALIASES[index]
        partners.append(item)

    sessions = []
    for source_session in source.get("sessions") or []:
        if not isinstance(source_session, dict):
            continue
        item = selected(source_session, SESSION_FIELDS)
        item["组队成员"] = anonymize_text(item.get("组队成员"), replacements)
        sessions.append(item)

    daily = [
        selected(item, DAILY_FIELDS)
        for item in (source.get("daily") or [])
        if isinstance(item, dict)
    ]

    matches = []
    for source_match in source.get("matchOverviews") or []:
        if not isinstance(source_match, dict):
            continue
        item = selected(source_match, MATCH_FIELDS)
        item["组队成员"] = anonymize_text(item.get("组队成员"), replacements)
        matches.append(item)

    return {
        "target": TARGET_ALIAS,
        "summary": summary,
        "partners": partners,
        "sessions": sessions,
        "daily": daily,
        "matches": matches,
        "privacy": {
            "anonymized": True,
            "note": "页面使用真实统计结构，但玩家昵称、数字 ID 和所有内部标识均已替换；不包含 subject、matchId、partyId、事件 ID 或真实 IP。",
        },
    }


def render_html(payload: dict[str, Any]) -> str:
    target = html.escape(str(payload["target"]))
    embedded = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace(
        "</", "<\\/"
    )
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="匿名化玩家最近100场组队关系分析示例，展示常用队友、连续场次、胜率、模式分布和逐场记录。">
<meta name="robots" content="index,follow">
<title>{target} · 最近100场组队分析_WGame VAL</title>
<style>
:root{{--bg:#070d13;--panel:#101923;--panel2:#0b141d;--line:#26394a;--text:#eef7ff;--muted:#8fa5b8;--cyan:#5bdcff;--green:#39d993;--coral:#ff5c72;--gold:#ffc857;--blue:#6ba8ff}}
*{{box-sizing:border-box}}html{{scroll-behavior:smooth}}body{{margin:0;background:radial-gradient(circle at 50% -20%,#142331 0,#070d13 42%);color:var(--text);font:14px/1.55 "Microsoft YaHei","Segoe UI",system-ui,sans-serif}}
a{{color:inherit}}.site-header{{position:sticky;top:0;z-index:20;border-bottom:1px solid var(--line);background:rgba(7,13,19,.92);backdrop-filter:blur(14px)}}.header-inner{{max-width:1240px;margin:auto;min-height:68px;padding:0 22px;display:flex;align-items:center;justify-content:space-between;gap:20px}}.brand{{display:flex;align-items:center;gap:10px;text-decoration:none}}.brand-mark{{display:grid;place-items:center;width:36px;height:36px;border:1px solid #415366;border-left:3px solid var(--coral);font-weight:900}}.brand span{{display:block;color:var(--muted);font-size:11px}}.nav{{display:flex;gap:20px;color:#aec0cf}}.nav a{{text-decoration:none}}.nav a:hover{{color:var(--gold)}}
main{{max-width:1240px;margin:auto;padding:42px 22px 70px}}.hero{{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(310px,.65fr);gap:20px;align-items:stretch}}.hero-main,.hero-side,.panel{{border:1px solid var(--line);background:linear-gradient(145deg,rgba(18,29,40,.98),rgba(10,18,26,.98));border-radius:14px}}.hero-main{{padding:34px}}.kicker{{margin:0 0 10px;color:var(--cyan);font-weight:800;letter-spacing:.08em}}h1{{margin:0;font-size:clamp(32px,5vw,54px);line-height:1.08}}h1 em{{color:var(--gold);font-style:normal}}.hero-lead{{max-width:760px;margin:18px 0;color:#b4c5d3;font-size:16px}}.hero-actions{{display:flex;gap:10px;flex-wrap:wrap;margin-top:22px}}.btn{{min-height:40px;display:inline-flex;align-items:center;justify-content:center;padding:0 15px;border:1px solid #42586c;border-radius:7px;background:#172433;text-decoration:none;font-weight:800}}.btn.primary{{background:var(--coral);border-color:var(--coral);color:#fff}}.btn:hover{{transform:translateY(-1px);border-color:var(--cyan)}}.hero-side{{padding:24px;display:flex;flex-direction:column;justify-content:space-between}}.privacy-badge{{display:inline-flex;align-items:center;gap:7px;width:max-content;padding:5px 9px;border:1px solid rgba(57,217,147,.35);border-radius:999px;background:rgba(57,217,147,.1);color:var(--green);font-weight:800}}.hero-side h2{{margin:20px 0 7px;font-size:22px}}.hero-side p{{margin:0;color:var(--muted)}}.time-range{{margin-top:22px;padding-top:18px;border-top:1px solid var(--line)}}.time-range strong{{display:block;font-size:17px}}.time-range span{{color:var(--muted)}}
.metrics{{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;margin:18px 0}}.metric{{min-height:105px;padding:16px;border:1px solid var(--line);border-radius:11px;background:var(--panel)}}.metric span{{display:block;color:var(--muted);font-size:12px}}.metric strong{{display:block;margin-top:8px;font-size:29px;line-height:1;color:var(--cyan)}}.metric small{{display:block;margin-top:8px;color:#9fb0bd}}
.section-title{{display:flex;align-items:end;justify-content:space-between;gap:15px;margin:32px 0 12px}}.section-title h2{{margin:0;font-size:24px}}.section-title p{{margin:0;color:var(--muted)}}.insights{{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}}.insight{{padding:17px;border:1px solid var(--line);border-radius:11px;background:var(--panel2)}}.insight b{{display:block;color:var(--gold);font-size:19px;margin-bottom:5px}}.insight p{{margin:0;color:var(--muted)}}
.chart-grid{{display:grid;grid-template-columns:.72fr 1.28fr;gap:14px}}.panel{{padding:20px}}.panel h3{{margin:0 0 4px;font-size:19px}}.panel-sub{{margin:0 0 16px;color:var(--muted)}}.donut-wrap{{display:flex;align-items:center;justify-content:center;gap:26px;min-height:250px}}.donut{{--party:0;width:178px;height:178px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(var(--coral) calc(var(--party)*1%),#21303d 0);position:relative}}.donut::after{{content:"";position:absolute;inset:23px;border-radius:50%;background:#0d1822}}.donut-center{{position:relative;z-index:1;text-align:center}}.donut-center b{{display:block;font-size:34px}}.donut-center span{{color:var(--muted)}}.legend div{{margin:10px 0}}.dot{{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:7px}}.dot.party{{background:var(--coral)}}.dot.solo{{background:#21303d;border:1px solid #607485}}
.bars{{display:grid;gap:10px}}.bar-row{{display:grid;grid-template-columns:minmax(130px,.55fr) minmax(140px,1fr) 48px;gap:10px;align-items:center}}.bar-name{{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}.bar-track{{height:10px;border-radius:999px;background:#1b2a36;overflow:hidden}}.bar-fill{{height:100%;border-radius:inherit;background:linear-gradient(90deg,var(--cyan),var(--blue))}}.bar-value{{text-align:right;color:var(--cyan);font-weight:800}}.mode-strip{{display:flex;gap:8px;flex-wrap:wrap;margin-top:18px}}.mode-chip{{padding:7px 10px;border:1px solid var(--line);border-radius:7px;background:#0c1720;color:#cfe4f3}}.mode-chip b{{color:var(--gold)}}
.trend{{width:100%;height:205px;overflow:visible}}.trend .axis{{stroke:#2b3e4e;stroke-width:1}}.trend .party-line{{fill:none;stroke:var(--coral);stroke-width:3}}.trend .win-line{{fill:none;stroke:var(--cyan);stroke-width:3}}.trend-legend{{display:flex;gap:18px;color:var(--muted)}}.trend-legend b{{color:var(--text)}}.trend-empty{{display:grid;place-items:center;height:190px;color:var(--muted)}}
.table-wrap{{overflow:auto;border:1px solid var(--line);border-radius:10px}}table{{width:100%;border-collapse:collapse;white-space:nowrap}}th,td{{padding:11px 12px;border-bottom:1px solid #1c2c39;text-align:left}}th{{background:#142331;color:var(--cyan);font-size:12px}}tbody tr:hover td{{background:#112330}}td strong{{color:var(--gold)}}.positive{{color:var(--green)}}.negative{{color:var(--coral)}}.muted{{color:var(--muted)}}
.filters{{display:grid;grid-template-columns:minmax(220px,1fr) repeat(3,165px);gap:9px;margin-bottom:11px}}input,select{{height:40px;border:1px solid #354b5d;border-radius:7px;background:#09131b;color:var(--text);padding:0 11px;font:inherit}}.match-list{{display:grid;gap:8px}}.match{{display:grid;grid-template-columns:52px 145px 65px 70px minmax(170px,1fr) minmax(190px,1fr);gap:10px;align-items:center;padding:13px 14px;border:1px solid var(--line);border-radius:9px;background:var(--panel2)}}.match-index{{color:var(--cyan);font-weight:900}}.result-win{{color:var(--green);font-weight:900}}.result-loss{{color:var(--coral);font-weight:900}}.party-text{{color:var(--gold)}}.solo-text{{color:var(--muted)}}.match small{{display:block;color:var(--muted)}}.list-footer{{display:flex;justify-content:space-between;align-items:center;margin-top:12px;color:var(--muted)}}button{{font:inherit}}.load-more{{min-height:38px;padding:0 14px;border:1px solid #40566a;border-radius:7px;background:#172433;color:var(--text);font-weight:800;cursor:pointer}}.load-more:hover{{border-color:var(--cyan)}}.method{{margin-top:30px;padding:18px;border-left:4px solid var(--gold);border-radius:8px;background:#151b20;color:#b8c7d2}}.method strong{{color:var(--text)}}
@media(max-width:980px){{.hero{{grid-template-columns:1fr}}.metrics{{grid-template-columns:repeat(3,1fr)}}.insights{{grid-template-columns:repeat(2,1fr)}}.chart-grid{{grid-template-columns:1fr}}.filters{{grid-template-columns:1fr 1fr}}.match{{grid-template-columns:45px 1fr 60px 65px}}.match-main,.match-party{{grid-column:2/-1}}}}
@media(max-width:620px){{.header-inner{{padding:0 14px}}.nav a:nth-child(-n+2){{display:none}}main{{padding:24px 13px 50px}}.hero-main{{padding:23px}}.metrics{{grid-template-columns:repeat(2,1fr)}}.insights{{grid-template-columns:1fr}}.filters{{grid-template-columns:1fr}}.donut-wrap{{flex-direction:column}}.bar-row{{grid-template-columns:115px 1fr 38px}}.match{{grid-template-columns:38px 1fr 55px}}.match-score{{display:none}}.match-main,.match-party{{grid-column:1/-1}}}}
</style>
</head>
<body>
<header class="site-header"><div class="header-inner">
  <a class="brand" href="/public"><span class="brand-mark">WV</span><b>WGame VAL Query<span>国服战绩查询</span></b></a>
  <nav class="nav"><a href="/public">公共查询</a><a href="/live">实时对局</a><a href="/live#features-title">本地部署</a><a href="/public">GitHub</a></nav>
</div></header>
<main>
  <section class="hero">
    <div class="hero-main">
      <p class="kicker">PLAYER PARTY INSIGHT · 匿名化展示</p>
      <h1><em>{target}</em><br>最近 100 场组队分析</h1>
      <p class="hero-lead">从逐场双方阵容与队伍标识中，归纳常用队友、连续同行场数、组队会话、共同胜率和单排占比。所有结论都可以回到逐场记录核对。</p>
      <div class="hero-actions"><a class="btn primary" href="#partners">查看常用队友</a><a class="btn" href="#matches">浏览逐场记录</a><a class="btn" href="/public">返回公共查询</a></div>
    </div>
    <aside class="hero-side">
      <div><span class="privacy-badge">✓ 已完全匿名化</span><h2>真实统计，隐去身份</h2><p id="privacy-note"></p></div>
      <div class="time-range"><span>覆盖时间</span><strong id="time-range">-</strong><span>完整阵容可用于更可靠的组队判定</span></div>
    </aside>
  </section>

  <section class="metrics" id="metrics" aria-label="核心统计"></section>

  <div class="section-title"><div><h2>快速结论</h2><p>先看最值得注意的行为模式</p></div></div>
  <section class="insights" id="insights"></section>

  <div class="section-title"><div><h2>组队结构</h2><p>组队占比、常用同行玩家和模式构成</p></div></div>
  <section class="chart-grid">
    <article class="panel"><h3>组队 / 单排占比</h3><p class="panel-sub">按最近 100 场逐场判定</p><div class="donut-wrap"><div class="donut" id="party-donut"><div class="donut-center"><b id="party-rate">-</b><span>确定组队</span></div></div><div class="legend" id="party-legend"></div></div></article>
    <article class="panel"><h3>最常同行玩家</h3><p class="panel-sub">共同组队场次 Top 8</p><div class="bars" id="partner-bars"></div><div class="mode-strip" id="mode-strip"></div></article>
  </section>

  <div class="section-title"><div><h2>每日变化</h2><p>青色为胜率，红色为组队场次占比</p></div></div>
  <section class="panel"><div class="trend-legend"><span><i class="dot" style="background:var(--cyan)"></i><b>胜率</b></span><span><i class="dot party"></i><b>组队占比</b></span></div><div id="trend"></div></section>

  <div class="section-title" id="partners"><div><h2>确认组队对象</h2><p>相同匿名昵称在全部表格中保持一致</p></div></div>
  <section class="panel"><div class="table-wrap"><table><thead><tr><th>同行玩家</th><th>共同场次</th><th>共同胜率</th><th>组队会话</th><th>最长连续</th><th>最近组队</th><th>模式构成</th></tr></thead><tbody id="partner-table"></tbody></table></div></section>

  <div class="section-title"><div><h2>最近组队会话</h2><p>把连续使用同一队伍标识的比赛合并为一次会话</p></div></div>
  <section class="panel"><div class="table-wrap"><table><thead><tr><th>会话</th><th>开始</th><th>连续场数</th><th>同行玩家</th><th>结果</th><th>胜率</th><th>模式</th></tr></thead><tbody id="session-table"></tbody></table></div></section>

  <div class="section-title" id="matches"><div><h2>逐场记录</h2><p>100 场均可按模式、结果和组队状态筛选</p></div></div>
  <section class="panel">
    <div class="filters"><input id="match-search" placeholder="搜索地图、英雄或匿名队友"><select id="mode-filter"><option value="">全部模式</option></select><select id="result-filter"><option value="">全部结果</option><option>胜利</option><option>失败</option><option>未知</option></select><select id="party-filter"><option value="">全部状态</option><option>确定组队</option><option>确定单排</option><option>无法完整判断</option></select></div>
    <div class="match-list" id="match-list"></div>
    <div class="list-footer"><span id="match-count"></span><button class="load-more" id="load-more" type="button">再显示 20 场</button></div>
  </section>

  <div class="method"><strong>判定说明：</strong>同一场比赛中，目标玩家与同阵营玩家出现相同且有效的队伍标识时，记为“确定组队”；阵容完整且没有同行玩家时，记为“确定单排”。本页展示的是行为线索与统计推断，不代表玩家之间的现实关系。</div>
</main>
<script id="party-data" type="application/json">{embedded}</script>
<script>
const data=JSON.parse(document.getElementById("party-data").textContent);
const s=data.summary;
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}}[c]));
const pct=v=>`${{Math.round(Number(v||0)*1000)/10}}%`;
const partyRate=Number(s["确定组队场次"]||0)/Math.max(1,Number(s["总场次"]||0));
const topPartner=data.partners[0]||{{}};
const longest=[...data.partners].sort((a,b)=>Number(b["最长单次连续场数"]||0)-Number(a["最长单次连续场数"]||0))[0]||{{}};
const grouped=data.matches.filter(x=>x["组队判定"]==="确定组队");
const solo=data.matches.filter(x=>x["组队判定"]==="确定单排");
const wins=rows=>rows.filter(x=>x["结果"]==="胜利").length;
document.getElementById("privacy-note").textContent=data.privacy.note;
document.getElementById("time-range").textContent=`${{String(s["最早时间"]).slice(0,10)}} — ${{String(s["最近时间"]).slice(0,10)}}`;
document.getElementById("metrics").innerHTML=[
  ["样本比赛",s["总场次"],"最近完整采集"],
  ["确定组队",s["确定组队场次"],pct(partyRate)],
  ["确定单排",s["确定单排场次"],pct(Number(s["确定单排场次"])/Number(s["总场次"]))],
  ["同行玩家",s["确认组队对象数"],"一致性匿名化"],
  ["组队会话",s["组队会话数"],"按连续队伍合并"],
  ["完整阵容",s["完整阵容场次"],`${{s["总场次"]}} 场中`]
].map(x=>`<article class="metric"><span>${{x[0]}}</span><strong>${{x[1]}}</strong><small>${{x[2]}}</small></article>`).join("");
document.getElementById("insights").innerHTML=[
  [`${{pct(partyRate)}} 组队率`,`${{s["总场次"]}} 场中有 ${{s["确定组队场次"]}} 场可确认与他人同行。`],
  [`${{esc(topPartner["昵称"]||"-")}}`, `最常同行，共 ${{topPartner["共同组队场次"]||0}} 场，分布在 ${{topPartner["共同组队会话数"]||0}} 次会话。`],
  [`最长连续 ${{longest["最长单次连续场数"]||0}} 场`, `与 ${{esc(longest["昵称"]||"-")}} 出现最长连续同行记录。`],
  [`组队胜率 ${{pct(wins(grouped)/Math.max(1,grouped.length))}}`, `单排样本胜率为 ${{pct(wins(solo)/Math.max(1,solo.length))}}，仅作样本比较。`]
].map(x=>`<article class="insight"><b>${{x[0]}}</b><p>${{x[1]}}</p></article>`).join("");
document.getElementById("party-donut").style.setProperty("--party",partyRate*100);
document.getElementById("party-rate").textContent=pct(partyRate);
document.getElementById("party-legend").innerHTML=`<div><i class="dot party"></i>确定组队 <b>${{s["确定组队场次"]}} 场</b></div><div><i class="dot solo"></i>确定单排 <b>${{s["确定单排场次"]}} 场</b></div>`;
const maxPartner=Math.max(...data.partners.slice(0,8).map(x=>Number(x["共同组队场次"]||0)),1);
document.getElementById("partner-bars").innerHTML=data.partners.slice(0,8).map(x=>`<div class="bar-row"><span class="bar-name" title="${{esc(x["昵称"])}}">${{esc(x["昵称"])}}</span><div class="bar-track"><div class="bar-fill" style="width:${{Number(x["共同组队场次"]||0)/maxPartner*100}}%"></div></div><span class="bar-value">${{x["共同组队场次"]}}</span></div>`).join("");
const modeCounts=data.matches.reduce((acc,x)=>(acc[x["模式"]]=(acc[x["模式"]]||0)+1,acc),{{}});
document.getElementById("mode-strip").innerHTML=Object.entries(modeCounts).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<span class="mode-chip">${{esc(k)}} <b>${{v}}</b></span>`).join("");
function trendSvg(){{
 const rows=[...data.daily].reverse();
 if(!rows.length)return `<div class="trend-empty">暂无每日数据</div>`;
 const w=1000,h=180,p=14,x=i=>p+i*(w-p*2)/Math.max(1,rows.length-1),y=v=>h-p-Number(v||0)*(h-p*2);
 const win=rows.map((r,i)=>`${{x(i)}},${{y(r["胜率"])}}`).join(" ");
 const party=rows.map((r,i)=>`${{x(i)}},${{y(r["组队场次占比"])}}`).join(" ");
 const ticks=[0,.25,.5,.75,1].map(v=>`<line class="axis" x1="${{p}}" y1="${{y(v)}}" x2="${{w-p}}" y2="${{y(v)}}"/><text x="${{p}}" y="${{y(v)-4}}" fill="#688093" font-size="20">${{Math.round(v*100)}}%</text>`).join("");
 return `<svg class="trend" viewBox="0 0 ${{w}} ${{h}}" preserveAspectRatio="none">${{ticks}}<polyline class="party-line" points="${{party}}"/><polyline class="win-line" points="${{win}}"/></svg>`;
}}
document.getElementById("trend").innerHTML=trendSvg();
document.getElementById("partner-table").innerHTML=data.partners.map((x,i)=>`<tr><td><strong>${{esc(x["昵称"])}}</strong></td><td>${{x["共同组队场次"]}}</td><td>${{pct(x["共同胜率"])}}</td><td>${{x["共同组队会话数"]}}</td><td>${{x["最长单次连续场数"]}} 场</td><td>${{esc(x["最近组队"])}}</td><td>${{esc(x["模式构成"])}}</td></tr>`).join("");
document.getElementById("session-table").innerHTML=data.sessions.slice(0,20).map(x=>`<tr><td>#${{x["会话编号"]}}</td><td>${{esc(x["开始时间"])}}</td><td>${{x["连续场数"]}} 场</td><td><strong>${{esc(x["组队成员"]||"单排")}}</strong></td><td>${{x["胜场"]}}胜 ${{x["负场"]}}负</td><td>${{pct(x["胜率"])}}</td><td>${{esc(x["模式构成"])}}</td></tr>`).join("");
const modeFilter=document.getElementById("mode-filter");
modeFilter.innerHTML+=Object.keys(modeCounts).sort().map(x=>`<option>${{esc(x)}}</option>`).join("");
let visible=20;
function renderMatches(reset=false){{
 if(reset)visible=20;
 const query=document.getElementById("match-search").value.trim().toLowerCase();
 const mode=modeFilter.value,result=document.getElementById("result-filter").value,party=document.getElementById("party-filter").value;
 const rows=data.matches.filter(x=>{{
   const hay=[x["地图"],x["目标英雄"],x["组队成员"],x["目标段位"]].join(" ").toLowerCase();
   return (!query||hay.includes(query))&&(!mode||x["模式"]===mode)&&(!result||x["结果"]===result)&&(!party||x["组队判定"]===party);
 }});
 document.getElementById("match-list").innerHTML=rows.slice(0,visible).map(x=>{{
   const resultClass=x["结果"]==="胜利"?"result-win":x["结果"]==="失败"?"result-loss":"muted";
   const partyClass=x["组队判定"]==="确定组队"?"party-text":"solo-text";
   const rr=x["目标RR变化"]!==""&&x["目标RR变化"]!=null?` · RR ${{Number(x["目标RR变化"])>0?"+":""}}${{x["目标RR变化"]}}`:"";
   return `<article class="match"><span class="match-index">#${{x["场次序号"]}}</span><span>${{esc(x["时间"])}}</span><span class="${{resultClass}}">${{esc(x["结果"])}}</span><span class="match-score">${{esc(x["比分"])}}</span><span class="match-main"><b>${{esc(x["地图"])}} · ${{esc(x["目标英雄"])}}</b><small>K/D/A ${{esc(x["目标K/D/A"]||"-")}} · ACS ${{esc(x["目标ACS"]||"-")}} · ${{esc(x["目标段位"]||"非排位")}}${{rr}}</small></span><span class="match-party ${{partyClass}}">${{esc(x["组队判定"])}}<small>${{esc(x["组队成员"]||"无同行玩家")}}</small></span></article>`;
 }}).join("")||`<div class="trend-empty">没有符合筛选条件的比赛</div>`;
 document.getElementById("match-count").textContent=`显示 ${{Math.min(visible,rows.length)}} / ${{rows.length}} 场`;
 document.getElementById("load-more").style.display=visible<rows.length?"inline-block":"none";
}}
for(const id of ["match-search","mode-filter","result-filter","party-filter"])document.getElementById(id).addEventListener("input",()=>renderMatches(true));
document.getElementById("load-more").addEventListener("click",()=>{{visible+=20;renderMatches();}});
renderMatches();
</script>
</body>
</html>"""


def main() -> int:
    parser = argparse.ArgumentParser(description="生成公开匿名化玩家组队分析示例")
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source = json.loads(args.source.read_text(encoding="utf-8"))
    payload = public_payload(source)
    body = render_html(payload)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(body, encoding="utf-8")
    print(
        json.dumps(
            {
                "output": str(args.output),
                "bytes": args.output.stat().st_size,
                "matches": len(payload["matches"]),
                "partners": len(payload["partners"]),
                "sessions": len(payload["sessions"]),
                "target": payload["target"],
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
