# 离线采集与分析工具

本目录工具不参与 8787/8788 在线服务启动。它们用于受控采集玩家历史、补齐逐局
阵容、判断 PartyID 和生成私人/匿名报告。

| 工具 | 输入/作用 | 主要输出 |
| --- | --- | --- |
| `collect_wegame_history.py` | 分页采集历史，支持 checkpoint 和冷却 | 历史 JSON/CSV |
| `collect_match_rosters.py` | 为各场补齐双方玩家和 PartyID | 阵容数据 |
| `build_detailed_party_report.py` | 逐场、每日、同行者、连续会话分析 | HTML/CSV |
| `build_party_showcase.py` | 严格匿名化真实报告 | 公共示例 |

历史掌瓦/Frida/抓包调查脚本已经从项目根目录移到
[`legacy-mval/`](legacy-mval/README.md)，它们不属于生产服务。

“拉取超过 10 场历史 + 逐场阵容 + 组队分析”的完整操作流程与参数说明见
[历史战绩批量采集与组队分析指南](../docs/HISTORY_COLLECTION_GUIDE.md)。

### 图片读取辅助（DeepSeek 无视觉时）

Codex 接入 DeepSeek 后模型 `input_modalities=["text"]`，本身不能看图。
可用 [`vision_reader.py`](vision_reader.py) 把本地图片发给硅基流动的视觉
模型（如 `Qwen/Qwen3-VL-32B-Instruct`、`GLM-4.5V`），返回文字描述：

```powershell
python tools\vision_reader.py "C:\path\截图.png" "描述这张截图"
```

需要先在 `.private/siliconflow.env` 写入 `SILICONFLOW_API_KEY=sk-...`
（或设置同名环境变量）。图片会上传到第三方平台，敏感内容请先打码。

2026-08-02 实测结论（中文截图 + 卡通图对比）：

| 模型 | 速度 | 文字/数据识别 | 结论 |
| --- | --- | --- | --- |
| `Qwen/Qwen3-VL-32B-Instruct` | 中（37–63s） | 最准 | **默认推荐** |
| `zai-org/GLM-4.5V` | 快（10–34s） | 很准 | 高速备选 |
| `Qwen/Qwen3-VL-8B-Instruct` | 中 | 一般（偶有误读） | 备用 |
| `Qwen/Qwen3-VL-30B-A3B-Instruct` | 中 | 一般（个别误读） | 备用 |
| `Qwen/Qwen3-Omni-30B-A3B-Instruct` | 快 | 差（表格数据易乱） | 不推荐读截图 |
| `ByteDance-Seed/Seed-OSS-36B-Instruct` | - | 不支持（非 VLM，HTTP 400） | 不可用 |

## 推荐流程

```text
collect_wegame_history
  -> collect_match_rosters
  -> build_detailed_party_report
  -> 人工核验
  -> build_party_showcase（仅在需要公开示例时）
```

在线页面的“疑似组队”是基于相同对局和胜负的推断；离线阵容若有相同 PartyID，
才是更强的确定组队证据。报告中应分别标注“确定”和“推断”。

## 安全

- 真实结果写入根目录 `exports/`，该目录已忽略；
- 不把 subject、matchId、partyId、事件 ID、IP 或完整昵称清单提交到 Git；
- checkpoint 可能含登录态或内部标识，按私密运行数据处理；
- 公开展示必须通过匿名化工具并人工复核；
- 不在脚本中硬编码目标玩家、SSH 密码或 API 管理口令。

含真实昵称和 subject 常量的旧版一次性报告脚本已经删除；历史输出保留在私人
`exports/`，当前流程只接受命令行输入或结构化数据文件。
