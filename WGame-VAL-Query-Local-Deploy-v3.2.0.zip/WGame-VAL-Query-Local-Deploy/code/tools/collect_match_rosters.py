from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any


PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

import wgame_query_server as server


BATTLE_LIST_PATH = "/api/v1/wegame.pallas.game.ValBattle/GetBattleList"
MATCHUP_PATH = "/api/v1/wegame.pallas.game.ValBattle/GetMatchup"
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


def write_json_atomic(path: Path, value: Any) -> None:
    temp_path = path.with_suffix(path.suffix + ".tmp")
    temp_path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temp_path.replace(path)


def cursor_after_match(value: str, hours: int = 1) -> str:
    parsed = datetime.strptime(value, TIME_FORMAT)
    return (parsed + timedelta(hours=hours)).strftime("%Y%m%d%H%M%S")


def api_result_code(value: Any) -> Any:
    if not isinstance(value, dict):
        return None
    result = value.get("result")
    return result.get("error_code") if isinstance(result, dict) else result


def fetch_matchup(
    target_subject: str,
    battle: dict[str, Any],
    retries: int,
) -> dict[str, Any]:
    payload = {
        "apEventId": battle.get("apEventId"),
        "from_src": "valorant_web",
        "subject": target_subject,
    }
    last: dict[str, Any] = {}
    for attempt in range(1, retries + 1):
        last = server.browser_context_query(MATCHUP_PATH, payload)
        players = last.get("players") if isinstance(last, dict) else None
        if api_result_code(last) in (0, None) and isinstance(players, list) and players:
            return last
        if attempt < retries:
            time.sleep(5 * attempt)
    return last


def fetch_player_match(
    player_subject: str,
    battle: dict[str, Any],
    retries: int,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    attempts: list[dict[str, Any]] = []
    for cursor_hours in (1, 2):
        cursor = cursor_after_match(str(battle.get("dtEventTime") or ""), cursor_hours)
        payload = {
            "after": cursor,
            "from_src": "valorant_web",
            "size": 10,
            "subject": player_subject,
        }
        for attempt in range(1, retries + 1):
            data = server.browser_context_query(BATTLE_LIST_PATH, payload)
            battles = data.get("battles") if isinstance(data, dict) else None
            attempts.append(
                {
                    "cursor": cursor,
                    "attempt": attempt,
                    "error_code": api_result_code(data),
                    "returned": len(battles) if isinstance(battles, list) else None,
                }
            )
            if isinstance(battles, list):
                matched = next(
                    (
                        item
                        for item in battles
                        if str(item.get("matchId") or "")
                        == str(battle.get("matchId") or "")
                        or str(item.get("apEventId") or "")
                        == str(battle.get("apEventId") or "")
                    ),
                    None,
                )
                if isinstance(matched, dict):
                    return matched, attempts
            if attempt < retries:
                time.sleep(4 * attempt)
        time.sleep(2)
    return None, attempts


def compact_player_record(
    roster_player: dict[str, Any],
    battle_record: dict[str, Any] | None,
    name: str,
    target_subject: str,
    target_party_id: str,
) -> dict[str, Any]:
    record = battle_record or {}
    party_id = str(record.get("partyId") or "")
    subject = str(roster_player.get("subject") or "").lower()
    return {
        "subject": subject,
        "name": name,
        "teamId": roster_player.get("teamId") or record.get("teamId") or "",
        "characterId": roster_player.get("characterId") or record.get("characterId") or "",
        "partyId": party_id,
        "isTarget": subject == target_subject,
        "isTargetParty": bool(
            subject != target_subject
            and party_id
            and target_party_id
            and party_id == target_party_id
        ),
        "recordResolved": bool(battle_record),
        "statsKills": record.get("statsKills"),
        "statsDeaths": record.get("statsDeaths"),
        "statsAssists": record.get("statsAssists"),
        "statsScore": record.get("statsScore"),
        "roundsPlayed": record.get("roundsPlayed") or record.get("statsRoundsPlayed"),
        "wonMatch": record.get("wonMatch"),
        "competitiveTier": record.get("competitiveTier")
        or record.get("CompetitiveTierBefore"),
        "rankedRatingEarned": record.get("CompetitiveTierRankedRatingEarned"),
    }


def name_for_subject(
    subject: str,
    role_infos: dict[str, dict[str, Any]],
    name_cache: dict[str, str],
) -> str:
    role = role_infos.get(subject) or {}
    name = str(role.get("name") or "").strip()
    if name:
        name_cache[subject] = name
        return name
    cached = str(name_cache.get(subject) or "").strip()
    if cached:
        return cached
    display = str(server.display_for_subject(subject) or "").strip()
    if display and display != subject:
        name_cache[subject] = display
        return display
    return subject


def main() -> int:
    parser = argparse.ArgumentParser(
        description="补采每场双方阵容，并通过同局 partyId 确认组队关系"
    )
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--target-subject", required=True)
    parser.add_argument("--target-name", required=True)
    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="只处理按时间倒序排列的最近 N 场；0 表示全部",
    )
    parser.add_argument("--player-delay", type=float, default=0.5)
    parser.add_argument("--match-delay", type=float, default=2.5)
    parser.add_argument("--retries", type=int, default=3)
    args = parser.parse_args()

    target_subject = args.target_subject.strip().lower()
    source_rows = json.loads(args.source.read_text(encoding="utf-8"))
    battles = [item for item in source_rows if isinstance(item, dict)]
    if args.limit > 0:
        battles = battles[: args.limit]
    battle_by_event = {
        str(item.get("apEventId") or ""): item
        for item in battles
        if item.get("apEventId")
    }
    output_path = args.output.resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    state: dict[str, Any] = {
        "metadata": {
            "targetSubject": target_subject,
            "targetName": args.target_name,
            "source": str(args.source.resolve()),
            "totalMatches": len(battles),
            "completedMatches": 0,
            "generatedAt": datetime.now().isoformat(timespec="seconds"),
            "method": (
                "GetMatchup 获取双方 subject/team/character；"
                "按同一 matchId 对齐每名玩家 GetBattleList 记录；"
                "同阵营且 partyId 与目标相同即确定为组队成员"
            ),
        },
        "nameCache": {target_subject: args.target_name},
        "matches": [],
    }
    if output_path.exists():
        loaded = json.loads(output_path.read_text(encoding="utf-8"))
        if isinstance(loaded, dict):
            state.update(loaded)
            state.setdefault("nameCache", {}).setdefault(target_subject, args.target_name)
            state.setdefault("matches", [])

    state["matches"] = [
        item
        for item in state["matches"]
        if isinstance(item, dict)
        and str(item.get("apEventId") or "") in battle_by_event
    ]
    completed = {
        str(item.get("apEventId") or "")
        for item in state["matches"]
        if isinstance(item, dict) and item.get("apEventId")
    }
    state["metadata"]["totalMatches"] = len(battles)
    state["metadata"]["completedMatches"] = len(completed)
    state["metadata"]["limit"] = args.limit
    if completed:
        print(
            f"[resume] 已完成 {len(completed)}/{len(battles)} 场，继续断点采集",
            flush=True,
        )

    for index, battle in enumerate(battles, 1):
        event_id = str(battle.get("apEventId") or "")
        if event_id in completed:
            continue

        matchup = fetch_matchup(target_subject, battle, args.retries)
        roster = matchup.get("players") if isinstance(matchup, dict) else None
        if not isinstance(roster, list) or not roster:
            detail = {
                "index": index,
                "apEventId": event_id,
                "matchId": battle.get("matchId") or "",
                "dtEventTime": battle.get("dtEventTime") or "",
                "status": "matchup_failed",
                "errorCode": api_result_code(matchup),
                "players": [],
                "resolvedPlayers": 0,
                "targetPartyStatus": "数据不完整",
                "targetPartyMembers": [],
            }
            state["matches"].append(detail)
            completed.add(event_id)
            state["metadata"]["completedMatches"] = len(completed)
            write_json_atomic(output_path, state)
            print(
                f"[{index}/{len(battles)}] {battle.get('dtEventTime')} "
                f"GetMatchup 失败 code={api_result_code(matchup)!r}",
                flush=True,
            )
            time.sleep(args.match_delay)
            continue

        roster_subjects = [
            str(player.get("subject") or "").lower()
            for player in roster
            if isinstance(player, dict)
            and server.SUBJECT_RE.fullmatch(str(player.get("subject") or "").lower())
        ]
        missing_names = [
            subject
            for subject in roster_subjects
            if not state["nameCache"].get(subject)
        ]
        role_infos: dict[str, dict[str, Any]] = {}
        if missing_names:
            try:
                role_infos = server.browser_role_infos(missing_names)
            except Exception as exc:
                print(
                    f"[{index}/{len(battles)}] 昵称批量查询失败："
                    f"{type(exc).__name__}: {exc}",
                    flush=True,
                )

        target_party_id = str(battle.get("partyId") or "")
        player_rows: list[dict[str, Any]] = []
        request_attempts: dict[str, list[dict[str, Any]]] = {}
        for roster_player in roster:
            if not isinstance(roster_player, dict):
                continue
            player_subject = str(roster_player.get("subject") or "").lower()
            if not server.SUBJECT_RE.fullmatch(player_subject):
                continue
            name = name_for_subject(
                player_subject,
                role_infos,
                state["nameCache"],
            )
            if player_subject == target_subject:
                matched = battle
                attempts: list[dict[str, Any]] = []
            else:
                try:
                    matched, attempts = fetch_player_match(
                        player_subject,
                        battle,
                        args.retries,
                    )
                except Exception as exc:
                    matched = None
                    attempts = [
                        {
                            "error": f"{type(exc).__name__}: {exc}",
                        }
                    ]
                time.sleep(args.player_delay)
            if attempts:
                request_attempts[player_subject] = attempts
            player_rows.append(
                compact_player_record(
                    roster_player,
                    matched,
                    name,
                    target_subject,
                    target_party_id,
                )
            )

        target_player = next(
            (item for item in player_rows if item.get("isTarget")),
            {},
        )
        target_team = str(target_player.get("teamId") or "")
        party_members = [
            str(item.get("name") or item.get("subject") or "")
            for item in player_rows
            if item.get("isTargetParty")
            and str(item.get("teamId") or "") == target_team
        ]
        resolved_count = sum(bool(item.get("recordResolved")) for item in player_rows)
        if party_members:
            party_status = "确定组队"
        elif resolved_count == len(player_rows) and len(player_rows) >= 2:
            party_status = "确定单排"
        else:
            party_status = "数据不完整"

        detail = {
            "index": index,
            "apEventId": event_id,
            "matchId": battle.get("matchId") or "",
            "dtEventTime": battle.get("dtEventTime") or "",
            "queueId": battle.get("queueId") or "",
            "mapId": battle.get("mapId") or "",
            "targetTeamId": target_team,
            "targetPartyId": target_party_id,
            "targetPartyStatus": party_status,
            "targetPartyMembers": party_members,
            "targetPartySize": 1 + len(party_members),
            "resolvedPlayers": resolved_count,
            "playerCount": len(player_rows),
            "status": "complete"
            if resolved_count == len(player_rows) and len(player_rows) >= 2
            else "partial",
            "players": player_rows,
            "requestAttempts": request_attempts,
        }
        state["matches"].append(detail)
        state["matches"].sort(
            key=lambda item: str(item.get("dtEventTime") or ""),
            reverse=True,
        )
        completed.add(event_id)
        state["metadata"]["completedMatches"] = len(completed)
        state["metadata"]["generatedAt"] = datetime.now().isoformat(timespec="seconds")
        write_json_atomic(output_path, state)
        print(
            f"[{index}/{len(battles)}] {battle.get('dtEventTime')} "
            f"{resolved_count}/{len(player_rows)} 人，{party_status} "
            f"{'、'.join(party_members) if party_members else ''}",
            flush=True,
        )
        time.sleep(args.match_delay)

    state["metadata"]["completedMatches"] = len(completed)
    state["metadata"]["finishedAt"] = datetime.now().isoformat(timespec="seconds")
    write_json_atomic(output_path, state)
    print(f"[done] {len(completed)}/{len(battles)} 场：{output_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
