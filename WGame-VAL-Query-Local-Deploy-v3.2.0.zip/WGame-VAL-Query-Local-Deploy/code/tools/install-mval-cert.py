"""Install mitmproxy cert into Android 14 system store via bind mount"""
import os, subprocess, time

adb = os.environ.get("ADB_PATH", "adb")
em = "emulator-5554"
cert_src = os.path.expanduser(r"~\.mitmproxy\mitmproxy-ca-cert.cer")

def adb_shell(cmd, root=True):
    full = [adb, "-s", em]
    if root:
        full.append("root")
    result = subprocess.run(full + ["shell"] + cmd, capture_output=True, text=True)
    return result.stdout + result.stderr

# 1. Get cert hash
import hashlib
from cryptography import x509
with open(cert_src, "rb") as f:
    cert = x509.load_pem_x509_certificate(f.read())
# Android uses little-endian 4-byte integer of MD5(subject DER)
md5_bytes = hashlib.md5(cert.subject.public_bytes()).digest()
h = format(int.from_bytes(md5_bytes[:4], 'little'), '08x')
print(f"Hash: {h}")

# 2. Push to /data/local/tmp
subprocess.run([adb, "-s", em, "push", cert_src, f"/data/local/tmp/{h}.0"], capture_output=True)
print("Pushed to /data/local/tmp")

# 3. Remount apex as rw and copy
# Android 14 emulator: /apex is typically read-only, use overlay
# Try creating /apex/com.android.conscrypt/cacerts/<hash>.0 via mount
cmds = [
    "mount -o rw,remount /",
    f"cp /data/local/tmp/{h}.0 /apex/com.android.conscrypt/cacerts/{h}.0",
    f"chmod 644 /apex/com.android.conscrypt/cacerts/{h}.0",
    f"ls -la /apex/com.android.conscrypt/cacerts/{h}.0",
]
for cmd in cmds:
    o = adb_shell(cmd.split())
    print(f"  {cmd}: {o.strip()}")
    time.sleep(0.3)

# 4. Restart app
print("\nRestarting app...")
adb_shell(["am", "force-stop", "com.tencent.apps.valorant"], root=False)
time.sleep(1)
print("Done. Please manually tap the app icon in the emulator.")
