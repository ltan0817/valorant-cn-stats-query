# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import csv
import html
import json
import shutil
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any


PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

import wgame_query_server as server
from collect_wegame_history import normalized_row


MODE_NAMES = {
    "competitive": "排位",
    "unrated": "匹配",
    "swiftplay": "极速",
    "deathmatch": "死斗",
    "hurm": "乱斗",
    "fortcollins": "团队乱斗",
}

EXPECTED_PLAYER_COUNTS = {
    "deathmatch": 12,
}


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8-sig")
        return
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def parse_time(value: Any) -> datetime:
    return datetime.strptime(str(value or ""), "%Y-%m-%d %H:%M:%S")


def percent(numerator: int, denominator: int) -> float:
    return round(numerator / denominator, 4) if denominator else 0.0


def display_mode(queue_id: Any) -> str:
    value = str(queue_id or "")
    return MODE_NAMES.get(value, value or "未知")


def display_result(value: Any) -> str:
    if value in (1, "1", True):
        return "胜利"
    if value in (0, "0", False):
        return "失败"
    return "未知"


def player_row(
    match: dict[str, Any],
    player: dict[str, Any],
    party_label: str,
) -> dict[str, Any]:
    rounds = int(player.get("roundsPlayed") or 0)
    score = int(player.get("statsScore") or 0)
    return {
        "场次序号": match.get("index"),
        "时间": match.get("dtEventTime") or "",
        "matchId": match.get("matchId") or "",
        "apEventId": match.get("apEventId") or "",
        "阵营": player.get("teamId") or "",
        "昵称": player.get("name") or player.get("subject") or "",
        "subject": player.get("subject") or "",
        "英雄": server.agent_name(player.get("characterId")),
        "K/D/A": (
            f"{player.get('statsKills')}/{player.get('statsDeaths')}/"
            f"{player.get('statsAssists')}"
            if player.get("recordResolved")
            else ""
        ),
        "ACS": round(score / rounds) if rounds else "",
        "段位": (
            server.rank_name(player.get("competitiveTier"))
            if player.get("competitiveTier") not in (None, "")
            else ""
        ),
        "RR变化": (
            player.get("rankedRatingEarned")
            if player.get("rankedRatingEarned") is not None
            else ""
        ),
        "该玩家结果": display_result(player.get("wonMatch")),
        "partyId": player.get("partyId") or "",
        "组队分组": party_label,
        "是否目标玩家": "是" if player.get("isTarget") else "否",
        "是否与目标组队": "是" if player.get("isTargetParty") else "否",
        "同局记录解析": "完整" if player.get("recordResolved") else "缺失",
    }


def assign_party_labels(
    players: list[dict[str, Any]],
    target_team: str,
    target_party_id: str,
) -> dict[str, str]:
    labels: dict[str, str] = {}
    team_groups: dict[str, dict[str, list[dict[str, Any]]]] = defaultdict(
        lambda: defaultdict(list)
    )
    for player in players:
        team_id = str(player.get("teamId") or "")
        party_id = str(player.get("partyId") or "")
        if player.get("recordResolved") and party_id:
            team_groups[team_id][party_id].append(player)

    for team_id, groups in team_groups.items():
        repeated = [
            (party_id, group)
            for party_id, group in groups.items()
            if len(group) >= 2
        ]
        repeated.sort(
            key=lambda item: (
                0 if item[0] == target_party_id and team_id == target_team else 1,
                -len(item[1]),
                item[0],
            )
        )
        counter = 0
        for party_id, group in repeated:
            if party_id == target_party_id and team_id == target_team:
                label = "目标玩家组队"
            else:
                counter += 1
                label = f"{'我方' if team_id == target_team else '敌方'}预组队{counter}"
            for player in group:
                labels[str(player.get("subject") or "")] = label

    for player in players:
        subject = str(player.get("subject") or "")
        if subject in labels:
            continue
        if not player.get("recordResolved"):
            labels[subject] = "无法判断"
        elif player.get("isTarget"):
            labels[subject] = (
                "目标玩家单排"
                if not any(item.get("isTargetParty") for item in players)
                else "目标玩家组队"
            )
        else:
            labels[subject] = "单排"
    return labels


def build_match_rows(
    raw_matches: list[dict[str, Any]],
    roster_matches: list[dict[str, Any]],
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
]:
    raw_by_event = {
        str(item.get("apEventId") or ""): item
        for item in raw_matches
        if isinstance(item, dict)
    }
    roster_by_event = {
        str(item.get("apEventId") or ""): item
        for item in roster_matches
        if isinstance(item, dict)
    }
    overviews: list[dict[str, Any]] = []
    player_rows: list[dict[str, Any]] = []
    detailed: list[dict[str, Any]] = []

    for index, raw in enumerate(raw_matches, 1):
        event_id = str(raw.get("apEventId") or "")
        roster = roster_by_event.get(event_id, {})
        players = [
            dict(item)
            for item in (roster.get("players") or [])
            if isinstance(item, dict)
        ]
        target_team = str(roster.get("targetTeamId") or raw.get("teamId") or "")
        target_party_id = str(
            roster.get("targetPartyId") or raw.get("partyId") or ""
        )
        labels = assign_party_labels(players, target_team, target_party_id)
        target_members = [
            str(item.get("name") or item.get("subject") or "")
            for item in players
            if item.get("isTargetParty")
            and str(item.get("teamId") or "") == target_team
        ]
        resolved = sum(bool(item.get("recordResolved")) for item in players)
        expected_players = EXPECTED_PLAYER_COUNTS.get(
            str(raw.get("queueId") or ""),
            10,
        )
        roster_complete = (
            len(players) >= expected_players and resolved == len(players)
        )
        if target_members:
            party_status = "确定组队"
        elif roster_complete:
            party_status = "确定单排"
        else:
            party_status = "无法完整判断"

        normalized = normalized_row(raw)
        overview = {
            "场次序号": index,
            "时间": normalized.get("时间") or "",
            "模式": display_mode(raw.get("queueId")),
            "结果": normalized.get("结果") or "",
            "比分": normalized.get("比分") or "",
            "地图": normalized.get("地图") or "",
            "目标英雄": normalized.get("英雄") or "",
            "目标K/D/A": (
                f"{normalized.get('击杀')}/{normalized.get('死亡')}/"
                f"{normalized.get('助攻')}"
            ),
            "目标ACS": normalized.get("ACS"),
            "目标段位": normalized.get("段位前") or "",
            "目标RR变化": normalized.get("RR变化"),
            "组队判定": party_status,
            "组队人数": 1 + len(target_members),
            "组队成员": "、".join(target_members),
            "双方玩家解析": f"{resolved}/{len(players) or 10}",
            "预期玩家数": expected_players,
            "阵容完整性": "完整" if roster_complete else "不完整",
            "阵容说明": (
                ""
                if roster_complete
                else (
                    f"WeGame 仅返回 {len(players)} 人，"
                    f"该模式通常应有 {expected_players} 人；"
                    "已确认的组队成员仍然有效，但可能遗漏其他玩家。"
                )
            ),
            "我方玩家": "、".join(
                str(item.get("name") or item.get("subject") or "")
                for item in players
                if str(item.get("teamId") or "") == target_team
            ),
            "敌方玩家": "、".join(
                str(item.get("name") or item.get("subject") or "")
                for item in players
                if str(item.get("teamId") or "") != target_team
            ),
            "matchId": raw.get("matchId") or "",
            "apEventId": event_id,
            "partyId": target_party_id,
        }
        overviews.append(overview)
        current_player_rows = [
            player_row(roster, player, labels.get(str(player.get("subject") or ""), ""))
            for player in players
        ]
        player_rows.extend(current_player_rows)
        detailed.append(
            {
                "raw": raw,
                "overview": overview,
                "targetTeamId": target_team,
                "targetPartyId": target_party_id,
                "expectedPlayerCount": expected_players,
                "rosterComplete": roster_complete,
                "players": [
                    {
                        **player,
                        "rankName": (
                            server.rank_name(player.get("competitiveTier"))
                            if player.get("competitiveTier") not in (None, "")
                            else ""
                        ),
                        "partyLabel": labels.get(
                            str(player.get("subject") or ""),
                            "",
                        ),
                    }
                    for player in players
                ],
            }
        )
    return overviews, player_rows, detailed


def build_partner_summary(
    detailed_matches: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    counters: dict[str, dict[str, Any]] = {}
    for match in detailed_matches:
        overview = match["overview"]
        raw = match["raw"]
        for player in match["players"]:
            if not player.get("isTargetParty"):
                continue
            subject = str(player.get("subject") or "")
            item = counters.setdefault(
                subject,
                {
                    "昵称": player.get("name") or subject,
                    "subject": subject,
                    "共同组队场次": 0,
                    "胜场": 0,
                    "对局时间": [],
                    "partyIds": set(),
                    "模式": Counter(),
                },
            )
            item["共同组队场次"] += 1
            item["胜场"] += 1 if overview.get("结果") == "胜利" else 0
            item["对局时间"].append(str(overview.get("时间") or ""))
            item["partyIds"].add(str(raw.get("partyId") or ""))
            item["模式"][str(overview.get("模式") or "未知")] += 1

    rows: list[dict[str, Any]] = []
    for item in counters.values():
        times = sorted(item["对局时间"])
        count = int(item["共同组队场次"])
        sessions: Counter[str] = Counter()
        for match in detailed_matches:
            raw = match["raw"]
            if any(
                player.get("isTargetParty")
                and str(player.get("subject") or "") == item["subject"]
                for player in match["players"]
            ):
                sessions[str(raw.get("partyId") or "")] += 1
        rows.append(
            {
                "昵称": item["昵称"],
                "共同组队场次": count,
                "共同胜场": int(item["胜场"]),
                "共同胜率": percent(int(item["胜场"]), count),
                "共同组队会话数": len([key for key in sessions if key]),
                "最长单次连续场数": max(sessions.values(), default=0),
                "首次组队": times[0] if times else "",
                "最近组队": times[-1] if times else "",
                "主要模式": item["模式"].most_common(1)[0][0]
                if item["模式"]
                else "",
                "模式构成": "、".join(
                    f"{mode}{number}场"
                    for mode, number in item["模式"].most_common()
                ),
                "subject": item["subject"],
            }
        )
    rows.sort(
        key=lambda item: (
            -int(item["共同组队场次"]),
            str(item["昵称"]),
        )
    )
    return rows


def build_sessions(
    detailed_matches: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for match in detailed_matches:
        party_id = str(match.get("targetPartyId") or "")
        if party_id:
            grouped[party_id].append(match)

    rows: list[dict[str, Any]] = []
    sessions = sorted(
        grouped.items(),
        key=lambda item: max(
            str(match["overview"].get("时间") or "")
            for match in item[1]
        ),
        reverse=True,
    )
    for index, (party_id, matches) in enumerate(sessions, 1):
        matches.sort(key=lambda item: str(item["overview"].get("时间") or ""))
        members: Counter[str] = Counter()
        wins = 0
        complete = 0
        for match in matches:
            wins += 1 if match["overview"].get("结果") == "胜利" else 0
            complete += 1 if match["overview"].get("组队判定") != "无法完整判断" else 0
            for player in match["players"]:
                if player.get("isTargetParty"):
                    members[
                        str(player.get("name") or player.get("subject") or "")
                    ] += 1
        if members:
            status = "确定组队"
        elif complete == len(matches):
            status = "确定单排"
        else:
            status = "无法完整判断"
        rows.append(
            {
                "会话编号": index,
                "开始时间": matches[0]["overview"].get("时间") or "",
                "结束时间": matches[-1]["overview"].get("时间") or "",
                "连续场数": len(matches),
                "组队判定": status,
                "组队成员": "、".join(
                    f"{name}({count}场)"
                    for name, count in members.most_common()
                ),
                "胜场": wins,
                "负场": len(matches) - wins,
                "胜率": percent(wins, len(matches)),
                "模式构成": "、".join(
                    f"{mode}{count}场"
                    for mode, count in Counter(
                        str(match["overview"].get("模式") or "未知")
                        for match in matches
                    ).most_common()
                ),
                "partyId": party_id,
                "场次": "、".join(
                    str(match["overview"].get("场次序号") or "")
                    for match in matches
                ),
            }
        )
    return rows


def build_daily(overviews: list[dict[str, Any]]) -> list[dict[str, Any]]:
    days: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in overviews:
        days[str(row.get("时间") or "")[:10]].append(row)
    output: list[dict[str, Any]] = []
    for day, matches in sorted(days.items(), reverse=True):
        wins = sum(1 for item in matches if item.get("结果") == "胜利")
        grouped = sum(1 for item in matches if item.get("组队判定") == "确定组队")
        solo = sum(1 for item in matches if item.get("组队判定") == "确定单排")
        undecided = len(matches) - grouped - solo
        incomplete_roster = sum(
            1 for item in matches if item.get("阵容完整性") != "完整"
        )
        output.append(
            {
                "日期": day,
                "总场次": len(matches),
                "胜场": wins,
                "负场": len(matches) - wins,
                "胜率": percent(wins, len(matches)),
                "确定组队场次": grouped,
                "确定单排场次": solo,
                "无法判断组队场次": undecided,
                "阵容不完整场次": incomplete_roster,
                "组队场次占比": percent(grouped, grouped + solo),
            }
        )
    return output


def html_report(
    path: Path,
    target_name: str,
    summary: dict[str, Any],
    partner_rows: list[dict[str, Any]],
    session_rows: list[dict[str, Any]],
    detailed_matches: list[dict[str, Any]],
) -> None:
    payload = {
        "summary": summary,
        "partners": partner_rows,
        "sessions": session_rows,
        "matches": detailed_matches,
    }
    embedded = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    template = """<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(target_name)} · 逐场玩家与组队分析</title>
<style>
:root{{--bg:#071019;--panel:#0e1a25;--line:#233749;--text:#eef7ff;--muted:#8fa8ba;--cyan:#61d8ff;--green:#43e49a;--red:#ff6682;--gold:#ffc85a}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font:14px/1.55 system-ui,"Microsoft YaHei",sans-serif}}
main{{max-width:1680px;margin:auto;padding:26px}}h1{{margin:0;font-size:30px}}h2{{margin:30px 0 12px}}p{{color:var(--muted)}}
.hero{{display:flex;gap:20px;justify-content:space-between;align-items:end;flex-wrap:wrap}}.stamp{{color:var(--muted)}}
.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin:20px 0}}
.card,.panel,.match{{background:var(--panel);border:1px solid var(--line);border-radius:12px}}.card{{padding:15px}}.card b{{display:block;font-size:25px;color:var(--cyan)}}.card span{{color:var(--muted)}}
.notice{{padding:14px 16px;border-left:4px solid var(--gold);background:#171b20;border-radius:8px;color:#d9e4ec}}
.toolbar{{display:flex;gap:10px;flex-wrap:wrap;position:sticky;top:0;z-index:5;padding:12px;background:#071019e8;backdrop-filter:blur(12px)}}
input,select{{background:#0c1822;color:var(--text);border:1px solid var(--line);border-radius:8px;padding:10px 12px;min-width:190px}}
.tablebox{{overflow:auto;border:1px solid var(--line);border-radius:10px}}table{{width:100%;border-collapse:collapse;white-space:nowrap}}
th,td{{padding:9px 11px;border-bottom:1px solid #1d3040;text-align:left}}th{{background:#122333;color:var(--cyan);position:sticky;top:0}}tr:hover td{{background:#102331}}
.match{{margin:12px 0;overflow:hidden}}.match summary{{cursor:pointer;padding:14px 16px;display:grid;grid-template-columns:52px 155px 70px 80px 1fr 130px;gap:12px;align-items:center}}
.match summary::-webkit-details-marker{{display:none}}.match[open] summary{{border-bottom:1px solid var(--line)}}.match-body{{padding:14px}}
.win{{color:var(--green);font-weight:700}}.loss{{color:var(--red);font-weight:700}}.party{{color:var(--gold);font-weight:700}}.solo{{color:var(--muted)}}.unknown{{color:var(--red)}}
.teams{{display:grid;grid-template-columns:1fr 1fr;gap:14px}}.team h3{{margin:0 0 8px}}.self{{background:#14372d!important}}.target-party{{box-shadow:inset 4px 0 var(--gold)}}
.tag{{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:2px 7px;font-size:12px;color:var(--muted)}}.count{{margin-left:auto;color:var(--muted)}}
@media(max-width:900px){{main{{padding:14px}}.teams{{grid-template-columns:1fr}}.match summary{{grid-template-columns:42px 1fr 70px}}.match summary span:nth-child(4),.match summary span:nth-child(5),.match summary span:nth-child(6){{display:none}}}}
</style>
</head>
<body><main>
<div class="hero"><div><h1>{html.escape(target_name)}</h1><p>逐场双方 10 人与组队关系分析</p></div><div class="stamp">生成时间：{html.escape(str(summary.get("生成时间") or ""))}</div></div>
<div class="cards" id="cards"></div>
<div class="notice">判定规则：同一场、同一阵营且 <code>partyId</code> 相同，才标记为“确定组队”。该模式预期阵容全部解析且无人和目标 <code>partyId</code> 相同时，标记为“确定单排”；必要记录缺失时标记为“无法完整判断”。</div>
<h2>与目标玩家确定组过队的人</h2><div class="tablebox"><table><thead><tr><th>昵称</th><th>共同组队场次</th><th>共同胜率</th><th>组队会话数</th><th>最长连续</th><th>首次</th><th>最近</th><th>主要模式</th></tr></thead><tbody id="partners"></tbody></table></div>
<h2>组队 / 单排会话</h2><div class="tablebox"><table><thead><tr><th>会话</th><th>开始</th><th>结束</th><th>连续场数</th><th>判定</th><th>成员</th><th>胜负</th><th>模式</th></tr></thead><tbody id="sessions"></tbody></table></div>
<h2>逐场双方玩家</h2>
<div class="toolbar"><input id="search" placeholder="搜索昵称、地图、英雄"><select id="status"><option value="">全部组队状态</option><option>确定组队</option><option>确定单排</option><option>无法完整判断</option></select><select id="mode"><option value="">全部模式</option></select><input id="date" type="date"><span class="count" id="count"></span></div>
<div id="matches"></div>
</main>
<script>
const data={embedded};
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}}[c]));
const pct=v=>`${{(Number(v||0)*100).toFixed(1)}}%`;
const s=data.summary;
document.querySelector("#cards").innerHTML=[
["总场次",s["总场次"]],["完整阵容",s["完整阵容场次"]],["确定组队",s["确定组队场次"]],["确定单排",s["确定单排场次"]],["阵容不完整",s["阵容不完整场次"]],["确认组队对象",s["确认组队对象数"]]
].map(x=>`<div class="card"><b>${{esc(x[1])}}</b><span>${{esc(x[0])}}</span></div>`).join("");
document.querySelector("#partners").innerHTML=data.partners.map(x=>`<tr><td class="party">${{esc(x["昵称"])}}</td><td>${{x["共同组队场次"]}}</td><td>${{pct(x["共同胜率"])}}</td><td>${{x["共同组队会话数"]}}</td><td>${{x["最长单次连续场数"]}}</td><td>${{esc(x["首次组队"])}}</td><td>${{esc(x["最近组队"])}}</td><td>${{esc(x["主要模式"])}}</td></tr>`).join("")||`<tr><td colspan="8">没有解析到确定组队对象</td></tr>`;
document.querySelector("#sessions").innerHTML=data.sessions.map(x=>`<tr><td>${{x["会话编号"]}}</td><td>${{esc(x["开始时间"])}}</td><td>${{esc(x["结束时间"])}}</td><td>${{x["连续场数"]}}</td><td>${{esc(x["组队判定"])}}</td><td>${{esc(x["组队成员"]||"-")}}</td><td>${{x["胜场"]}}胜 ${{x["负场"]}}负</td><td>${{esc(x["模式构成"])}}</td></tr>`).join("");
const modes=[...new Set(data.matches.map(x=>x.overview["模式"]))].sort();
document.querySelector("#mode").innerHTML+=modes.map(x=>`<option>${{esc(x)}}</option>`).join("");
function playerTable(players,team,targetTeam){{
 const rows=players.filter(x=>x.teamId===team);
 return `<div class="team"><h3>${{team===targetTeam?"我方":"敌方"}} · ${{esc(team)}} · ${{rows.length}}人</h3><div class="tablebox"><table><thead><tr><th>昵称</th><th>英雄</th><th>K/D/A</th><th>ACS</th><th>段位</th><th>组队分组</th></tr></thead><tbody>${{rows.map(p=>{{
  const rounds=Number(p.roundsPlayed||0),acs=rounds?Math.round(Number(p.statsScore||0)/rounds):"-";
  const kda=p.recordResolved?`${{p.statsKills}}/${{p.statsDeaths}}/${{p.statsAssists}}`:"-";
  const cls=p.isTarget?"self":p.isTargetParty?"target-party":"";
  return `<tr class="${{cls}}"><td>${{esc(p.name||p.subject)}}${{p.isTarget?' <span class="tag">目标</span>':""}}</td><td>${{esc(p.characterId?agentName(p.characterId):"-")}}</td><td>${{kda}}</td><td>${{acs}}</td><td>${{esc(p.rankName||p.competitiveTier||"-")}}</td><td>${{esc(p.partyLabel)}}</td></tr>`;
 }}).join("")}}</tbody></table></div></div>`;
}}
const agentMap={json.dumps(server.AGENTS, ensure_ascii=False)};
const agentName=id=>agentMap[String(id||"").toLowerCase()]||id||"-";
function render(){{
 const q=document.querySelector("#search").value.trim().toLowerCase(),status=document.querySelector("#status").value,mode=document.querySelector("#mode").value,date=document.querySelector("#date").value;
 const rows=data.matches.filter(m=>{{
  const o=m.overview,hay=[o["地图"],o["目标英雄"],o["组队成员"],...m.players.map(p=>p.name)].join(" ").toLowerCase();
  return (!q||hay.includes(q))&&(!status||o["组队判定"]===status)&&(!mode||o["模式"]===mode)&&(!date||String(o["时间"]).startsWith(date));
 }});
 document.querySelector("#count").textContent=`显示 ${{rows.length}} / ${{data.matches.length}} 场`;
 document.querySelector("#matches").innerHTML=rows.map(m=>{{
  const o=m.overview,cls=o["结果"]==="胜利"?"win":o["结果"]==="失败"?"loss":"",pcls=o["组队判定"]==="确定组队"?"party":o["组队判定"]==="确定单排"?"solo":"unknown";
  const rosterNote=o["阵容完整性"]==="完整"?"":` · 阵容${{esc(o["双方玩家解析"])}}（预期${{esc(o["预期玩家数"])}}）`;
  return `<details class="match"><summary><b>#${{o["场次序号"]}}</b><span>${{esc(o["时间"])}}</span><span class="${{cls}}">${{esc(o["结果"])}}</span><span>${{esc(o["比分"])}}</span><span>${{esc(o["地图"])}} · ${{esc(o["目标英雄"])}} · ${{esc(o["目标K/D/A"])}}</span><span class="${{pcls}}">${{esc(o["组队判定"])}}${{o["组队成员"]?" · "+esc(o["组队成员"]):""}}${{rosterNote}}</span></summary><div class="match-body">${{o["阵容说明"]?`<div class="notice">${{esc(o["阵容说明"])}}</div><br>`:""}}<div class="teams">${{playerTable(m.players,m.targetTeamId,m.targetTeamId)}}${{[...new Set(m.players.map(p=>p.teamId))].filter(t=>t!==m.targetTeamId).map(t=>playerTable(m.players,t,m.targetTeamId)).join("")}}</div></div></details>`;
 }}).join("");
}}
for(const id of ["search","status","mode","date"])document.querySelector("#"+id).addEventListener("input",render);
render();
</script></body></html>"""
    template = (
        template.replace("{{", "{")
        .replace("}}", "}")
        .replace("{html.escape(target_name)}", html.escape(target_name))
        .replace(
            '{html.escape(str(summary.get("生成时间") or ""))}',
            html.escape(str(summary.get("生成时间") or "")),
        )
        .replace("{embedded}", embedded)
        .replace(
            "{json.dumps(server.AGENTS, ensure_ascii=False)}",
            json.dumps(server.AGENTS, ensure_ascii=False),
        )
    )
    path.write_text(template, encoding="utf-8")


def write_readme(
    path: Path,
    target_name: str,
    summary: dict[str, Any],
    partners: list[dict[str, Any]],
) -> None:
    lines = [
        f"# {target_name} · 逐场玩家与组队分析",
        "",
        f"- 总场次：{summary['总场次']}",
        f"- 时间范围：{summary['最早时间']} ～ {summary['最近时间']}",
        f"- 完整解析每场全部玩家：{summary['完整阵容场次']}",
        f"- 确定组队：{summary['确定组队场次']}",
        f"- 确定单排：{summary['确定单排场次']}",
        f"- 阵容不完整：{summary['阵容不完整场次']}",
        f"- 确认组过队的不同玩家：{summary['确认组队对象数']}",
        "",
        "## 判定方法",
        "",
        "1. `GetMatchup` 获取每场双方 10 人的 subject、阵营和英雄。",
        "2. 按同一 `matchId` 对齐每名玩家自己的 `GetBattleList` 记录。",
        "3. 同一场、同一阵营且 `partyId` 与目标玩家相同，判为确定组队。",
        "4. 双方 10 人记录均解析、但无人和目标 `partyId` 相同，判为确定单排。",
        "5. 任一必要记录缺失时标记为无法完整判断，不推断为单排。",
        "6. 如果 WeGame 返回的人数少于该模式通常人数，会单独标记阵容不完整；已经匹配到相同 partyId 的组队证据仍然有效。",
        "",
        "## 确认组队对象（按共同场次排序）",
        "",
        "| 昵称 | 共同场次 | 胜率 | 会话数 | 最长连续 | 首次 | 最近 |",
        "|---|---:|---:|---:|---:|---|---|",
    ]
    lines.extend(
        f"| {item['昵称']} | {item['共同组队场次']} | "
        f"{float(item['共同胜率']):.1%} | {item['共同组队会话数']} | "
        f"{item['最长单次连续场数']} | {item['首次组队']} | {item['最近组队']} |"
        for item in partners
    )
    lines.extend(
        [
            "",
            "## 文件",
            "",
            "- `逐场玩家与组队分析.html`：推荐入口，可搜索、筛选并展开每场双方玩家。",
            "- `*.xlsx`（如另行生成）：多工作表筛选与统计。",
            "- `逐场概览.csv`：每场一行，包含双方昵称和组队结论。",
            "- `逐场玩家明细.csv`：每名玩家一行，包含阵营、英雄、K/D/A、partyId。",
            "- `组队对象汇总.csv`：和目标确定组过队的玩家汇总。",
            "- `组队会话.csv`：按目标 partyId 归并的连续会话。",
            "- `分析数据.json`：网页与 Excel 使用的结构化分析结果。",
            "- `原始记录/`：原始 328 场摘要与逐场补采结果，便于复核。",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="生成逐场玩家与组队分析报告")
    parser.add_argument("--raw-matches", type=Path, required=True)
    parser.add_argument("--rosters", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--target-name", required=True)
    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="只分析按时间倒序排列的最近 N 场；0 表示全部",
    )
    parser.add_argument("--allow-partial", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    raw_matches = json.loads(args.raw_matches.read_text(encoding="utf-8"))
    if args.limit > 0 and isinstance(raw_matches, list):
        raw_matches = raw_matches[: args.limit]
    roster_state = json.loads(args.rosters.read_text(encoding="utf-8"))
    roster_matches = roster_state.get("matches") if isinstance(roster_state, dict) else None
    if not isinstance(raw_matches, list) or not isinstance(roster_matches, list):
        raise SystemExit("原始对局或阵容断点格式不正确")
    completed = int((roster_state.get("metadata") or {}).get("completedMatches") or 0)
    if completed < len(raw_matches) and not args.allow_partial:
        raise SystemExit(f"阵容补采尚未完成：{completed}/{len(raw_matches)}")

    output_dir = args.output_dir.resolve()
    if output_dir.exists() and not args.overwrite:
        raise SystemExit(f"输出目录已存在，为避免覆盖已停止：{output_dir}")
    output_dir.mkdir(parents=True, exist_ok=args.overwrite)

    overviews, player_rows, detailed = build_match_rows(raw_matches, roster_matches)
    partners = build_partner_summary(detailed)
    sessions = build_sessions(detailed)
    daily = build_daily(overviews)
    statuses = Counter(str(item.get("组队判定") or "") for item in overviews)
    complete_rosters = sum(
        1 for item in overviews if item.get("阵容完整性") == "完整"
    )
    summary = {
        "目标玩家": args.target_name,
        "总场次": len(overviews),
        "最早时间": overviews[-1]["时间"] if overviews else "",
        "最近时间": overviews[0]["时间"] if overviews else "",
        "完整阵容场次": complete_rosters,
        "确定组队场次": statuses["确定组队"],
        "确定单排场次": statuses["确定单排"],
        "无法判断组队场次": statuses["无法完整判断"],
        "阵容不完整场次": len(overviews) - complete_rosters,
        "确认组队对象数": len(partners),
        "组队会话数": sum(
            1 for item in sessions if item.get("组队判定") == "确定组队"
        ),
        "单排会话数": sum(
            1 for item in sessions if item.get("组队判定") == "确定单排"
        ),
        "生成时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    analysis = {
        "summary": summary,
        "partners": partners,
        "sessions": sessions,
        "daily": daily,
        "matchOverviews": overviews,
        "playerRows": player_rows,
        "matches": detailed,
    }
    write_json(output_dir / "分析数据.json", analysis)
    write_csv(output_dir / "逐场概览.csv", overviews)
    write_csv(output_dir / "逐场玩家明细.csv", player_rows)
    write_csv(output_dir / "组队对象汇总.csv", partners)
    write_csv(output_dir / "组队会话.csv", sessions)
    write_csv(output_dir / "每日统计.csv", daily)
    html_report(
        output_dir / "逐场玩家与组队分析.html",
        args.target_name,
        summary,
        partners,
        sessions,
        detailed,
    )
    write_readme(output_dir / "说明.md", args.target_name, summary, partners)

    raw_dir = output_dir / "原始记录"
    raw_dir.mkdir(exist_ok=args.overwrite)
    write_json(raw_dir / "matches.raw.json", raw_matches)
    shutil.copy2(args.rosters, raw_dir / "match-rosters.json")
    write_json(raw_dir / "采集与判定元数据.json", roster_state.get("metadata") or {})
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(output_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
