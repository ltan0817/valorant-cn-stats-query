from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import wgame_query_server as app


STATE_PATH = app.DATA_DIR / "alias-watch-state.json"


def load_seen() -> set[str]:
    try:
        data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return set()
    if isinstance(data, list):
        return {str(item) for item in data}
    return set()


def save_seen(seen: set[str]) -> None:
    app.DATA_DIR.mkdir(parents=True, exist_ok=True)
    STATE_PATH.write_text(
        json.dumps(sorted(seen), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def row_key(row: dict[str, Any]) -> str:
    return f"{row.get('subject')}:{app.normalize_name(str(row.get('name') or ''))}"


def main() -> None:
    parser = argparse.ArgumentParser(description="Watch captured friend alias lookups and build battle pages.")
    parser.add_argument("--interval", type=float, default=2.0)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--rebuild", action="store_true")
    args = parser.parse_args()

    app.init_db()
    seen = set() if args.rebuild else load_seen()
    print("Watching alias captures. Keep Proxifier capture running, then add a friend in the game client.", flush=True)
    while True:
        changed = False
        for row in app.scan_alias_captures():
            key = row_key(row)
            if key in seen:
                continue
            try:
                result = app.build_player_page(row["name"], row["subject"], row["source"])
                printable = {
                    "name": result["name"],
                    "subject": result["subject"],
                    "battle_count": result["battle_count"],
                    "page": str(Path(result["page"])),
                    "url": "http://127.0.0.1:8787" + result["href"],
                }
            except Exception as exc:
                printable = {
                    "name": row.get("name"),
                    "subject": row.get("subject"),
                    "error": f"{type(exc).__name__}: {exc}",
                }
            print(json.dumps(printable, ensure_ascii=False), flush=True)
            seen.add(key)
            changed = True
        if changed:
            save_seen(seen)
        if args.once:
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
