@echo off
cd /d "%~dp0"
python watch-friend-aliases.py
