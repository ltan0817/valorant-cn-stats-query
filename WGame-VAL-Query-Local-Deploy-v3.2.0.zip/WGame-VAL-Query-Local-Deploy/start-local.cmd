@echo off
chcp 65001 >nul
cd /d "%~dp0code"
start "WGame VAL Query" python wgame_query_server.py --port 8787
timeout /t 2 /nobreak >nul
start "WGame Login Chrome" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%CD%\auto-login-chrome.ps1" -ProjectDir "%CD%"
timeout /t 2 /nobreak >nul
start "WGame Control Center" "%~dp0start-control-center.cmd"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8787/public"
echo.
echo 本地查询页: http://127.0.0.1:8787/public
echo 本地实时页: http://127.0.0.1:8787/live
echo 控制中心: http://127.0.0.1:8788/
echo.
echo 需要本机当前对局时: 安装 mitmproxy + Proxifier 后运行 code\start-proxifier-capture.ps1
echo.
pause
