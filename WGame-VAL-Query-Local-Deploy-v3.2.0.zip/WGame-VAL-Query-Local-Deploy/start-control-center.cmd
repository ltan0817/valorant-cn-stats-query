@echo off
chcp 65001 >nul
cd /d "%~dp0code"
set "PYTHONW=%LocalAppData%\Programs\Python\Python39\pythonw.exe"
if exist "%PYTHONW%" goto launch
for /f "delims=" %%P in ('where pythonw.exe 2^>nul') do set "PYTHONW=%%P"
if exist "%PYTHONW%" goto launch
echo 未找到 pythonw.exe，改用当前窗口启动控制中心。
python -B ops_control_center.py --port 8788 --open-browser
exit /b %errorlevel%

:launch
start "" "%PYTHONW%" -B ops_control_center.py --port 8788 --open-browser
exit /b 0
