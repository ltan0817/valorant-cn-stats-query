# WGame VAL Query 本地部署版 v3.2.0

这是一个只在本机运行的源码交付包。默认服务只监听 `127.0.0.1`，不连接项目
维护者的域名、远程服务器或 token 中继。包含主查询服务、控制中心和离线分析
工具，并提供面向开发者的接口与数据接入文档。

## 快速开始

1. Windows 10/11 安装 Python 3.10+ 与 Google Chrome。
2. 双击 `install-dependencies.cmd` 安装 Python 依赖。
3. 双击 `start-local.cmd`：自动启动主查询服务、专用 Chrome 与本机控制中心。
4. 在自动打开的专用 Chrome 中登录 WeGame。

本机入口：

- 战绩查询：`http://127.0.0.1:8787/public`
- 实时对局：`http://127.0.0.1:8787/live`
- 控制中心：`http://127.0.0.1:8788/`

需要本机当前对局时，再运行 `code/start-proxifier-capture.ps1`（需先安装
mitmproxy 与 Proxifier，配置模板见 `config-examples/`）。

查询输入格式为完整的 `昵称#数字ID`。公开查询只加载排位数据。

## 可选：读取自己的当前对局

此功能需要 mitmproxy 10+ 和 Proxifier，并会读取本机游戏网络流量。请先完整阅读
`docs/INSTALL.md`、`docs/CONFIG.md` 与 `docs/SECURITY.md`，确认风险后再运行
`code/start-proxifier-capture.ps1`。结束时运行 `code/stop-proxifier-capture.ps1`
恢复直连配置。Proxifier 配置模板见 `config-examples/`。

## 文档

- `docs/INSTALL.md`：安装与启动
- `docs/CONFIG.md`：配置文件、环境变量与需要修改的地方
- `docs/ARCHITECTURE.md`：本地实现流程与组件
- `docs/API.md`：本地接口、参数、返回字段与调用示例
- `docs/DEV_GUIDE.md`：面向开发者/AI 的数据接入指南
- `docs/TOOLS.md`：离线批量采集与组队分析工具
- `docs/NETBAR_PUSH.md`：远程推送工具（网吧/队友端）脱敏版说明
- `docs/DEBUGGING.md`：常见故障与检查命令
- `docs/SECURITY.md`：数据、网络与发布边界

## 隐私

运行后产生的 `code/data/`、`code/captures/`、`code/pages/` 以及 Chrome profile
可能包含登录态、玩家标识或网络请求记录。不要上传、分享或提交这些目录。

本项目是非官方社区工具，与游戏运营方无隶属或授权关系。
